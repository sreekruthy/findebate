## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning. I would like to welcome everyone to Kennametal's First Quarter Fiscal 2022 Earnings Conference Call. [Operator Instructions] I would now like to turn the conference over to Kelly Boyer, Vice President of Investor Relations.

**Investor Relations**
: Thank you, operator. Welcome, everyone, and thank you for joining us to review Kennametal's first quarter fiscal 2022 results. Yesterday evening, we issued our earnings press release and posted our presentation slides on our website. We will be referring to that slide deck throughout today's call. I'm Kelly Boyer, Vice President of Investor Relations. Joining me on the call today are Chris Rossi, President and Chief Executive Officer; and Damon Audia, Vice President and Chief Financial Officer. After Chris and Damon's prepared remarks, we will open the line for questions. At this time, I would like to direct your attention to our forward-looking disclosure statement. Today's discussion contains comments that constitute forward-looking statements. And as such, involve a number of assumptions, risks and uncertainties that could cause the company's actual results, performance or achievements to differ materially from those expressed in or implied by such statements. Risk factors and uncertainties are detailed in Kennametal's SEC filings. In addition, we will be discussing non-GAAP financial measures on the call today. Reconciliations to GAAP financial measures that we believe are most directly comparable can be found at the back of the slide deck and on our Form 8-K on our website. And with that, I'll now turn the call over to Chris.

**CEO**
: Good morning, and thank you for joining us today. I'll start today's call with some general comments on our strong results this quarter and some recent strategic wins as well as our expectations for Q2 and the full year. Damon will then go over the quarterly financial results and the outlook in more detail, and finally, I'll make some summary comments before opening the call for questions. Beginning on slide two of the presentation deck. We posted strong results this quarter by successfully executing our commercial and operational excellence initiatives as underlying demand continued to improve. Our sales performance was in line with our expectations, increasing 19% organically year-over-year and outpacing our normal quarter-over-quarter seasonal trend. Year-over-year, we experienced growth in all regions and end markets due to our strategic initiatives and improvement in underlying demand. Within our end markets, the strongest performance was in general engineering, energy and aerospace, with aero returning to growth this quarter after eight quarters of decline. Transportation increased as well with 14% growth year-over-year and outpaced the normal sequential decline. That said, increasing production cuts due to chip shortages and other supply chain challenges limited transportation customer demand in the quarter. Our strong operating leverage resulted in adjusted EBITDA margin improving significantly by 730 basis points to 18.6%, demonstrating the benefits of the investments we have made over the last few years. Operating expense as a percentage of sales decreased year-over-year to 21% and sequentially was flat on lower sales. Our target for operating expense remains at 20%. Adjusted EPS improved significantly to $0.44 compared to $0.03 in the prior year quarter. Free cash flow was approximately breakeven, which is significantly better than our typical Q1 use of cash. As a reminder, cash flow in the first quarter of the fiscal year is affected by the payment of performance-based compensation. We also began our recently announced share repurchase program, buying back $13 million of shares in the quarter, reflecting the high level of confidence we have in our growth and margin improvement initiatives and free cash flow generation. Looking ahead, we believe the underlying market demand is strong. However, some customers' production levels in the near-term are being affected to varying degrees by supply chain bottlenecks and other uncertainties. For example, there's not yet been a notable improvement in the supply of semiconductor chips, which affects the metal cutting operations of our transportation and associated general engineering customers. And although we do not expect the situation to get worse, we believe it is likely to continue to constrain customer production levels in Q2. However, public comments for auto companies suggest the situation may start to improve in the second half of fiscal year 2022. So, we expect revenue growth in transportation and associated general engineering to improve when our customers are able to increase production to meet the pent-up demand. Another source of uncertainty is related to potential power disruptions in certain regions like China, where they are rationing power to varying degrees in some provinces, which could affect customer production levels. Thus far, we've not seen a material effect on customer demand, but it is a source of uncertainty going forward. Nevertheless, despite the production slowdowns related to the chip shortages and other uncertainties, we expect Q2 sales to be up 9% to 14% year-over-year and in line with the normal sequential growth pattern of 1% to 2%, which highlights the relative strength of our other end markets outside of transportation. Now, as it relates to our own operations, inflation, supply chain bottlenecks and other uncertainties are presenting some challenges, but we believe to a far lesser extent than some of our customers and other manufacturers. We're benefiting from our in-region/for-region local supply chain setup and inventory planning geared toward increasing on-time performance and availability levels. And our proactive pricing approach, we believe, will continue to be effective in dealing with inflationary pressures. So, as always, we'll continue to focus on what we can control. And despite the existing market and supply chain uncertainties, we remain confident in driving strong underlying operating leverage for the full year. Now, let's turn to slide three for an update on our commercial excellence initiatives aimed at gaining share. We've always had world-class application engineering expertise and product innovation, and we continue to leverage these core strengths to win with customers. In addition, the investments we've made over the last few years have improved quality and delivery performance, resulting in higher levels of customer service. As you can see from the slide, our commercial excellence initiatives continue to deliver. Through our innovation and leadership in machining electric vehicle components, we continue to win business with auto manufacturers as they add more hybrid and electric vehicles to their product portfolios. Our focus on channel access and fit-for-purpose video brand tooling, we have seen success in displacing competitors at aero tier suppliers in Asia Pacific. We continue to deliver innovative solutions for machining components and renewable energy equipment like wind turbines, where we provided a new drilling solution, improving productivity by 200% and extending tool life by 700%. Finally, we continue to drive share gains through our focus on expanding our wear-resistant solutions to mining adjacencies like surface mine. So, collectively, our product innovations and commercial and operational excellence are a winning value proposition, driving share gains and strong operating leverage. And with that, I'll turn the call over to Damon, who will review the first quarter financial performance in more detail.

**CFO**
: Thank you, Chris, and good morning, everyone. I will begin on slide four with a review of Q1 operating results on both the reported and adjusted basis. As Chris mentioned, we leverage our modernizes footprint to drive strong results this quarter. Sales increased by 21% year-over-year and 19% on an organic basis with foreign currency contributing 2%. On a sequential basis, sales declined only 6%, which is less than our normal Q4 to Q1 seasonal decline. Adjusted gross profit margin increased 650 basis points to 33.5%. Adjusted operating expense as a percentage of sales decreased 210 basis points year-over-year to 21.2%, approaching our target of 20%. Adjusted EBITDA and operating margins were up significantly by 730 and 870 basis points, respectively. The strong year-over-year margin performance was due to significantly higher volume and associated absorption as well as strong manufacturing performance, including some simplification/modernization carryover benefits. Price and mix were also positive contributors. These factors were partially offset by the removal of $15 million of temporary cost control actions taken in the prior year and a slight headwind from higher raw material costs beginning to flow through the P&L. The adjusted effective tax rate in the quarter of 26.9% was lower year-over-year, primarily as a result of higher pre-tax income. We reported GAAP earnings per share of $0.43 versus an earnings per share loss of $0.26 in the prior year period. On an adjusted basis, EPS was $0.44 per share versus $0.03 in the prior year. The main drivers of our improved adjusted EPS performance are highlighted on the bridge on slide five. The effect of operations this quarter were $0.33, which included approximately $0.04 of simplification/modernization carryover benefits and the negative effect of approximately $0.12 from temporary cost control actions taken last year. The factors contributing to a substantial improvement are the same as the drivers of our strong margin performance this quarter that I just reviewed. Taxes and currency contributed $0.04 and $0.02, respectively. Slide six and seven detail the performance of our segments this quarter. Metal Cutting sales in the first quarter increased 19% organically year-over-year compared to a 23% decline in the prior year period. A foreign currency benefit of 2% was partially offset by fewer business days, which amounted to 1%. All regions posted year-over-year sales growth with the Americas leading at 22%, followed by EMEA at 21%. Asia Pacific posted more modest growth at 7%, reflective of the timing of the economic recovery from the pandemic, reduced government subsidies for wind energy year-over-year as well as lower industrial activity, mainly in transportation. Year-over-year, all end markets also posted gains this quarter with general engineering, leading with strong growth of 23%. Aerospace grew 19% year-over-year and transportation, 14%. Energy grew 1% year-over-year. Adjusted operating margin increased substantially to 10.2%, a 920 basis point increase over the prior year quarter. The increase was driven by higher volume, mix, favorable pricing versus raw material increases and manufacturing performance, including benefits from simplification/modernization carryover. These were partially offset by temporary cost control actions taken in the prior year. Turning to slide seven for Infrastructure. Organic sales increased by 19% year-over-year compared to a decline of 18% in the prior year period. A foreign currency benefit of 3% was partially offset by fewer business days of 1%. Again, all regions were positive year-over-year, with the Americas leading at 28%, EMEA at 8% and Asia Pacific at 7%. The strength in the Americas was driven mainly by the improvement in the U.S. oil and gas market as seen in the continued increase in the U.S. land only rig count. By end market, energy was up 37% year-over-year and general engineering was up 23%. Earthworks was also up 3%, but down sequentially, reflecting the typical seasonal decline we experienced in Q1 related to the traditional road construction season. Adjusted operating margin improved by 760 basis points year-over-year to 14.1%. This increase was driven by higher volume, favorable pricing exceeding raw material increases and manufacturing performance, including some simplification/modernization carryover benefits, partially offset by temporary cost control actions taken last year. Now, turning to slide eight to review our balance sheet and free operating cash flow. We continue to maintain a strong liquidity position, healthy balance sheet and debt maturity profile. At quarter end, we had combined cash and revolver availability of $807 million and we're well within our financial covenants. Primary working capital decreased year-over-year to $608 million and was effectively flat on a sequential basis. On a percentage of sales basis, primary working capital was 32.1%, a decrease both year-over-year and sequentially. Net capital expenditures were $17 million, a decrease of approximately $22 million from the prior year. We continue to expect fiscal year '22 capital expenditures to be in the range of $110 million to $130 million. Our first quarter free operating cash flow was negative $2 million, an improvement of $27 million from the prior year quarter, reflecting the strong sales and operating performance this quarter. We also paid the dividend of $17 million in the quarter. And finally, as Chris noted, we repurchased $13 million of shares during the quarter under our recently announced repurchase program. The full balance sheet can be found on slide 14 in the appendix. Now, let's turn to slide nine to review the outlook in more detail. Starting with the second quarter, we currently expect sales to be up approximately 9% to 14% year-over-year and in the range of $480 million to $500 million. As Chris mentioned, this implies sequential growth in line with our normal seasonality of around 1% to 2%, reflecting the challenges in the transportation end market and continued uncertainty in the general macro environment, offsetting strength in aerospace, energy and general engineering. At the midpoint, we've assumed transportation sales to be approximately flat sequentially, given the continued production challenges our customers are dealing with due to the chip shortage. Additionally, we do not expect disruptions due to supply chain or energy issues to worsen. Lastly, given that we believe customers will continue to maintain their cautious behavior, we aren't forecasting meaningful restocking. Adjusted operating income is expected to be a minimum of $46 million, implying continued strong operating leverage year-over-year, excluding $10 million of temporary cost actions taken last year. Sequentially, higher raw material costs will begin to flow through the P&L as expected. When coupled with the timing of annual merit increases and incremental D&A, the sequential increase in costs will be approximately $10 million. Lastly, for Q2, we expect the adjusted effective tax rate to remain in the range of 25% to 28% and free operating cash flow to be positive. Turning to slide 10 regarding the full year. We believe the recovery is still underway, but the uncertainties we discuss make the pace and trajectory difficult to forecast. That said, we expect sales in the second half to exceed normal sequential patterns, assuming that transportation starts to recover in Q3 and other market uncertainties do not worsen. On that basis, as Chris mentioned, we expect year-over-year growth and strong operating leverage on an annual basis, excluding temporary cost control headwinds from the prior year. In terms of the sequential cadence, we continue to expect operating leverage to be more favorable in the first half due to the timing of strong net price versus raw material benefits and simplification/modernization carryover benefits. On a year-over-year basis, the second half will be affected by the above normal leverage we saw in the fourth quarter last year due to net price versus raw material benefits. The second half will also be affected by other inflationary pressures. Nevertheless, we remain committed to driving strong operating leverage for the full year. The above average leverage in the first half and these effects in the second half serve as a reminder of the unevenness that can occur in year-over-year operating leverage comparisons from quarter-to-quarter. This is why, as we've discussed, looking at leverage over a longer time frame, such as the full year, is more representative of the underlying performance of the business. Moving on to other variables, they are essentially unchanged from last quarter. This includes depreciation and amortization increasing $15 million to $20 million year-over-year to a range of $140 million to $145 million, capital expenditures to be in the range of $110 million to $130 million and working capital to trend toward our 30% goal by fiscal year-end. Together, over the full year, these assumptions translate to free operating cash flow generation at approximately 100% of adjusted net income, in line with our long-term target, further demonstrating our progress transforming the company. And with that, I'll turn the call back over to Chris.

**CEO**
: Thanks, Damon. Turning to slide 11. Let me take a few minutes to summarize. We posted an excellent quarter and is demonstrated by our strong operating leverage, simplification/modernization investments are contributing to improved financial performance. Furthermore, our product innovations and commercial and operational excellence initiatives have well positioned us to drive share gain and improve margins as markets continue to recover. And although supply chain bottlenecks and other uncertainties are limiting visibility, we currently expect to exceed normal sequential quarterly growth patterns in the second half of fiscal year 2022 and are confident in driving strong full year operating leverage. Strength of our balance sheet and free operating cash flow gives us the flexibility to both continue investing in our strategic initiatives and optimize capital allocation. And I remain fully confident we will meet our adjusted EBITDA profitability target of 24% to 26% when sales reached the range of $2.5 billion to $2.6 billion. And with that, operator, please open the line for questions.

### Q&A
**Operator**
: Thank you.[Operator Instructions] Our first question comes from Steve Volkmann from Jefferies. Please go ahead.

**Analyst-1**
: Hey, Good morning everybody. Thank for taking the question. Maybe, Damon, I'd just pick up on sort of some of the last things you were saying, and I'll take you up on your offer to look at leverage on a longer term basis. Can you say what you think the full year 2022 sort of bookends would be for how we should think about that leverage? And then maybe even as we kind of normalize into 2023, what's the right way to think about that?

**CFO**
: So, I think, Steve, for us, when we think about the underlying operating leverage, what we've been talking about for the last several quarters is sort of the 40% standard margin plus some of this incremental absorption that we've been picking up given the level of utilization of our fact, the reason I think you guys and we've agreed that directionally, we've -- that's around 50% is sort of what we would expect for the full year. Operationally, as what you're seeing here when you look at the first quarter and you adjust for the temporary cost actions, obviously, we levered better than that in the first quarter. We would expect to have strong leverage here in the second quarter as well. And then it's some of the timing of the raw material benefits. And you look at it year-over-year start to come into effect in the back half of the year. That's going to bring our average down to around 50% for the full year. And then I think if you look longer, what Chris and I have been talking about is given the strength of our footprint with the simplification and modernization efforts, we would expect, again, on average, through the cycle, to do it around 50% for the longer term. But again, that can fluctuate in any given quarter based on some of these timing of pricing actions versus raw materials or other things that can sort of influence one particular quarter.

**Analyst-1**
: And then the quick follow-up, just on the Opex target at 20%, what has to happen to get there? Is that just basically kind of try to hold the lid on that and grow revenue or is there something that you can do there to actually lower the denominator?

**CFO**
: I think, Steve, it's really going to be more holding that number, trying to keep costs under control and relatively flat here as the merits flow into it into Q2, but really more of revenue growing and operating expenses not growing in kind with the revenue growth.

**Analyst-1**
: Understood. Thank you guys.

**Operator**
: The next question comes from Ann Duignan from JPMorgan. Please go ahead.

**Analyst-2**
: If I could just ask a quick follow-up on the last question, it wasn't really clear to me. If you look at your operating leverage in fiscal Q1, can you just tell us what operating leverage you're calculating in the quarter? Just want to understand what you're taking out of the denominator. Thank you.

**CFO**
: So, Ann, we really don't -- we don't calculate the leverage. We sort of give you guys the tools to do that. But what we have said is when you look at the change in sales versus the change in EBIT or change in operating income, that is sort of what we would term the leverage here. Again, this quarter, you have to go back and you have to add back the $15 million of temporary cost actions that were in effect last year because of the pay reductions that we had in place. And what we've said is from a sales perspective, we wouldn't ever expect to be able to leverage on those costs that were artificially lower last year. So, when you look at the change in sales versus the change in operating income, adjusting for that $15 million, you see a very strong operating leverage in the quarter, well north of this 50% that we've been talking about as sort of that rule of thumb for the cycle for us, and that's partly or heavily influenced by the timing of the pricing actions that our teams put in place before the raw material costs have really started to flow into our cost of goods sold here in Q1, also some of the carryover simplification/modernization benefits that we saw in the Q1, and those will sort of reduce themselves as we move through the year here in FY 2022.

**Analyst-2**
: I just wanted to make sure we were adding back the right numbers to last year. Then on a more fundamental basis, can you talk about how much your earthworks business was down in China, specifically, you called out Asia, down 14% quarter-over-quarter, but how much was China down?

**CFO**
: I think, Ann, we don't give specifics by end market by country. What I would tell you, I think as you -- China, as a total for us last year was around 13% of revenue, and that's both Metal Cutting and Infrastructure. But we don't go into specifics by country, by end market.

**CEO**
: And I would just add to that, in China, there was a series of mine inspections that occurred. And I think that lowered the number beyond what we typically would see. So, that's not going to repeat in Q1, we expect it to recover.

**Analyst-2**
: And then just real pick along the same lines. Any big differences in end market demand in EMEA between one segment was up 21% and the other was up 8%. Just any big differences there or just timing and different comps.

**CEO**
: Yes, I think it's just timing and different comps.

**Analyst-2**
: Ok, Thank you. I'll leave it there.

**CEO**
: Thank you Ann.

**Operator**
: Our next question comes from Julian Mitchell from Barclays. Please go ahead.

**Analyst-3**
: Hi, Good morning. Just wanted to explore a little bit perhaps the margin difference between Metal Cutting and Infrastructure. Infrastructure has come back close to prior peak margins already now for a couple of quarters so very, very good performance there. Metal Cutting, obviously, still lagging quite a bit versus prior peaks. So maybe help us understand how quickly it can get back there and overtake the infrastructure margins? And what are the one or two main drivers? Is it really just about mix as you see transport and aero coming back that should automatically give you kind of super normal leverage and push the Metal Cutting margins back to that mid-high teens prior peak.

**CEO**
: Let me just -- I guess, to give you the punchline, we still expect, like we talked about on the last call that the Metal Cutting margins will overtake Infrastructure by the end of the fiscal year, Julian. And then just in the way of background, both segments, of course, are seeing margin improvement. But keep in mind with Infrastructure, they have a higher material content and that leads to greater sensitivity to this price raw timing. And as Damon said, that's quite favorable in Q1 and certainly in the first half. So, that's driving part of the difference for sure. Then on Metal Cutting margins, they have a higher labor content and also a higher sales expense. So that leads to much greater sensitivity to volume and the related absorption. So, as we drive more volume through the Metal Cutting factories and leveraging that sales force, that's going to help drive the higher margins. I like what you said about super-duper margins and these other areas and so we're certainly focused on growing those. But it will happen naturally just by bringing more volume through.

**Analyst-3**
: And maybe just following up, you mentioned the price cost or material headwinds perhaps in Infrastructure that could build over the balance of the year. So I just wanted to ask two things on that point. One is what's the type of price realization you're seeing right now in your organic revenue line, just sort of order of magnitude would be helpful. And then on a net basis, should we think about price versus cost for Kennametal firmwide being a headwind in the second half of the fiscal year or it's just kind of more neutral at that point?

**CEO**
: I think just basically on pricing, as you know, you studied this industry for a while. We've had a lot of success in being able to offset, in this case, we're talking about material costs with price, and we expect that trend to be able to continue. And I think what Damon was saying is that there's higher level of favorability in the first half of the year, price versus raw versus the second half of the year. But over the course of the full year, we still expect to be neutral to maybe even have some upside to cover other inflationary costs. That's kind of how we see it. Then in terms of the realization of pricing, as I said, we've had success in the industry to bring forward price increases. So, it's never 100%, Julian. There's always some exceptions, but it's in the very high 90s, I would say, in terms of our effectiveness.

**Analyst-3**
: And Chris, any sort of color on within the organic sales growth right now in the first half of the fiscal year, kind of any split of price in battle price versus volume?

**CEO**
: I think price is a driver there. But the underlying volume, I think, is the bigger driver for sure, Julian.

**Analyst-3**
: Great, Thank you.

**Operator**
: The next question comes from Steven Fisher from UBS. Please go ahead.

**Analyst-4**
: Thanks. Good morning, Just looking at the energy business in both Metal cutting and Infrastructure. I'm just curious why the growth rates are so different between those two segments with 37% in Infrastructure and kind of low single-digits in Metal Cutting. It seems like maybe China could be a difference. But I think, Chris, you said you weren't seeing any changes in demand there yet. So, just curious if there's anything in particular going on in those two segments in the -- for the energy business.

**CEO**
: I think the thing to keep in mind, energy for Metal Cutting is -- has a high percentage associated with components for wind turbines. So, technically, that's a piece of equipment that operates in the energy market, so we classify it as energy versus, as you correctly pointed out, Infrastructure is more driven by oil and gas, and there's been a large uptick in that, so that's the difference. And as we talked about, I think, last quarter's call, the wind subsidies in China had been not renewed in that country and so we saw a decline in the components business for wind turbines. Now, still a very good business and still has a long-term growth trend, but in terms of pulling the subsidies, you saw the sort of dis-adjustment. So, that's the main difference.

**CFO**
: And Steve, those subsidies ended in December, so you're going to see a couple of quarters of year-over-year decline comparing that to the -- for those -- that particular part of the business in Metal Cutting energy.

**Analyst-4**
: And then just a follow-up, more of a strategic question. I know you guys have focused on gaining market share. So, I'm curious how much of the key to your competitiveness is focused on how you go-to-market versus with what products you're actually going to market with sort of quality of product or offering versus distribution channels and your approach to the sales effort?

**CEO**
: Well, if you remember, Steve, for Metal Cutting, as an example, we are repositioning the Widia brand to serve the fit-for-purpose application segment. And that application segment goes across all sort of end markets. And part of that was to do some channel expansion and reengineering and so we've realigned them. And each REIT in the world is a little bit different. So, that is part of it. And then the other piece of it is that the Widia product portfolio which was sort of competing and was in the same space as the Kennametal portfolio, we are adjusting that through a value engineering value analysis effort to make sure that it's got the right value proposition at the right price and profitability for us. And so that's the other big piece is leveraging that channel to bring this other portfolio to both our existing customers as well as new customers that will be served through this channel. So, there's a little bit of both going on some channel work and then also this product portfolio repositioning, if you will.

**Analyst-4**
: Got it. Thanks a lot.

**Operator**
: The next question comes from Dillon Cumming from Morgan Stanley. Please go ahead.

**Analyst-5**
: Great, Good morning guys. Thanks for taking the question. If I could just start asking about kind of the top line guidance. I mean, it feels like demand across your end markets would appear to kind of support performance above normal seasonality for next quarter. I mean, you can correct me if I'm wrong, but I don't think transportation is normally a huge sequential tailwind for you guys kind of quarter-over-quarter. And I guess -- and that's even in a normal year. So, I mean, do you feel like is it more supply chain constraints at kind of the customer level outside of transportation that might be driving the more normal potential pattern versus a level of outperformance versus normal seasonality or kind of is there something else to keeping in mind there that's actually constraining growth a bit.

**CEO**
: I think it's really, I know you did your math on transportation, but it's really -- the transportation was, what I would say, even at their normal levels, we wouldn't be having this conversation because, to your point, the other markets, end markets seem to be strong. And -- but the transportation chip issue is basically slowing that market down. But without that, we -- Q2, I think would be more in line with what your -- the prior expectations were in terms of consensus. So that's really the driver. We talked -- there's a little bit of a potential slowdown in China. There's some power uncertainties and those type of things. But frankly, from what's changed for the last time we talked to you guys was we now have a better feel of what the impact of the chip issue is having on transportation as it relates to our business. So, it's really -- to me, it's about that. And that's the big uncertainty. Our current feeling is that based on what the automakers are saying publicly anyway, that, that situation should start to improve in Q3 and Q4. And so we look for transportation to come back accordingly. That's the big driver, though.

**Analyst-5**
: And then maybe just to wrap it up, you're obviously not embedding any kind of level of restocking activity in your forecast. I mean, that's a huge surprise. But just given that inventories are so low kind of across the initial complex, your own production capacity seems to be a bit more isolated from some of the supply chain pressures. Can you just talk a little bit about when you might expect a more meaningful restock and what the kind of appetite for that is at the customer level?

**CEO**
: I think, like we said, customers are being cautious in terms of the amount of stocking levels that they're carrying. And I think it's because they're looking at all these uncertainties and that's affecting their decision, but -- so we expect the restocking is still an opportunity that's ahead of us. And as Damon talked about, at least in Q2, we don't expect that to change significantly. Maybe it will start to improve in the later half of the year as another opportunity.

**Analyst-5**
: Got it. Thank you..

**Operator**
: The next question comes from Ross Gilardi from Bank of America. Please go ahead.

**Analyst-6**
: Hey, Good morning guys.

**CEO**
: Hey, Ross.

**Analyst-6**
: I just had a question on your share repurchase. You dipped the toe end a bit this quarter, and I'm just wondering your appetite to step that up with just your presumably improving seasonal free cash generation over the rest of the year.

**CFO**
: I think, Ross, for us, it's sort of an open market repurchase and what we said is we're going to be flexible based on cash flow generation and other uses of cash. I think as I said on the last call, at a minimum, our goal would be to try to offset the annual dilution that we deal with as a company with equity-based compensation and that could be somewhere in the range of -- given your 800,000 to maybe one million shares. So, we're going to be opportunistic. But I don't think we're going to -- we'll look at this based on free cash flow and sort of use that as our guide versus other uses of cash that we see here going forward.

**Analyst-6**
: And then obviously, you guys have addressed some of the price cost issues, how you're thinking about it. But could you talk a little bit more about tungsten and your key raw materials and what you're really seeing in those markets? And are you doing anything to -- and are there opportunities more to secure longer term supply given the cyclical recovery that you guys seem to anticipate for the next several years?

**CEO**
: So, APT is the biggest cost driver for us. It's definitely the biggest spend we have from a direct material perspective. And just to put it in perspective, Ross, I think in Q4, it was around -- and this is an index price of $2.70. And Q1 average was around $3.03 are just just slightly above. So there's no mechanism to buy that material in advance or hedge it or anything like that. So, it kind of is what it is, and we have to -- that's why we have to be strategic about our pricing and those type of things and also our inventory planning. The second spend would be cobalt, and it's quite a distant spend. And that has also seen some increases, but it's -- recently, it's stabilized. And then the third course would be steel, and that's a much smaller part of our overall spend. So, the big effect for us is on ATP. And you can see it in the numbers. That's why we talk about this unevenness in quarter-to-quarter operating leverage, that can be driven a lot by this price raw material because it's such a big part of our direct cost.

**CFO**
: And I think, Ross, you're well aware, again, we have affiliations with mines in Bolivia and so access to material is not really an issue for us. Again, the price, as Chris alluded to, is something we deal with, and we've been very effective in raising prices. But in addition to those affiliations with the mines, again, I think you're aware, we also have a very robust global recycling program that allows us to get access to material back to our factories. And then we do have some third-party contracts where we can buy a procure that, if necessary. So, I think from an availability standpoint, we're not overly concerned. And as Chris said, we've been diligent in addressing the pricing side of the house to address the inflation on the cost.

**Analyst-6**
: Got it. Thank you very much.

**Operator**
: The next question comes from Chris Dankert from Loop Capital. Please go ahead.

**Analyst-7**
: Hey, Good morning everyone. Why don't you guys were able to quantify for us, fit-for-purpose growth in the quarter, I guess, if you can break it out separately or maybe just the contribution to Metal Cutting growth, any detail you can give us on kind of the relative success there this quarter.

**CEO**
: Chris, it's something we're watching closely, because as I said, it's an important strategic initiative and it opens up basically a 40% part of the market that we weren't really serving before. So, we track it closely. It's still early stages, but we feel quite good about the traction that we're getting. And one of the ways that we sort of measure ourselves is, is it growing faster than the normal general engineering market by itself. And sequentially, that happened again this quarter. So, we're getting very good traction on it. It's on a trajectory. That's different than the gen end market, a steeper trajectory. So that gives us some confidence that we're growing share. And also because we measure the sales of that to existing customers where they weren't buying this type of tooling from us before, anecdotally, that tells us, again, that we're positioned in the right place. And then actually, we've had some places where we've now expanded our channel, for example, in China. And they were -- the companies were buying a local brand and they're not buying Widia. So, we feel like we're giving good traction. We're not breaking it out separately for sort of public disclosure. But when we have our next Investor Day, I think we'll be able to give a little more color on where we see that thing heading and how important it is to our overall growth strategy.

**Analyst-7**
: And then just more of a housekeeping question, I suppose. Thinking about incentive comp, can you just kind of remind us what the impact was on kind of the first quarter and kind of how that shifts into 2Q here?

**CFO**
: From a profit standpoint or from a cash flow standpoint, Chris?

**Analyst-7**
: Sorry, from an EBIT standpoint, yes.

**CFO**
: It was de minimis in Q1 from de minimis Q2 year-over-year or sequentially.

**CEO**
: You would have taken the -- the incentive comp would have been reserved in Q4 of last year.

**CFO**
: Yes, I mean, we're accruing it's what I'll call nor type target last year and target this year. So no real material change year-over-year in Q1 or expected for Q2.

**Analyst-7**
: Perfect. Thank you so much guys.

**Operator**
: Our next question comes from Steve Barger from KeyBanc Capital Markets. Please go ahead.

**Analyst-8**
: Hey, Thanks. Good morning.

**CEO**
: Good morning.

**Analyst-8**
: Can I just go back to raw material for a quick second. Are you modeling sequential raw material increases as you go through 3Q and 4Q similar to what you're seeing in 2Q, which will be a drag on gross margin and incrementals or are you going to be price cost-neutral in the back half, meaning gross margin grows from 1Q levels?

**CFO**
: So, we are -- so Steve, tungsten is, as Chris just said on one of the prior questions, tungsten has continued to increase here in the first quarter. I think, as you know, that generally takes around two quarters to lag into our P&L and so we will start to see these higher prices flow through here in the back half. What Chris has also said is, again, we're going to remain disciplined on our pricing actions and we'll do what we need to do to offset those, and we'll be at a minimum price versus raws neutral for the full year. And I think as Chris alluded to earlier, we might be a little bit ahead of that based on the speed at which we are putting on pricing actions in effect.

**Analyst-8**
: And I know getting pricing right is always hard, but just broadly speaking, through earnings season, we're seeing mid single-digit to low double-digit price increases across the industrial space. Are you driving more price from the value-added strategy you're putting in place or more from cost covering price increases? And just in general, why not be a little more aggressive on price given the environment?

**CEO**
: I think we're -- our pricing is very strategic and we always start with the value proposition. And so that's the basis on which we go in. And we also talk about cost, and that's a conversation that also kind of helps because, as you know, the environment is -- everyone's raising prices, right? But we start with our value proposition discussion. Some of these price increases we would have put in any way on that basis. But for example, in our fit-for-purpose segment, there -- those customers are looking more at value and so prices is as different point. And so there maybe the conversation is more around cost. And so it's a balancing act. But I think we're being -- I think we've got the right aggressiveness. And as Damon pointed out, the price should still be an opportunity for us in terms of not only covering the raw material costs, but also other inflationary pressures. And the reason for that is because we are also pricing based on value.

**Analyst-8**
: So, if I can just ask a quick follow-up, when you talk about a major win at an auto OEM, for instance, like in the slides, is that taking 100% of that cutting tool business and does that volume usually come at the expense of margin or how do you gauge what's acceptable as you try and go into the market and take share?

**CEO**
: We have a very good by SKU a cost accounting system that tells us exactly what kind of margin we're making on these parts. But we do not price necessarily based on -- it's not definitely -- it's definitely not a cost plus pricing. So, when we're taking the share, especially in transportation, and we've talked about this before, because when I first came in the company, we had ended up taking up -- I think, as a company, we're taking a lot of business where we weren't necessarily making acceptable margins. And we either moved away from that business or raised our prices. And in many cases, the customers actually pay the higher price because they -- because of the value we're delivering. So, we've already sort of made that transition and we're not going to let ourselves fall back into just getting -- buying share, if you will. What we're looking for is profitable growth. And when you're talking about PV, some of these applications are -- there's only a few metal cutting competitors that can even have a shot at this. And we're bidding against those competitors. And so when you win, it tells you that your technical solution was brought the best value proposition and it's not something that just anyone can deliver. And that's what gives us confidence that as we move to EV or even hybrid vehicles, we -- whatever one of these wins, I think we strengthened our position in that segment.

**Analyst-8**
: Thanks very much.

**Operator**
: This concludes the question-and-answer session. I'd like to turn the conference back over to Chris Rossi for closing remarks.

**CEO**
: Thanks, operator, and thanks, everyone, for joining us on the call today. As we said, this was a strong quarter and I think another data point demonstrating that our strategic initiatives to drive share gain and margin improvement and strong operating leverage are working. Also, just a quick reminder, we issued our second annual ESG report, which is now posted on our website. And as always, we appreciate your interest and support. Please don't hesitate to reach out to Kelly, if you have any questions on today's call. Have a great rest of your day. Thanks.

**Operator**
: A replay of this event will be available approximately one hour after its conclusion. To access the replay, you may dial toll-free within the United States (877)-344-7529. Outside of the United States, you may dial (412)-317-0088. You will be prompted to enter the conference ID 10150733, then the pound or hash symbol. You will be asked to record your name and company.