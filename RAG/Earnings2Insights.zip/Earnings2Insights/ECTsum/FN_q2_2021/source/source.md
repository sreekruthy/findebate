## Financial Earnings Call


### Prepared remarks
**Operator**
: Welcome to Fabrinet's Financial Results Conference Call for the Second Quarter of Fiscal Year 2021. At this time, all participants are in a listen-only mode. Later, we will conduct a question-and-answer session and instructions on how to participate will be provided at that time. As a reminder, today's call is being recorded. I would now like to turn the call over to your host, Garo Toomajanian.

**Investor Relations**
: Thank you, operator, and good afternoon everyone. Thank you for joining us on today's conference call to discuss Fabrinet's financial and operating results for the second quarter of fiscal year 2021, which ended December 25, 2020. With me on the call today are Seamus Grady, Chief Executive Officer and Csaba Sverha, Chief Financial Officer. This call is being webcast and a replay will be available on the Investors section of our website located at investor.fabrinet.com. Please refer to our website for important information, including our earnings press release and investor presentation, which include our GAAP to non-GAAP reconciliation. I would like to remind you that today's discussion will contain forward-looking statements about the future financial performance of the company. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from management's current expectations. These statements reflect our opinions only as of the date of this presentation and we undertake no obligation to revise them in light of new information or future events, except as required by law. For a description of the risk factors that may affect our results, please refer to our recent SEC filings, in particular the section captioned Risk Factors in our Form 10-Q filed on November 3, 2020. We will begin the call with remarks from Seamus and Csaba, followed by time for questions. I would now like to turn the call over to Fabrinet's CEO, Seamus Grady. Seamus?

**CEO**
: Thank you, Garo and good afternoon everyone. We had another record quarter with Q2 results that exceeded our guidance and support our longer-term optimism. In fact, based on our current outlook, we are positioned to deliver another record quarter in Q3 with strength across all key areas of our business. Revenue in the second quarter was a record $453.8 million, representing year-over-year as well as sequential growth. We remain focused on driving efficiencies, which helped generate margins that were at their highest levels in over a year. As a result, EPS also increased year-over-year and sequentially to a record $1.10. On today's call, I will focus my comments on the broader themes that drove our strong performance and support our outlook and Csaba will provide more details on our financial results and guidance. Our second quarter played out largely as anticipated combined with an unexpected positive surprise from automotive programs, which represented the most significant driver of upside in the quarter. In fact, automotive revenue grew more than 30% from the first quarter and more than doubled from a year ago. We continued to see a recovery from traditional automotive customers and even stronger growth from new automotive programs such as LIDAR, which are beginning to contribute to our growth in a more meaningful way. We are optimistic that this momentum in the automotive space will continue into the third quarter revenue. Revenue from industrial lasers was approximately flat and was slightly better than expected. We expect industrial laser revenue to improve in the third quarter and we remain optimistic about the longer-term potential for increased outsourcing from this market. In optical communications, we had anticipated that continued telecom strength would offset continuing softness from datacom products that are deployed inside the data center. In fact, we saw modest growth in optical communications revenue in the second quarter. Datacom revenue did moderate as we anticipated. However, this was more than offset by stronger telecom revenue. We are optimistic that datacom revenue will show an improvement in the third quarter and that both datacom and telecom revenue should increase sequentially. Part of our telecom growth was driven by our optical transport systems program at Cisco, which we have discussed on past calls. This transfer has been progressing very well and is ahead of plan. We had been anticipating that the transfer would be largely complete by the end of our fourth quarter and we now believe we are nearly a full quarter ahead of expectations. This faster ramp will also contribute to our anticipated growth in optical communications revenue in the third quarter. Due to the combination of the earlier Cisco ramp, growth from new automotive customers, and continuing optimism as we execute on our strategy, we are advancing our plans to expand our manufacturing footprint. We recently broke ground on a new 1 million square foot building at our campus in Chonburi, Thailand. This is twice the size of our originally contemplated expansion reflecting confidence in our ability to further scale our business over the longer-term. This expansion will roughly triple our footprint in Chonburi and will increase our global footprint by approximately 50% to 3 million square feet, providing us with considerable capacity to serve our anticipated growth. We expect construction to take approximately 1.5 years, which means we could start to see revenue from this facility in approximately two years. To summarize, we are very pleased that our second quarter represented record revenue and earnings with results that once again exceeded our guidance. Our continual focus on efficiency helped produce improvements in gross margin and operating margin in the quarter. As we continue to expand on our market leadership, we are optimistic that Q3 will be another record-breaking quarter for the company and we believe that growth from new products and programs will continue to demonstrate the success of our growth strategy as we look ahead. Now I'd like to turn the call over to Csaba for additional financial details and our guidance for the third quarter of fiscal 2021. Csaba?

**CFO**
: Thank you, Seamus and good afternoon everyone. We were excited to deliver a record performance that exceeded our guidance ranges. Revenue of $453.8 million was nearly $14 million above the high-end of our guidance range. This was our strongest revenue beat in two years and a new record. Optical communications was $347.8 million or 77% of total revenue, up 1% from Q1. Non-optical communications revenue was $106 million or 23% of total revenue and increased 14% from Q1. Within optical communications, telecom revenue was $273.2 million, up 5% from last quarter. Datacom revenue was $74.6 million, down 10% sequentially. While datacom revenue declined as expected, we were pleased to see growth in telecom more than offset this in Q2. We are also optimistic that datacom revenue will return to growth in the third quarter. Silicon photonics revenue was $101.8 million, down 6% from a very strong Q1, but up 24% from a year ago. Revenue from 100-gig products saw a decline as faster data rate products saw very significant growth. 100-gig revenue of $128.2 million was down 50% from Q1 while revenue from 400-gig and faster was $104.2 million, up 50% from last quarter and more than doubled from a year ago. Looking at our non-optical communications business, automotive has grown to become the largest category with record revenue of $47 million in the second quarter, up 34% sequentially and more than 100% from a year ago. As Seamus mentioned, new automotive programs which include LIDAR saw strong growth and we continue to be optimistic in this market. Industrial laser revenue was $33.7 million, down about 1 percentage point from Q1. Sensor revenue was stable at $2.8 million and other non-optical communications revenue was up 5% to $22.5 million. Now turning to the details of our P&L. Unless otherwise noted, profitability metrics are on a non-GAAP basis. A reconciliation of GAAP to non-GAAP measures is included in our earnings press release and investor presentation, which you can find on our website. Gross margin was 12.1%, up from 12% in the prior quarter. This improvement was the result of our ongoing focus on manufacturing efficiencies and cost reductions. Operating expenses in the quarter were $12.8 million or 2.8% of revenue. This produced record operating income of $41.9 million or 9.2% of revenue. Taxes in the second quarter were $1 million and our normalized effective tax rate was 3%. Due to tax incentives at our Chonburi facility, which represents a growing portion of our profit, we now expect our effective tax rate to be about 4% for the year. Non-GAAP net income was also a record at $41.5 million or $1.10 per share. On a GAAP basis, net income was $35.4 million or $0.94 per diluted share. Turning to the balance sheet and cash flow statement. At the end of the second quarter, cash, restricted cash and investments were $488.6 million. Operating cash flow was an inflow of $6.8 million, a decrease from the prior quarter primarily due to increased working capital in support of our strong revenue growth. With capex of $10.1 million, free cash flow was an outflow of $3.3 million in the second quarter. As Seamus mentioned, we have already broken ground on a new building at our Chonburi campus. We expect incremental capex of approximately $50 million over an estimated 1.5-year construction period. This investment is in alignment with our capital allocation strategy to invest in our longer-term growth. During the quarter, we repurchased approximately 102,000 shares at an average price of $69.64 for a total cash outlay of $7.1 million. These repurchases are also consistent with our capital allocation strategy. At the end of the quarter, we had 93 [Phonetic] million remaining in our share repurchase program. I would now like to turn to our guidance for the third quarter of fiscal year 2021. We are optimistic that the positive trends we have been experiencing will continue in the third quarter and we expect revenue growth across all key categories. We expect optical communication to grow sequentially. Telecom growth is being driven by continued demand at higher data rate products combined with the earlier than expected ramping of our Cisco transfer program. We also believe that datacom trends are becoming more positive and we anticipate modest growth in this area. In non-optical communications, we also anticipate sequential growth. We expect trends we have seen with new automotive programs will continue in the third quarter. We also anticipate industrial laser revenue to increase sequentially as well. We expect total revenue in the third quarter to be between $455 million and $475 million and EPS to be in the range of $1.10 to $1.17 per diluted share. In summary, we are pleased to deliver a record second quarter result and are optimistic that the third quarter will produce another record performance. We are excited with the growth from new programs in multiple areas coupled with our ability to expand margins. We continue to aggressively pursue new opportunities that will further our position and driving growing revenue and profitability and enhance long-term shareholder value. Operator, we are now ready to open the call for questions.

### Q&A
**Operator**
: Thank you. [Operator Instructions] Our first question is from Alex Henderson with Needham. Your question please.

**Analyst-1**
: Thanks guys. So a couple of questions. So just a little off subject. I wanted to make sure that you didn't have any issues as a result of any of your customers getting penetrated with SolarWinds hack and experienced lateral or did you have any issues with SolarWinds?

**CEO**
: Hi Alex, this is Seamus. No, we did not have any issues. We were quite fortunate not to be hit by the SolarWinds issue. We're not aware of any impact to our customers. So we've been quite fortunate. We do have obviously very, very tight controls, but I think there is an element of good fortune as well. So, thankfully, we haven't been impacted.

**Analyst-1**
: I'm glad to hear that. Thanks for answering that one. The second question I wanted to ask was really could you just tell me what the tax rate comment was because I couldn't understand you when you gave the tax guide.

**CFO**
: Hi Alex, this is Csaba. So basically what we are commenting on our tax rate, we are anticipating more and more profit coming from our Chonburi campus where we have tax incentives. So that's obviously driving our tax rate down.

**Analyst-1**
: Yeah, I know, but you gave a guidance, I just couldn't hear the number.

**CFO**
: [Speech Overlap] Sorry about it. That's about 4%.

**Analyst-1**
: About 4%, thanks. The second question I wanted to ask is obviously Acacia and Cisco merger looks like it's going to get done. Does that have any impact on you and given that closure, would it change your trajectory at all?

**CEO**
: Yes, so far we feel good about that relationship. I think in the past we've said if the deal went through or if the deal didn't go through, we didn't really have strong views frankly one way or the other. So we're happy to see the deal go through, we think it's good for both companies and we're very happy with obviously with our relationship there again with both companies, now Cisco. So no major impact from our point of view.

**Analyst-1**
: And how about the Lumentum acquisition that was announced. Any impact to you from that one way or the other?

**CEO**
: Yeah, so obviously, we had a strong relationship with both -- with Lumentum for many years and they were our largest customer for some time and Coherent is also a customer of ours. They are less than a 10% customer, but they are a customer of ours and our work with Coherent has been focused on the industrial laser side. So it's kind of in our sweet spot. You know, it's very early to say, time will tell. We haven't had any conversations actually with either company at this stage related to the acquisition, but we're optimistic. Given our long-standing relationship with both companies, we're optimistic that any impact from the combination would not negatively impact us and historically we've tended to benefit from these type of business combinations, but it's very early stages yet.

**Analyst-1**
: From what I understand, Rofin's manufacturing footprint inside of Coherent is extremely distributed and the company said that 65% of their benefits -- Lumentum said 65% of their synergies are coming from rationalizing footprint into Thailand. I assume that, that means you and therefore that should that be a considerable positive for you because obviously Coherent was not moving as fast as Lumentum seems to intend to do.

**CEO**
: Well, we'd certainly like to take that, but I'd point out we're not the only manufacturer in Thailand. We're not Lumentum's only manufacturer and of course, Lumentum have their own facility in Thailand too. So I certainly wouldn't want to speak on Lumentum's behalf, but we'll be doing everything we can to try and win our share of that business.

**Analyst-1**
: I see and then finally, if I could just go back to the comments on Cisco happening faster, just a last question. So does that mean that we should anticipate that coming on faster and therefore having less growth impact as we move into the back half of the year and get against as those comps and as we move forward or do you think that the fast move is actually going to incent them to continue to move more production over to you?

**CEO**
: No, I think your first assumption is correct. It's really pulled everything in by about a quarter, but you know, the business is what it is, it's a business that we've moved from our competitor in Chonburi. That's the transfer that's about a quarter ahead of schedule, but it just means that the growth has accelerated, but it's not necessarily going to result in more revenue if that makes sense.

**Analyst-1**
: Great, thank you. I appreciate your answers.

**CEO**
: No problem. Thanks, Alex.

**Operator**
: Thank you. Our next question comes from John Marchetti with Stifel. Your question please.

**Analyst-2**
: Thanks very much. Seamus, the announcement of the breaking ground on the new building in Chonburi. It sounds like it really got pulled forward a little bit for you and I'm curious if that's just a function of the Cisco business being completed from the transfer process a little bit ahead of schedule or if it's some of this new LIDAR strength that you've alluded to. Just curious because it does seem like a fairly big departure from where we were even just a quarter ago?

**CEO**
: Well, it's been, -- I suppose it's been in the works and in consideration for a while. We always say we never wait until you know the previous factory is full. We're going to pull the trigger on the next one in anticipation of growth and if you think about a lot of where the growth has come from in the last while has just come from new customers that we've been adding into Chonburi. So the Cisco transfer is a big one, a big chunk of the business we transferred from Infinera in Berlin went to Chonburi and of course, a lot of our new automotive programs in particular LIDAR, laser lighting and a few others have gone to Chonburi. So we've got to the point where we're getting quite busy in Chonburi and it's the right time to pull the trigger on the next building. So for us it's a -- we don't really -- I suppose we don't really indicate when we're going to do it until we do it, John, so it might look like it's a surprise or big news if you like from last quarter, but really we hadn't been indicating precisely when we would be planning to build next building. So we see it as a, you know, it's a good indication of our optimism in the growth trajectory that we're on and it will be a much bigger footprint than the last building.

**Analyst-2**
: Got it. And then if I just think about the 100-gig, 400-gig split. We've been talking a little bit in these last several quarters about sort of some of the challenges you've had on the datacom side because of that transition. It seemed like it hit pretty strongly this quarter. Do you think that inflection point is behind you and I'm just curious as we're looking out going forward, is the expectation now that, that 400-gig plus revenue continues to scale up, but I guess how much risk is there that the 100-gig continues to decline at that kind of rate that we recently just saw?

**CEO**
: Yeah, it's an interesting one. I think we talked about our datacom revenue, we're guiding up on that. We expect it to increase a bit [Phonetic] in Q3. And that's, just to remind, we're talking inside the data center. So for us, datacom is inside the data center. Outside the data center are biz [Phonetic] and interconnect we categorize in telecom. We have seen, I would say a fairly strong transition from 100-gig products to let's say 200-gig and 400-gig inside the data center. We have a few customers there who have transitioned to 200-gig or 400-gig products. It started I would say two quarters ago and it's really beginning to accelerate now and our anticipated sequential growth in datacom comes from those customers who are really transitioning. And also, we talked in the past about that trade-off between price and volume. We think that the demand trends and the pricing are now more, if you like, more in equilibrium than they were in the past. So we see the datacom business going up now. So yeah, we think that inflection point is kind of, we're kind of in it or it's maybe slightly behind us at this point. We should see those higher data rates data center products start to ramp now.

**Analyst-2**
: Got it. And then one last question for you all. Given some of the strength that you've recently showed in auto and then how you're talking about it going forward, we've certainly been hearing about some supply constraints, particularly within that market vertical. Just curious if there is -- that's something that we have to be aware of or be thinking about as we're looking at that business strength continuing as we go through the year.

**CEO**
: Yeah, I think it's always a -- it seems to be a pattern in our industry that there's always some supply challenges every 1.5 to two years, just seems to be some big supply constraint that hits us all and for us it has become part of our, if you like, our standard operating procedure for us to figure out how to identify and secure these critical parts. We work very closely with the customers and our supply chain partners to make sure we get our share and hopefully our own fair share of the parks. We have seen like others I think have spoken about, we have seen longer lead times mostly related to our automotive business, but this -- we factored this into our guidance and we will continue to do so. It is an issue, but we wouldn't want to make too much of it. We just have to make sure we secure the parts, work with the customers, work with the suppliers to make sure we secure the parts and like I said, we have factored that into our guidance.

**Analyst-2**
: Great, thanks very much.

**CEO**
: Thanks, John.

**Operator**
: Thank you. Our next question comes from Samik Chatterjee with J.P. Morgan. Your question please.

**Analyst-3**
: Hi guys, this is Joe Cardoso on for Samik. So my first question is a follow-up on the automotive question that was just asked. I guess relative to our expectation, automotive continues to outperform expectations and it sounds like the primary drivers LIDAR and then to a lesser degree the traditional business. I guess if we compare it to like 90 days ago or 180 days ago, has this demand kind of caught you guys by surprise as well and like what's really driving this demand for LIDAR specifically. Is this going into production vehicles? Any color there would be helpful?

**CEO**
: So, for us, the growth in automotive has come from a couple of areas. It's traditional automotive but more so as you correctly point out, LIDAR. You know, we go by our customers' 13-week rolling forecast. We don't -- unfortunately Joe, we don't necessarily have visibility into what specific applications our customers are planning for those LIDAR modules that we're producing and shipping. So it's probably a question better directed to our customers, but we're just very happy to be participating in that supply chain. We do feel we have a lot of strengths that position us very well to capitalize on the hopefully explosive growth that the world will see in LIDAR business. We're very well positioned. We believe we're the strongest contract manufacturer in that space, but to answer your question, the specific applications that are behind it, we wouldn't be so sure I'm afraid.

**Analyst-3**
: Got it. No, that's fair. And then my second question is more of a clarification or confirmation. I believe in the past, this is related to the Chonburi build out. In the past, you've disclosed that roughly one plant equates to 550,000 square feet or $500 million of total revenue opportunity. So is it correct to think the new building will account for roughly $1 billion of revenue?

**CEO**
: Yeah, I mean the ballpark math would be would be correct, yeah, but it really does depend on the mix. If for a given 10,000 square feet, it depends and if you're producing a very densely populated very small, physically small transceiver versus a big system that has a lot of air in it, the revenue mix would be different, but they are the numbers we've used in the past, roughly 550,000 square feet is about $0.5 billion revenue capacity. So yeah, that's the correct assumption at this point.

**Analyst-3**
: Got it. Appreciate the insight, guys. Congrats on the quarter.

**CEO**
: Thank you, Joe. Appreciate it.

**Operator**
: Thank you. [Operator Instructions] Our next question is from Tim Savageaux with Northland Capital. Your question please.

**Analyst-4**
: Hi, good afternoon and congrats on the results.

**CEO**
: Thank you, Tim.

**Analyst-4**
: All right, I wanted to follow-up on the kind of capacity addition question because of the way you put it upfront, realizing that you may not have kind of telegraphed the timing of breaking ground. You did mention it was twice what the original plan was. So I guess when was that original plan developed and how recently did it change and why did it change?

**CEO**
: Well, when I seen the original plan, I mean I guess we had always envisaged at a high level the building that we called it Building 8. We don't have a very exciting naming convention, but Building Eight in Chonburi, we had always envisaged that Building 9 would be, if you like, a carbon copy of Building 8 again without having given it much thought. And then as we got closer to making the decision, there's always a trade-off between the size and then the cost per square foot. So obviously, the bigger the building, the lower the cost per square foot to build the building. So that was the trade-off, really. So we just felt the time was right to make a bigger investment in capacity and again, like a lot of our operations there will be a disproportionately high amount of clean room space relative to other contract manufacturers and that does take time to bring on and get ready for. So it's been an iterative process. There wasn't, if you like, a big bang event that drove us to this decision. It was more of an iterative process as we looked at. We have ample land. We have enough land to last us for a long, long time. So the size of the latter -- the land was never going to be a constraint. It was more about how big we wanted to build the building taking into account parking space for employees and future growth and expansion capabilities. So I hope that answers your question, Tim.

**Analyst-4**
: Not quite, but let me try one more thing and then I'll move on to a couple of more detailed questions which is, you mentioned a number of factors kind of driving current capacity at Chonburi. Cisco is ramping faster, but it's not ramping larger in magnitude, I would imagine. I think that's kind of what you said. So I guess I'm still looking for outside of parking spaces, what sort of opportunities may have arisen in the last quarter or two, assuming if I'm correct that Cisco is just happening quicker, but in terms of its overall contribution is about in line with expectations. Are there anything that you can point to that might have given you a sense that you could make use of greater capacity?

**CEO**
: Sure, well, of course, the Cisco opportunity that I mentioned, it's ramping in line with our expectations that we had when we won that business, but Cisco is a very large company and we'd be very, very determined to make sure we continue to expand that relationship. Maybe the specific program that we're transferring it is what it is in terms of the size and scale of that program, but we've certainly be working very hard to make sure we win additional business from Cisco. So that's one opportunity. Then the other is, there are a lot of other system opportunities that we're pursuing. We've had some considerable success we think with Infinera and with Cisco, but there are a lot of other companies out there that we'll also be pursuing. In addition, our automotive business is growing and LIDAR is becoming a bigger share of the automotive business and then also, we want to be able to make sure we have capacity for the inevitable move toward increased outsourcing in the industrial laser market because again, we think that, that industry is very under-penetrated in terms of outsourcing. So it's really to position ourselves to be able to fulfill the pipeline of the existing business and new business that we have in the works.

**Analyst-4**
: Got it. Crystal clear and while we're on Cisco realizing, there's probably a limited amount you can say, I mean you have indicated that it's ramped quicker than expected. I assume not to the magnitude where you'd have any additional 10% customers in the second quarter, but would you expect that, that could possibly be the case in Q3 or sometime in the second half of the year in terms of adding new kind of logos to that 10% list?

**CEO**
: I think we disclose the 10% at the end of the year. I think I'd be optimistic we'll have -- we've talked in the past about Infinera becoming a 10% customer. We believe Cisco will be a 10% customer and I think we're still on track for that. Beyond that, I wouldn't like to speculate.

**Analyst-4**
: Fair enough. And last question from me, you did see a decline in silicon photonics revenue in the quarter after a couple of quarters of very strong growth, at least sequentially, which seems to marry up to some degree with the decline in datacom. Should we assume that, that headwind came more from the datacom side versus your other silicon photonic applications and higher data rates in telecom?

**CFO**
: Hi, Tim, this is Csaba. Yes, that's pretty much a fair assumption. We do believe that the datacom have bottomed out. So silicon photonics had also been impacted with that downward trend in the datacom and we anticipate the growth is going to come back in Q3 [Phonetic].

**Analyst-4**
: Great, thanks very much and congrats again.

**CEO**
: Thank you, Tim.

**Operator**
: Thank you. Our next question comes from Dave Kang with B. Riley. Your question please.

**Analyst-5**
: Thank you. Good afternoon. My first question is regarding 100-gig and 400-gig. Just wanted some additional color. So I think you said 100-gig declined 15% [Phonetic] sequentially whereas 400-gig plus increased 50% sequentially. Is that correct?

**CEO**
: Yes, that's correct.

**Analyst-5**
: Now, are you lumping both datacom and telecom there and if you are, then can you just provide some color between datacom and telecom?

**CFO**
: Yes, we do have datacom and telecom combined in both categories. We usually not break out by data rate our datacom and telecom business. However, we did mention that in the datacom space, we are anticipating the 200-G and 400-G take a little bit bigger market share from the revenue. However that's at this point is not meaningful. So the growth on 400-G is primarily in our telecom segment. And as a reminder, our data center interconnect is also categorized in that category, which was a strong driver there.

**Analyst-5**
: Got it. And then of that 400-gig bucket, can you provide any color regarding 400-gig versus 600-gig and 800-gig?

**CFO**
: No, we don't break out beyond that. So it's 400-gig and above. It's a combination at this point of 400-gig and 600-gig. 800-gig at this stage is not a substantial amount yet. So it's going to be a combination of 400-gig and 600-gig.

**Analyst-5**
: Got it and then you mentioned that datacom seems to have bottomed. I mean I think the last peak was about, what nine, 10 quarters ago, I think it was fiscal first quarter '19 looking at the model and it was about $109 million. I mean, can we get back to that level or how should we think about this -- the next cycle?

**CFO**
: So, again, since that time I think what we have been seeing is a significant price erosion, which I think is a main reason of our revenue decline, why the volumes have been pretty strong in datacom space. So a number of factor [Phonetic] of that revenue was primarily driven by price erosion and lower ASPs. When we look out in the future, we really don't like to speculate beyond one quarter or so. At this point, I wouldn't make any comments whether or not it's going to return to that rate, but again 400G -- 200G and 400G is starting to ramp, which is obviously driving the higher ASP. So I would say that pricing a cyclical trend, it will be fair to say that it should continue as it has been in the last 18 months.

**Analyst-5**
: Got it. And then lastly on the auto. I mean, what's the mix -- rough mix between LIDAR versus traditional?

**CFO**
: We usually don't break that out in terms of traditional and LIDAR, particularly not on LIDAR. So when we talk about newer automotive, it does include LIDAR and other newer automotive programs as well for example, laser lightings and e-vehicle related business as well. So we are not breaking it out from traditional, but the growth came in the past quarter both from strong traditional and stronger newer automotive products.

**Analyst-5**
: Got it. Thank you.

**CEO**
: Thank you, Dave.

**CFO**
: You're welcome.

**Operator**
: Thank you. Our next question --

**CEO**
: Operator, are you still on the line?

**Operator**
: And our next question comes from Alex Henderson with Needham. Your question please.

**Analyst-1**
: Great, thank you. Couple of follow-up questions. When we look at the automotive segment, is it concentrated in a few names that are achieving the bulk of that revenue or is it distributed across multiple manufacturers?

**CEO**
: It's in a few names, not a huge number of names. I mean our traditional automotive business, we have one major customer there on what we call our traditional automotive business, that's Valeo. They are not a 10% customer but they are a significant customer for us in our traditional automotive business. And then our newer automotive -- we have others as well, but Valeo would be the bigger -- the biggest one in our traditional automotive. And then in newer automotive business, we've talked about Velodyne in the past. We brought them on -- the customer brought them into Fabrinet West originally, then transferred them to Bangkok. We didn't name them as a customer until I think it was maybe last quarter or the quarter before when -- with Valeo's agreement, we were able name them. We have a couple of other, I would call, newer automotive customers as well in you know laser lighting companies, electric vehicle companies and then some other automotive customers that we're just bringing on, other LIDAR companies, solid state LIDAR and ADAS type companies who are quite sensitive about us naming them until they're ready to communicate that, but we have a good pipeline -- I say -- the pipeline of new business is almost all on the new automotive side of the business with, I would say, a strong pipeline of LIDAR companies. There's a lot of LIDAR companies out there today. Obviously, they won't all succeed, but for us, we want to make sure we're working with the ones that we believe have the best chance of success. So we have a good pipeline of LIDAR companies, but not ones where we'd be able to name at this stage.

**Analyst-1**
: Right, so these are predominantly people who are then selling to the large auto companies as opposed to directly to the auto companies themselves?

**CEO**
: That's correct.

**Analyst-1**
: Okay. Second question I had, when you do kick this manufacturing plant into production, should we anticipate the same kind of 10 basis point to 20 basis point pressure to gross margins. It's a fairly modest hit for gross margins relative to the impact when you turn the plant on still. Is that the right way to think about it?

**CFO**
: So obviously, there will be more of depreciation expense of the facility. So as anything, as we run the facility, the absorption should more than offset, but initially the depreciation expense will obviously put the pressure on our gross margin. Nevertheless, as we have always been driving efficiencies to offset the headwinds in the past, we will continue to do so to make sure that we stay within our gross margin range.

**Analyst-1**
: I recall last time you turned up the new facility, it was about a 10 basis point to 20 basis point hit. The question would be, is this twice that because it's twice the size or should it still be that kind of magnitude?

**CFO**
: Well, if you think about it, the depreciation expense of a $50 million investment, if you do the math, I haven't done the exact match at this stage, but that's what you should think about in terms of gross margin headwind.

**Analyst-1**
: Okay and then I noticed one of the OEMs in the networking space finally launched a co-packaged product. Are you starting to see more interest in co-packaging and to what extent is that creating a new growth vector for you?

**CEO**
: We are and I think for us co-packaged optics is inevitable given the increase in speed and bandwidth from the networking silicon. You know it's probably a couple of years out before it becomes, let's say, mainstream, but we're very firmly working with our customers on that. And for us, co-packaged optics for us is more of an evolution from what we've been doing with regard to silicon photonics over the last several years. So we're seeing it being a driver for us in the coming years. Nothing imminent, but certainly it will become, you know, it's inevitable is the move to co-packaged optics.

**Analyst-1**
: And then finally, can you talk about the baht, obviously, it strengthened over the course of last year, but it was fairly stable I think in the last quarter. Can you remind us how you are hedged and to what extent do you expect any variance from that hedging program?

**CFO**
: So basically, there are two aspects of the baht situation and overall exchange rate situation. If you look at our income statement, we have had about $500,000 loss in the last quarter with a small gain in the prior quarter. That represents approximately $0.02 headwinds, but when we look at the broader FX trends, primarily U.S. dollar has been weakening in the last couple of months. Obviously, there are two effects, baht is appreciating, U.S. dollar is strengthening which is representing a headwind for us. So the hedging program we have in place is a layer hedge. We are 100% hedged for the next quarter, 50% hedged for the following quarter, and about 25% hedged three quarters out. So if you look at the market trends, we have a pretty predictable estimate for the current quarter, but as we go on in the future, the current market situation will be reflected in our future results. So in Q2, because of that, we didn't really have a significant impact from the baht because of the hedging program. However, as you look out to Q3, the baht have strengthened somewhat in the last three, four months and that impact is going to start putting the pressure on our Q3 gross margins, which is baked in our guidance at this point.

**Analyst-1**
: Would have been improving further or otherwise. [Speech Overlap] Go ahead.

**CFO**
: That is correct. So that [Technical Issues] our margin expansion because we have to make up for that headwind and will improve the efficiencies.

**Analyst-1**
: All right. Okay, that's all I had. Thanks.

**CEO**
: Thanks, Alex.

**CFO**
: Thank you.

**Operator**
: Thank you. And this concludes our Q&A for today. I would love to turn the call back to Seamus Grady for his final remarks.

**CEO**
: Thank you for joining our call today. We are pleased to have exceeded our guidance with record revenues and EPS in the second quarter. We're optimistic that the coming quarter will represent another record performance illustrating that our strategy is working. We look forward to speaking with you again soon. Goodbye and thank you.

**Operator**
: [Operator Closing Remarks]