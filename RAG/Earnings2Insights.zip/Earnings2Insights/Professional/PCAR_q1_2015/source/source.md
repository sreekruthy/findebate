## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCARs First Quarter 2015 Earnings Conference Call. All lines will be in a listen-only mode until the question-and-answer session. Todays call is being recorded. And if anyone has any objection, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCARs Director of Investor Relations. Mr. Hastings, please go ahead.

**CTO**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCARs Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer; and Michael Barkley, Vice President, Controller. As with prior conference calls, if there are members of the media on the line, we ask that they participate in a listen-only mode. Certain information presented today will be forward-looking andinvolve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

### Q&A
**CEO**
: Good morning. PACCAR reported excellent revenues and net income for the first quarter of 2015. PACCARs first quarter sales and financial services revenues were $4.8billion. And quarterly net income was $378 million and after tax return on revenues of 7.8%. Net income increased 38% compared to the results generated in the first quarter last year. Im very proud of our 23,000 employees who have delivered industry leading products and services to our customers worldwide. The first quarter marked another major milestone for PACCAR with DAF celebrating its 1 millionth truck delivery. Im very proud of the thousands of DAF and Leyland employees over the years who contributed to this achievement. PACCAR delivered 38,300 trucks during the first quarter, a 20% increase versus the first quarter last year, slightly ahead of our expectations. The improvement reflects increased truck deliveries in the U.S. and Canada due to a good economy, record freight demand and expansion of fleet capacity. Deliveries in Europe were 10% higher than last years first quarter. Looking ahead, we expect to increase truck deliveries in the second quarter by 5% to 7% compared to the first quarter reflecting higher production rates for medium and heavy duty trucks in North America and Europe. Second quarter gross margins are projected to be slightly higher than the first quarter reflecting the benefits of increased production levels and improved operating efficiencies. Europes economic outlook has been helped recently by the European Central Banks quantitative easing program and lower oil prices. GDP growth expectations for this year are 2.6% in the UK which is PACCARs strongest market in the region, and 1.3% on the continent. Freight transport activity on German highways in March was up 4% over last year and at the highest first quarter level since the German toll system was launched in 2007. We have raised our forecast for Europes greater than 16-tonne market to a range of 220,000 units to 250,000 units reflecting a rebound in orders and the brighter economic outlook. Year-to-date, DAF has achieved a 15.5% share of the heavy truck market. I want to comment on the effects the translation had on our revenues during the first quarter of this year. Looking at truck and other revenue, revenues were impacted by $232 million. Looking at parts, parts was impacted by $49 million for a total impact on revenues of $281 million. The impact on financial services was a reduction of $16 million. On profit, the effects of translation were largely offset by a natural hedge that we have with respect to the purchase of engine components for our engines that we manufacture in North America. Turning to the U.S., the economic picture in the U.S. remains positive with GDP forecast to grow 2.9% this year. The housing and automotive industries create a large amount of freight. Housing starts are projected to grow 14% this year to over 1.1 million. And the automotive industry is expected to deliver 16.8 million vehicles near record levels. We estimate U.S. and Canadian Class 8 industry retail sales will be in a range of 260,000 units to 290,000 units this year, up from 250,000 units in 2014. The stronger market reflects expansion in industry fleet capacity due to continued strong freight fundamentals. Industry truck orders for the U.S. and Canada in each of the last two quarters were the highest since 2006. Peterbilt and Kenworths combined share of the U.S. and Canadian market is over 27% year-to-date. PACCARs parts business generated quarterly revenues of $753 million, a 4% increase compared to $727 million in the same quarter of last year. PACCAR parts quarterly pretax income was $139 million, an increase of 24% compared to the $112 million earned in the first quarter of 2014. The strong results were driven by high fleet utilization, growth in the size of the North American truck parc, and the many innovative products and services offered by PACCAR parts and our dealers. PACCAR Financial Services first quarter pretax income was $89 million compared to $86 million earned a year ago with profits, which resulted from growth and asset balances and excellent portfolio performance. PACCAR strong balance sheet and positive cash flow have enabled the company to invest over $3.1 billion in new products and facilities in the last five years. Were delighted that the new Kenworth T880 truck powered by the PACCAR MX-13 engine was honored as the 2015 Commercial Truck of the Year by the American Truck Dealers. PAACARs capital spending of $325 million to $375 million this year is targeted at enhanced powertrain development and increased operating efficiency of our assembly and distribution facilities. Research and development expenses are estimated to be in a range of $225 million to $250 million. PAACAR continues to enhance its leadership position in the global truck market by developing the highest quality products and services in the industry. Thank you. Id be pleased to answer your questions.

**Operator**
: [Operator Instructions] The first question comes from the line of Andy Casey with Wells Fargo.

**Analyst-1**
: Thank you. Good morning, everybody.

**CEO**
: Good morning, Andy.

**Analyst-1**
: Just a quick question Ron on whether you guys have seen any improvement in the outlook for pricing whether it would be Q2 or second-half specifically in North America?

**CEO**
: I just say pricing is very stable. Customers recognize the value of the Peterbilt, Kenworth and DAF products around the world. Markets are always competitive and we have a great product to offer. And so I think that the pricing at this point is very stable.

**Analyst-1**
: Okay, thanks. And then the comment about the 5% to 7% sequential production increase. Is part of that more days in the quarter, or are you able specifically in North America to increase production by utilizing some of your other production sites as opposed to the two primary ones for Class 8?

**CEO**
: I would say, most of it is higher daily production rates with maybe a day or two extra.

**Analyst-1**
: Okay. Thank you very much.

**CEO**
: Sure.

**Operator**
: The next question comes from the line of Andrew Kaplowitz with Barclays.

**Analyst-2**
: Hey, good morning, guys. Nice quarter.

**CEO**
: Thank you. Good morning, Andrew.

**Analyst-2**
: So incremental margin appear to take a meaningful jump this quarter and gross margin was well ahead of your previous guidance of 100 basis points to 150 basis points of year-over-year improvement. So can you talk about what ended up being better than your expectations? It does look like some of that is strong parts margin, and maybe your distribution center is ramping up there significantly, I dont know or are you starting to get better absorption and pricing in Europe?

**CEO**
: I think your observation about parts is right on point, several things there. One was favorable mix of the products that were sold, the operating leverage of our cost structure, and we did see some benefits from the lower oil price and the effect on our delivery costs from our parts business. So those factors played a role, and then just the - a more stable build rate in the operating efficiencies that come with operating at a stable level.

**Analyst-2**
: Okay, thats good. And then Ron, you said the gross margin would be about 50 basis points better for the year, but after being better than expectations in 1Q, what could that margin improvement look like for the year?

**CEO**
: I would think that for the year we look at something that would be comparable to first quarter levels.

**Analyst-2**
: Okay. Thank you.

**CEO**
: Yes.

**Operator**
: Your next question comes from the line of Ann Duignan with JPMorgan.

**Analyst-3**
: Hi, good morning guys.

**CEO**
: Good morning, Ann.

**Analyst-3**
: Good morning. Can you comment on your - what you mentioned about some fleet expansion out there, whether thats part of a trend you are beginning to see, we hear a lot about driver shortage, et cetera, et cetera. And then comment on if we continue to see some fleet expansion, could that have a negative impact on your parts business as we go forward, more new trucks, fewer parts and services?

**CEO**
: I think the parts business is well positioned. The trucks that are there are operating at over 90% utilization, which is really a peak level. So I dont see any tapering off from whether its that those are new trucks or older trucks. I think the parts business will continue to benefit from strong freight markets not only in North America, but also in Europe. And I think, the fleets, there was some pent-up demand over the more challenging years more and more fleets are renewing their fleets, and also I think if they had additional drivers they would probably purchase additional trucks. But weve seen some fleets be able to make those expansion, so.

**Analyst-3**
: Okay, thank you. And then just if you could comment on the rise in cancellations last month, I know it was an industry number. But are you seeing anything out there on the cancellation side that caused you any concern as we go through the year, [indiscernible] oil and gas or anything?

**CEO**
: No, no concerns at all.

**Analyst-3**
: Okay. Thank you. I appreciate it.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Jerry Revich with Goldman Sachs. Jerry, your line is open. Please proceed with your question.

**Analyst-4**
: Good morning. Sorry about that. Im wondering if you gentlemen can talk about the book to bill in the quarter in Europe? One of your competitors spoke about a 40% year-over-year increase in orders in the quarter. Are you seeing as much momentum as they are? Can you just calibrate us there?

**CEO**
: Yes. So as we look at DAFs orders in the first quarter compared to fourth quarter levels, were also up about 40%.

**Analyst-4**
: And in terms of in the PACCAR financial business, you continue at pretty good margin performance there. Can you just talk about how we should think about the debt to equity ratio for that business? Youve taken it down about a turn over the past year, plus can you just talk about whats driving the more conservative balance sheet there and how we should think about the ratio longer term?

**CEO**
: I think weve just been able to - weve retained the earnings that weve achieved over the last many years and retained those in the business. So more of our portfolio is being funded with the equity, but I would see the leverage would continue at similar levels to where were at currently in the foreseeable future.

**Analyst-4**
: Okay. And then can you update us on your push on the operating lease side? Whats your penetration look like? Is that still a meaningful priority for you folks in that business?

**CEO**
: Yes. I mean we have a full line of products that PACCAR Financial Services offer. So were very willing to provide loans, leases, floor plan financing, all the products that we offer to all of our customers and our dealers. And were not preferential to anyone particular product; we just want to meet our customers needs and support the growth of those that sell PACCAR trucks.

**Analyst-4**
: Yes. Thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of JB Groh with D.A. Davidson.

**Analyst-5**
: Hey, guys. Thanks for taking my call. Just a couple of housekeeping issues on the SG&A that - year-over-year that pretty nice decrease there. Is there something that was happening last year that caused that to be a little higher, is this roughly $110 million a good run rate for the remainder of the year should that go up a little bit?

**CEO**
: The SG&A did benefit about $10 million from exchange effects.

**Analyst-5**
: Okay.

**CEO**
: And the current exchange rate, this is a fairly good run rate.

**Analyst-5**
: Okay. And I know you cant give us any details on this European Commission in terms of the potential impact, but how about timing? Any idea when there will be some sort of...?

**CEO**
: Yes. Weve got - provided the update in our press release. We really have nothing else to add at this point, JB.

**Analyst-5**
: Okay, thats fair. And then how about an update on South America? How are things going there?

**CEO**
: Things are going very well. Our factory continues to build excellent trucks for the Brazilian market. More and more dealers are opening their new facilities, continue to construct new facilities. Were still identifying dealers in some areas of expansion, so its all progressing very well and as we look at the long-term that will be an excellent investment for us.

**Analyst-5**
: But is the rate that you are currently delivering there, is that probably a little bit of a drag on the margin?

**CEO**
: Our deliveries are very steady, so its been at the same rate for the last several quarters.

**Analyst-5**
: Okay. And then did you get, I didnt - I dont know if I got this, do you give the delivery numbers?

**CEO**
: By region or - a total of 38,300 trucks in the first quarter.

**Analyst-5**
: Okay. Okay. Thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Joel Tiss with Bank of Montreal.

**CEO**
: Good morning, Joel.

**Analyst-6**
: Hey, how its going?

**CEO**
: Great.

**Analyst-6**
: That was a beautiful quarter.

**CEO**
: Thank you.

**Analyst-6**
: Is your European share gain, do you think thats going to continue, or do you think the growth for the foreseeable future is going to be more or less in line with the market growth?

**CEO**
: I think our growth will be in line with market. And if you look over the last 15 years, weve sort of gone from less than 10% to up to 16% last year being a little bit of an anomaly with the Euro 5 noise in the market. So, I think the 15.5% is about where we expect to see the year and hopefully, well continue to grow and build on that base, as we go forward in the years to come.

**Analyst-6**
: Are we going to see any tax rate benefit from the mix shift, maybe a little more Europe coming in the future?

**CEO**
: Yes, there could be tenths of a point, but its not going to be significant.

**Analyst-6**
: It wont be meaningful.

**CEO**
: Yes.

**Analyst-6**
: Great. Thank you so much.

**CEO**
: Thank you, Joel.

**Operator**
: Your next question comes from the line of Steven Fisher with UBS.

**Analyst-7**
: Thanks. Good morning.

**CEO**
: Good morning.

**Analyst-7**
: Im not sure if this is what youre exactly answering Andy Kaplowitz before. But how sustainable do you think this level of parts margin is? And what were the biggest contributors to the mix in there that you mentioned?

**CEO**
: The mix is primarily just a higher mix of proprietary and PACCAR brand and product compared to maybe all mix versus vendor product line. So thats the mix side of that. And 4%, we expect the year to be somewhere in the 2% to 5% range at current exchange rates.

**Analyst-7**
: Okay. But the 18.5% margin that you did in the parts business is the sustainability of that?

**CEO**
: Yes, I think we see that the parts margins as we go forward in the succeeding quarters would be comparable to first quarter level.

**Analyst-7**
: Okay. And then can you just talk about the cadence, the free cash flow over the balance of the year, and I think the CapEx you might be ramping up from the $55 million in the first quarter, but would you see some offset there to get your free cash flow posted your net income level?

**CEO**
: Yes, I think we will see an acceleration of capital spending, as we progress through the year, but wont be dramatic. And so, yeah, we continue to generate strong operating cash flow and well see a pretty normal, as we progress through the rest of this year.

**Analyst-7**
: Okay. Thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Tim Thein with Citigroup.

**Analyst-8**
: Great. Thank you. Good morning.

**CEO**
: Hi, Tim.

**Analyst-8**
: Ron, the first one is just on actually two on Europe. As you - as we kind of exit 2015 based on the way that you expect the market to play out, where would you think whoever you expect to be in terms of that spread between the average truck price in Europe relative to the higher Euro 6 content, i.e., does that that headwind that you faced in 2014, does that go away, or still not - volume is not high enough to be able to offset the full amount?

**CEO**
: Tim, I think it really depends on the strength of the market and the competitive nature of the market. And its just, its early days. We have seen some very positive signs in the last couple of months in terms of order intake activity in Europe, but well see how things progress. So it will be dependent on level of market demand at that point.

**Analyst-8**
: Okay. And then just again sticking in Europe, did you take your, or did you adjust your parts in a constant currency - on a constant currency basis? Did you adjust your full-year parts sales expectations in Europe on the back of the better freight environment that you mentioned?

**CEO**
: Yes. So I mean, we expect that parts will grow in Europe during the course of this year, because the effects of currency, parts revenue growth consolidate will be somewhere probably in the 2% to 5% range for the year and 4% for the first quarter.

**Analyst-8**
: Okay. Thanks a lot.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Nicole DeBlase with Morgan Stanley.

**Analyst-9**
: Yes, good morning, guys. Nice quarter.

**CEO**
: Thank you.

**Analyst-9**
: So my question is around pricing in Europe. I think that this has alluded a little bit earlier in the call. But can you discuss what youre seeing? Are you seeing competitors get a bit more aggressive with pricing since volume is starting to pick up there?

**CEO**
: No, I dont. I dont see aggressiveness in pricing, and we see pretty consistent pricing with what weve been seeing. And the level of market demand will sort of dictate how things will progress in the pricing side, or progress through the rest of this year. So right now, I would say, its pretty steady.

**Analyst-9**
: Okay, got it. And then just going back to the oil and gas issue, we talked about this on the last call, but Im just curious if you heard any changes, any oil and gas customers that are cutting back on their spend for the year. Anything anecdotally youve heard there?

**CEO**
: No there is nothing significant what we talked about before. I think oil and gas - for oil and gas exploration and production related items, well probably be lower this year, but thats offset by other things other segments of the market. So I think it will be a pretty nominal impact.

**Analyst-9**
: Okay, thanks. Well, I pass it on.

**Operator**
: Your next question comes from the line of Steve Volkmann with Jefferies.

**Analyst-10**
: Hi, good morning. Just a couple of quick clarification, as you said the production of 5% to 7% sequentially, which will be up more, U.S. or Europe?

**CEO**
: Its going to be pretty even across the Board in terms of Europe and North America.

**Analyst-10**
: Okay, thanks for that. And then Im just curious about just your view and Ill take opinion here rather than fact, if you like, but Im curious what you think of the North American cycle, obviously theres a lot of debate there. We do see a little bit weaker Class 8 order number recently and then and alluded to the cancellations thing up a little bit. Is that your view that this is kind of a peak of a cycle, or do you think theres enough demand drivers whatever you might want to list that that could keep this cycle going sort of a couple more years?

**CEO**
: Yes, the economy is good. And as long as the economy continues at good growth pace, I think there will be the need for the movement of goods and that will create demand for freight, and the freight numbers continue to be at or near record levels. So I think as long as that continues and trucks are operating at 90% plus utilization that well see a reasonably good demand for trucks in the foreseeable future.

**Analyst-10**
: Thanks very much.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Jamie Cook with Credit Suisse.

**Analyst-11**
: Hi. Good morning and congrats on a nice quarter.

**CEO**
: Thank you.

**Analyst-11**
: I guess just two questions. One, can you talk about your markets, your opportunity in the U.S. for the sort of back half of the, or I guess, the remaining eight months of the year. One of your peers is out of capacity, your other peer, people are reluctant to buy truck from. So should we, I mean, is it a - do you think as we look at 2015, PACCARs ability to gain share is probably above what you know it is historically just because of the dynamic of the market? My second question, can you sort of talk about whats your lead times are? And then I guess, the other question is just given the - I guess, your approach to managing this cycle, would you rather extend your backlogs at some point you get some visibility into latter half of the year into 2016, or take production up and gain share? Thanks.

**CEO**
: Okay. So from a market share standpoint, obviously were very focused on growing the profitable market share that we can achieve in the market. And we have great products full lineup with the combination of the 2.1 meter cab, the other products that we offer in the - on highway, off-highway. So we have a great product lineup and were looking to grow our share and continue to move that forward. Lead times are very normal. Customers can get a truck within a reasonable window of time. And so were very comfortable with where were at lead times and you have good prospects backlog for the second-half of the year. And then going into 2016, were - that were very vigilant in monitoring orders. Orders come from customers. When they need a truck, well slot it in the backlog, and so we built based on the orders that we have. And so thats been our approach for 110 years, and that will continue to be our approach as we go forward.

**Analyst-11**
: I guess, just one follow-up question, the margin performance and the incremental margins in the quarter were obviously they exceeded my expectations. You guys did a great job. I mean, historically, you play down your ability to achieve sort of prior peak margins. I mean, did this quarter surprise you? How do you think about your ability to get back to prior peak based on the performance you had this quarter and just the overall strength youre seeing in sort of the US and Europe?

**CEO**
: So the prior peak obviously benefited from a very extended backlogs both in North America and Europe. The markets today are still - if you look at Europe, theyre probably 20% to 25% below what they were in 2006-2007 timeframe and here in the North America theyre 10% to 15% below those levels. So yes, we still havent gotten to those kinds of levels and so margins are excellent and the operational efficiency that were able to achieve with our factories has been outstanding and the stability of our build rates is serving us well. So well continue to focus on, continue to move the needle forward and achieving the best operating margins that we can for our shareholders.

**Analyst-11**
: Alrighty, thanks. Ill get back in queue.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Seth Weber with RBC.

**Analyst-12**
: Good morning. This is Emily Mclaughlin on for Seth. Just a couple of questions, given your production guidance for 2Q, can you comment on the growth mix by heavy-duty versus medium-duty within the regions?

**CEO**
: I think it will be similar. Well see growth in both the medium-duty and heavy-duty in the quarter probably of comparable amounts.

**Analyst-12**
: Okay. And then with build rates ticking up as the supply chain continues to meet OEM needs are there any bottlenecks there at this point?

**CEO**
: Supply chain has done just a marvelous job of supporting the ramp-up activities. And the first quarter was very smooth and so the supply base I think is well-positioned to support the industry at this and even potentially higher levels.

**Analyst-12**
: Okay. And then one more if I may. Can you just speak to whats going on in the individual countries in Europe, what youre expecting for the rest of the year there?

**CEO**
: Well, I mean, the UK is our largest market and mentioned in my comments the GDP growth in the UK is very good. And just had the NEC show in Birmingham last week, where DAF was well represented and lots of positive feedback from customers in the UK. We talked about Germany where the trade activity in Germany in the month of March was at the highest level since they have been tracking the mouth [ph] toll statistics, so German freight activity is good. Some of the southern countries Spain and Italy, they really had a very challenging situation with the crisis and in the ensuing couple years but were starting to see some rebounds between Italy, Spain and Portugal. So thats moving forward as well. So the mood in Europe is generally positive as its been in a couple years.

**Analyst-12**
: Thats great. Thanks very much.

**CEO**
: Thank you.

**Operator**
: The next question comes from the line of David Leiker with Robert W. Baird.

**Analyst-13**
: Hi, good afternoon. This is Joe Vruwink for David.

**CEO**
: Good morning, Joe.

**Analyst-13**
: When you see high-end brands like Scania and DAF gaining market share at the high-end of the market, whats your general interpretation of that sort of trend going on in Europe, particularly in the sense that normally if you see the premium brands gaining share, thats a pretty good indication of kind of underlying health in the marketplace?

**CEO**
: I think its a focus on value and in operating efficiency. And DAF really focuses on lowest total operating cost providing a great fuel-efficiency with the PACCAR MX engines, both the MX-11 and the MX-13. The Euro 6 products have performed excellently in the market. So now that were past the Euro 5 transition period, the DAF products are standing tall in the market and very well received by our customers from a value and operational efficiency perspective.

**Analyst-13**
: So there was a question earlier on pricing competition that may or may not be occurring in Europe. Just from your vantage point it may very well be occurring but the customers youre targeting probably arent forcing that issue with you.

**CEO**
: No, its a very competitive market. And its still at 220,000 to 250,000 trucks. Its still 30% below the peak level. So theres a lot of competition to gain customers. But our products and our services stand tall in the marketplace.

**Analyst-13**
: And then one last one, I missed the comment earlier on the strength and parts margins. Are we finally beginning to see more of an impact from PACCAR specific engine parts show up in the mix of the segment, is that whats happening?

**CEO**
: Yeah, so obviously the PACCAR engines have been in Europe for many years and so thats always been there. And were seeing the growth of the PACCAR MX engine at the end of last year. We had 75,000 engines in the market and that will continue to grow again this year. So as time goes on well continue to see that benefit, more and more parts sales supporting PACCAR engines.

**Analyst-13**
: Okay. Great. Ill leave it there. Thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Rob Wertheimer with Vertical Research.

**Analyst-14**
: Hi, good morning.

**CEO**
: Good morning, Rob.

**Analyst-14**
: I wonder, I mean, I had a smaller impact on the transactional offset from currency. I wonder if you can give an overview. I mean, I know you had started assembly of engines here. Then you sort of moved more integrated. I mean, theres obviously a bunch of more that Im not thinking of that youre sending, I guess, from Europe to U.S. I mean, if you could just outline generally what that stuff is?

**CEO**
: Well, were buying blocks and heads, and a lot of components for our plant in Columbus from European suppliers. So a good portion of the material content comes from Europe.

**Analyst-14**
: Perfect, that I figure, is there much outside of engines or no?

**CEO**
: No, that is primarily engine component.

**Analyst-14**
: Okay. Ill follow-up that offline. Thank you.

**CEO**
: Yes, thanks, Rob.

**Operator**
: Your next question comes from the line of David Raso with Evercore ISI.

**Analyst-15**
: Yes, my question is related to currency. I mean, the operational improvement was solid for the quarter, but isnt that currency did help your margins by 60 bps? So somewhat related to the last question that should also be a help to 2Q as well, but can you explain in a little more detail if you could how currency, obviously negative 7% or so for the quarter can still be neutral on EBIT, because the 60 bps help to the quarter is obviously something that helped the quarter. It should have happened for 2Q, maybe even 3Q. But once the currency situation flattens out Im just trying to manage the expectations here a little bit on the margin performance whats really operational versus just currency.

**CEO**
: Yes, most of the effects are operational. I mean, we had - I guess, I mentioned on the profit side the translation effects on our pretax income were largely offset by the effects of the natural hedge that we have with the purchase of components. I dont know that the 60 basis points, they dont recognize that number. So but...

**Analyst-15**
: Well, just to be clear, maybe clarify if I heard incorrectly. $281 million revenue helped to truck and other, correct?

**CEO**
: No, that was a...

**Unidentified Company Representative**
: A decline.

**CEO**
: ...a decline.

**Unidentified Company Representative**
: A decline.

**Analyst-15**
: Well, I mean, helped meaning you take away the revenue.

**CEO**
: Sure.

**Analyst-15**
: But there is no impact on the EBIT. Thats 60 bps help to the margins.

**CEO**
: Yes, its - yes, okay.

**Analyst-15**
: And that should help 2Q as well and 3Q, but just want to think about the cadence of the gross margin guidance. It is 14 then up a little bit, but then only for the year it seems like the second-half is not sequentially improving. Is that partly it, you lose some of the currency help to margin, is that the way to think about it?

**CEO**
: No, as we mentioned for the second quarter, yes, we will see some slight improvement with the higher volumes, the currency impact, assuming a constant currency as were at now well see a similar benefit in the second quarter.

**Analyst-15**
: But then the second-half diminishes a little bit and thats why - Im just trying to manage expectations little bit on, its not gross margins thats going up 14.5, then 14.9 in the back-half, and then to 16. Just being sensitive to the currency is helping the gross margin right now - the operating margin as well.

**CEO**
: It benefitted in the first quarter and well see that benefit, again assuming that consistent with the current the translation rates well see that benefit in the second quarter as well.

**Analyst-15**
: All right, thats great. I just wanted to clarify that. Thank you so much. Bye-bye.

**CEO**
: Yes, sure. Thank you.

**Operator**
: Your next question comes from the line of Alex Potter with Piper Jaffray.

**Analyst-16**
: Hi guys, one housekeeping question here. Could we get the deliveries by region, so Europe, U.S., Canada, and other?

**CEO**
: Sure. U.S. deliveries were 21,400 in 2015 and compared to 16,100 last year. Canada was 3,000 compared to 2,500. Europe was 10,100 compared and 9,300. And Mexico, Australia and other was 3,800 compared to 3,900 last year.

**Analyst-16**
: Okay, excellent. And then, I guess, one last question on pricing. You mentioned that in Europe obviously the trajectory of pricing is going to be dependent upon the strength of the market that competitive position where ultimately it comes down to volume. In North America were obviously seeing very strong volume typically speaking that, I should imply that the OEMs have good pricing pressure, but we havent necessarily seen a big uptick in pricing. I was just wondering if you can comment on what exactly it is you think is going on there. Thanks.

**CEO**
: Well, I think, again its a very competitive market and each transaction is negotiated with the customer and the dealer. And so you reflect what the market conditions are, and so we have great products and get the premium value for what we sell and so thats evidenced by the fact that our operating margins when compared and looked at the competition are the highest in the industry. So you were proud of our product and well look to continue to grow our share profitably.

**Analyst-16**
: Okay, thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Neil Frohnapple with Longbow Research.

**Analyst-17**
: Hi, good morning. A quick question regarding used truck price in North America, what are you seeing in the market? Are you seeing any signs of softening with greater supply coming into the market?

**CEO**
: Id say that the prices are certainly arent going up. Theyre stable compared to where they were a year ago. There are more trucks, but theres also a bit more demand so pricing is very stable. And we see the similar thing in Europe. Prices in Europe were reasonably stable, compared to where they were at this time last year.

**Analyst-17**
: All right, and then can you provide any more color on what youre seeing in the medium-duty market in North America, and your outlook for that business this year relative to heavy-duty?

**CEO**
: So, I think last year, the medium 6 tonne to 7 tonne market was in the 73,000 truck range and we think to 70,000 to 80,000 trucks is a reasonable range for that market for this year. So market is started off with good demand. Weve been able to increase our production of the Peterbilt and Kenworth medium-duty trucks for the North American market and so were...

**Analyst-17**
: Great. And then just one last one, can you provide the MX penetration rate in the U.S. and Canada in Q1? And as follow-up, any way to quantify the percentage in your current order board and just curious if youre on track to get in the 40% range for the full-year outlook like you guys have outlined at Mid-America? Thank you.

**CEO**
: Yes, so the first quarter was about 37% for MX and 40% is very reasonable target for this year.

**Analyst-17**
: Great. Thanks very much.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Ted Grace with Susquehanna.

**Analyst-18**
: Good morning, gentlemen.

**CEO**
: Good morning, Ted.

**Analyst-18**
: I was hoping to circle back the parts. Could you just comment how each region performed kind of U.S., Europe? And I just want to confirm, did you say that FX was a $49 million headwind to parts overall?

**CEO**
: Yes. It was, $49 million is the effect. So both North America and Europe performed very well in the parts business and so the effects of currency is primarily the effect of the euro.

**Analyst-18**
: So for organically Europe more like 10%. Could you just maybe give us...

**CEO**
: So if you add back the exchange rate effect, thats roughly where the growth would have been in 10% range.

**Analyst-18**
: Yes, yes, exactly. Could you just give us a sense for what U.S., what it done versus Europe in the context of that 10%?

**CEO**
: So U.S., North America would be slightly above the 10% and Europe would be slightly below.

**Analyst-18**
: Okay, okay. And then the other thing I just wanted to ask you, Ron, if you take out your long-term crystal ball and you think about PACCARs vertical integration looking up five or 10 years, how would you kind of frame what PACCAR will look like on that basis, looking that far out?

**CEO**
: I mean thats - weve got an excellent business model that serves us well, we obviously a little bit more vertical integration in Europe, where we make axles, we buy axels in North America. So we have the flexibility. And from time to time, we will evaluate what level of vertical integration makes sense for our company but I think we are very comfortable with where we are at currently and I dont see any major revisions to how we manage that and positioned ourselves in the marketplace in the near future.

**Analyst-18**
: In the near future, but I mean is there potential to see some type of step function improvement looking out 5 years or 10 years, or is that the wrong way to think about the business?

**CEO**
: Anything can happen, but I would say at this point were pretty comfortable with the structure as we have it today.

**Analyst-18**
: Got it, okay. Well, congratulations again and best of luck this quarter, guys.

**CEO**
: Yes, thank you.

**Operator**
: Your next question comes from the line of Scott Group with Wolfe Research.

**Analyst-19**
: Hi, good morning. This is...

**CEO**
: Good morning, Scott.

**Analyst-19**
: Hi, good morning. This is actually Reena Krishnan sitting in for Scott Group.

**CEO**
: Okay.

**Analyst-19**
: So most of our questions have been answered. Maybe just a follow up on that question related to vertical integration, I guess, you guys mentioned youre comfortable where things are. Does that mean you havent thought about maybe looking at where you could be with the medium-duty market in terms of more vertical integration? Or is it just something you dont want to talk about at this moment, if you guys feel comfortable just giving some color there?

**CEO**
: Yes, I think weve got great medium-duty products, but obviously out over the years we continue to invest in all of our products and we will continue to make enhancements to heavy-duty, medium-duty engines, components, work closely with our major suppliers around the world to provide us customized products that integrate with our componentry to provide outstanding operating solution for our customers. And so I think well continue to have an ongoing investment program that will continue to move the needle forward for us.

**Analyst-19**
: Okay and then just one last follow-up related to fleet expansion. Could you guys maybe give us some color in terms of what you are hearing from your fleets as it relates to fleet expansion this year versus last year? Would you say its at a similar level or is it accelerating, again just in the context of where the driver situation is and where capacity could probably be for the industry?

**CEO**
: In think its a similar state of affairs for our customers that they are all making very good of profits in their business reinvesting in new trucks and expanding their fleet I think both strategically and tactically. So, this is really just the second year where weve had expansion after five or six years of below replacement level demand. So I think our customers are enjoying good rates, good profitability and thinking about their business expansion plans in a pretty aggressive way.

**Analyst-19**
: Okay, great. Thank you for your time.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Mike Shlisky with Global Hunter Securities.

**Analyst-20**
: Good morning.

**CEO**
: Good morning.

**Analyst-20**
: You had mentioned in your release that your key plants are producing at record levels and it sounds like youll have probably another record coming up here in Q2. Is there a way you can kind of quantify for us just how close you are in your max levels and are there any break-points where you had that additional shifts which may impact margins above a certain volume level going forward?

**CEO**
: Were in great position capacity-wise. We have lots of capacity to support higher production levels in North America, Europe and around the world, so were in great shape capacity-wise.

**Analyst-20**
: Great, thanks. And just to kind of follow up on that, could you maybe just tell us a little bit about are you constrained at all with your people at your facilities? Are they at some point maxed out, where youre going to have to hire some additional folks who might be less experienced to handle additional volumes?

**CEO**
: As we go up in volumes, we have provided great opportunities for people that live and work around our factories. We are a great employer. We have a great working environment, and so when we solicit applications for people to join our company, we always get many more than the number of openings. So filling open positions for our factories is something that obviously takes time and effort and a lot of focus to get the right people, but lots of supply to support the demand that we have.

**Analyst-20**
: Super. Great quarter. I appreciate you guys.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Michael Feniger with Bank of America.

**Analyst-21**
: Hey, guys, this is Mike, just filling in for Ross Gilardi. Just a quick question, the U.S. market has been on a gradual upward trajectory, orders have been strong in Q4. Theyre trying to - they came back a little bit in March. Whats your view, the biggest risk to get to the bottom end of your forecast?

**CEO**
: It would be the economy. I mean, if the economy softens substantially in the second quarter, things dont progresses as economists project. That clearly is the thing that has the biggest impact on our business. So the economy is good. I think you will continue to see good demand. When you look at the products that we continue to enhance, youve got connected truck capability. Youve got the predictive cruise control capability for our products. And so, the attractiveness in the operating benefits that customers can get with current products that we will be introducing into the market in the second-half are very attractive propositions for them.

**Analyst-21**
: Thanks, guys.

**CEO**
: Thank you.

**Operator**
: [Operator Instructions] There are no other questions in the queue at this point. Are there any additional remarks from the company?

**CEO**
: I would like to thank everyone for their excellent questions and thank you operator.

**Operator**
: Ladies and gentlemen, this concludes PACCARs earnings call. Thank you for participating. You may now disconnect.