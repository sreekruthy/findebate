## Financial Earnings Call


### Prepared remarks
**Operator**
: Good day, ladies and gentlemen, and welcome to the First Quarter 2014 Cummins Incorporated Earnings Conference Call. My name is Steve, and Ill be your operator for today. At this time, all participants are in a listen-only mode. We will conduct a Q&A session towards the end of this conference. (Operator Instructions) As a reminder, this call is being recorded for replay purposes. Now, I would like to turn the call over to Mr. Mark Smith, Vice President of Investor Relations. Please proceed, sir.

**CTO**
: Thank you, Steve, and good morning, everyone, and welcome to our teleconference today to discuss, Cummins results for the first quarter of 2014. Participating with me today are our Chairman and Chief Executive Officer, Tom Linebarger; our Chief Financial Officer, Pat Ward; and President of our Engine Business, Rich Freeland. Well all be available for your questions at the end of the prepared remarks. Before we start, please note that some of the information that you will hear or be given today will consist of forward-looking statements within the meaning of the Securities Exchange Act of 1934. Suchstatements express our forecasts, expectations, hopes, beliefs and intentions on strategies regarding the future. Our actual future results could differ materially from those projected in such forward-looking statements because of a number of risks and uncertainties. More information regarding such risks and uncertainties is available in the forward-lookingdisclosure statement in the slide deck and our filings with the Securities and Exchange Commission, particularly the Risk Factors section of our most recently filed Annual Report on Form 10-K and any subsequently filed quarterly reports on Form 10-Q. During the course of this call we will be discussing certain non-GAAP financial measures and we refer you to our website for the reconciliation of those measures to GAAP financial metrics. Our press release with a copy of the financial statements and a copy of todays webcast presentation are available on our website at www.cummins.com under the heading of Investors and Media. Now, Id like to begin with our Chairman and Chief Executive Officer, Tom Linebarger.

**CEO**
: Thank you, Mark, and congratulations on being a Vice President. I know it must be those thrilling disclosure statements that got you that promotion. Good morning everybody on the call. Ill start with a summary of our first quarter results and provide an update on our outlook for the full year. As usual, Pat will then take you through more details of both our first quarter financial performance and our forecast for the year. Revenues for the first quarter were $4.4 billion, an increase of 12% compared to the first quarter of 2013. First quarter EBIT was $528 million or 12% of sales, compared to $437 million or 11.1% in the same quarter last year. We delivered incremental EBIT margins of 19% driven by stronger performance in the components and engine businesses, as well as demand improved in on-highway markets in North America and China. Engine business revenues increased by 11% year-over-year and EBIT improved 200 basis points to 10.5%. The components business delivered record quarterly revenues and earnings as sales increased 21% and EBIT margins increased by 190 basis points to 13.6%. Both businesses demonstrated that as end markets improve, we can deliver strong incremental margins. And as Pat will discuss later, we have raised our outlook for both businesses for the year. Revenues in the Distribution segment increased 22% in the first quarter, but earnings declined year-over-year due to the negative impact of currency movements, costs associated with distributor acquisitions and IT infrastructure investments. EBIT for the quarter was 8%. We will still see earnings growth in subsequent quarters as the pace of distributor acquisitions accelerates and acquisition related costs are spread over a larger revenue base. End market demand in North America is improving, which will also contribute to increased earnings. We are on track with our plan to acquire our North American distributors and we expect to deliver incremental revenues of at least $400 million and add earnings per share of between $0.20 and $0.25 this year from the acquisitions consistent with our prior forecast. Our guidance for the segment remains unchanged, with full year revenues expected to grow between 22% and 30% and EBIT to be in the range of 9% to 10%. In the Power Generation business, revenues declined by $107 million or 14% due to lower revenues in India and North America. Gross margins improved 10 basis points year-over-year despite the revenue drop, but gross margin dollars declined. EBIT margin declined from 6.8% to 3.9% due to the reduction in volumes and the negative impact of currency movements, particularly the appreciation of the UK pound against the U.S. dollar. We do expect revenues to increase in the second quarter with demand improving in North America, China and the Middle East. For the full year, we still expect revenues to be flat year-over-year, but we now expect EBIT to be in the range of 7% to 8%, lower than our previous forecast, due mainly to the impact of the stronger pound. Now, I will comment on some of our key markets starting with North America. Our revenues in North America grew 25% in the first quarter and as a result of improving demand, we are raising our full year outlook for most on-highway markets. Shipments to the North American heavy-duty truck market exceeded 22,000 units in the first quarter, an increase of 18% from 2013 levels. First quarter market share was 40%. We now expect the full year market size to increase by 12%, up from our previous forecast of an 8% increase. We still expect our full year market share to be at 38%, unchanged from our previous guidance. In the medium-duty truck market, we delivered more than 19,000 engines in the first quarter, up 74% from a weak quarter last year, following the implementation of the EPA 2013 emissions regulations. We now expect the market to grow by 9% for the year, up from our previous expectations of 7% growth. Our market share improved to 66% in the first quarter and we expect to achieve full year market share of 70%, consistent with our prior forecast and 7% higher than 2013. Shipments to Chrysler increased by 31% in the first quarter, compared to a very weak quarter a year ago when demand was low due to Chryslers model year changeover. We expect that for the full year shipments will increase 5% compared to 2013, up from our previous forecast that shipments would be flat. Power Generations revenues declined in North America by 11% year-over-year. In the first quarter of 2013, we experienced very strong orders for data centers, which did not repeat in the first quarter this year. Power Generation order rates increased during the quarter and we expect stronger revenues in North America in the second quarter. Our international revenues were flat year-over-year with growth in China and Europe offset by declines in India, Australia, Mexico and Brazil. As I will discuss, we are raising our full year outlook for China and lowering our forecasts for India and Brazil. First quarter revenues in China including joint ventures were $720 million, an increase of 21% year-over-year. The growth was driven primarily by stronger demand for engines and components in on-highway markets. Industry demand for heavy and medium-duty trucks in China increased by 12% for the first quarter as demand remained strong ahead of the expected transition to the NS4 emission standard. In the first quarter OEMs increased the production of NS4 compliant vehicles to between 15% and 40% of total output depending on the OEM. The variation in build mix between OEMs reflects their specific strategies in target segments, as well as general market uncertainty regarding both the extent of enforcement of the new regulations and the strength of end-user demand for the new vehicles. Some OEMs including Dongfeng are actively promoting the transition to NS4 product. However, it appears that the OEMs that have ramped up their production of NS4 vehicles more aggressively have lost their market share. Last week, the Ministry for Industry and Information Technology, MIIT, published a directive that sales of NS3-compliant vehicles must cease by the end of this year. This is a positive development and clear plans for strict enforcement of regulations have not been shared. With the deadline for sales of NS3-compliant vehicles now set it would be logical to assume the demand for NS3 vehicles will remain strong for the remainder of this year. But with OEMs already having shifted a significant proportion of production to NS4 vehicles, its not yet clear how overall industry demand and OEM production will play out in the second half of the year. Overall demand in the first quarter did exceed our original expectations and our current forecast assumes that industry demand is flat for the year, an improvement from our previous forecast of a decline of 7%. Our shipments of light-duty engines in China more than doubled year-over-year as our partner, Foton, increased the proportion of its trucks powered by the 2.8 liter and 3.8 liter engines manufactured in our BFCEC joint venture. Demand for power generation and construction equipment is expected to grow by less than 5% for the year, consistent with slower growth in the economy and unchanged from our view three months ago. First quarter performance was consistent with our full year view. Overall, full year revenues in China including joint ventures are now expected to grow 15% for the year, up from our previous guidance of growth of 11%. First quarter revenues in India, including joint ventures were $385 million, down 25% year-over-year due to weaker demand across most end markets as the economy remains very weak. Industry demand in the truck market declined 7% in the first quarter, compared to the first quarter last year, but did rebound from very low levels in the fourth quarter of 2013. We expect the truck market to be flat for the full year, unchanged from our view three months ago with much easier comparisons to come in the second half of the year. Power Generation revenues in India declined 46% in the first quarter. Demand in the first half of 2013 remained strong due to power shortages, but weakened significantly in the second half of 2013 as the economy slowed. Demand remained weak in the first quarter this year. The implementation of new emissions regulations in the Power Generation market called CPCB II were delayed from April 1 to July 1, pushing back sales of higher value products for Cummins. For the full year, we now expect Power Generation revenues to decline by 15%, down from our previous expectations that revenues would be flat. In total, we now expect revenues in India to decline by 8% for the year, compared to our previous forecast that revenue would be flat. First quarter revenues in Brazil were $183 million, down 11% from the first quarter last year. Business and consumer confidence in Brazil has weakened as the economy has slowed, hurting demand for capital goods. Industry production of trucks declined 19% in March, as orders slowed and OEM inventory levels increased. In order to reduce inventory, a number of OEMs are playing shutdown from second quarter that will lead to a sharp reduction in industry production. We now expect that the full year truck market could decline by as much as 20%, compared to our previous forecast that industry production would be flat compared to 2013. We now expect our full year revenues in Brazil to decline by 15% due to the weaker truck demand. In summary, we currently expect company revenues to increase between 6% and 10% for the full year, up from our previous forecast of between 4% and 8%. The increased forecast reflects stronger demand in North America and to some degree, China. Within international markets, our improved outlook for China should offset weaker demand in India and Brazil. We expect EBIT to be in the range of 12.75% to 13.25%, consistent with our prior forecast. We have said in previous quarters that as end markets improve, we expect to deliver strong incremental margins. Im pleased that in the Engine and Components businesses, weve clearly demonstrated our ability to grow margins as demand increased in the first quarter. We are on track to deliver the benefits associated with the distributor acquisitions in North America and we expect that as demand in Power Generation improves and we complete our restructuring actions, we will demonstrate clear improvement and profitability. Thank you for your interest today and now Ill turn it over to Pat, who will cover our first quarter results and full year guidance in more detail.

**CFO**
: Thank you, Tom, and good morning everyone. First quarter revenues were $4.4 billion, an increase of 12% from a year ago and much stronger than we anticipated three months ago. Including demand in on-highway markets in North America and in China and the better than expected start to the year in Europe, resulted in higher than expected revenues in both the Engine and Components segments. North America sales, which represented 56% of our first quarter revenues, were up 25% from a year ago, primarily as a result of higher demand in on-highway markets along with the impact of acquisitions in the Distribution segment. International sales were flat with continued weakness in international power generation markets and negative foreign currency movements offset by growth in our Components segment. Compared to the fourth quarter of 2013, sales were down 4%. The decrease was driven by lower demand in global power generation markets, which impacted both our Power Gen and Distribution segments, as well as expected weakness in European and North American construction demand after their transition to Tier 4 Final emission standards from the 1st of January. Gross margins were 25.3% of sales, up almost 1% from last year. The improvement was driven by stronger volume and lower warranty and material costs, partially offset by unfavorable foreign currency movements, primarily related to the British pound, the Brazilian real and the Australian dollar. Compared to the previous quarter, despite the lower revenues, gross margins as a percent of sales remained relatively flat. Selling, admin and research and development costs were up $66 million from the prior year, but were lower as a percent of sales. The acquisitions in our Distribution segment accounted for $18 million of this increase. Compared to last quarter selling, admin and research and development costs increased by $11 million. Joint venture income of $90 million was up $8 million compared to a year-ago and up $10 million compared to the prior quarter. The year-over-year increase was driven by contributions from joint ventures in China where truck demand was higher compared to the first quarter of 2013. Earnings before interest and tax were $528 million or 12% of sales. This compares to 11.1% of sales last year, reflecting a 19% incremental EBIT margin. Foreign currency movements negatively impacted EBIT margins by 30 basis points compared to the first quarter of last year. Compared to the fourth quarter, EBIT margins decreased by 30 basis points from the lower revenues. Earnings per share in the quarter were $1.83, compared to $1.49 a year ago, an increase of 23% with a tax rate of 29.9% in the quarter including discreet items. Lets move on now to the operating segments and further discuss the first quarter performance and the outlook for the full year. In the Engine segment, revenues were $2.6 billion, an increase of 11% over last year. The increase was driven by strong demand in North American on-highway markets, partially offset by a 15% decrease in high-horsepower revenues primarily related to weak mining and power generation markets. On-highway revenues were up 24% compared to the prior year as a result of the increased demand in North America. Compared to the prior quarter, sales were flat. Sequentially, we experienced stronger demand in North American on-highway markets, offset by lower demand for construction and agriculture engines in North America and in Europe as the industry transitioned to Tier 4 Final standards. Segment EBIT was $269 million, or 10.5% of sales, up from 8.5% last year as a result of the higher volumes and more material and more product coverage costs. Sequentially, margins improved by 140 basis points. For the full year, we now expect revenues to be up 6% to 8%, higher than our original guidance of 4% to 6%. Increased demand in North American on-highway markets will more than offset the weakness that we are seeing in Brazil. We continue to expect industrial revenues to be flat in 2014 and high horsepower volumes will be flat to down 10%. EBIT projections for the full year remain unchanged at 10.5% to 11.5% of sales. The Components segment reported record sales of $1.2 billion and a record EBIT margin of 13.6% in the quarter. Revenues were up 21% from last year and up 8% from last quarter. Compared to the prior year and the prior quarter, the higher revenues were primarily driven by increased demand in North American and Chinese on-highway markets, along with increased demand for aftertreatment systems in Europe post transition to Euro 6 standards on the 4th of January this year. Segment EBIT was $167 million, or 13.6% of sales, up from 11.7% last year, as a result of the stronger volumes and lower material costs, which offset a negative impact to margins from foreign currency movements. Selling, admin and research and development cost grew at a slow rate in sales, positively impacting margins by 150 basis points. Compared to last quarter, EBIT margins increased 130 basis points, or an 8% increase in sales. The sequential increase in margins was driven by higher volumes and lower credit coverage costs. We now expect revenue growth of 10% to 15% this year, higher than our previous guidance of 8% to 12%. The increase is a result of stronger demand for all four businesses in North American truck markets and in China where we expect truck production to be flat in 2014 compared to our previous projection of down 7%. We are raising our EBIT projections for the full year to 12.75% to 13.75% and this compares to our full year 2013 margin of 12.1%. In the Power Generation segment, first quarter sales were $639 million, down 14% from last year and 16% lower than last quarter. Year-over-year, we saw weakness in North America and international markets, particularly in India, which was down 46%. Sequentially we saw lower demand in most markets with North America down 21% and international revenues down 13%. EBIT margins were 3.9% in the quarter down from 6.8% last year. The lower volumes had a significant impact in margin performance and foreign currency movements, primarily a stronger British pound negatively impacted margins by 110 basis points. EBIT margins were lower than those reported in the fourth quarter by 220 basis points as a result of the lowered volumes and the negative currency movements. For 2013 we continue to expect sales to be in the range of minus 3% to plus 3% and we are lowering EBIT projections for the full year to a range of 7% to 8%, mainly due to the impact of the unfavorable foreign currency movements. For the Distribution segment, first quarter revenues were $950 million, an increase of 22% compared to the prior year. Acquisitions accounted for 21% of the growth year-over-year. Organic growth was 6%. However, unfavorable foreign currency movements lowered segment sales by 5%. The organic growth was driven by strong service demand especially in North America, compared to last quarter, revenues declined by 11% or 15% excluding the acquisitions. Standard North American service demand was more than offset by weakness in global Power Generation markets. EBIT margins for the quarter declined from 12.2% last year to 8% due to the negative impact of foreign currency movements, which impacted margins by 200 basis points and also from the costs associated with distributor acquisitions and IT infrastructure investments. Compared to last quarter, margins declined by 250 basis points, as a result of the foreign currency movements and the dilutive impact of acquisitions on the EBIT percent. For 2014, we continue to forecast revenue growth of between 22% and 30% over last year, with 3% organic growth and the balance from acquisitions, and we expect EBIT margins to be in the range of 9% to 10%. Our North American acquisitions remain on track to add $400 million of revenue to Cummins in 2014 and earnings of between $0.20 to $0.25 per share. As Tom mentioned, we now project total Cummins revenues to be up 6% to 10% in 2014, driven primarily by improving North American on-highway demand and the impact of distribution acquisitions. We continue to expect higher horsepower markets to be flat to down 10% this year, and total industrial markets to be flat, which is consistent with what we saw in the first quarter. We are increasing our expectations for revenue growth in North American on-highway markets. We continue to see weakness in a number of international markets. We have lowered our expectations for truck production and reserve for 2014, and see no signs of demand improving this year in India. We now expect the joint venture income will be flat when compared to 2013. This is an increase from our previous guidance of down 10% and is driven by increased expectations with truck production in China, which Tom discussed earlier, along with strong performance in our North American distribution channel. We continue to project EBIT margins for the Company will be in the range of 12.75% to 13.25% of sales, compared to 12.5% last year. We remain focused on driving improvements in our gross margin in 2014, particularly for more material cost and from our supply chain initiatives. The full year tax rate is projected to be 28.5%, excluding any discrete items and our tax rate guidance does not assume that the research and development tax credit is extended into 2014. Finally, with regards to cash flow, we produced $263 million in cash from operations in the first quarter, lower than the amount we produced last year as a result of an increase in working capital associated with higher revenues and an increase in our pension contributions in the quarter. We continue to expect our operating cash flow to be in the range of 10% to 13% of sales for the full year. As expected, our cash and marketable securities balance decreased by over $500 million in the quarter. This reduction was driven by $419 million outlay in share and repurchases as well as from the acquisition of a North American distributor. The Company returned $534 million of cash to shareholders in the first quarter, including the repurchase of 3 million shares consistent with our commitment to return 50% of operating cash flow to shareholders. And finally as we discussed in our last call, we still expect to invest $700 million to $800 million on capital expenditure projects this year and between $400 million to $500 million related to the previously announced acquisition of the North American Distribution channel. Now let me turn it back over to Mark.

### Q&A
**CTO**
: Thanks Pat and Steve. We are now ready to move on to our question-and-answer section. I would request that everybody try to limit yourself to one question and one related follow-up and then please get back in the queue. Okay, we are ready to proceed, thank you.

**Operator**
: (Operator Instructions) Please standby for your first question and its from the line of Alex Potter. Please go ahead, Alex.

**Alex E. Potter – Piper Jaffray & Co**
: Hi, guys good quarter. I guess first of all just starting off on India. It sounds like they have got a couple of people out there starting to make some incrementally more positive comments on (indiscernible) demand in India. It sounds like you guys are seeing that. What do you think about that?

**CEO**
: Yes. Alex I would just say that it's way too early to call the turnaround in India. We obviously have a bullish medium to long-term outlook on India. We think there's a lot of positive trends in the country about developing middle-class and all the other things we have talked about before at our Investor Day. But short term the economy is in pretty bad shape. They have got budget deficits. They have got a divided government. The elections aren't even complete. I don't think they finish for another couple of weeks, counting of the votes. There is still quite a bit of turmoil. So there's no direct action from the government to resolve some of the critical issues. Road building's slowed to a halt. A lot of the things that were going well have really slowed down over last year, not to mention, just the basic macroeconomic effect. So our view is it's too early to call, and as you mentioned, our results are pointing out that things have definitely not turned around. If anything, we should see some stabilizing and given the comparisons in the second half, we will see some improvement I think, but that's just because the second half comparisons are so much weaker.

**Alex E. Potter – Piper Jaffray & Co**
: Okay fair enough. And then I guess, secondly on restructuring in Power Gen, if you could just give an update there, where do we stand, when do you think you start to see some positive I guess margin normalization as a result of restructuring in Power Gen? Thanks.

**CEO**
: We do expect that to be largely done with the restructuring that we talked about by the end of this first half. So the second half, we'll begin to see results. We've done significant restructuring in the large alternator business. We've reduced headcount in our European operations there and also moved some of our production into lower cost plants. So we've done quite a bit of work. It's taken a long time. And unfortunately volumes have been slipping away, while we've been taking actions, making the incremental benefit of those each step of the restructuring seem less good, because each time we make steps, the volume slips lower. But we do expect those actions to be done by the first half and to begin to see improvements in the second half. As again, what we hope is that volumes stabilize and then begin to improve. If they do, we'll see significant improvements in margins in Power Gen. We have lowered our costs. We are positioned well to ramp up. Our plants very low utilization today, almost across the board in Power Gen and as volumes start to ramp up, we'll see benefits.

**Alex E. Potter – Piper Jaffray & Co**
: Okay, very good, thanks a lot.

**Other**
: Alex, just a quick follow-up, you didn't ask on the India piece. Tom mentioned, we've got a lot of capacity there, because we invested in aftermarket sales, but part of our gross margin improvement you're seeing is, we're utilizing those plants to export more and more product. And so, be it on Engines, Components, in the turbo area or even from a technical standpoint, getting more of our engineering capability out there. So, we've been able to use the investment we've made there to apply it to the rest of the business.

**Alex E. Potter – Piper Jaffray & Co**
: Okay, interesting. Thanks a lot.

**CEO**
: Thanks Alex.

**Operator**
: And your next is from the line of Jamie Cook. Please go ahead, Jamie.

**Jamie Cook – Credit Suisse Securities LLC**
: Hi good morning.

**CEO**
: Hi Jamie.

**Other**
: Good morning.

**Jamie Cook – Credit Suisse Securities LLC**
: Just a couple of questions. Just on the new Engine guidance, I'm surprised we're not taking our margins up, given the revenue increase. Is that just sort of high horsepower? Can you just talk through the puts and takes of that or do you see that high end is more likely? And then on the Power Gen side, you talked a little bit, I think about, it sounds like order trends might be improving in North America, can you just give a little more color on what you're seeing  what you've seen post, the first quarter in terms of order trends in any particular markets? Thank you.

**CFO**
: Yes, so we left the Engine segment margin consistent with the previous guidance of 10.5% to 11.5%. We did 10.5% in the first quarter, Jamie. We are expecting to see improvement as we go through Q2 through the end of the year, but at this stage, it's still a little bit premature to think about increasing that. As Tom mentioned, we are a little bit uncertain about how China is going to play out in the second half of the year. That was a big help to Richard's business in the first quarter. So at the moment we are fine with 10.5% to 11.5% and we will see how things are three months from now.

**CEO**
: It is true what you said about high horsepower. We are seeing mining decline further on the negative side and we are  but we are seeing of course North America stronger, China stronger and marine markets stronger. But there are some puts and takes even within the...

**Jamie Cook – Credit Suisse Securities LLC**
: How much worse was mining in the quarter relative to last?

**CFO**
: 28% in revenues.

**CEO**
: Down 28% in compared costs.

**CFO**
: Yes. Down 28, units were a bit more than that.

**Jamie Cook – Credit Suisse Securities LLC**
: Okay.

**CEO**
: And you see there is further deterioration again. Fortunately, marine  commercial marine has come back a little bit so that's helping a little bit. Generator is still weak, so in high horsepower we are still not really improving much. It's really been in the truck side that we are seeing improvement both in China and North America. On the Power Gen side can you do your question one more time?

**Jamie Cook – Credit Suisse Securities LLC**
: No. I just wondered, if you could give a little more color or just on order trends with the optimism around them as sort of improving and then just what you are seeing in the emerging markets?

**CEO**
: Yes. We just saw orders increase through the quarter. So we saw orders step up each month. January was very low, which again is not atypical for Power Gen to get seasonal low orders in January. And then during the quarter they picked up and so that's why we feel confident that second quarter revenues will improve for Power Gen North America. We also saw some improvement coming in China and in the Middle East. Again all those are against the backdrop of pretty weak markets. That so it's not that things are booming or anything. But we definitely saw improvement through the quarter and so we believe we will see revenues step up. Some places that aren't really stepping up yet, I mentioned big project markets or the big, large rail markets, stuff like  business that Aggreko is in. They're a very large customer of ours, big projects that we sell those large alternatives, so those really aren't improving still, and again we do expect them to at some point, but I think that's a function of, sort of, general economic improvement in markets outside the U.S.

**Jamie Cook – Credit Suisse Securities LLC**
: And sorry, I hate to ask this, but did you have any weather impact in the quarter on the quarter or in terms of order trends or anything like that?

**CEO**
: I can't speak so much to order trends. I can't say logistics costs were higher. We definitely saw some increase in logistics costs due to weather and trucking around the U.S., I talked to quite a few people and that seems to be a pretty common theme, logistics costs were higher due to bad weather.

**Jamie Cook – Credit Suisse Securities LLC**
: Are you willing to quantify that or not?

**CEO**
: I'm not unwilling, I'm just unable to quantify at this point, but I know, Mark will have some figures for you, he can share with you.

**Jamie Cook – Credit Suisse Securities LLC**
: Okay great, thank you.

**Operator**
: And your next question is from the line of Adam Uhlman. Please go ahead.

**Adam Uhlman – Cleveland Research Co. LLC**
: Hi, guys good morning.

**CEO**
: Good morning Adam.

**Adam Uhlman – Cleveland Research Co. LLC**
: Can we talk through the China NS4 transition a little bit more. I guess I'm trying to understand better how difficult it would be for OEMs to switch back to NS3, if they feel like they have a little room to sell more of those trucks and if there's any risk to the Components guidance from that?

**CEO**
: Yes, so they definitely can switch their production at least until the end of the year. It seems like they can do it largely at their choice. There's a couple of problems. One is that some of the cities are requiring NS4. And so depending on how vehicles are registered, that impacts the customers' demand. Second thing is that many of the OEMs have put in significant investments in technology Dongfeng included, I mentioned them, but many of the others as well have put in significant investments, and therefore they'd like to use those investments, and they of course have launched new products with good features and good capabilities and they'd like to get the new customers to see those features and buy those features and so, they have in part what is a regulatory issue to deal with and in part, which is just new vehicles, new capabilities kind of moving the technology of the market up and since they've made the investment, they'd like to transition the customer. So, they have a vested interest frankly in moving production to NS4, but as I mentioned in my remarks, the market is still uncertain as to how quickly that uptake is going to be, how many customers are willing to pay for the new features as well as the other benefits and yet have to pay for the emissions technology and the enforcement techniques even after the end of the year are not clear. The government has talked about enforcement techniques they're going to use in the past. We just haven't seen much practical, on the ground evidence of those enforcement methods yet. So, anyway a lot uncertain, I guess, is what I'd say to you. With regard to Components forecast, clearly, we have components content that we're selling on NS4 that we're not selling on NS3. We do have significant components content on NS3 too, but we won't have aftertreatment on NS3. So that it will affect our forecast depending on how big of a change it is. Remember, we have a pretty conservative ramp up forecast for the year. So I think the downside risk to our emissions related equipment forecast for China isn't very large. Right now, it's looking better than we planned, but there's not much  I don't think there's a big upside potential given the way I'm seeing things play out and there's not a big downside either.

**Adam Uhlman – Cleveland Research Co. LLC**
: Got you, thank you. Thats very helpful. And then, I might have missed it, but Pat, could you walk through the currency impact to sales and profits for the quarter and then what's embedded in the guidance for the year? Please.

**CFO**
: Yes. So for the quarter Adam, year-over-year, currency impacted sales by $90 million, and for the EBIT line of the income statement, impact comes by around $25 million, $26 million. So that's a 330 basis point headwind I did reference to in my remarks. For the full year we are probably looking at somewhere around $130 million to $200 million sales impact year-over-year and somewhere in the region of $80 million to $100 million EBIT impact, thats currency rates (indiscernible).

**Adam Uhlman – Cleveland Research Co. LLC**
: Thank you.

**Operator**
: Your next question is from the line of Nicole DeBlase. Please go ahead.

**Nicole Deblase – Morgan Stanley & Co. LLC**
: Yes, good morning guys. Congratulations on the good quarter.

**CEO**
: Thank you.

**Nicole Deblase – Morgan Stanley & Co. LLC**
: So maybe just elaborating a little bit on what you are seeing in Brazil. I think you mentioned that production there was down 19% in March. I mean, has that decline continued into April or could it get even worse than that due to the inventory issues?

**CTO**
: Well we are seeing  Nicole this is Mark. We are seeing OEMs planning significant shutdowns into the second quarter. I think without commenting specifically on our numbers in April we are expecting a big cut in industry wide production in the second quarter. Then the outlook for the third quarter somewhat uncertain we will keep going on other than how much commercial activity there is going to be. Typically Q3 is seasonally the highest quarter in the year, but it's hard to see that right now. So I think clear move down, not clear what the catalyst for improvement in the short term.

**Nicole Deblase – Morgan Stanley & Co. LLC**
: Okay, got it. Thats helpful. And then just going back to maybe the Engine margins; I know you guys kind of walked through the headwinds, but I mean you guys did do 29% incrementals this quarter which was really very impressive. So I mean what could cause moderation in incremental margins for the rest of the year in that segment?

**CFO**
: Let me start and I will ask Rich to jump in. If you go back to the first quarter of last year Nicole, that was a pretty weak quarter for the Engine segment, especially North America medium duty truck revenues. So that had a significant impact on Q1 last year and maybe the incrementals probably look a little bit better than what they really are on a normal trend basis. Going forward, I think we're looking at 20% incremental EBIT margins for the segment for the rest of the year, and I'll let Rich make any comment he wants to add on to that.

**Other**
: I think that covers it, Pat. Thank you.

**CEO**
: The only thing I would add is, both Rich and I have been out to a bunch of plants this last quarter, and the thing I would say is, our plants are just doing an amazing job of figuring out how to get cost and productivity in weak demand environments. I was at Daventry in the high-horsepower plant, our mid-range plant in the U.K. I was in India, where, again demand  we're at 40% utilization in some of these plants, and these people are finding ways to reduce costs, break-even, even make a little bit of money at 40% utilization. So, as things ramp up, we will make significant incremental margins in the Engine business, there's no question about it. What we just don't know is; what's the ramp up rate, especially outside the U.S., North America? That's the place it looks like it is improving, you see clear trends. Most of the other places in the world, the markets are still not that great. China was good, but again, a lot of uncertainty and a whole bunch of other places, not great. But we do think that those markets will turn around at some point and when they do, our plants are really going to generate terrific incremental margins, and again, we just got a taste of it, but I think in Q1, and we're getting a little bit more of it through the year, but really it's not that strong of our economy in most for Cummins yet, and our hope is that switches around pretty soon and we'll really be able to demonstrate the power of the Company and the Engine business in particular to generate incremental margins.

**Nicole Deblase – Morgan Stanley & Co. LLC**
: Okay thanks Tom, thats really helpful, Ill pass it on.

**Operator**
: Thank you. And your next question is from the line of Jerry Revich, please go ahead.

**Jerry D. Revich – Goldman Sachs & Co.**
: Good morning.

**CEO**
: Good morning Jerry.

**CFO**
: Good morning Jerry.

**Jerry D. Revich – Goldman Sachs & Co.**
: On the new products side, I'm wondering if you could just talk about the expected startup of the Cummins Foton heavy-duty production given the fact that you're seeing some NS4 sales now in the market overall. And then Tom, if you could just touch on any Tier 4 final market share developments that you could talk about. I know you were optimistic about a few more releases. How is that shaping out and how does that factor into the outlook for your industrial business this year?

**CEO**
: I've got Rich here and I know he's just  he's been following both of those really closely. I'll let him start on those.

**Other**
: So, on the  to start with China, in the ISG product, so we're on track to introduce in Q2, which we've been saying for some time. The ramp up in 2014 is tied to the NS4. So, we think we've got a fairly conservative ramp up through this year, and then, see the big step up will happen in 2015. So product on schedule, reliability on schedule, cost on schedule. Some uncertainty still on the NS4, but we will go into production as planned. Then the second question was on Tier 4. Yes, so we had a bit of a pre-buy than we went through. We're now introducing a product, well, see the big ramp up will be in our high horsepower, where it'll begin to happen. And so, we're excited about that in the sense that we feel we're the one Company that's already demonstrated this technical capability because we've been doing this for almost a decade now in non-highway markets and so, we're excited about that. There's some different technologies being introduced. People are having different solutions and once again, we've played through this before in other markets, be it SCR, not SCR, we like our product, we like our position there as low to high horsepower.

**CEO**
: We were the first, just recently by the way, the first Company to receive Tier 4 certification in the large, the high horsepower power generation equipment. So, just to Rich's point, we are out there first. We have a clear solution. Weve have had on the  at the shows and available for people to see now for some time. So we think customers are ready for this. There is clearly a price premium that people were trying not to pay. So as long as they could find Tier 4 Interim or use credits they did that. It's getting hard now, it's getting harder and harder to do that with Tier 4 Final. So we will begin to see transition to those technologies, and we think we have a good position with regard to our competitors in terms of the quality of the product and people's knowledge of how it works and why it's going to be a better cost of operation for them.

**Jerry D. Revich – Goldman Sachs & Co.**
: Thank you and Pat on the currency, are there any markets where you might be able to offset those headwinds from a transactional standpoint with pricing and then if you could just breakout the impact and distribution of FX versus the acquisition costs that would be helpful?

**Jerry D. Revich – Goldman Sachs & Co.**
: The Distribution business.

**CFO**
: That was about $40 million in revenue and about $20 million on EBIT, so when you compare Q1 to Q1.

**CEO**
: Australian dollar and Canadian dollar were the two biggest hits on the DVU.

**Jerry D. Revich – Goldman Sachs & Co.**
: Thank you very much.

**Operator**
: And your next question comes from the line of Ted Grace. Please go ahead.

**Ted Grace – Susquehanna Financial Group LLLP**
: Hey guys, congratulations on the quarter.

**CEO**
: Thank you Ted.

**CFO**
: Thank you Ted.

**Ted Grace – Susquehanna Financial Group LLLP**
: I apologize if I missed this earlier but in Power Gen, the revenue guidance is unchanged at plus or minus 3%. The operating margin target was reduced 75 basis points. Was that mix or costs or can you just maybe quickly step through what the changes were there?

**CFO**
: Yes, Ted. So this is Pat. Let me take a crack and then if Tom may want to jump in. The major change from taking it down by 0.75 from the midpoint is from currency movements and that's the British pound. So we have a high cost structure in the UK with Power Gen and the strength of the British pound compared to year ago is having a significant impact on the profitability of the segment. There's a smaller impact on restructuring from what we said before on our last call. We're seeing volumes continue to deteriorate in Germany in particular, and that's going to mitigate some of the benefits that we anticipated getting from the restructuring benefits in the second half of the year, but the real driver is the foreign currency impact.

**Ted Grace – Susquehanna Financial Group LLLP**
: Yes.

**Ted Grace – Susquehanna Financial Group LLLP**
: Okay, that's really help and the second part is related. Could you just step through the geographies within Power Gen and kind of help calibrate it for full year expectations? I think you said North America was down mid-teens, but how are you thinking about the North American Power Gen market for the year? And then, same thing for EAME, which I think you said was up in the first quarter and in Asia Pac, which I think you said was up on China?

**CEO**
: Yes, so, its a good question. So, if you just look at longer term trends. North America's been improving. So, North America, even though was down quarter-over-quarter, we had a good group of sales to the data center market last year, so the comparisons were a little worse, but broadly speaking North America's on an improving trend in Power Gen. So, we're seeing good improvement there. The other place we're seeing some improvement is the Middle East. Middle East had a weaker year last year, as lot of the rental companies cut back a lot in the Middle East and we're seeing Middle East kind of steady out and improve. Where we're seeing deterioration is in India, so, India was a significant drop off in the second half of last year and that weakness continues and though we're going to have this transition to a new standard which should increase the price and value of genset, that was delayed. So, what that means as far as transition rates and all that kind of stuff, we're not sure, but it just adds to the weakness of the problem. In Europe, the European market is improving a little bit, but the big downside in Europe, is there's a lot of project kind of work and project companies, Aggreko, I mentioned already, large generator set project companies that we sell to there that are selling across the world in these big projects. They're all doing quite  the revenues are very weak. They're all doing poorly. And they're not buying hardly any equipment and right now, I don't see any improvement in that trend. So, that trend is, it's been bad for a while and it continues to be bad. So, that at least gives you a sense. So, while Europe is fine, generator sets to Europe, it's not a great market. The economy is still pretty weak there, but it's improving slightly. Our European sales that we report include all of these kind of project sales which are not going very well.

**Ted Grace – Susquehanna Financial Group LLLP**
: Okay. That's really helpful. Thanks a lot this quarter, guys.

**Operator**
: And your next question is from the line of Rob Wertheimer. Please go ahead.

**Joe J. O'Dea – Vertical Research Partners LLC**
: Hello, good morning. It's Joe O'Dea on for Rob.

**CEO**
: Hi Joe.

**Joe J. O'Dea – Vertical Research Partners LLC**
: First question is just on NAFTA heavy duty. You took your production outlook up about 3% for the year. But when you frame that against the continued strength in industry orders that we've seen, it seems like there could be more upside. So could you just talk about your order book for Class 8 heavy-duty engines? And is it just more that the recent orders are sort of more spread out and longer dated?

**Other**
: That's a good question. The way we took it up as you said, and the way we are paying attention to it is what's the backlog look like and what's the OEM kind of order board look like and when will they be taking build rates up. So I think where we stand right now is as an industry order boards are in pretty good shape. So there is actually some, not backlog, but some future orders out there kind of in the four to eight week range. So I'd look at it, we will see production better matching what sales are. So you look over the last four or five months, production has been less than sales as these order boards have filled up. They are at a nice healthy rate now, not too big, not too small. And so I think there will be a little less volatility in there, in the production rates given that that's been a steady increase. So we are a little bit behind ACT. ACT is a little bit higher than us, I think 10,000 units and clearly that's a scenario that could happen. There is a scenario for either more upside or downside, but we think we are pretty well matched kind of at a likely rate for right now.

**CEO**
: Just at a broad, in terms of just estimation, if your question is, is there potential strong growth? Of course, there is. But as Rich said weve been in a market that's had some volatility and then it had some brief ups and turns down. So we're just trying to strike the middle of that range and think about what's going to happen next, but we're prepared. We've been working on making sure we have capacity to deal with fluctuations in the market even if orders strengthen quite a bit, to make sure we can supply all of our customers when they need it with the right product. So we're ready for more upside, that'd be terrific. But we maybe estimate that where we think the most likely cases and there's some at risk on either side.

**Joe J. O'Dea – Vertical Research Partners LLC**
: Okay. That's very helpful. And then on the component side, is the sort of adoption curve of technologies trending faster than you had expected in any particular areas? And then specifically, within emissions solutions, the 1Q revenue was pretty strong. Is that a reasonable run rate or was there anything unique in the quarter there?

**CFO**
: I don't think there was anything unique. I think production rates depend on the implementation enforcement of the regulation. So, all the business is planned around the timing of those regulations. So if you went back two years, of course, China is much slower than we thought. If you go back to Power guidance at the start of the year, certainly the first half of the year is a little bit better than we thought. So again, enforcement is going to be the longer term driver of the business beyond the next couple of quarters.

**Joe J. O'Dea – Vertical Research Partners LLC**
: Great. Thank you.

**CFO**
: I think the other thing I'd say is, weve baked in a pretty dire scenario in Europe for emission solutions given the Tier 4 Final emissions regulations and the Euro 6 on-highway regulations. Now it's at least OEM build of trucks not so much construction and a little ahead of what we saw in the first quarter, not so much construction.

**Operator**
: And your next question is from the line of Andrew Kaplowitz, Barclays Capital.

**Andy Alec Kaplowitz – Barclays Capital, Inc.**
: Hey, guys. Nice quarter.

**CEO**
: Thank you.

**Andy Alec Kaplowitz – Barclays Capital, Inc.**
: So Tom, maybe it's a little unfair, this question, but after a quarter like 1Q and given a better North American truck market, are you guys feeling better about your ability to deliver sales in the range you predicted for 2015? Somewhere above that $20 billion number? Again, I know it's early, but you have that guidance out there. So any better visibility as we sit here today, or do we still have to worry about the international markets when it comes down to it?

**CEO**
: Yes, I mean, Andy, you know, I'm the CWO, the chief worrying officer. So, I do quite a bit of worrying about markets, and as I mentioned a little bit earlier, there aren't that many good markets now. There's markets that aren't a disaster and there's markets that are doing better. I mean, the North American truck market is the one market I can say it's actually getting pretty good. Still not a boomer yet; if we were discussing but it's maybe on its way to one; but really, most of the other markets, are not very good. So, again, we'll see what happens from here, but I do believe that if we get some turnaround and just the basic economic growth rates across the world and I think Europe is doing a little better than we thought and U.S. is definitely picking up. If we get some of these other emerging markets to get going, we'll see very, very good growth and then I could comment much better about where we see the end of 2015. Right now, I think it's pretty uncertain about what 2014's going to finish out like and how that sends us into 2015. So, I guess, while I'd love to give you more or less confidence, I'd just right now, I don't feel like I have any more visibility than I did three months ago or six months ago. I do think that we are positioned incredibly well, as I mentioned. Our plants are ready to take the volume. They are working at very efficient and productive levels. Our products are leading in the markets across the world. As they things  as these markets pick up we will grow and we will grow incremental profitability significantly. So I feel very good about that. I'm just having trouble calling is, so when do some of these emerging markets and these other project markets I think start to turn back and that's really difficult for me to say.

**Andy Alec Kaplowitz – Barclays Capital, Inc.**
: So Tom, let me ask you a related question about China then. That's another place that's been very difficult to forecast. It's done better actually for you over the last year. But how do you reconcile sort of the negative macro that we hear pretty regularly on China these days versus your performance here? And how worried are you that things could turn? Because we get that question sort of all the time, and we know you're putting a lot of new products into the market, you're getting share. Is that really the answer, but how much visibility do you have?

**Other**
: Yes, so a couple of things to think about China. One is that the infrastructure growth rates in China have definitely slowed down. And that's why you see construction markets, Power Gen markets start slowing. That has happened and it is definitely happening. You can see it almost everywhere, just number of claims deployed, definitely slowed down. And we really haven't seen significant improvement there. Theyve still got a very robust economy. Right GDP growth rates are still going, very large urban populations that are making products and buying products and things like that. And so that's driving trucking. Trucking is still going and they have a lot of big road infrastructure. They have gigantic logistics costs in the country that they're trying to reduce. So trucking well it is not unrelated. Trucking growth rate can continue even if infrastructure growth rates, things like build out of cities, new factories, et cetera, airport slowdown and that's exactly what we're seeing now. There's also this weird instability in the truck market related to these new technologies and that's kind of an overlay that makes it hard  it creates more noise than signal on the short run about what's going on in the economy. I would just tell you that from our perspective, the Chinese economy is still significantly weaker than it was just a couple of years ago, and that's really at these infrastructure things. Construction equipment sales are way down. Yes, they're up a little bit from year-over-year, but the comparisons are dismal. So this is very small growth. Power Gen market is not back, so there's still a lot of growth left to come in China when the global economy starts to heat up again, they start building infrastructure. Even mining of course is impacted by the Chinese economy in this way, whereas I think trucking can proceed and still move ahead as they try to just move goods around China, even as they switch more to consumer versus build and export, that also still promotes trucking. So that's kind of how I'd reconcile those comments. So we're feeling good about the truck market in China. We're just uncertain about with the overlay of emissions, which products are going to be sold when and what kind of impact is that going to have on customers.

**CEO**
: I guess I might add one thing, just as you mentioned, the hedge weve got on the overall market is just the new products we've got going in. There's a couple of examples. The heavy-duty market, we virtually have no market share, as we introduce the new product regardless of what happens to market size, we're going to see growth there. The same thing in LiuGong, our joint venture, where we've not been in some truck market, we're now there and we're producing and as the emissions come, we're going to add Components and we're going to have a lot of volume on our 2.8 and 3.8. So we've got some tailwinds on that kind of regardless of some of the macro market.

**Andy Alec Kaplowitz – Barclays Capital, Inc.**
: Thanks, guys. Appreciate it.

**CEO**
: Thanks Andy.

**CTO**
: I think there is time for one more question.

**Operator**
: And that question comes from the line of Stephen Volkmann. Please go ahead.

**Stephen E. Volkmann – Jefferies LLC**
: Thank you. Couple of you guys had mentioned materials costs a little bit lower in some of your prepared comments. Just anything to tease out there? How should we look at that going forward?

**CEO**
: So, here's Pat. Pat will tell you about material cost.

**CFO**
: It was a little positive in the quarter, close to 1% benefit year-over-year and as you look out for the full year, I think we're still looking at a 1% type of number. So, none of that's really coming from metal markets, Steve. That's all what was going on within the purchase and supply chain organization, but assuming metals are pretty much flat for the full year.

**Stephen E. Volkmann – Jefferies LLC**
: Okay, great. That's helpful. And then I guess just to quickly go back to the engine business, I mean it looks like your biggest increase was in the heavy duty. And I assume that's North America, which I would think of as kind of your best margin in the segment there, which sort of begs the question of mix getting a little bit better here. But I guess maybe you can dissuade me from that, or are we looking a little conservative with the flat margin?

**CEO**
: Just a caution on mix, I'd say, Steve, I think you noticed, that the way to think about mix for our company usually is, where we had strong market positions and leading technology, we tend to get, retrieve better margins than when we're entering markets, we have weak market positions or our technology lead is not so big. So, heavy-duty broadly is a difficult one, but I would say that heavy-duty North America, you know our market positions are pretty good. What's more is, now because of the content that we have on the Engines, we now have the technology components on there, a lot of them are ours. That helps us with thinking through incremental margin. So you not only have margins in the Engine, but you have margins in the Components which helps you. So, I guess, broadly speaking, I would say, the North American truck market is a good market for us, but saying, is it better mix, it just depends on compared to what, like compared to markets where we're not very big and just entering, yes, compared to other  some other markets, not so much. So it just depends. But we do like  we are good in the market. We do have a good position. We do like it and it is generating good margins for us now. Again part of the incremental thing you are seeing though is again at plants that are not even near capacity adding incremental volume. That really generates good incremental margins.

**Stephen E. Volkmann – Jefferies LLC**
: Okay, great. I appreciate it.

**Operator**
: Thank you for your participation in today's conference. This concludes your presentation. You may now disconnect. Good day.