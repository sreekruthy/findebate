## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to Deeres third quarter earnings conference call. [Operator instructions.] I would now like to turn the call over to Mr. Tony Huegel, Director of Investor Relations. Thank you. You may begin.

**CTO**
: Hello. Also on the call today are Raj Kalathur, our chief financial officer; Marie Ziegler, deputy financial officer; and Susan Karlix, manager of investor communications. Today well take a closer look at Deeres third quarter earnings, then spend some time talking about our markets and how we expect to end the fiscal year. After that, we will respond to your questions. Please note that slides are available to complement the call this morning. They can be accessed on our website at www.johndeere.com. First, a reminder. This call is being broadcast live on the internet and recorded for future transmission and use by Deere and NASDAQ OMX. Any other use, recording, or transmission of any portion of this copyrighted broadcast without the express written consent of Deere is strictly prohibited. Participants in the call, including the Q&A session, agree that their likeness and remarks in all media may be stored and used as part ofthe earnings call. This call includes forward-looking comments concerning the companys plans and projections for the future that are subject to important risks and uncertainties. Additional information concerning factors that could cause actual results to differ materially is contained in the companys mostrecent Form 8-K and periodic reports filed with the Securities and Exchange Commission. This call also may include financial measures that are not in conformance with accounting principles generally accepted in the United States of America, or GAAP. Additional information concerning these measures, including reconciliations to comparable GAAP measures, is included in the release and posted on our website at www.johndeere.com/financialreports under Other Financial Information. Susan?

**Other-1**
: Thank you, Tony. John Deeres strong performance continued in the third quarter of 2013. Earnings jumped 26% on a sales increase of 4%. Both earnings and sales were the highest of any third quarter in the companys history and it marked our 13th quarter in a row of record profits. The game was led by ag and turf, which had another terrific quarter, with operating margins of about 17%. Financial services also made a major contribution, while construction and forestry kept profits in line with last year in spite of a slump in sales. No doubt, John Deere is being helped by a strong market for large farm machinery in North and South America. However, our results showed disciplined execution of our business plans too, plans focused on winning new customers around the world while keeping a close watch on costs and asset levels. In all, it was a productive quarter, putting John Deere well on the way to another very good year. Now lets take a look at the third quarter in detail, beginning on slide three. Net sales and revenues were up 4% in the quarter, to $10 billion. Net income attributable to Deere & Company was $997 million. As noted, both sales and income were the best ever third quarter results recorded by the company. On slide four, total worldwide equipment [operator] net sales were $9.3 billion, up 4% quarter over quarter, including an unfavorable impact from currency translation of about 1 point. Price realization in the quarter was positive by 3 points. Turning to a review of our individual businesses, lets start with agriculture and turf on slide five. Sales were up 8% in the quarter, on continuing strength in the global ag economy, especially North and South America. Operating profit was $1.3 billion, up 32%. The divisions results included an impairment charge for long lived assets related to John Deere Water of approximately $50 million pretax, $44 million after tax. Before we review the industry sales outlook, lets look at some of the fundamentals [affecting] the ag business. Slide six outlines U.S. farm cash receipts. For the year ahead, crop yields are forecast to be higher than in 2012, and much closer to normal, but prices will be somewhat lower. This reflects recovery from last years drought conditions. Conversely, livestock receipts are forecast to be higher in 2013 than 2012. As a result of these factors, our forecast calls for 2013 cash receipts to be about $390 billion, the second highest on record, and a solid level of income. On slide seven, with forecasts of a bumper crop, lower crop prices, and an increase in stock [unintelligible] ratios, our initial outlook for 2014 U.S. farm cash receipts is down modestly, but remains at a historically high level, approximately $380 billion. 2014 cash receipts, the number one predictor of farm equipment sales, are expected to remain at an excellent level, helping keep farmers in a financially sound position. Our economic outlook for the E.U. 28 is on slide eight. We continue to see offsetting trends in the E.U. on the one hand, ag fundamentals remain positive and production is expected to increase about 7%. Above average commodity prices are driving supportive farm income. Beef prices are leveling off at historic highs while pork and milk prices are favorable. On the other hand, farm machinery demand is expected to be lower in 2013, as the financial crisis continues to weigh on farmer sentiment and softness in the U.K. continues. On slide nine, youll see the economic fundamentals outlined for a few of our other targeted growth markets. Of note is the decline in our outlook for the CIS countries. The market is softer than our previous forecast, as import duties continue affecting combine demand in Russia, Kazakhstan, and Belarus. Hot, dry weather has impacted crop prospects in southern Russia and Ukraine, and credit availability is also hurting equipment demand. Slide 10 illustrates the value of agricultural production, a good proxy for the health of agribusiness in Brazil. With expectations for a strong soybean crop due to an increase in acres planted, higher yields, and sustained high crop prices, the 2013 value of ag production in Brazil is expected to increase about 6% over the 2012 level. Our 2013 ag and turf industry outlook is summarized on slide 11. In the U.S. and Canada, we continue to see strength in demand, especially for high horse power tractors and combines. We continue to project industry sales to be up about 5% in relation to the healthy levels of 2012. The E.U. 28 industry outlook is down about 5%, no change from our prior forecast. Throughout fiscal 2013, we have, each quarter, raised the industry outlook for South America, and we have done so again. Based on a combination of positive farm fundamentals, plus supportive financing programs in Brazil, we now expect industry sales of tractors and combines in South America to be up about 20% in 2013. South America continues to grow in importance for Deere. Our tractor market share has grown considerably, but our strong presence in combines, sugarcane harvesters, and feeding equipment should not go unnoticed. Shifting to the CIS, as we noted earlier, our 2013 industry outlook is now moderately lower, a decrease from a quarter ago. In Asia, we continue to forecast little change in industry sales from 2012. Turning to another product category, we now expect industry retail sales of turf and utility equipment in the U.S. and Canada to be up about 5% in 2013, as favorable summer weather has driven much stronger demand. Deere is seeing strength in commercial mowing equipment, utility vehicles, and zero track mowers. Putting all of this together on slide 12, fiscal year 2013 Deere sales of worldwide ag and turf equipment continue to be forecast to be up about 7%, including about 1 point of negative currency translation. 2013 operating margin for the ag and turf division is forecast at about 16%, a point increase since our last forecast. As we have discussed all year, last years fourth quarter sales were particularly strong. Production schedules were higher to accommodate the interim tier 4 transition at a time when the factories were running at very high rates to catch up with customer orders. Consequently, sales for ag in the fourth quarter of 2013 are expected to be lower than the fourth quarter a year ago. This reflects a tough comparison. It does not indicate any change in our outlook for demand or global ag fundamentals. Lets focus now on construction and forestry on slide 13. Net sales were down 11% in the quarter, and operating profit was down 5% due to lower shipment volumes. That $190 million decline in sales was only a $6 million reduction in operating profit is a reflection of price realization, good execution, and lever pulling to control costs in response to slow demand. On slide 14, looking at the economic indicators on the bottom part of the slide, the outlooks for GDP and government spending have softened since last quarter. Although overall economic growth continues at a sluggish pace, we are beginning to see some positive indicators. While moving very slowly, residential investment is growing, home sales and prices are increasing, and there are reports that the number of build-ready lots are dwindling. Global forestry markets are now expected to be up 5-10% in 2013, as weakness in Europe and Russia is more than offset by improvement in North America. Forestry markets in the U.S. are considerably higher due to the year over year increase in housing starts. Fiscal 2013 net sales in construction and forestry are now forecast to be down about 8%. Our previous outlook was down about 5%. The year over year sales decline is reflected in lower inventory and receivable numbers, and it has had an impact on mix as we reduce shipments of high margin equipment. C&F full year operating margin is now projected to be about 6%, a 1 point improvement from last quarter, as the division is pulling levers and cutting costs to meet its operating goals. Lets move now to our financial services operations. Slide 15 shows the financial services provision for credit losses at 3 basis points, based on the percentage of the total average owned portfolio at the end of the quarter. This reflects the excellent quality of our portfolios and recoveries from prior years writeoff. Our 2013 financial forecast now contemplates a loss provision of about 5 basis points as a percentage of the average owned portfolio. This is well below the 10-year average of about 28 basis points. Moving to slide 16, worldwide financial services net income attributable to Deere & Company was $150 million in the third quarter, versus $110 million last year. The increased provision for credit losses cited in the press release is a function of small reductions taken in the third quarter of 2012. The loss experienced on the portfolio remains at an extremely low level. For the full year, net income attributable to Deere & Company is now forecast to be about $560 million. Slide 17 outlines receivables and inventory. For the company as a whole, receivables and inventories ended the quarter up about $20 million, or equal to approximately 30% of prior 12-month sales, compared with 32.3% a year ago. The year over year forecasted downward tweak in ag is due to the impact of currency and reflects no real change in absolute inventory levels. C&F is now projected to be down about $175 million as we respond to slowing demand and a reduction in Canadian confined inventories. We expect to end 2013 with receivables and inventory up about $50 million. Our guidance for cost of sales as a percentage of net sales, shown on slide 18, remains at approximately 74% for the full year. Factors affecting cost of sales include price realization, production or manufacturing costs, raw material costs, engine emissions product costs, absorption, and effects of foreign currency. When modeling the full year, keep in mind the following: price realizations: we are forecasting about 3 points in 2013; favorable year over year raw material costs; the impact on cost of sales of new employees; interim tier four product costs; absorption due to the low levels of inventory compared to 2012; and an unfavorable mix of product in C&F, as we talked about earlier. Looking at R&D expense on slide 19, R&D was down about 8% in the third quarter, compared with the same period last year. This is consistent with our earlier guidance that the increase in R&D spending for 2013 would occur in the first half of the year. Our 2013 forecast continues to call for R&D expense to be up about 3% for the full year. Moving now to slide 20, SA&G expense for the equipment operations was up about 4% in the third quarter. Very much like R&D, the quarter over quarter increases for SA&G were heavily weighted to the first half of the year. SA&G expense is forecast to be up about 7% in 2013, no change from our previous guidance. On slide 21, pension and OPEB was up about $15 million in the quarter, compared with last year. Turning to slide 22, the equipment operations tax rate was about 36% in the third quarter. For full year 2015 the effective tax rate is forecast to be in the range of 34-36%, representing no change from our previous forecast. On slide 23, UCR equipment operations history of strong cash flow: our forecast for cash flow from equipment operations is now about $3.8 billion in 2013. Of note is a $700 million Deere & Company debt maturity in April 2014. On slide 24, we outline our 2013 outlook for the fourth quarter and full year. Our net sales forecast for the fourth quarter is down about 5% compared with 2012, due to the extremely tough comparison discussed earlier. This includes about 3 points of price realization. The full year forecast calls for net sales to be up about 5%, with 1 point of unfavorable exchange. Thus, the forecast at constant currency up about 6% represents no change from our last forecast. Price realization is expected to be positive by about 3 points. Finally, our full year 2013 net income forecast has increased to about $3.45 billion. In closing, John Deere is well on the road to another year of impressive performance. Even with a difficult comparison in store for the fourth quarter, our financial guidance implies a healthy level of income, helping us wrap up a third consecutive year of record results. Also, it is significant to note that Deere has been consistently setting new performance records despite facing some significant headwinds, including a sluggish global economy, political gridlock in Washington, and a host of major product changeovers associated with more stringent emissions rules. As for the longer term picture, it remains extremely bright. Indeed, the broad trends weve been talking about, based on a growing, richer, more urban population appear to have plenty of staying power, staying power that we believe will help the company deliver substantial value to its customers and investors for years to come. Tony?

### Q&A
**CTO**
: Thank you, Susan. Now were ready to begin the Q&A portion of the call. The operator will instruct you on the polling procedures, but as a reminder, in consideration of others, please limit yourself to one question and one related follow up. If you have additional questions, we ask that you rejoin the queue. Operator?

**Operator**
: [Operator instructions.] Our first question comes from Ross Gilardi. And please state your company name.

**Analyst-1**
: I just wanted to ask about your cash receipt outlook. If you look at your cash receipt outlook for 2014, if youre right, cash receipts will essentially have been flat for the last four years, from 2011 to 2014. Yet Deeres top line has obviously grown substantially, so is the relationship between cash receipts and equipment breaking down? Is there risk that you have to give a lot of that sales increase back in coming years, even if cash receipts are kind of flattish next year? Could you explain that? Because clearly your sales have been growing at a much faster pace than cash receipts for the last several years.

**CTO**
: And I just want to clarify. Youre speaking to the U.S. farm cash receipt number, and as weve talked about in the past, that is probably the best indicator of equipment sales. And we have talked about, in recent years, that in these very high levels of cash receipts, when you see fluctuations plus or minus 5%, we would view those really as relatively flattish. And so to your point, longer term, certainly we dont believe theres a breakdown in the correlation between cash receipts and equipment sales, but when youre at these very high levels, it isnt necessarily as direct of a relationship as you would see over a longer cycle.

**Other-2**
: Maybe just to add to what Tony said, first, we have had very good price realization, and we have benefited from the array of new products that we have introduced over the last several years, including in Brazil, which has been a very strong growth market for us, and we have significantly increased our presence and our sales in that market. So youve really seen the benefit of a number of investments.

**Analyst-1**
: And could you just clarify, youve increased your net income outlook, but kept your sales outlook unchanged. Why is that?

**Other-2**
: Better execution. Youre seeing good discipline in terms of our R&D, our SA&G, factory spend, and we have successfully gone through the balance of the IT4 transition, so a number of positive trends. And again, kudos to our operating folks.

**Operator**
: The next question comes from Andrew Kaplowitz. And please state your company name.

**Analyst-2**
: Maybe you can give us a little more color on the early order book in the context of, we know you had a combine program out there that was sort of early, early order program. And then maybe if you can talk about, has there been any impact from the recent drop in crop prices on that order book?

**CTO**
: With combines in particular, its a little difficult to talk about year over year changes, because it is different this year. We did have a window in June really related to our final tier 4 transition, specifically our early order program begins in August. That program went very well, but keep in mind that it was a relatively short window, and then well open up the early order program again after our new product introduction for final tier 4 production in 2014. So its fairly early. On the other early order programs, though, the spring order programs, that would be planters, seeding equipment, tillage in particular, we had a very very good year in 2012 with the early order program. And were running about flat with those programs last year. And so again, that bodes very well. Again, its early, of course, but the early order programs to date are doing very well. And I would point out, to the extent that the combine early order program in June, all the slots did fill as expected. And then the other thing, while were talking about order book into next year that we tend to talk about at this point, is on tractors. As you know, we dont have an early order program, because its not seasonal, but again, tractors are at or better than, in most cases, they were a year ago. In fact, if you look at our 8R tractors, on the wheeled tractors, were basically out into April-May on our availability, which takes us beyond our final tier 4 transition. Last year availability was January. 8R tracks are roughly in line with a year ago. The 9R, the large four-wheel drive tractors, wheeled tractors are a little ahead this year. Theyre November. Last year was September, and then the tracks are a little bit behind year over year. But again, generally speaking, when you look at our order books, were in a very strong position against very high levels last year.

**Analyst-2**
: Can I ask you about the U.S. farm cash receipts forecast in a different way? Specifically, you only have crop receipts dropping about 4% despite what corn prices have done lately over the summer. You guys are usually pretty conservative with your forecasts, yet if I talk to the bears out there on ag, they would say your forecast looks not conservative at all. Can you talk about your confidence level in your forecast?

**Other-2**
: At this stage of the game, this is our best forecast. And remember that cash receipts is a function of quantity, which will be very good this year, in addition to price. And I think perhaps some arent focusing as much on the quantity.

**Operator**
: The next question comes from Jerry Revich. And please state your company name.

**Analyst-3**
: Can you just say more about the factory productivity improvement we saw in the quarter in ag and turf, as youve finished the interim tier 4 transition. It sounds like youre starting to get significantly improved productivity. Does that continue into the fourth quarter? And then just help us get a sense for the relative complexity of now transitioning to tier 4 final again compared to the transition that you just went through on interim tier 4.

**CTO**
: As it relates to productivity, when you think about fourth quarter, keep in mind, as we talked about in the opening comments, we do have a very tough compare. Part of productivity, of course, is volumes as well, and last year our factories were running at relatively high levels, especially as it relates to the combine factory. And we would be at more normal levels this year. And so youll see a little bit of a change there in a year over year basis. Of course, as we move into final tier 4, thats largely going to impact certain quarters as we move into 2014. Combines, for example, will begin transitioning in January. I mentioned, or hinted at at least a little earlier, that our 8R tractors will transition in the April timeframe. And so well go through those transitions very similar to what we had in 2010, and so well have some quarter over quarter disruption as we go through the year.

**Other-2**
: Maybe just the other thing, in the fourth quarter, in selected products, we will start the transition, or well start the factory prep, so there will be a little bit of impact. But nonetheless, theres been a real focus on the high quality execution youve come to expect from Deere and youre seeing that in our results.

**Analyst-3**
: And in terms of the production schedule into the fourth quarter, and maybe Marie, part of it is what you mentioned a moment ago, but the sequential decline is the biggest weve seen since 06, fourth quarter versus third quarter, how much of that is tier 4 final transition versus other factors. Just help us understand the sequential move, and obviously you explained it on a year over year basis. Im just trying to understand the sequential drivers.

**Other-2**
: Maybe the most important thing is to remember that last year we shifted $350 million of shipments out of the third quarter into the fourth quarter. And probably over talked about combines. And so that is probably the single biggest factor. There will be some adjustments here and there, but thats really the biggest.

**Operator**
: The next question comes from David Raso. And please state your company name.

**Analyst-4**
: I just needed some clarification on the order book. For whats in the order book in those time periods you gave us, those are largely all non final tier 4? Theyre interim tier 4?

**CTO**
: That would be correct. We are announcing our final tier 4 product actually this week. The new product introduction shows begin, and will be over the next couple of weeks. And then well be announcing pricing and opening the order book to final tier 4. So that is correct. Its interim tier 4 products.

**Analyst-4**
: And just trying to think about the pricing on the final tier 4, how it could be impacting the orders to get the remaining interim tier 4. Whats been communicated on the pricing? What is built into your expectations on the pricing? And really trying to get a read on some of the order book strength.

**CTO**
: We have made no final tier 4 price announcements at this point. So weve taken some small, on combines for example, price increases related to the interim tier 4 orders that we have early in fiscal 14, but weve announced no final tier 4 price increases. Again, it would be a little premature to announce price increases before the actual product is announced. So those price increases will follow the introduction.

**Analyst-4**
: Would you characterize the order books as they stand, even with obviously some overtures out there, people speculating on the price increases, its reflective of the current demand out there, you would not characterize it as any pull forward, getting in front of the final tier 4 price increases?

**CTO**
: Again, because we havent announced them, I wouldnt speculate that direction. All we can point to is where the demand is at this point, and what were seeing in our order book is a continued very strong demand level. Again, comparable or in some cases slightly better than what we saw a year ago at very strong levels. So thats about all we can say about that. So with that, thank you, and well need to move to the next caller.

**Operator**
: The next question comes from Andy Casey. And please state your company name.

**Analyst-5**
: Question on the Q3 ag and turf. If we could return to the margin performance, it was very good. Could you give the relative weighting for impact from volume productivity and material cost tailwinds, and stripping out the price and impairment charge?

**CTO**
: For ag and turf specifically, I dont know that I have that weighting. But as you look at the total cost of sales, obviously we talked about that ratio of price realization certainly helping benefit that ratio. Raw material costs would be the other positive, impacting the cost of sales in the quarter. But then you have overhead spend, you know, largely due to the higher employment costs, emissions costs, and some absorption as we had lower builds in inventory. And thats fiscal year numbers that Ive given you. Sorry about that.

**CFO**
: If you look at the third quarter, price realization was one of the contributors to the operating profit improvement. Next to that was essentially our costs. This is the material costs. And then there were contributions from mix as well. So those would be the three that stand out, in that order.

**Other-2**
: And just a reminder, that water impairment is $50 million, on the negative side.

**Analyst-5**
: The reason I ask is if I strip out the impairment charge and the pricing, the incremental margin is still very strong, somewhere around 30%.

**Other-2**
: Last years third quarter had inefficiencies, costs that we said for the ag and turf division were $50-75 million, which is something you need to bear in mind.

**CFO**
: So to that extent, it was an easier compare as well.

**Analyst-5**
: Oh, okay. Thank you, that clears it up. And then the second question, just a question on Europe. Theres some mixed signals coming out of there as you reflect in your forecast. You know, recent confidence indices turned positive within the ag side. Are you seeing any farmer concern about the revisions to the [CAP] subsidy package that are expected for next year?

**CTO**
: Not significant at all, and if you look at whats being proposed for CAP, if you look at it in nominal terms, the subsidies really are basically flat in terms of what the proposal is.

**Other-2**
: So so far, unlike other years, where there has been talk ahead of CAP changes, this has really been a, I hate to say nonevent, but has been very quiet.

**CTO**
: Very very minor changes.

**Operator**
: The next question comes from Jamie Cook. And please state your company name.

**Analyst-6**
: Two questions, and sorry to harp on the 2014 cash receipt forecast. But I guess can you just give color, when you guys have conversations with your dealers, or when the dealers are having conversations with the farmers, Marie, you point out that you have to look at the quantity and the crop price, but I think people are just concerned, optically, where, for example, corn prices are going, and if that will trump quantity. So can you talk about what theyre saying about, just given where prices are, and you think that could potentially have a bigger impact on demand in 2014, just because of how we get to the actual cash receipt number? And then my second question. Some of your peers have talked about a more competitive environment in construction, particularly seeing more discounting. Im just wondering if you could comment on what youre seeing in the industry.

**Other-2**
: Let me start with the cash receipts number. In our modeling, far and away the biggest driver and the highest correlation is cash receipts, and it doesnt discriminate between the commodity price and the quantity. So I will stop there. That is the biggest driver. In terms of the construction market, since the market has, candidly, been softer than I think all expected, Im not surprised to hear that theres some conversation about dynamics in the market. But we certainly dont have any comments related to pricing and our construction equipment division is a solid contributor to the 3 points of price realization that we announced for the year, and certainly for the quarter.

**Operator**
: The next question comes from Rob Wertheimer. And please state your company name.

**Analyst-7**
: Wanted to ask about the tier 4 final rollout. I gather you said you sold out the [stub] year on the combines. I guess you didnt try to run the factories extra hard, because I think youre implying combines are down year over year in Q4. Have you talked about whether you intend to do any extra tier 4 interim production as you roll on the various final things? And Im not sure if youre able to give a rough guestimate of what your interim versus final production might be versus next year.

**CTO**
: We havent discussed what the production levels would be in the kind of pre-final tier 4 production for combines in early fiscal 2014. I can tell you we are beginning the transition of combines in January. So youre really talking about the November-December production levels.

**Other-2**
: I think if your question was is there further upside, the answer is no.

**Analyst-7**
: So youre sold out where you want to sold out, and youre done, and its probably not running the factory as hard as last year, is what you said?

**Other-2**
: The run rates in the fourth quarter of last year were really not sustainable. That would be the bottom line. Not a way we would choose to run a business.

**Analyst-7**
: And then second question, Tony, you mentioned the early order programs on the springtime product on intelligent planting. Its not something you guys have talked a lot about. Can you just kind of go through, mechanically, how that works? Is it a significant portion of the volume, or just an indicator? Obviously I assume that would have no connection whatsoever to tier 4 final stuff, so it would be an indicator of underlying strength, I guess.

**CTO**
: With the exception of sprayers, of course it would be final tier 4, effective. But when you look at the tillage and seeding and so on, and really the importance there is, weve talked about this a little bit in the past, tillage tends to be a fairly good leading indicator, simply because its a relatively discretionary item, and so for us internally, we view it as a good leading indicator. So its more indicative of underlying strength more than the impact necessarily would have on the top line or bottom line.

**Operator**
: The next question comes from [Mig] Dobre. And please state your company name.

**Analyst-8**
: I guess Im wondering if maybe you can give us a little color on what youre hearing from dealers, and what youre seeing as far as used equipment prices, especially some of the newer models out there. Weve heard that theres been a little bit of softness, and if thats so, Im wondering how you think that impacts demand for equipment going forward.

**CTO**
: As we look at pricing on used equipment, what wed tell you is overall were actually seeing pretty healthy levels of pricing on used equipment. You see plus or minus a little bit. So large tractors, pricing up a single digit. Combines, down a single digit. But again, at very, very strong levels. So we dont view that as an issue at this point.

**Analyst-8**
: And then looking at the R&D expenses, obviously much higher level than a couple of years ago, because of all the tier 4 related items. But Im wondering, as were looking out today to 2014, given the higher base that youre currently operating on, should we continue to expect growth in this line item? Or is it fair to say that this level can actually account for a lot of the tier 4 final?

**CTO**
: At this point, I would not speculate on 2014 expenses. As weve talked about, we dont provide guidance. Theres some things maybe to consider. We arent finished with final tier 4, so we still have a number of products to transition, both in the upcoming year and in the following. And keep in mind also that we are continuing to invest in growth, and in some cases thats investing in new products in certain key markets. So thats about all we can say really at this point related to R&D.

**Operator**
: The next question comes from Steven Fisher. And please state your company name.

**Analyst-9**
: Wondering if you can just give us your thoughts on how the special depreciation benefits might play out over the next several months, how any debate might impact near term sales. And then just kind of remind us how that played out for you guys last year.

**CTO**
: Theres two separate items. Theres a Section 179 that can be utilized with used equipment as well as new, and of course the bonus depreciation. Both are subject to the task reform development. You know, as it looks at Section 179, it appears that there is much broader support for Section 179 in terms of speculation that it may or may not be extended, then included in proposals, even to make it permanent, through some of the small business tax reform proposals, those sorts of things. Certainly as you move toward the end of the year, especially Section 179 we think has been helpful in moving used equipment in the past. We would tell you while bonus depreciation is certainly beneficial, we think its had a marginal benefit on sales. Theres a number of other factors beyond tax considerations that farmers consider. Last year would be a good example, and you mentioned that. As we approach the end of 2012, of course, the expectation both internally and by most externally was that the bonus depreciation would not be extended. Section 179 actually had already dropped. The change at the end of the year made it retroactive. And we did not see any impact in our order book once availability went beyond December 31, which, again, in our view, kind of lends credibility to our view that at least last year the expectation that the bonus depreciation would be eliminated did not impact our order volumes.

**Operator**
: The next question comes from Eli Lustgarten. And please state your company name.

**Analyst-10**
: Well come back to ag in a minute, but can we talk about whats going on in the construction equipment sector? You went from down 8 to down 11. Is that because of weaker end markets, or more inventory liquidation that is required. [unintelligible] inventory liquidation as part of it in this quarter, so we can think of it more normalizing in the next year and maybe quantify how much of the downturn is that.

**Other-2**
: We would say that its both. Clearly the market has been weaker than we had anticipated, and we are continuing to reduce some of our inventory. We would expect to have that completed by the end of this year, so that we would go into next year poised for what we hope will be a stronger market outlook based on at least the market fundamentals.

**CTO**
: And I want to make a clarification. You said down 8 to down 11. Our forecast today is down 8. It was previously down 5.

**Analyst-10**
: But how much of that is inventory liquidation?

**Other-2**
: I dont have that. I dont know, half and half?

**CFO**
: The other thing Ill add is, as the lead times are getting lower, dealers have an incentive for holding less inventory as well. So thats also contributing to lower inventory in the channel.

**Other-2**
: Maybe I could just cite one positive note that we are seeing, is that our rental utilization is really up and high, and that can be a leading indicator. Well see how that plays out, but its been exceptionally high.

**Analyst-10**
: And a quick follow on. Can you talk about combine schedules? Were hearing from dealers about a buildup of used goods at dealers, a 30% cut in allocations by Deere for combines in the fourth quarter for next year. Can you talk about whats going on in that market in the fourth quarter as youre looking out?

**Other-2**
: The early part of the year, when you look at what allocations may or may not be, that is really not a good predictor of what the future holds. We start very conservatively. Recall that we are in the midst of a transition as you think about 2014, a fairly significant transition for our combine lines. So things are going to be parsed out over the course of the year in contrast to a traditional early order program where you really have your full years number of slots available.

**CTO**
: The only thing I would add is certainly there are a high level of used combines in the marketplace, but its really reflective of the high level of sales that weve had in the last couple of years. And as you look at the sales increase over the last several months, new sales is much higher than what weve seen increased on a percentage basis in used combine levels. So while high, were moving into a very key period of sales for used equipment, and are confident with our dealer network as well as the pool fund strategy that we use, that were in a good position to be able to move those used combines and other used equipment as well, out.

**Operator**
: The next question comes from Larry DeMaria. And please state your company name.

**Analyst-11**
: Not to harp on the crop receipts, but obviously you guys dont believe the USDA numbers from the other day as well, that theyre understated, because youre forecasting bigger yields on similar harvested acres, which implies obviously a much bigger production and bigger carryout. Similar in soybeans. I think you carry out over 10% versus 16% for corn going out for next year. But you kept the price very similar to the USDA, the same in corn and slightly lower in soybeans. So thats the delta that I think were all worried about. Can you just justify and explain why the price hasnt gone down that youre expecting, but the production levels you guys put forth are much higher?

**CTO**
: Keep in mind theres a large number of factors that go into each of those, and into the price, and I would also point out that our forecast did not change based on the USDA numbers that were recently reported. That was put together prior to the release of that data, and the basis for our forecast. So again, you have a lot of factors. You have exports, so on and so forth, in there. The other thing I would point out is theres a lot of conversation about the $4.90 corn. You know, if you look back historically, that is still very strong pricing for corn. Certainly down from last year, but keep in mind that last years price was very high coming off of very low production due to the drought. And so $4.90 corn, from the information we get, from Informa Economics, is still very supportive for farmers. We would tell you, according to Informa, that low $4 corn, farmers are still making good money. So at $4.90, still profitable levels for most farmers.

**Analyst-11**
: Okay, so it says August 14 in the slide, but this date is not...

**CTO**
: Those are a Deere estimate as of that date.

**Analyst-11**
: Okay. And so Ill stick with the order books. You mentioned the seasonal orders for planters, etc. were flat, I think, year over year. And last year it was up 15%. Have orders come in strongly over the last few weeks to get you there? Because it seems like initially they were behind. And then just more broadly, the slide in corn that weve seen, what kind of effect did that have on orders more recently, in the last four to six weeks?

**CTO**
: What I would tell you is we look at this as a snapshot, and dont get down into the details of the week to week changes. What we can tell you is that at this point we are relatively flat year over year, to your point, at very very high levels last year. And again, the early order program, its early in the year, but those indicators are very strong. And as well, look at the tractor order book, which is equally as strong, that were seeing out into 2014.

**Operator**
: The next question comes from Adam Fleck. And please state your company name.

**Analyst-12**
: I had a couple of questions on Russia specifically. You commented, I think, last quarter, that you wanted to see what happened with the import duties. It looks like they were extended. So that being the case, can you just update us on your plans for the strategy there and localized content?

**CFO**
: Yes, it was extended. And the indications are it will probably carry on at least a few months, if not a couple more years. One of the things we are doing is to look at how we can organize our operations in Russia to qualify for less of a tariff or wider tariffs. So right now we do, say, in SKD assembly, some of the considerations we would have for CKD assembly. So those are the types of changes we would be looking at, and that varies by the product and the volumes that would justify for that particular product category. So those should allow us to improve our volumes in that share, but as you said, directionally this is going to be an impact on us.

**CTO**
: The only thing I would add is keep in mind it certainly creates some short term challenges for us, but from a long term perspective, we remain very committed to that market. We continue to see a lot of strong opportunity there.

**Analyst-12**
: And then just one follow up. Something that maybe doesnt get discussed too much, but can you just disclose what your parts sales are to date? Are those up pretty substantially?

**CTO**
: We dont disclose today. What we would tell you is in past years parts tend to run 15-20% of our total sales. But beyond that, we cant go into more detail.

**Operator**
: The next question comes from Annual Duignan. And please state your company name.

**Analyst-13**
: I just wanted to go back to the cash receipts discussion. Not to beat a dead horse or anything, but would you at least agree that we have probably passed the peak of cash receipts in that farmers are likely to grow more corn, not only this year but next year? And cash receipts probably, we dont see corn at $7 again, unless we get another significant weather event in the next few years?

**Other-2**
: Ann, this is our best estimate. We are not soothsaying into the future. But I dont see anything that necessarily precludes prices from going up further. We know we have very strong demand conditions. You have the USDA increasing seed and residual use. You do have a slight bump on ethanol. We see good demand in the market. And so I cant concede that. On the other hand, I cant guarantee anything in the future other than the fundamental tailwinds for our business continue to look very strong.

**CFO**
: If you look at the fundamental tailwinds of demand for ag commodities, it is very strong. Its continuing to be very strong. And thats a primary driver. So weather may impact it one year to the next, but the fundamental drivers of demand are still in place, and thats going to drive our business here and [unintelligible].

**Analyst-13**
: And back to the construction side, you just said that build-ready lots are dwindling. Could you explain what you mean by that? And how do you gather that data?

**Other-2**
: Anecdotally were hearing that. Actually, we picked that up in our interviews with senior officers on multiple fronts. And what that means for us specifically is that a lot of the usage of our equipment in residential is when you are moving land to prepare the lots, to put in the street, to get the sewer into the division. So the fact that you see lower number of build ready lots, so to speak, may be a positive indicator as you move into the future, that there will be increased demand for the equipment in use.

**CFO**
: Essentially you can think of this is vertical or horizontal constructions. What uses more of our equipment is when you set up a completely new subdivision and have residential construction and commercial construction around it. So right now, early on, after the downturn, all the build-ready lots are being taken up, and ones that are no more of these build ready lots, which is what were hearing more of, there are going to be more constructions on complete new subdivisions. Thats what we meant by that.

**Analyst-13**
: Yeah, and I appreciate that. Weve written extensively about that, but I was just wondering how we get that data and kind of figure out when we switch from kind of brownfield to greenfield. But youre just hearing it anecdotally, thats what Im reading?

**CTO**
: Correct.

**Operator**
: The next question comes from Ashish Gupta.

**Analyst-14**
: Can you give us a sense of what levers you might be able to pull in a down market? Maybe what type of decremental margins you can manage towards?

**Other-2**
: I dont think weve been very specific. Each single product line, each department within the company, has a specific set of activities that as we move up or down we either cease or add. So it varies by product line, by department.

**CFO**
: If you look at our construction equipment business, lower end demand, lower market demand were the case in the third quarter. But if you look at how weve performed in terms of whether its R&D or SG&A, and overall margin environment, was impressive. So regardless of the end market environment, we are in a position to actually pull different levers or ramp up if necessary to meet those conditions. And thats what you saw in the construction case in the third quarter.

**Analyst-14**
: And are you still in a position where youre continuing to add headcount to facilitate future growth in the different global regions?

**Other-2**
: Id say the bulk of the headcount really occurred in the last couple of years. Im not actually, candidly, sure where we are year to date. But I dont anticipate there would be a lot, other than perhaps in Brazil, where were approaching the startup of those factories there. And maybe in China as well.

**CFO**
: So [unintelligible] in 10, 11, 12 were higher than in 13, so most of our investments have come in, or towards our aspirations that we have expressed outside [unintelligible] aspirations.

**Operator**
: The final question comes from Seth Weber. And please state your company name.

**Analyst-15**
: On capital allocation, it looked like your share repurchase actually picked up here in the quarter. Are you kind of moving that up in the pecking order? How should we think about share repo going forward? Or is it just you were being more opportunistic here in the quarter, or something like that?

**Other-2**
: Well, our pecking order, per se, has not changed, and weve long articulated maintaining a strong balance sheet, invest in the business, return dividends, and then excess cash would be used for share repurchase. We were very specific in the first and second quarters that we were conservative going into those because of the fiscal cliff in the first quarter, and then some residual shakiness, if you will, in the market as we went into the second quarter. As our cash flow has proven out, as were through our peak use of cash - remember we are big users of cash in the first and second quarters - as our stock has continued to provide us with a very good buying opportunity - we think were significantly below our intrinsic value - we were able to step up the share repurchase.

**Analyst-15**
: So as we look to 2014, do you think your capex number, the $1.3 billion for this year, should come down, and that gives you some more firepower?

**Other-2**
: I think its unlikely. We dont have a forecast for 14 yet. Obviously were working on some plans. But remember there is still a significant amount of work to be done with final tier 4 ahead of us. We wont see as much in the way of new plant investments. A lot of that is behind us. But theres a lot ahead of us, in a concentrated period, to meet final tier 4.

**CTO**
: And we have said that at least out through 2014, that that $1.3 billion is probably a good at least short or midterm run rate to anticipate. And then beyond that, as a percentage of sales, we would expect to see capex start to come down. But depending on where our sales are, you may or may not see the absolute number come down at that point. In conclusion, our strong performance continued in the third quarter of 2013, with earnings up 26% on a 4% sales increase, and were well on our way to another year of impressive performance. With that, we thank you for your participation in the call, and as always, well be available the rest of the day to answer any additional questions you may have.