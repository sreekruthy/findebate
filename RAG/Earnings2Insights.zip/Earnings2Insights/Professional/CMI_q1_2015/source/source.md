## Financial Earnings Call


### Prepared remarks
**Operator**
: Good day, ladies and gentlemen, and welcome to the Cummins Inc First Quarter 2015 Earnings Release Conference Call. At this time, all participants are in a listen-only mode. Later, we will conduct a question-and-answer session, and instructions will follow at that time. [Operator Instructions] As a reminder, this conference call is being recorded. I would now like to turn the conference over to Mark Smith, Vice President-Investor Relations. Please begin.

**Investor Relations**
: Thank you, Liz Marin [ph]. Good morning, everyone, and welcome to our teleconference today to discuss Cummins' results for the first quarter of 2015. Participating with me today are our Chairman and Chief Executive Officer, Tom Linebarger; our Chief Financial Officer, Pat Ward; President and Chief Operating Officer, Rich Freeland. We will be available for your questions after our prepared remarks. Before we start, please note that some of the information that you will hear or be given today will consist of forward-looking statements within the meaning of the Securities and Exchange Act of 1934. Such statements express our forecasts, expectations, hopes, beliefs and intentions on strategies regarding the future. Our actual future results could differ materially from those projected in such forward-looking statements because of a number of risks and uncertainties. More information regarding such risks and uncertainties is available in the forward-looking disclosure statement in our slide deck and our filings with the Securities and Exchange Commission, particularly the Risk Factors section of our most recently filed Annual Report. During the course of thiscall, we will be discussing certain non-GAAP financial measures, and we refer you to our website for the reconciliation of those measures to GAAP financials. Our press release with a copy of the financial statements and a copy of today's presentation are available on our website at www.cummins.com under the heading of Investors and Media. Now, I'll turn it over to our Chairman and CEO, Tom Linebarger.

**CEO**
: Thank you, Mark. Good morning. I will start with a summary of our first quarter results and provide an update on our outlook for the full year. Scott will then take you through more details of both our first quarter financial performance and our forecast for the year. Revenues for the first quarter were $4.7 billion, an increase of 7% compared to the first quarter of 2014. First quarter EBIT was $562 million, or 11.9% of sales, compared to $528 million or 12% in the same quarter last year. EBIT percent declined slightly year-over-year with a 50 basis point improvement in gross margin offset by a decline in joint venture income. Joint venture income declined in dollars and as a percent of sales due to the acquisition of our North American distributors, previously held as joint ventures and an impairment of our investment in off-highway engine joint venture. Joint venture earnings in China increased 20% as we gain market share in truck market. Engine business revenues increased by 1% year-over-year with strength in the North American truck market, offsetting lower demand for trucks in Brazil and in global off-highway markets. EBIT at 9.7% of sales declined from 10.5% a year ago. A strong operational performance from our manufacturing plants and benefits from material cost reduction issues were offset by higher warranty expenses. As we have discussed in previous calls, we have a very strong focus on improving quality and that implemented changes that will lower our future warranty expense. We expect warranty costs in the second half of this year to be lower than the first half and lower than the second half of last year. Engine business profitability is projected to increase from first quarter levels as sales grow and we capture benefits from quality improvements and other cost reduction initiatives. Revenues in our Components segment increased 6% from year ago, with strong demand in North America driving the growth. Sales in China also increased despite very weak end markets. EBIT at $195 million or 15% of sales was a record both in dollars and in margin percent. We had strong performance from four Components businesses, three of which delivered clear improvement year-over-year. Distribution revenues increased 55% compared to the first quarter of 2014, with acquisitions adding 57%. Currency reduced sales by 5% primarily as a result of the appreciation of the U.S. dollar, offsetting organic growth of 3%. EBIT for the quarter was 6%, down from 8% a year ago. Currency was the main driver of decline in EBIT percent. A strong operational performance largely offsets the dilution from acquisitions. We expect sales from existing Distribution businesses to increase in subsequent quarters and EBIT percent to improve as we continue to capture strong incremental margins on organic growth. We're on track to complete three further distributor acquisitions in North America in the third quarter for a total of 10 acquisitions over two years. Based on our current forecast, we expect to add approximately $600 million to company revenues this year, in addition to the more than $460 million added in 2014, exceeding the $1 billion in revenues we projected for this year at our 2013 Analyst Day. Last year, acquisitions contributed more than 40% of earnings per share and we currently expect to add further 20% this year for a total of at least $0.60 also ahead of our 2013 projections of $0.50 a share. By the end of this year, we have successfully integrated more than 7,000 employees in Cummins and I want to thank those employees for their continued focus on meeting the needs of our customers through this transition. I'd also like to thank all of our employees who have been working hard behind the scenes to make the integration of these 10 formerly independent businesses go so smoothly. In the Power Generation business, revenues increased by 6% compared to a very weak quarter last year. Gross margins improved year-over-year for the fifth straight quarter. EBIT improved from 3.9% to 7.2% due to improvements in gross margin and from lower operating expenses as a result of the cost reduction actions taken in the fourth quarter of 2014. We do expect margins to improve further in the second half as we complete the exit of the alternator operations in Germany as planned. Now, I will comment on some of our key markets, starting with North America. Our revenues in North America grew 17% in the first quarter, due primarily to strength in on-highway markets and distributor acquisitions. Shipments to the North American heavy-duty truck market exceeded 24,000 units in the first quarter, an increase of 8% from 2014 levels. First quarter market share was 33%. We expect the full-year market size to increase by 8% and project our full-year market share to be 36%, unchanged from our previous guidance. In the medium-duty truck market, we delivered almost 25,000 engines in the first quarter, up 14% from last year, primarily due to higher market share. We currently project that the market will grow by 1% for the year, consistent with our prior forecast. Our market share improved to 80% in the first quarter, and we expect to achieve full-year market share of 74%, 7% higher than our original projection, as OEMs with Cummins-powered trucks grow market share and we gain penetration at Navistar. Shipments to Chrysler increased by 2% in the first quarter, and we forecast full-year shipments to be flat compared to 2014, consistent with our view at the start of the year. Our engine revenues from the North American construction market decreased by 12% compared to the first quarter last year. While North America is currently the strongest major market for construction equipment sales, all volumes are down as OEM demand for engines was elevated in 2014, ahead of the Tier 4 final emissions regulations, which went in effect at the beginning of this year. Power generation revenues were flat in North America in the first quarter. Sales to the U.S. Military continued to decline as the current contract reached maturity. Our core business excluding Military increased 5% year-over-year. We expect full-year revenues in North America to be flat to up 2%. Our international revenues declined by 6% year-over-year with lower revenues in Europe and Brazil, offsetting growth in China. First quarter revenues in China including joint ventures were $807 million, an increase of 13% year-over-year. The growth was driven primarily by stronger sales of engines and components and on-highway markets despite weak end-market conditions. Industry demand for heavy- and medium-duty trucks in China declined by 33% in the first quarter as the industrial economy slowed and the truck industry continued its transition to NS4 emission standards. We estimate that approximately 70% of the industry truck production in the first quarter was NS4 compliant, up from 50% last quarter. Our market share increased to 17% from 11% a year ago and shipments increased of our new ISG 10-and 12-liter engines to Foton and we gained share in the medium-duty truck market with Dongfeng. Shipments of our light-duty engines in China grew 50% in the first quarter as we gain penetration of Foton displacing local competitor engines. We're on track to deliver more than 100,000 light-duty engines in China this year representing growth of 28% in a market that is expected to be flat at best. Our Power Generation revenues increased by 22% year-over-year in a fairly flat market, though performing well and gaining some share in the data center and telecom sectors. Industry demand for excavators in China declined 48% and orders in most categories of construction equipment deteriorated significantly in the first quarter as construction activity continues to contract.Our construction revenues declined by 35%, consistent with very challenging market conditions. With weak demand likely to persist for some time, we did impair our investment in one of our off-highway joint ventures that supplies the China construction market during the first quarter. The impairment reflects lower projections for future cash flows than originally anticipated when we formed the joint venture. Full-year revenues in China across all segments, including joint ventures, are expected to grow 15% for the year, consistent with our view three months ago. We've lowered our outlook for the heavy duty and medium duty truck market, and other markets remained weak, but we've made faster progress in gaining market share than we anticipated three months ago to bring an unchanged forecast for revenue growth. First quarter revenues in India, including joint ventures, were $385 million, up 22% year-over-year, primarily due to recovery in the truck market. Industry demand in the truck market increased 33% compared to the first quarter a year ago, and the economy showed some signs of improvement, and truck orders picked up after two years of very weak demand. We now expect industry truck production to increase 15% for the full year, up from our prior forecast of 8% growth. Power generation revenues in India declined 5% in the first quarter as industry order trends remained weak, especially at the start of the year. We are maintaining our full-year forecast for growth of up to 5% as we see some signs of modest growth and higher risk for our products. In India, we project total revenues, including joint ventures, to increase 8%, up from our previous forecast of 5%, due to stronger truck demand. Our operations in India have a much wider reach than the domestic market as our manufacturing facilities are an important source of low-cost engines and components that we leverage globally. We expect to grow our exports out of India by more than 10% this year, delivering globally competitive products that are helping the power generation business grow profitably in new markets, for example in Africa. First quarter revenues in Brazil were $124 million, down 32% from the first quarter last year with a very weak economy exacerbated by low business and consumer confidence. Industry truck production decreased by 49% year-over-year and our engine shipments declined 33% as the medium-duty truck segment in which we are strongest held up better than the heavy-duty segment which declined by 60%. We have lowered our full-year projection for industry production and now expect a decline of 28%, worse than our previous guidance of down 15%. Very weak production in the second half of 2014 makes for easier comparisons later this year. This explains why full-year production may be down only 28% after such a tough quarter. In summary, we currently expect company revenues to increase between 2% and 4% for the full year, unchanged from our previous forecast. North America remains our strongest market with India showing tentative signs of improvement. We anticipate weak conditions in Brazil and China this year. The marketing conditions in both countries have dipped further. Demand in high horsepower markets including mining and power generation also remain weak. We expect EBIT to be in the range of 13.5% to 14% for the year, consistent with our prior forecast and reflecting improvements in future quarters from a number of cost reduction initiatives, particularly in the engine business. Despite challenging conditions in a number of important markets, we continue to invest in the technology, products and distribution capabilities that will drive future profitable growth. Our successful start to the year in China reflects years of investment and partnership development in that country. We are also winning business in other markets despite weak conditions. You may have seen the recent announcement from Halliburton that have selected Cummins engines to power the first Tier 4 final compliant fracking installation in North America. This is an important win or an example of the power of combining leadership and technology and emissions capability with a deep understanding of customer support in our distribution business. Thank you for your interest today, and now, I'll turn it over to Pat, who will cover our first quarter results and full-year guidance in more detail.

**CFO**
: Okay. Thank you, Tom, and good morning, everyone. First quarter revenues were $4.7 billion, an increase of 7% from a year ago. Our strong on-highway markets and the acquisition of North American distributors more than offset weaker investor markets, as well as the negative impact of currency movements which reduced our sales by 3%. All four segments reported growth year-over-year. Sales in North America, which represented 61% of our first quarter revenues, were up 17% from a year ago, primarily as a result of the higher demand in on-highway markets, along with the impact of acquisitions in our Distribution segment. International sales decreased by 6% due to the negative impact of the strengthening U.S. dollar and from weaker demand in both Brazil and in Europe. Gross margins were 25.4% of sales, 50 basis points higher than last year. The improvement was driven by the stronger volume, lower material cost and productivity improvements, partially offset by higher warranty expense and some unfavorable foreign currency movements. Selling, admin and research and development costs increased by $37 million from the prior year, but were lower as a percent of sales. Acquisitions in our Distribution segment accounted for $28 million of this increase. Joint venture income of $68 million in the first quarter was down $22 million compared to a year ago, with the impact of distributor acquisitions and a $12 million asset impairment charge offsetting a 20% increase in joint venture earnings in China. Earnings before interest and tax increased to $562 million or 11.9% of sales compared to $528 million or 12% last year. The positive benefits of the higher sales and more material costs were partially offset by higher warranty costs, lower joint venture earnings and the negative impact of currency movements. The tax rates in the quarter including discrete items were 26.3% compared to 29.9% last year. Net earnings increased by 14% to $387 million, and earnings per share in the first quarter grew to $2.14, up from $1.83 a year ago. Now, let's move on to the operating segments to further discuss the first quarter performance and the outlook for the full year. In the Engine segment, revenues were $2.6 billion, an increase of 1% over last year. Strong demand in the North American on-highway markets was partially offset by a decrease in off-highway revenues, primarily related to weaker demand in construction, marine and mining markets. Segment EBIT was $253 million or 9.7% of sales, down from 10.5% last year as lower material cost and productivity improvements were offset by the higher warranty expense. For the full year, we are maintaining our guidance for revenues to be flat to up 2%. Strong demand in North American on-highway markets including our higher outlook for our market share in the medium-duty truck market is expected to offset weaker demand in Brazil and in industrial markets. We expect earnings from our China joint ventures to grow as our share of the heavy-duty truck market increases with the ramp-up of our new ISG10 and 12 diesel engines. EBIT projections for the full year remain unchanged at 11% to 12% of sales. For the Distribution segment, first quarter revenues were $1.5 billion, an increase of 55% compared to the prior year. Acquisitions contributed 57% growth, with organic growth from higher engine and product sales in Asia Pacific and North America and the stronger demand for power generation equipment in Africa being offset by the unfavorable impact of currency movements. EBIT margins for the quarter declined from 8% of sales last year to 6%. Margin improvements and existing operations were offset by the negative impact of foreign currency movements, which reduced the segment margins by 170 basis points and by the dilutive impact on the margin percent of the distributor acquisitions. For 2015, we continue to forecast revenue growth of between 23% and 27% over 2014 levels. We now expect EBIT margins to be in the range of 7% to 8% of sale, 100 basis points at the midpoint from our previous guidance, primarily due to currency. Our North American acquisitions remained on track to exceed the projections provided at the 2013 Analyst Day, as Tom just described. In the Components segment, first quarter sales are $1.3 billion, an increase of 6% from last year despite a 3% headwind from unfavorable currency movements. The higher revenues were primarily driven by increased demand in North American and highway markets. Revenues in China increased modestly as higher after-treatment sales more than offset the impact of a 33% decline in industry top demand year-over-year. Segment EBIT of $195 million or 15% of sales was a record, both in dollars and as a percent of sales, including from the 13.6% we reported last year. Higher volumes, combined with lower material costs, drove this improvement. We continue to project revenue growth of between 4% and 8% for the full year, and we are raising our EBIT projections to between 14% and 15% of sales, which is up 75 basis points at the midpoint compared to our previous guidance due to strong performance and cost reduction initiatives. In the Power Generation segment, first quarter sales were $680 million, an increase of 6% year-over-year. Organic growth of 8% was partially offset by a 2% reduction due to currency. Year-over-year growth in most parts of Asia, in Africa and in the Middle East more than offset lower military demand in the U.S. EBIT margins were 7.2% of sales in the quarter, up 330 basis points from last year. Improved operating leverage from higher volumes, along with the benefits of restructuring and from a weaker British pound were the primary drivers of the margin improvement. We are maintaining our guidance for the Power Generation business, with full-year revenues expected to be flat to down 4% and EBIT margins to be in the range of 8% to 9% of sales. Now, let me summarize for the company overall. For the full year, we continue to forecast total company revenues to be up 2% to 4%, with the continuous strength in North America on-highway markets, with distributor acquisitions and revenues from new products, offsetting weak off-highway markets. Currency movements are now expected to reduce our revenues by 3.5% when compared to 2014 levels. We continue to project our overall joint venture income to be down 10% as a result of the distributor acquisitions, partially offset by stronger joint venture earnings in China. We expect EBIT margins of between 13.5% and 14% of sales for 2015 and this compares to 13.2% for full-year 2014, excluding the expenses with cost reduction actions in our Power Generation Business last year. As we indicated three months ago, the first quarter is expected to mark the low point for EBIT margins this year. Improvements in gross margins from material costs, restructuring and higher volumes coupled with stronger year-over-year joint venture earnings in China will drive the EBIT margin this year. An effective tax rate for the full year is forecasted to be 29.5% excluding any one-time tax items. And finally with regard to cash flow, we generated $173 million in cash from operations in the first quarter, lower than last year as a result of an increase in working capital associated with the higher revenues. We continue to expect our operating cash flow to be in the range of 10% to 13% of sales for the full year. The combination of returns to shareholders and capital expenditures resulted in a decline in our balance of cash and marketable securities of $282 million from 2014 year-end levels. We returned $277 million of cash to shareholders in the first quarter through dividends and from the repurchase of 1 million shares and we expect to return 38% of operating cash flow to our shareholders in 2015. Now, let me turn it back over to Mark.

### Q&A
**Investor Relations**
: Okay. Thanks. And I think, operator, we're now ready to turn it over for questions please.

**Operator**
: Thank you. [Operator Instructions] The first question is from Nicole Deblase of Morgan Stanley. Your line is open.

**Analyst-1**
: Yeah. Good morning, guys.

**CEO**
: Good morning.

**CFO**
: Hi. Nicole.

**Analyst-1**
: So my first question is around what you guys felt with respect to oil and gas this quarter. Did you start to see the deterioration in the first quarter of the year? And if so, has the deterioration continue to Q2?

**COO**
: Yeah. Nicole, this is Rich. Actually, the first quarter sales in oil and gas are actually up 67%. Look, it's a bit misleading up, very low comps and we did start to see that deterioration at the end of the quarter. And so, we're now projecting despite a up 67%, 27% drop for the full year. So, we started to see a decline towards the tail-end of the first quarter and we're projecting that going forward.

**Analyst-1**
: Okay. Got it. That's helpful. And then my follow-up question is on the engine margins. Can you guys quantify the warranty headwind that you had during the quarter and what are your expectations for 2Q and then how much of year-on-year tailwind might this be in the second half of the year. If you have any sort of visibility on that would be helpful.

**CFO**
: Yeah. So Nicole, this is Pat. I'll start off and then I think Rick want to say a few words. So in the first quarter in the engine segment, warranty expense was up 1.4% from last year, so 2.6% of sales Q1 last year, 4% of sales Q1 this year. For the company, warranty expense increased from 2% last year to 2.6% in the first quarter this year. For the full year, we are expecting warranty, as Tom said, to come down as we go through the second half of the year and we'll probably end up around 2.5% for the full year, slightly above the 2.4% we reported last year.

**Analyst-1**
: Okay. That's really helpful. I'll pass it on. Thank you.

**Operator**
: Thank you. The next question is from Andrew Kaplowitz of Barclays. Your line is open.

**Analyst-2**
: Thank you. Hey. Good morning, guys.

**CEO**
: Good morning, Andy.

**Analyst-2**
: Tom, I wanted to ask you a little more about China. So, 17% share is an impressive result, I think. What do you think is realistic for the end of the year and into next year for market share? And maybe related, should we expect a  you talked about a material pick-up in JV earnings. Is it really just the heavy-duty business turning to significant profitability for the rest of the year?

**CEO**
: Well, first, let me just talk about market share. I know you were at our Analyst Conference, and the 17% number was what we had projected to say we want to get there by 2018. And somebody asked me, is that your target, and I said, no, my target is 25%. What I'm projecting is 17%, and there's  because there's risk in all those things. We feel really good about being where we are. 17 years, as you said, it's a good accomplishment. It's where we wanted to be, and that's terrific. I don't see a lot more market share gain this year. I mean, I think, as we go out of the year in 2017, I'd still feel pretty good because what we will have successfully done is we've got our light-duty business growing well now at 100,000 units forecasted for the year. We've got our heavy-duty business launched, and that product, the ISG is performing really well. And we're gaining some share at Dongfeng back because our engine is doing better in their trucks than some of their competitor engines, and their trucks are doing better. Remember, they were losing all the share with NS4. Now, they are getting some of that back as the NS4 compliance percentage of all the builders goes up. So, those are all good things. Again, I don't project a whole bunch more shift in those markets this year, but we still  I still have the same target for where I'd like to get over time in terms of market share. Anything you want to add on profitability, Mark, on heavy-duty?

**Investor Relations**
: No, the heavy-duty profitability clearly can significantly reduce or almost eliminate those losses in the first quarter as we've said a quarter ago, so that will pick up. There's still opportunity for the light-duty earnings to grow in China as well as you've said.

**CEO**
: Right. Right. And we are still investing in products, so the joint ventures have investments as well as revenues. Both are flowing through there as you know. But right now, the revenues are going a lot better. So, that's why we're seeing better joint venture earnings. And we expect to see step-up in those earnings in China just to be clear and in subsequent quarters which is one of the drivers in engine business margin improvement.

**Analyst-2**
: Yeah. Got it. And then, Tom, just about power gen, the quarter itself in terms of revenue growth again gained some optimism after several years of not too much going on outside the U.S. So maybe can you talk about, have we seen or are we seeing any type of inflection in power gen or is that too early to call? Not really. I mean just to call like it is, that we're not really seeing much of an inflection in power gen. I think what you're seeing in our results is lots of improvement on cost over a long period of time, slower than we would have liked, as you know. But I think we're gaining some traction now in the cost structure and that's why we're seeing better margin. The sales increases are pretty hard fought, frankly. I mean it's really not much better anywhere. But as we noted, we have a little bit of optimism about India, but even that is pretty early and its optimism in that borders. So, we've got a little bit of signs but not much and most of them are pretty subdued. So, there really hasn't been much change in the markets, I'd say.

**Analyst-2**
: Okay. That's helpful.

**CEO**
: Just to add to that, Andy. The story in power gen is all about improving profitability on the same level of sales right now. So, we feel pretty good about that and we saw the big step-up in Q1, and just recall the restructuring we took in Q4, the maturity of the benefits of that have yet to be realized. So they're kind of second half of 2015, yet to come.

**Analyst-2**
: Okay. Thanks, guys.

**Operator**
: Thank you. And the next question is from Joel Tiss of BMO. Your line is open.

**Analyst-3**
: Wow. I didn't think I was going to make it. How's it going?

**CEO**
: Hi. Good morning, Joel.

**Analyst-3**
: I don't usually. All right. So, I just wondered if, I guess, maybe it's not a fair question. But can you give us any sense if you feel like you're kind of maxing out in the operating margins in the Engine business? And I'm just sort of like looking back at the long-term history and companies who had engine businesses have kind of gotten to 10%, 11%, and had trouble getting a lot higher than that.

**CFO**
: I'll go ahead and take that, Joel. The short answer is no. We're not capping out. I'd give you just a couple of reasons. So, the implied guidance we have for the rest of the year, if you say we were at 9.7% in Q1 and we have not changed our guidance for the full year, so we'll be in the 12% range for the rest of the year. Kind of 11% to 12%, rest of the year. So, we're going to see increased volume. We're going to see increased JV earnings; we just talked about from the China growth. The warranty improvement, which has been a headwind for the last year, becomes a tailwind, being second half of the year and beyond. And then our high horsepower engines are down at kind of historically low levels. And so while the heavy-duty truck is up, we still have the tailwinds which are not here, and we're projecting in 2015 but all of our high horsepower markets are quite depressed right now.

**Analyst-3**
: Okay. And I just wondered, I'm hearing a little bit from other companies about optimism in Brazil getting better in 2016. I'm not asking for a forecast, just sort of flavor of the market. And any thoughts you guys have about Indian strengths continuing into 2016 also.

**CFO**
: Both Rich and I spent some time in Brazil and there was not much optimism when we were there. It doesn't mean it couldn't get better in 2016. It definitely could, but it was pretty bleak. And the problem I think not only is there's some economic weakness, but there was a lot of uncertainty with Petrobras investigation and other things that were hanging over. There's a bunch of good things in Brazil which could help. They've got infrastructure development, again, coming. They've got a lot of investments potentially to be made in those oil and gas fields. So there's a lot of opportunity for Brazil to get better. But there's also a whole bunch way on it right now. So it'd be really hard for me to be optimistic about fast recovery in 2016. It doesn't mean it won't happen, but I'm not particularly optimistic. On South America, in total though, I think has a little bit more opportunity. We also spent time in Colombia, in Chile, in Peru, and frankly, some of those markets have more opportunity even in the shorter run. There's mining in those which are a little depressed. But I would say all those markets are moving faster and have a potential to bounce a little bit quicker. Mexico is another. So the region, we see opportunity. Brazil, we hope comes back soon, but it's pretty down right now. With regard to India, I sort of talked about this, but there's a big infrastructure development program from the new government, a whole bunch of, what do you say, bureaucracy reduction programs and other things that they're trying to do to take decision making times down, all of which sounds awesome. It's a big country to manage and all the stuff that he and his government wants to go are going to be hard to do. So we are very optimistic about the potential and realistic about the timing and pace.

**Analyst-3**
: Okay. That's awesome. Thank you.

**CFO**
: Yeah.

**Operator**
: Thank you. The next question is from Jamie Cook of Credit Suisse. Your line is open.

**Analyst-4**
: Hi. Good morning.

**CEO**
: Hi. Jamie.

**Analyst-4**
: I guess a couple of questions. One, with regards to heavy-duty market share I think you said it's going from 33% to 36%. Can you just sort of talk about your line of sight, is this  and what's driving this, is it a function of one of the major truck or it's just out of capacity, how much is predicated on Navistar? My second question  I'm sorry, back to the engine margins, did the first quarter  I mean you seem confident in your ability to hit I think 11% or 12% for the year, but did the first quarter fall short of your expectations and what's embedded in engine margins in terms of material cost tailwind as well as any cost-related initiatives outside of warranty? And then last, Tom, I think you mentioned quality issues. Can you just correct me if I'm wrong there or elaborate? Thanks.

**CEO**
: That's a lot of questions.

**Analyst-4**
: Sorry. It's been a busy day.

**CEO**
: Yeah. Let me start and Mark, can you remind me on all the questions...

**Investor Relations**
: Heavy-duty share.

**CEO**
: I'll start just with heavy-duty share. So, we're leaving the guidance at 36%, really lower than that in Q1. And as you know, our share is based off of production. So we get some month-to-month variation and quarter-to-quarter variation just what's being produced even versus what's being told. So, we can't  we don't have a lot of visibility but we can see into Q2 and we'll see our share go up, so we have some confidence in that, that the share is going up and we can see it in the order books. And it mixes some again between OEs. So  and it mixes a little bit, our people building 15-liter or 13-liter at a given time. And so, a little more 13 were built in Q1, but we haven't seen that  those were all demand shifts in that.

**Analyst-4**
: Okay.

**CEO**
: So, with OEs, we're up in some and down in others, and I think you know generally what that looks, but no fundamental change there.

**CFO**
: Maybe I'll jump in and take the engine margin question, Jamie. So, yeah. It fell  to be honest, it fell a little bit below where we'd like it to be in Q1. We did go off to a very slow start at the beginning of the year. Things picked up as we went through February and March, so I feel good where we're coming out of the quarter with regard to the guidance for the rest of the year. Tom did make some comment about the asset impairment we took in the off-highway joint venture. That was a $12 million charge in Q1 at the Engine business. The material cost of that tailwind we got in Q1 was around 0.6. We expect that to pick up as we go through the rest of the year. So, they were the kind of key highlights, I think, for the Q1 result and why we feel as confident as what we do about the 11% to 12% margin guidance for the rest of the year.

**CEO**
: Yeah. And Jamie, the cost reduction issue, the material cost, I'll let Mark give you the numbers for material cost. For material cost, things are  programs are going well. We're seeing good benefits in those. Plants are producing well. We're getting productivity out of plants. And as Pat said, when we look at the February and March numbers, our confidence went up a lot that we're going to be able to hit the numbers Q2 and beyond even though the quarter was below in January. Frankly, it was just below our expectations. The  and you asked me if I mentioned quality. That was  are you talking about the impairment charge?

**Analyst-4**
: Well, I mean, you just mentioned quality. I'm sorry. You're the fifth company that's reported for me today, but I thought you mentioned quality issues. I just want to make sure. Can you just elaborate...

**CEO**
: No, no. In fact, the quality issues, I mean, Rich is in these things in detail, so he can comment. But we feel very good about where we are which is why we're sort of constantly projecting warranty coming down the second half but  Rich, you may want to say few words about that.

**COO**
: Yeah, just to recall, we took the rate up in Q2 last year based on the costs for repair being higher than we have forecasted. So, we are tracking each of those improvements to put in place. I've personally looked at them. And then with telematics, we can actually see, are the fixes working as we plan. So, what we really just need now is the miles to demonstrate the improvements and we're on track with that. So, we're projecting the rates begin to come down second half of the year. We've had no new issues during that time. And in addition, just triangulating talking to customers and say, are you seeing the same thing. I personally talk to dozens of them over the last several months and customers are seeing the same thing.

**Analyst-4**
: All right. Thanks. I'll get back in queue. Thank you.

**Operator**
: Thank you. The next question is from Rob Wertheimer of Vertical Research. Your line is open.

**Analyst-5**
: Hi. I wonder if I can just go back to power gen for a minute. I mean, you answered it generally, but I'm curious about general in specific. I mean, are you seeing any major project activity? There's couple in big countries like Brazil and South Africa, you mentioned Brazil which have maybe strains on goods for various regions. Is there a chance that you see a big backlog of orders building in support of the electric goods and situations like that? And the more specific one, if I'm reading my numbers right; power gen was up like five in 3Q, up one and then up  I don't have it here, six or something. And stationary power within engine is up like 14, 18, and 31. I just want to understand the reason for the bifurcation between those two. Thanks.

**CEO**
: Rob, I'll just talk about the broad project markets. There's not a concentrated project demand now. As you said, it does happen and it happens pretty frequently where there'll be some place where there's grid support needed, and we did have a little bit of that in Brazil last year because the water  we had water shortages. And again, it could happen again in Brazil. Their grid is very tight. They depend a lot on hydro, and with the  if there's weak rains, they need more grid support. Going the other way is their power demand is down because the economy is weak. So their reserve margin is a little bit higher than it was even last year. And so, again, it doesn't mean it wouldn't happen, but it's not as likely as it was last year. And it turned out to be some demand, but not as much as we would have hoped last year. So there are projects. Telecom is still a pretty active segment. Data centers are still pretty active, but not like they were. I mean, just generally speaking, the global economy is not as strong, and so all this project demand, it exists, but the level is just lower.

**CFO**
: And I think just in terms of some of the details you're getting into, Rob, yes, the Engine business revenues for stationary power were up a lot. First of all, Q1 was a relatively weak comp last year. The revenues have been influenced by a little bit of a pick-up with high horsepower units. So the revenues indicate a much bigger pickup in the market than the actual unit growth. So I don't think  that's not a sign of something, so much growth rate pickup, just a little bit of improvement at the bottom on the larger gen sets.

**Analyst-5**
: Perfect. Thanks. Bye.

**Operator**
: Thank you. The next question is from Jerry Revich of Goldman Sachs. Your line is now open.

**Analyst-6**
: Good morning.

**CEO**
: Hi, Jerry.

**CFO**
: Hi, Jerry.

**Analyst-6**
: I'm wondering if you could talk about the off-highway pure games opportunity from  now that Tier 4 Final is being implemented, and maybe throw in how the Hedgehog program is going as well? Based on your comments, Tom, it sounds like you're pretty optimistic on applications in pressure pumping. Where do you think your market share can move to, can you just give us the broader landscape?

**COO**
: Let me start, Jerry. This is Rich. Just, I'll start on the Hedgehog. So, we actually are, we're really pleased with where we are on Hedgehog, both in  we have customers secured, we have products in the field now, in power gen market. We have secured business and will begin shipping products, second half of this year. In the rail side, we've secured customers and customer in commercial marine. We're feeling pretty optimistic on that again. And again, having the tier, we will have a Tier 4 solution in rail, that's provided that opportunity for us. So, part of our overall strategy is introduce the emissions technologies. And on-highway, we're using those same technologies and bringing these to the off-highway markets. So the Tier 4, we do be believe is an opportunity for share and currently for more content as we had after treatment and other components to the product.

**CEO**
: Yeah. And the markets, in terms of doing the share, it's  as you'd know Jerry, its pretty complex picture across all of those segments, all of those regions. But we do believe there's pretty significant share gain opportunity both in terms of this larger engine which we don't even go in today. So, that's just all share gain. Plus, as you know, the components side, where we're getting more content is a pretty clear share gain. On the oil and gas side, we're still a pretty small player in the overall scheme of things and it'll be several years with this new larger engine before I think we're a meaningful share of the overall oil and gas market. We have a long way to go there and so we're sort of still at the small end of it, finding things to do. We're just pretty excited about some big customers like Halliburton telling us  hey, your product is technically leading enough and you guys have the customer support we need that will run that depend on you for this fracking installation. That's a pretty good sign that we're in the markets for real. We're still nothing like the size of some of our bigger competitors, but that's a pretty good recognition of where we come in just a few years.

**Analyst-6**
: Okay. Thank you. And then, on currency, in components, really strong margins this quarter even though the headwind was greater than in 4Q. Can you just talk about what's worked out well? And then in distribution, do you folks need price increases to push the margin structure and effectively make up for the currency rates, or are there any other opportunities to improve margin distribution?

**CEO**
: Pat will give you some more details on the currency and the margin. I just want to say from Components, as we talked about last quarter, we had a dip and we knew we were coming back. I mean, the Components business is just performing incredibly well and we knew we bounced back and this reflects that. In terms of some of the improvements, they continue to make though, they're still managing costs incredibly well and driving material cost down. And this is one of the areas where we said we were going to focus on material cost and weak market. That's an area where we know we can make progress and it really had a big benefit here. But that group, not only are we getting good content on the sales side, as we talked about earlier, but we're keeping cost under control and performing and executing well on those cost reductions. They're doing a terrific job, and I think that's why you're seeing the results you're seeing. Pat, you may want to add on that...

**CFO**
: Yeah. On the number side, for Components, we took a 3% headwind on revenue. It wasn't such a big deal at the bottom line. It's like $7 million negative at the bottom line. So, if you were to back that, I had a dilutive impact of 0.1 on return on sales. So, we'll probably see that pick up a little bit even through the rest of the year in terms of the headwind which is part of the reason why we gave this is a little bit low in Q1 results, but as Tom said, it was a really, really good first quarter for Cummins. And we're really pleased with that. The second part of your question around why we're doing our own pricing because this is really on a market-by-market basis. So in some parts of the world, in some parts of Asia, we have these prices to try and offset the problems and headwinds. It's much more difficult in Europe when you're up against European competitors to have built an advantage with the cost structure. So, where we can increase prices, we're doing that and we're really doing it on a market-by-market basis.

**Analyst-6**
: Just overall for the company, the net earnings from currency wasn't significant this quarter?

**CFO**
: No for the whole country, it's like $10 million, wasn't a big deal.

**Analyst-6**
: Okay. Thank you.

**Operator**
: Thank you. The next question is from Timothy Thein of Citigroup. Your line is open.

**Tim Thein**
: Great. Thank you and good morning. Just a follow-up on distribution, there's obviously a lot of noise in these numbers given what you've mentioned with FX but also the amortization. Do you maybe have some kind of, I don't know, just an update in terms of kind of a same-store sales type of metric? I'm especially interested in North America, just given all the movement in terms of the buying of the equity stakes, just how the underlying business in North America which is now pushing 60% of that segment, can you just update us on that, please?

**CFO**
: Yeah. So, I think last year, North America overall, if you know the ownership structure, we'd probably grew it about 9% in North America. This year, it's looking a little slow, it got a little slow with the oil and gas business. But still clearly single digit  north of mid single-digit growth with the strong parts business continuing. I think on just the revenue growth, if you look at the same-store performance, we're delivering consistently over several quarters, 100 basis points or more in segment margin improvement from strong execution on those incremental sales. So, that's really good. To your point, it is maxed somewhat by the currency in particular. But overall, we're pleased with that performance.

**CEO**
: Yeah. And, Tim, you're right. There's a lot of noise. But here's  the simple way to think about it is we have a business where currency is pushing down sales and margins. We've got amortization, which is just a non-cash charge which is pushing down margins, and then we have operating performance pushing forward on margins. And what we said is that we had about 100-basis-point improvement from just organic performance, just execution on same-store sales. We had about a 1% negative on amortization or just the overall kind of a dilution effect, amortization and dilution effect, and then we had negative currency. So, we feel like the business is performing well. We're putting them in. We're getting the revenue and dollar growth. We're getting the operational improvements. And we just got some headwind. And the headwind on currency all sits in the distribution business almost. A little bit in components, but mostly in distribution. It's just the way we do our intercompany pricing and that kind of thing. So, it's just creating more noise. Overall, the company is doing fine with currency. I mean, it's a headwind on revenue. It's not a gigantic headwind on margin. It's just it all sits in the distribution business. So, again, it's going to take a little while for, I think, everyone to kind of peel back these numbers, but the distribution business is doing incredibly well, and we're adding dollar margins to the company better than we expected even and integrating  we'll have 10 businesses integrated by the end of this year that'll be performing incredibly well.

**Tim Thein**
: Okay. Got it. And just, I guess, somewhat related, can you provide a little bit of an update in terms of just parts sales, what the guidance assumes within engine? I see I'm guessing it's kind of a function of small numbers. But the industrial segment, I guess you're guiding to parts growth there. Maybe just a little bit of color in terms of what's contributing to that.

**CFO**
: Sure. Yes. Overall, we're still projecting growth this year. So, kind of 5% to 7%. It's come from a little bit of pricing. North America in particular, with the heavy-duty truck, medium-duty truck is driving that. And then we've held pretty steady, to date, on our high horsepower. So even though some of those markets are down, to date, we've held just about flat to up a point or two there. So, overall, that adds to kind of 5% to 7%. We're down in areas where the markets are way down. For example, Brazil is a down market right now.

**Tim Thein**
: Great. Thanks a lot. Bye-bye.

**CFO**
: Thanks, Tim.

**Operator**
: Thank you. The next question is from Steven Fisher of UBS. Your line is open.

**Analyst-8**
: Thanks. Good morning. In terms of new products, which do you expect to have the biggest impact on revenues and profit this year, and was Q1 consistent with what you'd expect the rest of the year to be?

**CEO**
: I mean, just in terms of one single product, there's a lot of them acting different markets. But one single product, definitely the ISG, and then the ISF after that in China. Those are the places where we're seeing brand-new products launched, going from no sales to good sales. The ISG is the 10th and 12th leader in China that we're selling to Foton. And then the ISF is the light-duty engine we're selling from our Foton joint venture both in China and outside of China. So, those are the ones that I think that are having the most revenue growth just on their own, stand-alone basis.

**CFO**
: I guess I'll just add to that. What's included to that is the after-treatment that goes with those products.

**CEO**
: Yeah.

**CFO**
: And we're up to 20% share in after-treatment in China, for example. So we've designed new aftermarket products there that have added to it. We got the 5-liter V8, but it's not a big number yet this year. We've introduced it. It was built for sale very late in the year. We talked about the Hedgehog which is again not big numbers yet this year but gaining tractions and then our low kVA business.

**CEO**
: Yeah.

**CFO**
: So we feel good about on track with each of the products where we said we would be.

**Analyst-8**
: Okay. Great. And then on the China heavy-duty JV earnings, how quickly do you think you can get that running to kind of $10 million, $12 million a quarter profit from essentially to kind of breakeven levels now?

**CFO**
: Yeah. I mean it'll be profitable. As we said, next quarter, we're there. When we get to $10 million to $12 million, we don't have a forecast we can give you on that yet, but we are moving towards profitability. We will get a good profit stream out of that product. It's just we don't have that  the date for that number yet.

**Analyst-8**
: Okay. Fair enough. Thanks a lot.

**Operator**
: Thank you. The next question is from Ross Gilardi of Bank of America. Your line is open.

**Analyst-9**
: Yeah. Good morning. Thank you.

**CEO**
: Good morning.

**CFO**
: Good morning, Ross.

**Analyst-9**
: I just had a couple of questions. Just on Components, I mean, your biggest customers saw a nice bump in parts margin by selling more company-branded parts. That was one of the reasons. And I was wondering, could you  how was market share trending in Components over the last 6 to 12 months? Do you feel like you're at any risk of losing share in Components as Packard build more of its engines internally?

**CEO**
: Well, two comments. First, just with your opening comment, we may be confusing two things. One is the Components business is a new equipment sale and a parts business. I think you know that. So we are  we sell our components as our brand always and then of course we also have an aftermarket business associated with those. I think that's  but just to make sure. So with regard to our components business, as other companies make their own engines, that  if we lose our engine sale, we gain most of the time in the components side because most of them use some of our components. Packard is the one example you mentioned, so the MX engine uses several important components from Cummins. And we think that's one of the ways that we want to support these OEMs. And so we definitely want them to buy engines if they need engines and we also want to help them with their engines and we've got a bunch of component technologies that can help them make their engine successful and we're willing to go both  do both things with customers which I think makes us a better partner than if we were only willing to do one. So in the MX, where every time an MX is sold, we feel good. We have good business with them on components.

**Analyst-9**
: Got it. Thanks a lot. And then just maybe shifting to the Off-Highway market specifically construction and in North America, CAT seem to benefit from big dealer and stock event that seems likely to unwind later in the year. Do you see the same thing at all? Are you worried about destocking in construction in North American and do you find that your North American Off-Highway customers are leaning heavier for price concessions because I'm hearing a lot  a little bit more about increase price competition downstream in North American earth-moving equipment market.

**CFO**
: What I would say, North America represents probably the most stable to positive global market equipment sales for construction equipment. Its low-single digit, we think. Our issue is really that OEMs ordered a lot of engine last year. They use their engines credits to build products ahead of the Tier 4 final regulations. So, I think the market is stable to improving very modestly, but our businesses and new engine sales are impacted by that transition.

**CEO**
: Yeah. And we don't do any dealer stocking in this area. So, it doesn't mean that our end customers don't, but we're not doing any of that. I think that's probably obviously it works. So, we don't have any dealer stocking kind of issues.

**Analyst-9**
: Okay. Thanks a lot.

**CFO**
: With your question on pricing, just to close on that, generally, as a Tier 1 supplier, we have long-term agreements with each of these. So, it's kind of the retail pricing pressure in the components business. We don't feel that.

**Analyst-9**
: Got it. Thank you.

**CFO**
: Okay.

**Operator**
: Thank you. And the next question is from Alex Potter of Piper Jaffray. Your line is open.

**Alexander Potter**
: Hi, guys.

**CEO**
: Hi.

**CFO**
: Hi. How are you doing, Alex?

**Alexander Potter**
: I'm doing okay. I guess a follow-up to that question, if you were to look at North America, kind of all of your off-highway businesses put together. Obviously, there's a lot of moving parts, a lot of different segments. There's oil and gas in there, but there's construction, there's mining, everything. If you were to put that all together, would you expect that to be up in 2015 or flat or down? I guess, what are you seeing in that regard?

**CEO**
: Down slightly overall. Oil and gas will be down 20% from Q1 levels. It will be down a little for the full year. Mining will be down a little bit for the year. Construction for us will be down. But it doesn't leave many of the significant pieces. Probably commercial marine will be about flat. So, in aggregate, a little down part  will be part to offset lower equipment sales. But low-single digit down, I would say, Alex.

**Alexander Potter**
: Okay. Fair enough. And then the 100,000 units you were alluding to at the Foton joint venture, that's just for light-duty, I gather, but is that just for domestic sales in China, or does that include exports as well in that total number?

**CEO**
: That's just domestic. We're trying to call out what we're doing in China versus the market will be for the 130,000-plus. Now, some of those other markets like Brazil and which were down a little this year, but still overall for the volume.

**Alexander Potter**
: That's market volume, yeah.

**CEO**
: Yes.

**Alexander Potter**
: So 100,000 to China, and then another 30,000, 40,000 elsewhere is what the kind of base numbers are.

**CEO**
: Yeah.

**Alexander Potter**
: Okay. Very good. That's helpful. Thanks a lot.

**CEO**
: All right.

**Operator**
: Thank you. The next question is from Andy Casey of Wells Fargo Securities. Your line is open.

**Analyst-11**
: Thanks for sneaking me in. Good morning, everybody.

**CEO**
: Hi, Andy. You're welcome.

**Analyst-11**
: Just a question on pricing, but looking at regionally specific stuff within the U.S. through your distribution lens, are you seeing any incremental pricing in some of these annual contracts in the energy market  price down, I mean?

**CEO**
: In the Energy and Power Gen market, you mean?

**Analyst-11**
: Yes.

**CEO**
: Okay. Oil and gas, okay. Oil and gas. That's not the structure of our contracts. I mean, I'm not saying that some of our customers aren't seeing that, Andy. Maybe, Rich, you have a closer view. But right now, we're not getting much visibility to that. What we're seeing  our structure of our products is that we're selling engines in, and the equipment sale then gets made, and then somebody else is running the energy contract. It's obvious, though, that the market is under severe pressure, as Rich was describing. And so I would be shocked if there aren't negotiations on operating prices and things like that. But for us, our engine pricing is holding up fine. The equipment pricing is holding up fine. It's just volumes. It's just dropping like its down now.

**Analyst-11**
: Okay. Thank you, Tom. And then looking at the North American truck market a little bit, you've got this kind of nuance with the orders. I'm just wondering, are your customers asking Cummins to increase production rates for the second half, or is it just kind of stable when you get a little bit higher mix?

**COO**
: We have our customers have to come to us, and again, we're seeing it in Q2 to increase the rates to increase our share with them.

**CEO**
: Second half of the year is out ahead of where our order board is, Andy. But second quarter, as Rich said, is what we can see, and that's where we can see the increased orders and ask  and request for us to build more. They're building more, of course. They're increasing their production rates, and then they're asking for more engines from us.

**COO**
: You won't see it in a month, so much for going with that product.

**Analyst-11**
: Okay. That's great. Thank you very much.

**CEO**
: Yeah. All right.

**CFO**
: Thank you.

**CEO**
: Thank you, everybody. Appreciate your questions. Thank you.

**Operator**
: Thank you. Ladies and gentlemen, this concludes today's conference. You may now disconnect at this time. Good day