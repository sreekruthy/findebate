## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCARs Third Quarter 2014 Earnings Conference Call. All lines will be in a listen-only mode until the question-and-answer session. Todays call is being recorded; if anyone has an objection, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCARs Director of Investor Relations. Mr. Hastings, please go ahead.

**CTO**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCARs Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer; and Michael Barkley, Vice President, Controller. As with prior conference calls, if there are members of the media participating, we ask that they participate in a listen-only mode. Certain information presented today will be forward-looking and involve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like tointroduce Ron Armstrong.

### Q&A
**CEO**
: Good morning. PACCAR reported record quarterly revenues and increased net income for the third quarter of 2014. PACCARs third quarter sales and financial services revenues were $4.9 billion and net income was $371 million and after tax return on revenues of 7.5%. Revenues were up 15% and net income increased 20% comparedto the results generated in the third quarter last year. These excellent results reflect increased truck deliveries in North America and records for quarterly sales of PACCAR parts and quarterly pretax profit at PACCAR Financial Services. Im very proud of 23,400 employees who have delivered industry leading products and services to our customers worldwide. During the third quarter, PACCAR repurchased 581,000 shares of stock for $34.1 million. Under the current Board authorization of $300 million, PACCAR repurchased 5.6 million shares for $226 million. PACCAR delivered 37,400 trucks during the quarter, an 11% increase versus the second quarter of this year and 6% higher than the third quarter last year. This growth reflects increased truck deliveries in the U.S. and Canada due to many customers expanding their fleet and the ongoing replacement of older trucks. Industry orders for Class 8 trucks in the U.S. and Canada for the first nine months of this year were over 220,000 trucks, a 38% increase over the comparable period last year. Our customers are benefiting from positive economic trends that are generating record freight tonnage and higher fleet utilization. U.S. auto sales are projected to be over 16 million vehicles and housing starts over 1 million units this year. Other good economic news is that the U.S. unemployment gains this year have averaged 227,000 jobs per month and lower fuel prices are benefiting on customers operating costs. In Europe, it is encouraging that the UK economy, which is PACCARs largest market in the region, is expected to grow by about 3% this year. The Eurozone economies are projected to grow more modestly at around 1%. Year-to-date through September, freight in Germany as measured by the Maut toll system was 3% higher than the same period last year. During the third quarter, market registrations of Euro 6 vehicles continue to increase and were estimated to be about 85% to 90% of the industry. As a result, DAFs market share increased to over 15% for the third quarter. Looking to the fourth quarter, we expect to increase global truck deliveries by 5% to 7% compared to the third quarter, reflecting an increased number of workdays in Europe and the continued strength of the North American Class 8 market. Fourth quarter truck gross margin should be slightly higher than the third quarter reflecting the benefits of higher production levels. U.S. and Canadian Class 8 industry retail sales are estimated to be in the range of 245,000 to 255,000 trucks this year, the highest level since 2006. The 2015 estimate for the U.S. and Canada Class 8 market is 240,000 to 270,000 trucks. For 2014, Europes greater than 16-tonne market is projected to be in the range of 210,000 to 220,000 trucks with our 2005 estimate at 200,000 to 240,000 trucks. Production of DAF trucks in Brazil was steady, with build rates expected to increase gradually in 2015. PACCARs Parts business generated record quarterly revenues of $784 million. PACCAR Parts quarterly pre-tax income was $128 million, an increase of 20% compared to a year ago. The strong results were driven by improved fleet utilization and the many innovative products and services offered by PACCAR Parts. PACCAR Financial Services revenues were $306 million in the quarter. PACCAR Financials pre-tax income was a quarterly record $97 million compared to $88 million earned last year. The improved results benefited from growth in asset balances and strong portfolio performance. PACCARs strong balance sheet and positive cash flow have enabled the company to invest over $2 billion in new products and facilities in the last three years. In the third quarter, DAF introduced many exciting new products at the Hanover truck show including the new DAF CF and XF Low Deck tractors and DAF CF and XF trucks with Predictive Cruise Control. Kenworth and Peterbilt launched the innovative additions to their product lineups including natural gas versions of the Kenworth T680 and T880 and the Peterbilt Models 579 and 567. Capital expenditures for 2015 are projected to be $325 million to $375 million, and research and development expenses are estimated to be $200 million to $250 million. The investments will enhance our global product ranges, aftermarket support and manufacturing facilities. PACCAR continues to enhance its leadership position in the global truck market by developing the highest quality products and services in the industry, investing in new geographic regions and providing excellent returns to our shareholders. Ill be pleased to answer your questions.

**Operator**
: (Operator Instructions). The first question comes from the line of Steven Fisher from UBS.

**Analyst-1**
: Hi, good morning.

**CEO**
: Good morning.

**Analyst-1**
: Youre just talking about some of the CapEx trends there. Im wondering where are we in the investment cycle for parts distribution centers? And then how should we think about how much it would cost to spend into some of the newer regions that youve discussed? Im just kind of wondering against that $2 billion you spent the last few years, are there any particularly big CapEx programs we should be expecting in the next couple.

**CEO**
: I think capital expenditures next year, if you look back at sort of our average spending levels have been in the $300 million to $400 million level on average. And I think next year will be a typical year with continued investment in parts distribution centers. Were going to build a new parts distribution center in Renton, here in the Seattle area. Well continue to invest in new products and continue to invest in improving the efficiency of our manufacturing facilities around the world. One of the things that well be doing next year is investing a new paint facility at our Westerlo plant in Belgium.

**Analyst-1**
: Okay, its helpful. And then in terms of fleet expansion, your customers and you seem to be calling out little bit more clearly this quarter. What have you heard from end customers that maybe different at this point?

**CEO**
: I think the fleets have taken some actions to track more drivers through increasing pay rates and other activities. And so, I think they are feeling better about being able to keep their trucks utilized and of course freight tonnage is at an all time high. So, the demand is there and were starting to see a little bit more willingness to make that fleet expansion.

**Analyst-1**
: Okay, great. Thank you.

**CEO**
: Thank you.

**Operator**
: The next question comes from the line of Nicole DeBlase with Morgan Stanley.

**Analyst-2**
: Yes, thanks. Good morning, guys.

**CEO**
: Good morning.

**Analyst-2**
: So, my first question is around build rates. So you have been stepping up your build rates at your North American facilities. Im just curious today where are we from a plant capacity utilization perspective. How does that compare to prior peak levels? And is there scope to take up your build rates further?

**CEO**
: Were in good shape from a capacity standpoint. We have a fair amount of capacity remaining in several of our plants, in North America. So, we dont see capacity being a limiting factor for our operations in the near term. And so in Europe obviously where I think were in good shape capacity wise as well. So we feel good about our capacity really in all of our markets around the world.

**Analyst-2**
: Okay, got it. Thats helpful. Thanks. And then maybe the second one around pricing. How is truck pricing for you guys during the quarter and whats your view on pricing as we move into next year, because as build rates increase, there could be the scope for pricing term prove in the industry? Im just curious on your thoughts around that.

**CEO**
: Yes. Pricing has been pretty steady for us in the last 12 months. We talked about with Euro 6 coming on board early part of 2014, the market still remains at a relatively low level compared to some of the peak levels. So, pricing continues to be steady. And if there is some opportunity for market improvement as we go forward, maybe some opportunity for pricing realization. But Id say steady is how were thinking about pricing as we go forward.

**Analyst-2**
: Okay, thanks. Ill pass it on.

**Operator**
: Next question comes from the line of Steve Volkmann with Jefferies.

**Analyst-3**
: Hello, good morning out there.

**CEO**
: Good morning. How are you?

**Analyst-3**
: Im well, thank you for asking. I hope everybody is good there. Im curious about maybe sort of another way to think about this pricing thing. How far out are your delivery slots in North America these days kind of roughly?

**CEO**
: I mean, were pretty full for the rest of this year and then just starting to add to our backlog for next year.

**Analyst-3**
: Okay. And did you have sort of a normal price increase associated with 2015? I assume you do that every year.

**CEO**
: There is typical adjustments effective with the model year change and so when that happens next year, there probably would be a list price adjustment that goes with that.

**Analyst-3**
: Okay. Fair enough. And then are you seeing anything on the supplier side with respect to cost or tighter schedules as things ramp up, are they able to keep up with you and is that having any impact on your cost?

**CEO**
: Suppliers did a great job of supporting our build rate ramp up during the third quarter. And everything is running very smoothly at this point and we see no particular challenges with being able to continue to support that and commodity prices are relatively stable. So thats obviously allowing us a stable cost situation.

**Analyst-3**
: Okay. Thank you very much. Ill pass it on.

**CEO**
: Thank you.

**Operator**
: The next question comes from the line of Jamie Cook with Credit Suisse.

**CEO**
: Good morning Jamie.

**Analyst-4**
: A couple of questions. As we think about 2014, you guys have had nice margin improvement on the operating margin line based on how it will trend for the year. The gross margins look like they will probably be more flattish for the year. As we look ahead, do you see further opportunities on the SG&A and R&D side to get operating margin leverage or going forward do the operating margin leverage really need to come more from the gross profit side or gross margin side and can you talk about your comfort level there? And then my other question is just on the markets. Can you talk about sort of the vocational side of the markets how much that was up year-over-year and sequentially? Thanks.

**CFO**
: Well on the cost side, SG&A is -- I think well continue to see comparable levels next year to what weve seen this year. So, I dont see that -- if there is higher revenues that provides some leverage, but spending levels will remain relatively constant and R&D we talked about for next year, our range being in the $200 million to $250 million range as we continue to invest in new products, energy engine efficiency and other product enhancements. So again, that spending level will be in that range somewhere. So again, the leverage will depend on whether we have increased revenues or not to go with that. From a factory standpoint, we will see to the extent that build rates increase, well see some operating leverage as a result of that. So, its a pretty typical operating leverage as weve seen over the years. What was the...

**Analyst-4**
: The second question, so you feel comfortable you could get gross margin improvement next year?

**CFO**
: I think it really depends on the volumes that we see. I think we see pricing has been steady and there is opportunity to get additional operating leverage with additional volume I think.

**Analyst-4**
: Okay. And sorry the last question was just color on the vocational markets, what youre seeing sort of sequential and year-over-year? Thanks.

**CEO**
: Sure. PACCAR does a great job with the vocational business. The vocational market in the North American continent is on order of 25% to 30% of the total market, probably up 5% to 10% year-on-year and our market share is in the 45% to 50% range. So, the good solid steady market for PACCAR. And in Europe the guys are working really hard to capture a larger share of that rigid or vocational business in Europe and certainly its an opportunity for us there.

**Analyst-4**
: All right, thanks. Ill get back in queue.

**Operator**
: Question comes from the line of Andy Casey with Wells Fargo.

**CEO**
: Good morning Andy.

**Analyst-5**
: Hey, good morning Ron. How are you doing?

**CEO**
: Great.

**Analyst-5**
: Good. If I missed it, I apologize. Could you highlight what the truck shipments were in the quarter and then maybe by two of the regions?

**CEO**
: So, total deliveries were 37,400, so I dont know. Well get the information by region, I have it here. So, 37,400 in U.S. and Canada; 23,500 Europe; 9,200 in the West Mexico, South America, Australia and other.

**Analyst-5**
: Okay, great. And then on the 2015 industry sales outlook, I know its the initial view. But between the two primary regions, U.S., Canada and then Europe, which region do you think has the highest likelihood for upside risk at this point?

**CEO**
: Upside risk. I mean, I guess we feel good about the ranges that weve provided, Andy; I dont -- if U.S. and Canada continue at third and fourth quarter pace, it would be probably towards the higher end of that range. And Europe a lot depends on how things develop in the economy over the coming months. So, I dont have a comment which was say more risky than the other. I think we feel good about our ranges at this point.

**Analyst-5**
: Okay, thanks. And then one last one and its along the same lines. If you look at the midpoint, its kind of low single-digit growth in both primary regions. And if you assume no dramatic market share shift in anywhere for you folks, does the modest sales growth suggest modest production growth? And the reason Im asking is youve increase production pretty much sequentially for most of the year, so first part should have pretty good growth?

**CEO**
: Yes, I think were at a production level to support the current market conditions in U.S. and Canada. So assuming the market is near the -- within our range, I think well see fairly steady production levels through next year. And Europe orders have been relatively steady and weve been producing at a pretty steady pace there. And so, well see how things develop as we enter 2015. But our perspective is that the markets will be similar to up depending on how the economic conditions develop.

**Analyst-5**
: Okay. Thank you very much.

**CEO**
: Thank you.

**Operator**
: The next question comes from Andrew Kaplowitz with Barclays.

**CEO**
: Good morning, Andy.

**Analyst-6**
: Good morning, nice quarter.

**CEO**
: Thank you.

**Analyst-6**
: Ron, so maybe we can talk a little bit more about the European truck market. If you look at the data available for the important countries for you guys like the UK that you mentioned and Germany, the data looks still somewhat weak but maybe stable and a low level is more accurate and September did appear a bit better than July from the data that I see. So maybe you could talk about order book and inventory levels in the major European markets for you guys?

**CEO**
: Orders are -- Id say theyve been pretty steady the last couple of quarters and supporting our current build rates. And I dont see anything thats going to cause to change in the short-term. So what was the rest of your question, Andy?

**Analyst-6**
: Inventory...

**CEO**
: Yes. Inventories both for our truck operations and our dealers are in great shape. Dealers have reasonable levels that are consistent with the current market conditions. Id say thats true not only in Europe but also in North America, and if anything dealers can probably use maybe a little bit more inventory in some of our North American activities.

**Analyst-6**
: Okay, thats helpful Ron. And then you talked about your parts related growth this year to be in the 5% to 8% range and it continues to pretty consistently be around 10%. So besides more difficult comparisons as your freedom service continues to get a larger, why wouldnt parts continue to grow at least on the higher end of your previous range?

**CEO**
: Yes, I think as we now work to the point in the year, were 10% up year-on-year, so I think for the full year, well be at the higher end of that range for the full year.

**Analyst-6**
: And as we look in the 15 Ron, I mean again youre going to put in new distribution. And it still seems like its pretty consistent growth there especially with the bigger fleet. Can we expect still at least mid single-digit growth?

**CEO**
: I would expect, our parts team does a great job of putting together innovative programs and services to support our dealers, customers around the world. So, I would think we would see some continued growth in the parts business as we progress into 2015.

**Analyst-6**
: All right. Thanks Ron.

**CEO**
: Sure.

**Operator**
: The next question comes from the line of Ann Duignan with JP Morgan.

**CEO**
: Good morning

**Analyst-7**
: Hi guys. How are you?

**CEO**
: Great.

**Analyst-7**
: Good. Maybe you could take a step back, you know that the vocational market is up about 5% year-to-date. Could you just break that down and give us some more color in terms of construction end markets versus oil and gas? And then what youre seeing in other applications like long-haul versus short-haul? Just give us the more color on where youre seeing the strength in demand.

**CEO**
: I would say that in the oil and gas area activity is steady, probably is the best way to say that year-on-year; probably have a little bit more growth in residential and commercial construction applications. And in the current environment, we would think that that would be the trend moving forward as well. Construction activity would continue to lead the vocational market until oil and gas pricing really recovers from its current level.

**Analyst-7**
: Okay. And perhaps just the same question around fleet expansion; what kind of fleets are expanding, is it common either geographically or tie to oil and gas or not...

**CEO**
: No, Ann Id say the economy is in the midst of long slow economic recovery and its -- all of the segments of the Class A business long-haul short-haul, theyre all responding within the same solid range of growth.

**Analyst-7**
: Okay. So, no one end market or application specific to expansion of fleet?

**CEO**
: Which is great for PACCAR because weve got a very diverse product lineup; were strong in all of those segments.

**Analyst-7**
: Indeed, indeed. And then just finally on Brazil, you normally tell us how many trucks per day youre building, probably today where were going and the market doesnt look great down there, so maybe talk about are you going to continue to proceed ramping up or would you consider curtailing production in the region?

**CEO**
: No, its early days for us and our build rates are steady and we anticipate being able to gradually ramp up build rates as we start into 2015. Our dealers get more of their final facilities in place and operational and we get contact with more and more customers, we have lots of demo trucks that are out with customers that they are testing and were getting traction really as we continue to go week-by-week, month-by-month. So, team has done a great job and weve got a great long-term opportunity in Brazil. So, the short-term situation in Brazil doesnt really impact us.

**Analyst-7**
: Okay. And I think you were at about 3 trucks per day at the end of the last quarter, where are you right now?

**CEO**
: Yes. Were in a 2 to 3 truck range.

**Analyst-7**
: Okay. Ill leave it there. Thanks guys. Thanks for the color.

**CEO**
: All right. Thank you.

**Operator**
: The next question comes from the line of Jerry Revich with Goldman Sachs.

**Analyst-8**
: Hi. Good morning.

**CEO**
: Good morning.

**Analyst-8**
: Im wondering if you could talk about how the warranty performance is tracking on the new products in Europe and I think the industry was just working through some electronics issues on engines in the U.S. Can you talk about how the quality performance has trended since the last time you spoke on the call?

**CEO**
: Yes. Products are great. The Euro 6 products have been very well received by our customers. Obviously, we continue to increase the penetration of engines in North America, 35%, 40%. So, I think we have 65,000 engines in the field these days. And so, the feedback on the engines all of our truck models around the world is excellent and warranty performance is just normal. So, products are doing great.

**Analyst-8**
: And I know your [counting] is deliberately conservative on the warranty side, can you talk about over what time period you would expect the accrual rates to come down and to match that quality performance at least as of last quarter look like youre running 80 basis points plus above normal accrual rates on the new introductions?

**CEO**
: Yes. I think warranty as I said is very normal. There is nothing unusual about our warranty rates. And so, I think well see steady warranty as we go.

**CFO**
: Steady improvement.

**CEO**
: Yes.

**Analyst-8**
: Okay. And in Europe, can you just calibrate us since this was just a transition year. How much this year are your retail sales higher than your production rates on the numbers you shared with us year-to-date. How much higher would the retail sales for your dealers have been?

**CEO**
: One more time Jerry.

**Analyst-8**
: Sure. So, retail sales for your dealers Im assuming were higher than your production this year in Europe given the translation to Euro 6. Can you just talk about how significant that gap was your dealers now, how much do they bring down inventories post the Euro 6 transition?

**CEO**
: No, I think retail sales were pretty consistent with our production levels. Probably maybe a 1,000 trucks or so from the beginning of the year dealer inventory down to where were at today, but its nothing of significance.

**Analyst-8**
: Okay. And lastly, you spoke about the CapEx and SG&A outlook, Im wondering if you could just touch on R&D heading into next year youre coming off of a couple of really significant new product cycles. Is there an opportunity for R&D to move lower in 15 and maybe 16?

**CEO**
: No, I think as we put our range for next year, we think it will be $200 million to $250 million somewhere very comparable to what we saw this year as we continue to invest in our new product line ups and engine efficiency, facility enhancements, new systems to support continuing to improve our business efficiency. So, I think R&D will be in that comparable level as we look at 2015.

**Analyst-8**
: Okay. Thank you.

**CEO**
: Thank you.

**Operator**
: Next question comes from Joel Tiss of Bank of Montreal.

**Analyst-9**
: Hey guys. How is it going?

**CEO**
: Good.

**Analyst-9**
: I think a lot of the operating stuff has been asked already, but I just wanted to ask a little bit about sort of the philosophy of your cash pile and the build-up. I think youve got a little less than $3 billion right now and between 2015 and 2016 you could easily generate another $2.5 billion of free cash flow. And I just wondered if sort of the number and the size of the projects that you already have on your plate plus your special dividend is enough to deal with that or is there any reason to do some new thinking about where you are and where we are in this cycle?

**CEO**
: Well, as were talking about capital expenditures for next year in $325 million to $375 million range, weve got a $0.22 per quarter regular dividend and well take a look at what the year-end might bring with respect to special dividend payments. The Board will evaluate that and make a decision. And we continue to -- its a cyclical business, having a strong cash position is healthy for our company in industry. And well continue to look at alternative uses; and obviously having a strong cash position and strong cash flow gives us a lot of flexibility to take advantage of situations that might arise. And we periodically from time-to-time will go in the open market and repurchase shares, so thats always an option for us. So that will be our plan as we continue forward.

**Analyst-9**
: All right. Thank you.

**CEO**
: Thank you.

**Operator**
: The next question comes from Patrick Nolan of Deutsche Bank.

**Analyst-10**
: Good morning everyone.

**CEO**
: Good morning Patrick.

**Analyst-10**
: Most of my questions have been answered but I wanted to follow back up on the earlier pricing discussion to see if you expand on particularly what youre seeing in pricing in Europe. Have we seen prices move up sequentially? Are you capturing more of the Euro 6 cost than you were earlier this year?

**CEO**
: No, I think pricing is pretty constant. Its -- we have a great product lineup. We have a broad Euro 6 product offering. And so the customers are very appreciative of the great products. And so pricing has been Id say fairly constant as weve moved throughout this year for Euro 6 products.

**Analyst-10**
: And your statement about pricing next year relatively constant as well that price for Europe as well?

**CEO**
: I think itll depend a lot on market demand and the amount of what the market size potential maybe. So at this point, I dont see any significant ups or downs in price expectations for 2015.

**Analyst-10**
: Thanks. And I just had one follow-up on the Q4 shipments, I apologize if I missed it. Can you just discuss how you see shipments materializing for each region sequentially going into Q4?

**CEO**
: So, we talked about 5% to 7% increase in our fourth quarter deliveries with the majority of that coming from just increased workdays in Europe. Our European business has their traditional summer shutdown period during the third quarter. So, that gives us more workdays in the fourth quarter. And then we continue to see the benefits of the strong North American market.

**Analyst-10**
: Thanks very much.

**CEO**
: Thank you.

**Operator**
: The next question comes from the line of David Leiker with Robert W. Baird.

**Analyst-11**
: Good morning.

**CEO**
: Good morning David.

**Analyst-11**
: I wanted to try and picture two items here, first on Brazil. Where are you on coming off the profit curve and breakeven in the region?

**CEO**
: Thats a long-term proposition for us where we do expect to ramp up our build rate in 2015; its held steady. Market conditions are -- its a challenging market but the opportunity for DAF to continue to gain traction and build this place in the market is great. And so we look for continued improvement in 2015 and beyond. And well get to that breakeven point in the near term.

**Analyst-11**
: Is anything as you ramp those, the drag on the numbers might become larger before it gets better or are we opening up on that?

**CEO**
: No, I dont think so.

**Analyst-11**
: Okay, great. And then just a little bit more color if we could on capacity utilization. Where are you in terms of shifts that you are running in your plants and build rates and things like that; anything you can share?

**CEO**
: Yes, I mean were producing at record build rates in our Chillicothe and Denton factories. We still have lots of opportunity to build more trucks and our Renton factory and Sainte-Therese in Canada. Our Mexico factory obviously has some additional capacity, in Europe were in great shape capacity wise. So, good shape really in all of our geographic areas.

**Analyst-11**
: Are you running overtime anywhere?

**CEO**
: No, no scheduled overtime. So, were in good shape and all the capacity investments that weve made over the last five years have really positioned our facilities to be in great shape to support current market conditions, as well as reasonable growth prospects that may come.

**Analyst-11**
: Okay, great. Thank you very much.

**CEO**
: Thank you.

**Operator**
: The next question comes from the line of Bob Wertheimer with Vertical Research.

**Analyst-12**
: Hi. Good morning.

**CEO**
: Good morning, Bob.

**Analyst-12**
: So one quick one on Europe, just trying to sort through the pre-buy and I want a thought that you would have had I dont know deeper overhang just given the geography of where youre selling there for you 1Q might have been worse and would up come up 2Q and 3Q despite 2Q maybe some production shutdowns in August left off. So, Im just curious if you see Europe trending a little bit worse because that overhang was there in 1Q and having not better if you see it steady, maybe Im misunderstanding how your overhang works?

**CEO**
: Yes. I guess Im not clear on what you mean by the overhang?

**Analyst-12**
: Yes. So, 9,300 deliveries in 1Q, 9,200 in 3Q. And I would thought that that 1Q would have been the most depressed just given the pre-buy before that?

**CEO**
: I think as we look at -- build rates have been reasonably steady, I mean we took to build rates up in third quarter and fourth quarter of 2013 to support the demand for the Europe by pre-buy as we reduce that back down at the beginning of 2014. That build rate has been relatively steady at that level through the course of the year.

**Analyst-12**
: Okay. That answers it. That answers. One other question, Im not sure you will be able to address it, but Im just curious given the strong success of your engine -- North America did it come with any launch or its been launched a while back down I guess. But any initial hesitation from customers that would have cost you to have a pricing strategy thats less aggressive and then it proves out to be seemingly really high quality and working well is there opportunity to move the margin up on it?

**CEO**
: No, I think we had a well thought out pricing strategy with our engine when we launched it four years ago in 2010. Weve stayed pretty consistent with our approach. And think the engine obviously provides great value for our customers, it provides a great option for them, its lightweight fuel efficient and reliable and durable. So, great engine. Like I said 65,000 engines in the field currently. And so, I think thats again pretty stable outlook on sort of what we see as pricing and value for our customers.

**Analyst-12**
: Thank you.

**CEO**
: Thank you.

**Operator**
: Next question comes from the line of David Raso with ISI.

**Analyst-13**
: Good morning. Thinking the build schedule for the Europe. I know with the days, its not the cleanest analysis, but Im just trying to think about the build for fourth quarter versus third quarter. It would appear you will be over roughly 10,000 units. Is that the right way to think about the sequential?

**CEO**
: No. Thats fair.

**Analyst-13**
: So with that, when I think of the first half of 15 and I guess really if youre thinking your build schedule being steady, is there any reason to think from what you see in your order book right now that we cant take our fourth quarter build schedule and think of it as at a minimum consequentially flat without the first couple of quarters next year was pretty healthy year-over-year growth in Europe?

**CEO**
: Yes. So, our current thoughts the market will be comparable to this year and that we hope to improve our share of that market as we look to 2015. And so, I think build rates will enter next year at rates comparable to where were at currently.

**Analyst-13**
: And thats always giving to your industry outlook is midpoint and also wide range, but up 2.3% but just taking your prior answer again if you run that build schedule from fourth quarter out, Europe a lot more than that, should we take that to mean some implicit thought about market share or again its a wide range its an early look?

**CEO**
: Yes. And when I say build schedule I am thinking about the daily build rate. And again, our daily build rate has been pretty steady throughout 2014 what has been a difference is the number of work days in the fourth quarter relative to the third quarter.

**Analyst-13**
: Okay. Last question, gross margins a little stronger than you had forecasted at the end of last quarter. What would be driving that in particular? I mean, was there any change on the build schedule versus what you thought was the particularly good mix. This doesnt sound like pricing is necessarily giving it to you as a cost just trying to understand where that gross margin upside came from and how to think about that moving forward?

**CEO**
: Yes. Primarily it was the benefits of operating leverage, 11% up in terms of delivered volumes during the quarter and so really was the manifest of operating leverage.

**Analyst-13**
: And I guess more specifically, the North American production upside, Europe builds were generally as you thought?

**CEO**
: Yes, Europe was and it was really the ability of the suppliers and facilities to deliver the ramp up plans very efficiently and very effectively.

**Analyst-13**
: Okay. I appreciate it. Thank you.

**CEO**
: Sure. Thank you.

**Operator**
: Question comes from Scott Group of Wolfe Research.

**CEO**
: Good morning.

**Analyst-14**
: Hey, thanks. Good morning to you guys. So, I wanted to ask about on the engine side, as you start doing booking orders for next year, are you seeing any further maybe material pickup in engine share on your side as you think that can get to kind of the 50% penetration number next year and how should that impact the gross margin?

**CEO**
: Well, I think we continue to see the increased penetration of our engines over time; in the third quarter, we were in a 35% to 40% range. And so I think deals continue to see a steady progression as time goes. And so 50%, at some point in the near term is not -- is certainly achievable. And as we increased utilization of our factory, there are some operating leverage benefits that come with that.

**Analyst-14**
: And have you seen -- how long after you sell a truck with a PACCAR engine is the aftermarket opportunity on that come through?

**CEO**
: Well, it starts when the engine gets put in service, but that ramps up over time. And so as we increase the number of engines in the field, that aftermarket benefit really starts to take again two to three, four years. So the part stream has a little bit longer tail, the service opportunities because its a captive engine and will be serviced at Kenworth and Peterbilt dealer provides good near-term opportunity for our parts organization to sell parts that are also installed in different service intervals. And so the service captivity is an important piece of the engine strategy.

**Analyst-14**
: Okay. And then last one for you Bob, not a big data on things but that any preliminary thought on pension as a potential headwind for next year?

**CFO**
: Yes, I would just say that our pensions are fully funded and the contribution rates are steady and we dont really expect a much of change from that.

**Analyst-14**
: I was just saying on the expense side from where it is coming but you say nothing material?

**CFO**
: Yes.

**Analyst-14**
: Okay. Thank you, guys.

**CEO**
: Thank you.

**Operator**
: The next question is from Alex Potter with Piper Jaffray.

**CEO**
: Good morning, Alex.

**Analyst-15**
: Sorry. This is Ashley Lee in for Alex. The first question is on margins in the financial service statement. And we saw an improved margin in Q3. Can you maybe talk about how sustainable those margins are on a go forward basis?

**CFO**
: And how are you measuring margins?

**Analyst-15**
: Were taking the -- one second here. Were taking the gross profit by the revenue.

**CFO**
: Okay. So the...

**Analyst-15**
: Gross profit margin.

**CFO**
: Okay. So, the revenues minus the cost. So, part of that is obviously were A+ rated borrower and so we have -- able to borrow at very competitive rates and we were able to support our dealers and our customers for them at very cost effective rates to support our business. Part of the reason for that improved margin is the fact that market rates are trending down and so the revenue number and the cost number both are going down. And so it sort of creates a higher margin percentage just because of market rate movements.

**Analyst-15**
: Okay, got it. Thank you. And then just another question on the outlook in Europe. Lastly WABCO also reported, they expect flattish demand and growth in Europe with the productions forecasts out up 3% to 8% for 2015. I was wondering if you can maybe talk about what your 2015 outlook in terms of production growth?

**CEO**
: I think our market estimate for Europe you were talking about 210,000 to 220,000 this year and next year 200,000 to 240,000. We would expect DAF to earn its typical share of that market and so that will be indicative of production. So, I dont think there is any big difference between sort of market registrations and our production for either year.

**Analyst-15**
: Okay. Thank you very much.

**CEO**
: Thank you.

**Operator**
: Question comes from the line of Adam Uhlman with Cleveland Research.

**Analyst-16**
: Yes. Hi guys.

**CEO**
: Good morning Adam.

**Analyst-16**
: I was wondering if you could talk about what youre seeing in Eastern Europe and Russia?

**CEO**
: Well, our deliveries in Russia this year will be lower than last year effective of some of the uncertainty that exists in that region, but we continue to sell trucks. Weve got a great and growing dealer network in Russia. And so we see it as a great long-term market for us, but certainly impacted this year by whats going on in the region and you see that in some of the other areas. The other areas of Eastern Europe we continue to grow our business there and again see that whole region as a great long-term opportunity for DAF.

**Analyst-16**
: Okay. And then what proportion of your DAF volume is going to be non-Euro 6 for the year do you think?

**CEO**
: Its probably in the 10% to 20% range for the year for Euro 5 and other emissions levels.

**Analyst-16**
: Okay. Great. Thank you.

**CEO**
: Thank you.

**Operator**
: Question comes from the line of Neil Frohnapple with Longbow Research.

**Analyst-17**
: Hi. Good morning guys and congrats.

**CEO**
: Thank you.

**Analyst-17**
: Regarding used truck pricing in North America, what are you seeing in the market and do you think where (inaudible) and just any other color you can add there and how that will potentially impact the new truck side?

**CEO**
: Well, the used market has been very good throughout this year, up 5% to 10% year-on-year. And so its -- there is no signs of that being significantly different in the near-term. So, used truck prices are near all-time highs and were benefiting from that in our finance operations.

**Analyst-17**
: And then can you speak to any early signs on the 11-liter MX engine launch in Europe and wondering if you can just update us on your plans for timing of the launch in North America?

**CEO**
: Yes. So, the plans for launching in North America early 2016. The feedback in Europe has been excellent. I was in Europe in September and met with some customers and dealers and the benefits that engine provides in terms of payload, capacity, the weight, the efficiency of the engine in terms of improved fuel efficiency. Its great for a lot of customer applications. And so, as we see downsizing becoming a growing trend in Europe, the MX-11 is being very well received and well have the launch here in 2016 and we think that will be a nice addition to our engine offerings in North America as well.

**Analyst-17**
: Great. Thank you very much.

**CEO**
: Thank you.

**Operator**
: Question comes from the line of Ted Grace with Susquehanna Financial.

**Analyst-18**
: Hey guys, I was hoping to follow-up on Davids question on Europe. And I know the range you gave is kind of down, call it down mid singles to up high singles. Could you maybe speak to your key markets in Europe and whether you expect those to outgrow and that might help bridge kind of your build rate versus what you jump into next year with versus year-to-date?

**CEO**
: So, the UK, the Netherlands, Belgium sort of our home markets if you will. Got impacted a fair amount of the Euro 5 pull forward and Netherlands and UK had unique transition rules. So, those markets are down quite a bit this year compared to 2013. And the expectation for next year is that those markets will see some growth which will benefit DAF both in terms of production volumes and share position. Were very strong in Central European countries, market leader in Central Europe. And so, I think well continue to see reasonable growth in Central Europe as we go forward. So, I feel DAF, again DAF Euro 6 product has been very well received; the MX or the MX-11 engine has been very well received. So the product line up is as broad and as it never has been and so DAF is well positioned to continue their march towards the 20% market share in the mid-term.

**Analyst-18**
: Okay. So when you overlay your footprint in those dynamics relative to your plus 2% market growth, you should out grow the market by a meaningful portion correct?

**CEO**
: There is potential there for sure.

**Analyst-18**
: Okay. And then the second thing I wanted to ask was on the U.S. outlook. Youve got the midpoint of 2% next year. Could you just maybe about how youre thinking about the on highway market versus the vocational, the relative growth rates, which would be above 2%, which would be below 2% in your forecast?

**CEO**
: I dont think -- we havent got that precise with our outlook. Id say that we expect both markets to continue to grow in the short-term, obviously the long-term well see how things develop. But right now, I think we see as Bob mentioned earlier, the improving construction market conditions will support vocational growth in the short-term and record freight tonnage obviously supports the long haul and less than truckload business as well as in the short-term.

**Analyst-18**
: But the freight side is facing tougher comps. So just intuitively it makes sense to think vocational should grow to faster rate, would that be fair assumption?

**CEO**
: Again, I dont -- we havent thought that precisely about growth expectations.

**Analyst-18**
: Okay. Thank you very much. Good luck this quarter guys.

**CEO**
: Thank you.

**Operator**
: Next question is from Seth Weber with RBC.

**Analyst-19**
: Hey, good morning everybody.

**CEO**
: Good morning.

**Analyst-19**
: Just a couple of quick tie up questions. Just going back to Brazil, have you heard anything about the government subsidies, what their plan is there; I guess post election or how thats looking for 2015?

**CEO**
: Well obviously with the Rusev administration continuing and we expect that those subsidy arrangements will continue, I think there will be some discussions in the coming weeks and months about what exactly those terms and conditions will be. But our expectation is that those will continue in at least a similar form or fashion just to what they have currently.

**CFO**
: We expect to hear the details of the new program in December.

**Analyst-19**
: In December, okay, so you dont anticipate any interruption into next year?

**CFO**
: We dont think so.

**Analyst-19**
: Okay. And then just on the Finco given kind of the low interest rate environment, are larger percentage of customers relative to history using the Finco and how do you handicap what would happen in that business if rates did go higher?

**CEO**
: Over time, the market share penetration, so the percentage of PACCAR trucks that are finance and leasing companies supported then in the 28% to 30% range. And so I think we would continue to expect to see it in that range. Our team provides really strong customer service. Were dedicated to the transport industry. So the increased level of customer service and technology that we have to support the business is beyond what others can offer. So I think well continue to see it in that range.

**Analyst-19**
: Okay, thats all I had. Thank you very much.

**CEO**
: Thank you.

**Operator**
: And the question comes from the line of Jeff Kauffman with Buckingham Research.

**Analyst-20**
: Thank you very much. Hey guys congratulations. Terrific quarter. A lot of my questions has been answered at this point, so let me just as a softer one here. In terms of the ASP and the improvement youre seeing there, how much of thats coming from customers, how many you say I listened, I just want different specs on my truck and here is how I want to expect and maybe look at what your heavy duty buyers are asking for versus medium duty and I know there is a lot of different kinds of markets there versus youre going out there and saying look the base truck is just (inaudible).

**CEO**
: Well, when you say ASP I guess youre talking about average selling price just to make sure were right.

**Analyst-20**
: Right. And I understand that thats kind of a residual fall out between revenues youre generating and units youre selling.

**CEO**
: Well, our discussions with our customers are all based on the value that we provide to them to meet their needs and each customer is different and their expectations and demands may change overtime. So, its a very dynamic pricing environment and we price our product to earn fair return and provide them a great product that they can have the lowest lifetime operating costs for their operation.

**Analyst-20**
: All right. Let me follow-up a different way. At the dealership level with the Parts and Service business being so strong, how was the absorption rates at your dealer levels trending right now and where do you think youre going to be in terms of dealer inventory?

**CEO**
: So absorption rates are trending up. Our dealers are performing excellently and taking advantage of the high freight levels and providing great service, extending their hours of service, opening new facilities. So, you see the benefits of that in their business. Their inventories are in great shape. And as I mentioned earlier, in fact maybe they are bit too low from where maybe the optimal situation might be. But dealers are doing very well in North America, as well as in Europe.

**Analyst-20**
: Okay. Big questions have been answered, so thank you for the follow-ups guys.

**CEO**
: Thank you.

**Operator**
: There are no other questions in the queue at this time. Are there any additional remarks from the company?

**CEO**
: Id like to thank everyone for their excellent questions. And thank you, operator.

**Operator**
: Ladies and gentlemen, this concludes PACCARs earnings call. Thank you for participating. You may now disconnect.