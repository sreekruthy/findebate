## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCAR's First Quarter 2014 Earnings Conference Call. [Operator Instructions] Today's call is being recorded, and if anyone has an objection, they should disconnect at this time. I would now like to introduce Mr. Robin Easton, PACCAR's Treasurer. Mr. Easton, please go ahead.

**Other**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Robin Easton, Treasurer of PACCAR, and joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer; and Michael Barkley, Vice President, Controller. [Operator Instructions] Certain information presented today will be forward-looking and involve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

### Q&A
**CEO**
: Good morning. PACCAR reported improved revenues and net income for the first quarter of 2014. PACCAR's first quarter sales and Financial Services revenueswere $4.4 billion, and quarterly net income was $274 million and after-tax return on revenues of 6.3%. Net income increased 16% compared to the results generated in the first quarter last year. I'm very proud of our 21,700 employees who have delivered industry-leading products and services to our customers worldwide. 2014 marks another major milestone for PACCAR, with Peterbilt celebrating its 75th anniversary. The company's 75-year tradition of excellence and innovation has established an uncompromising focus to deliver the highest levels of product quality, customer satisfaction and return on investment. PACCAR delivered 31,800 trucks during the first quarter, a 4% increase versus the first quarter last year and in line with our expectations. The improvement reflects increased truck deliveries in the U.S. and Canada due to the ongoing replacement of the aging truck population and improving construction in automotive sectors. Looking ahead, we expect to increase truck deliveries in the second quarter by 8% to 10% compared to the first quarter. Second quarter gross margins should be somewhat higher than the first quarter, reflecting the benefits of higher production levels and improved operating efficiency. It is encouraging that housing starts in the U.S. are over 900,000 units, and there's growth in nonresidential construction. Other good economic news is that U.S. auto production should be around 16 million vehicles this year. These positive trends should benefit truck demand in North America. U.S. and Canadian Class 8 industry truck retail sales are estimated to be in the range of 220,000 to 240,000 units this year, up from 212,000 units in 2013. The stronger market reflects ongoing replacement demand and some expansion in industry fleet capacity due to continued strong freight fundamentals. Industry truck orders for the U.S. and Canada in the first quarter were 80,000 units. Economic news in Europe is trending positively, with GDP growth expectations for this year of 1%. Freight in Germany, as measured by the amount index, has risen 5% compared to the same period last year. Europe's greater than 16-tonne market is projected to be in a range of 200,000 to 230,000 units. Customers in Europe accelerated purchases of Euro 5 vehicles in the second half of last year and are adjusting to the increased prices of Euro 6 trucks. Production of DAF trucks in Brazil is progressing, with production levels expected to increase gradually through 2014. PACCAR's Parts business generated quarterly revenues of $727 million, a 9% increase compared to $667 million in the same quarter of the prior year. PACCAR Parts' quarterly pretax income was $112 million, an increase of 18% compared to the $95 million earned in the first quarter of 2013. The strong results were driven by increased freight tonnage, improved fleet utilization and the many innovative products and services offered by PACCAR Parts. PACCAR Financial Services revenues were $294 million in the first quarter, comparable to a year ago. PACCAR Financial's first quarter pretax income was $86 million compared to $80 million earned a year ago. The improved results benefited from growth in asset balances and excellent portfolio performance. PACCAR's strong balance sheet and positive cash flow have enabled the company to invest over $2.2 billion in new products and facilities in the last 3 years. PACCAR began production of the new vocational Kenworth T880 and that Peterbilt Model 567 trucks in late 2013. These new vehicles expand PACCAR's offering in the construction, utility and refuse markets and complement the Kenworth T680 and Peterbilt Model 579 on-highway trucks launched in 2012. The launch of the new DAF XF, CF and LF Euro 6 vehicles in 2013 strengthen's DAF's position as the leading provider of integrated transport solutions. PACCAR's capital spending of $300 million to $350 million this year is targeted at enhanced powertrain development and increased operating efficiency of our assembly facilities. Research and development expenses are estimated to be in a range of $200 million to $250 million. PACCAR continues to enhance its leadership position in the global truck market by developing the highest-quality products and services in the industry and by investing in new geographic regions. Thank you. I'd be pleased to answer your questions.

**Operator**
: [Operator Instructions] Our first question comes from the line of Jamie Cook from Credit Suisse.

**Analyst-1**
: Actually this is Andrew on behalf of Jamie. So I just have a quick question. Can you just comment quickly on your parts business in the quarter? And what you're seeing particularly across each region?

**CEO**
: Yes, the Parts business had good growth, I'd say slightly a little bit stronger in the U.S. and Canadian markets compared to some of our other markets, but good growth in really all regions for the quarter. And I think that's evidence of the improving freight conditions that we've seen both in North America and Europe.

**Analyst-1**
: Then just along those lines, with the -- given how the U.S. has trended going forward, what do you guys see for the remainder of the year in terms of just the North American market?

**CEO**
: Are you talking about the truck market or the parts business?

**Analyst-1**
: Yes, trucks.

**CEO**
: Our projection for U.S. and Canada is in the range of 220,000 to 240,000 units. And so we're thinking that the market will progressively improve as we go through the year and we have -- and we talked about our planned production increase of 8% to 10% in the second quarter.

**Operator**
: Your next question comes from the line of Stephen Volkmann from Jeffries.

**Analyst-2**
: I'm going to drill in a little if you let me on this production increase of 8% to 10% in the second quarter. Can you just give us a rough magnitude of how that breaks down sort of, U.S. versus Europe, and then maybe even heavy versus medium, if you would?

**CEO**
: I'd say, on the heavy versus medium, I would say that the increases are comparable across those categories. And in terms of geography, I'd say the increase in the U.S. and Canada is probably a little bit higher than that average percentage, and Europe is a little bit below that.

**Analyst-2**
: Can you talk a little bit, I think historically, once we hit some sort of inflection point, I'm not sure really where that is but we would expect to get a little bit better pricing as you start to build the backlog further out, are we there yet? Is that happening or is it maybe something different this cycle? Just any comment on that.

**CEO**
: Well, I think, as we've progressed through the market, we continue to work closely with our customers and be very competitive in the marketplace, providing the best solutions. You look at things like our industry-leading residual values, allows us to provide a very competitive price to our customers with the lowest operating life cycle costs of any of the manufacturers. And so we can provide a very attractive proposition, and we'll continue to gauge the market and price accordingly.

**Analyst-2**
: All right, maybe more simply then, is pricing up year-over-year or flat or down?

**CEO**
: I would say it's maybe up a bit.

**Operator**
: Your next question comes from the line of Ross Gilardi from Bank of America.

**Analyst-3**
: I would just wonder if you talk a little bit more about Europe, some of your other competitors have kind of suggested things, maybe slightly better, could you talk a little bit more about DAF orders during the quarter?

**CEO**
: Sure, as we transition from Euro 5 to Euro 6, I'd say orders started off in the first quarter, soft in January, we've seen progressive improvement through February and through March, and we discussed some good momentum as we head through the rest of the year so we feel good about DAF's continued strong position in the European market.

**Analyst-3**
: And then just shifting to Brazil, I mean, obviously, the economy faces challenges there. Is it making it tougher for you to gain traction there? Many of your peers seem to be complaining about the slowing environment and pricing pressure, obviously you're kind of starting more from a ground zero position, but what's your thoughts on Brazil?

**CEO**
: Yes, I think Brazilian market does have its challenges but as you mentioned, we're in a startup mode, really focused on getting our production, our distribution network well-established, doing it all right first time, if you will. And so market conditions aren't as significant to us and we'll continue to progress in our build plans, shouldn't affect our plans for 2014.

**Analyst-3**
: Okay, great. And then just lastly, I'm just wondering, could you give a little more color on why you think orders have been so strong in North America so far year-to-date? What are you hearing about -- from customers on the sustainability? Is the issue that your customers are finally getting pricing power for the first time in a long time and therefore are more willing to invest, but anything you provide there will be helpful.

**CEO**
: I think, it's a matter of confidence. You look at the customers today and over the past years, there's been a lot of uncertainty about how significant the economic improvements might be and what might the government do. And I think some of the positive things that the government was able to achieve in the fourth quarter last year, with solid budget plans without stopping the government. And so I think people feel better about the ability to support, keeping their trucks active and being able to get fair rates off to get for their business. So I think it's a matter of confidence.

**Operator**
: Your next question comes from the line of Andrew Kaplowitz from Barclays.

**Analyst-4**
: Can I ask you about your other revenues? You talked and broken it up in the past about geography, maybe if you could do that again. The number sequentially continued to come down a little bit. Has there been an impact on you Russia business and is Mexico still kind of weak, when it comes down to it?

**CEO**
: I think there is some softness in Mexico. We saw their economic situation was challenging in the second half of last year, but I think we're starting to see some signs of recovery in that market and Australia has been up and down a little bit with the effects of the mining industry, but starting to see some solid business there. So I think we see some of the other markets starting to show some positive signs.

**Analyst-4**
: Okay, and then maybe can you talk about the penetration of the new products that you had over the last 6 months, a lot of vocational trucks? I would assume that they come with modestly higher margins and maybe you could talk about the overall construction market and its receptivity to these trucks. Have you seen a pretty good growth rate out of these trucks here in the early going?

**CFO**
: This is Bob Christensen. So the impact of productions with our new models, at Kenworth and Peterbilt, is about 50% new model production. Of course, DAF is almost 100% with our new Euro 6. With respect to the vocational market, we're seeing strong growth in the overall market, and both Kenworth and Peterbilt have high penetration levels. And so we're selling a lot more vocational trucks than we have over the last 3 or 4 years, and that's good for PACCAR and good for our customers.

**Operator**
: Your next question comes from the line of Jerry Revich from Goldman Sachs.

**Analyst-5**
: I'm wondering if you could talk about the margin ramp over the course of the year, presumably as Europe ramps up, margins should improve each quarter sequentially from here. But can you just help us with the order of magnitude for improvement in the second quarter? Can you come close to the 13% gross margins you were delivering last year? Do you need a healthier European truck production environment before we could talk about that margin range?

**CEO**
: I think we see second margins probably improving somewhere in the 20 to 40 basis point range for the second quarter, continue to be able to leverage our cost structure. DAF in the first quarter transitioned its production from roughly 15% Euro 6 vehicles to 80% Euro 6 vehicles. And so that transition now is done, and DAF -- the DAF team did a tremendous job of really transitioning that product line and achieving great production efficiency as they transition. And so we will continue to see -- depends on the market conditions and et cetera, but we're well-positioned to the extent that we're able to continue to increase our production levels, we'll achieve some level of operating efficiency with that.

**Analyst-5**
: And in Brazil, I know you're all-makes parts business is it a big part of distributor build out strategy? Is that a significant part of the parts franchise where you can give us a sense for how that's going and just give us, if you could and update on the broader distributor build out there?

**CFO**
: So the Parts business will start slow in Brazil and will build out over a long period of time. Certainly, the all-makes program that you refer to is an important part of our strategy. We have 20 dealer locations in Brazil, and they are all beginning to sell both trucks and parts. But it's going to be a slow ramp-up over the next several quarters, if not years.

**Analyst-5**
: And from a capital deployment standpoint, Ron, I think you in the past spoken about a 45% to 50% net income payout ratio, is that still the way to think about business and any other capital uses that we should be thinking about?

**CEO**
: Obviously, first point of investment is back into our products and our services and our facilities to make sure that we can continue to provide the best trucks and the industry leading operating efficiencies that we're accustomed to. Our payout ratio has been in the range that you talked about, but obviously that's a matter that's reviewed and discussed with the board over time. And so we'll continue to monitor that and adjust our capital deployment strategies as we go forward.

**Analyst-5**
: Okay, and lastly, think you did nudge down your CapEx and R&D outlook for the year, can you just give us a sense for what's driving you, I guess, to the lower end of the previous range?

**CFO**
: Yes, as we look at specific things that we're doing, and we continue to invest strongly in our products and our services. And so, as we look at where we're at and where we're going, just felt like we're probably going to be at the lower end of those prior ranges as we look forward, there's a lot of things that we're looking at, as we go forward to maintain a strong, steady flow of new products and services and keep improving our warehouse and plant operating efficiency.

**Operator**
: Your next question comes from the line of Rob Wertheimer from Vertical Research.

**Analyst-6**
: So just a quick question on the gross margin in the quarter, which is lower than it's been for a long time and the overall margins weren't all that bad obviously, but curious as to whether that was the pass through the European price increase or that was mix in the U.S. Maybe if you just give some color around it, maybe you didn't see this all that bad, and just wanted your take.

**CEO**
: We feel good about how the teams performed around the world. In Europe, the Euro 6 product, as I mentioned, was a higher percentage of our deliveries in the first quarter, and with that comes a -- about a 15% average price increase for the price of a Euro 6 truck and we were able to recover that cost increase but the ability to make a margin on that increase was challenging just given the transition in the competitive environment that we were placed with in Europe.

**Analyst-6**
: Okay, great. And then if you could just comment on, if you're willing, on the margin environment in U.S. Perhaps it was more big fleet deliveries than it will be for the rest of the year, I don't know if it's an abnormally fleet driven quarter?

**CEO**
: Margins are solid, our teams are doing well and we're competing very well in the marketplace. So we feel good about where we're at in North America with margin-wise.

**Operator**
: Your next question comes from the line of Seth Weber from RBC Capital Markets.

**Analyst-7**
: Just following up on an earlier question on Europe, I mean, the trends there do seem to be a little bit better-than-expected. Is there something that you're seeing that's preventing you from raising your market outlook for the European market this year or you're just trying to be conservative?

**CEO**
: Yes, we didn't feel like there was enough evidence at this point to raise our outlook because there's a mix of Euro 5 and Euro 6 trucks that are being registered and delivered to customers right now. And so we felt like we'll continue to monitor that as we always do. We'll be smarter in 90 days than we are today, and we'll modify our market estimates as we see fit based on how things develop. But we didn't feel like there's enough evidence, probably, change at this point.

**Analyst-7**
: Okay, understood. I guess, follow-up question on the MX 13, can you give us the penetration there on the Kenworth and Peterbilts, and just an update on where you are with the capacity?

**CEO**
: Yes, the MX is 35% to 40% of our build for Kenworth and Peterbilt heavy duty trucks. And we continue to support the production and have all the great shape from a capacity standpoint and lots of opportunity to continue to grow that penetration within our product line.

**Operator**
: Your next question comes from the line of Ted Grace from Susquehanna.

**Analyst-8**
: The first question I have was a follow-up on Jerry's. He'd asked about the operating margins relative to a year ago. Ron, you mentioned you thought you could expand them 20 to 40 basis points, was that a sequential comment or a year-on-year comment?

**CEO**
: That's a sequential comment.

**Analyst-8**
: Okay, that's helpful. And then as it relates to Europe, can you just bifurcate how you're thinking about kind of the U.K. versus of the continent in terms of end-market improvements in 2014?

**CEO**
: Yes, so the U.K. and the Netherlands had their -- they follow one set of Euro 5, Euro 6 transition rules. The other markets followed a different set and so you saw in the first quarter registrations, the U.K. the Netherlands were down and those were markets where DAF has a market leadership presence and on the continent, Germany, France, Spain, had increases again because they had different transition rules for Euro 6. So I think we'll see that the Europe -- or that the U.K. and the Netherlands will accelerate in terms of total market because U.K. economy is good and the Dutch economy is starting to show signs of improvement as well.

**Analyst-8**
: Okay, that's helpful, then the last thing before I get back in queue, over the last couple of years, the first quarter has tended to be the most weighted on SG&A, is that progression you should look forward or repeat itself in 2014 or might there be any change in that normal pattern?

**CEO**
: No, I think that's probably what you should think about it. The SG&A numbers will be comparable to a little bit down, maybe as you progressed through the rest of the year.

**Operator**
: Your next question comes from the line of David Raso from ISI Group.

**Analyst-9**
: First a clarification, when you said margin is up 20 to 40 bps, 1Q to 2Q, that was gross margins, not operating, correct?

**CEO**
: That's gross margins, correct.

**Analyst-9**
: That were 2 different answers, so gross margins. On the production, the first and second quarter just hopping between a lot of calls today, my apologies, can you re -- say -- state again the production changes first quarter to second quarter, and then an answer to an earlier question, North America versus Europe? Can you just repeat that, please?

**CEO**
: Our expectation is for overall production to be up 8% to 10% in the second quarter compared to first with slightly above average -- above that average in the U.S. and Canada and slightly below that average in Europe.

**Analyst-9**
: And we don't have the detail yet about the truck sales with the breakdown, some I'm going off of more kind of total geographic revenue, so I apologize, but does that seem to imply that we're going to be up in Europe again year-over-year in revenues in the 2Q?

**CEO**
: Again remember that the Euro 6 vehicles, the average sales price for a Euro 6 truck is about 15% higher than a Euro 5 vehicle. So that's part of the equation.

**Analyst-9**
: Maybe that's my question, sorry to interrupt, when you say production, I'm thinking unit production, you're speaking in revenues.

**CEO**
: Yes, production and deliveries are the same for us.

**Analyst-9**
: Okay, that's a distinction, so it's the pricing, which is particularly help a sequential Europe. Are units going up sequentially 1Q to 2Q?

**CEO**
: They are, yes. So when I talk about a the 8% to 10%, that is units.

**Analyst-9**
: Okay, so that was different than what you just said it. 8% to 10%, North America up more, Europe up a little less, is that as units or is it including the pricing from Euro 6, I apologize, to be clear.

**CEO**
: That is units.

**Analyst-9**
: That's interesting, so if units are up that much and then the pricing on top of it, as I assume that's even a lower heavier mix Euro 6 in the first quarter say you had some Euro 5 going out to start the quarter, the year-over-year growth in Europe sounds healthy in 2Q, North America strong, I do appreciate you not getting any margin on that Euro 6 price increase, but with that backdrop, the gross margin still seem to be a little more challenging you would have thought. So just trying to flesh out why the gross margin is going to be, let's just take the exact comment, 20 to 40 bps at only 12.3%, why would that not be up more? I'm just trying to be clear. Is there something about North America or, is it look we're just not getting any incremental margin on that Euro 6 pricing?

**CEO**
: I mean, there's not an incremental margin on the Euro 6 pricing as we said here today. As we progress through the year, the market improves, it could be an opportunity.

**Analyst-9**
: So the last question related to that, do we expect the gross margin to be up year-over-year at all in this year, meaning third quarter or fourth quarter, without the second quarter is implied, it's down year-over-year again?

**CFO**
: I think as we look for I think -- as we see here today, that the margin this year will be comparable over the prior year but that will depend on how the markets progress, how the pricing situation progresses, et cetera, so there's a lot of variables in that equation.

**Analyst-9**
: Okay, so we get back to full year the same, we do need a little bit of growth somewhere year-over-year in the second half?

**CEO**
: Yes, right.

**Operator**
: Your next question comes from the line of Neil Frohnapple from Longbow Research.

**Analyst-10**
: A follow up to Seth's question on the MX engine, part segment pretax margins were up record level in the quarter, just wondering if you're starting to see benefits from the increased MX penetration rate that's occurred over the last few years, or is tailwind that still -- could still be to come?

**CEO**
: I think it's still to come. It's obviously the more engines we have in the part, the more opportunity we have for parts sales. But that's still developing, that part is up to 55,000 engines that we've put into Peterbilt and Kenworth vehicles. And so it's a great story but one that there's still a lot more upside as we progress.

**Analyst-10**
: Got it. And then sorry if I missed this but can you provide a breakdown of the new truck deliveries by geographic region in the quarter? I think you mentioned 31,800 for a total company, but just wondering if you can provide more granularity between Europe and North America?

**CEO**
: Sure, so for U.S. and Canada, 18,600 units; Europe, 9,300 and rest of world, 3,900.

**Operator**
: Your next question comes from the line of Jeff Kauffman from Buckingham.

**Analyst-11**
: Actually, lot of my questions have been answered so I'll just follow-up on an earlier clarification. The gross margins that you mentioned, you're just not getting gross margin on the increase in Europe, but that doesn't explain the full amount, and it looks like gross margins are trailing down 50, 60, 70 basis points. Is there anything else in there that's kind of complicating that analysis?

**CEO**
: No, I don't think so. Obviously, we're in the startup mode in Brazil but I think it's -- we feel good about where we're at and the margins are solid.

**Operator**
: Your next question comes from the line of Alex Potter from Piper Jaffray.

**Analyst-12**
: First of all, I guess I have kind of high-level philosophical question here, and I guess you kind of break it into 2 parts. Number one, do you think over the next 2, 3, 5 years there's going to be a higher percentage of fleet buyers as a result of our service and everything else pushing these smaller fleets and owner operators out of the market. That's part 1, and part 2 of the question is, if so, do you think that, that's going to drive, I guess, lower peaks and higher values or less kind of amplitude of the truck cycle as we go forward?

**CEO**
: I mean, I guess, we've seen that trend with fewer owner operators, more fleet buyers in the market over the last 5, 6, 7 years, will it continue or is it to a point where it's about where it's going to be, I don't know but we're ready to be able to flex to whatever -- however, the market evolves. I think we've seen customers being very prudent in their purchasing habits over the last 2 or 3 years, as there's been uncertainty. Will that lead to less volatility? I don't know. But clearly, I think buyers of trucks have exercised restraint, if you will, as they lack the clarity of their ability to put trucks into operation and maintain those, and I think we're seeing improved confidence in that realm. And so, as backlogs get extended whether that changes, we'll see how that develops.

**Analyst-12**
: Okay, and then I guess the last question here is shift on natural gas, I was wondering if you could give a quick update also if possible, what percentage of your production approximately right now is natural gas?

**CEO**
: Well, we continue to be the leader in the natural gas business, but it continues to be very much a niche market. It's probably 1% to 2% of our production, is what we see and what the industry is seeing. And so as we look forward for the near future, it will continue to be a niche market, one that we're prepared to serve, but not a major element.

**Operator**
: Your next question comes from the line of Scott Group from Wolfe Research.

**Analyst-13**
: So I know there have been a lot of questions on the gross margin. I want to ask one on the operating margin. So if I kind of plug in what you guys are kind implying for revenue and gross margin, it's tough for me to see much operating margin or any operating margin improvement in the second quarter, and I know you saw good operating margin improvement in the first quarter. So just wondering, does that sound about right with the way you guys are thinking about it?

**CFO**
: I don't have those numbers lined up in front of me but -- so I think as we look at our R&D spending range, or SG&A, so we feel second quarter we'll see numbers comparable to the first quarter in those areas. And so I think -- the operating margin probably, would be in terms of trend, similar to what the gross margin has trended from first to second quarter.

**Analyst-13**
: Okay, that makes sense. In terms of share, down maybe just a little bit year-over-year, I know it can be choppy, but how are you thinking about Class 8 share going forward the rest of the year?

**CEO**
: Obviously Peterbilt and Kenworth have some great new products that they've launched in the last 6 to 18 months and those markets have -- gained great acceptance with our customers. As we continue to add additional features and elements that the market expects, then we'll continue to grow that. So Peterbilt and Kenworth are in great shape. Market share has been very consistent over the last 2 or 3 years and we think there's more upside as they continue to get more customers in these new trucks.

**Analyst-13**
: And then just last one, if we go back historically after a new big product launch, where there a new technology or regulation, where the cost of the truck goes up a lot, how quickly do you, after that, is it 1 quarter or 2 quarters a year before you can start to make a little bit of a margin on that price increase?

**CEO**
: I mean, it's really dependent on the market conditions. And so if there's a improvement in market demand, that opportunity can present itself. But if you recall in 2010, it's a big increase, and it takes a while to work through that.

**Operator**
: Your next question comes from the line of Sara Majors from Wells Fargo Securities.

**Sara Majors**
: I'm on for Andy Casey. Most of our questions have been asked and answered, but I wanted to explore the pricing pressure question a little bit more. I know you had said that pricing was up a bit but could you give us a little bit more color on how pricing trends are geographically either U.S. and Canada and then European market? And then how competitive are those in the market versus the recent past?

**CEO**
: So I think we talked about Europe, that the pricing is up, consistent with the additional content that's added with Euro 6 and in North America. We're looking at small price realization enhancements as the market allows but it's a very competitive -- it's always competitive, I mean, that's the nature of our business and there's -- you always look to have the best value looking at the opportunity to provide your customers the best transportation solution and that includes operating costs, residual values, and we think we have a great solution for our customers.

**Sara Majors**
: I mean, and in the U.S. and Canada, what's the competitive environment surrounding pricing right now?

**CFO**
: It's always competitive. In all markets. It's what we do. And so we have great new products and great dealers and excited employees and we're pushing ahead and making inroads with new fleets that are appreciating the new Kenworth and Peterbilt models. And, but, for as long as I've been here, it's always competitive.

**Operator**
: There are no questions in the queue at this time. Are there any additional remarks from the company?

**Other**
: I'd like to thank everyone for their excellent questions. And thank you, operator.

**Operator**
: Ladies and gentlemen, this concludes PACCAR's earnings call. Thank you for participating. You may now disconnect.