## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCARs Fourth Quarter 2014 Earnings Conference Call. All lines will be in a listen-only mode until the question-and-answer session. Todays call is being recorded; and if anyone has any objection, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCARs Director of Investor Relations. Mr. Hastings, please go ahead.

**CTO**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCARs Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer; and Michael Barkley, Vice President, Controller. As with prior conference calls, if there are members of the media on the line, we ask that they participate in a listen-only mode. Certain information presented today will be forward-looking and involve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

### Q&A
**Analyst-1**
: Good morning. I am pleased to share that 2014 was an excellent year for PACCAR with many records expanded product and service offerings and investments that provide the foundation for future growth. PACCAR achieved record revenues of $18.9 billion in 2014. Net income was $1.36 billion and increase of 16% versus a year ago and the Companys second best annual profit in history. 2014 was PACCARs 76thconsecutive year of earning a net income. These excellent results reflect the strongest North America heavy truck market retail sales since 2006. In addition, PACCAR parts and PACCAR Financial Services earned record pretax income. PACCAR celebrated several important milestones last year including Peterbilt's 75thanniversary. The delivery of Kenworth's one millions truck and the production of the one million DAF's cab in our Westerlo, Belgium factory. More good news this week Kenworths new vocational truck the T880 truck, equipped with the PACCAR MX-13 engine, earned "2015 Truck of the Year" from the American Truck Dealers. I am very proud of our 23,300 employees who deliver industry leading products and services to our customers everyday. PACCARs fourth quarter sales and financial services revenues were quarterly record $5.1 billion and quarterly net income was $394 million. Net income increased 18% compared to the results generated in the fourth quarter last year. The positive contribution of all company segment enables PACCAR to obtain the highest operating margins in our industry and to deliver excellent shareholder returns. PACCAR declared cash dividends of $1.86 per share last year, a 9% increase compared to 2013. PACCARs total return to shareholders was 18.3% last year. Stockholders equity at year end was a record $6.75 billion. And during 2014, PACCAR repurchase 731,000 shares of stock for $42.7 million. PACCAR delivered 40,100 trucks during the fourth quarter, a 7% increase versus the third quarter. Vehicle deliveries in the first quarter this year will be 15% to 18% higher than the first quarter last year reflecting increased production in the U.S. and Canada. Truck and other margins are forecast to be 1% to 1.5% better than last years first quarter. Peterbilt and Kenworth achieved excellent market share of 27.9% in the U.S. and Canadian heady-duty truck market in 2014. Retail sales totaled 250,000 units for the year. U.S. and Canadian Class 8 industry retail sales are estimated to increase to a range of 250,000 to 280,000 units this year driven by ongoing replacement demand and further fleet expansion which reflects continued economic growth. If recent order trends continue retail sales would be towards the higher end of the range. DAF achieved a share of 13.8% in the European above 16-tonne truck market, which totaled 227,000 units last year. Looking at this year, we anticipate the European above 16-tonne truck market will be in a range of 200,000 to 240,000 vehicles. It is encouraging that the growth rate of the UK economy which is DAFs largest market is expected to grow by more than 2% this year. Lower diesel prices, low interest rates and other economic stimulus measures could improve European truck market conditions during the year. PACCAR parts generated strong quarterly revenues of $789 million and 8% increase compared to the same quarter of the prior year. PACCAR parts quarterly pretax income was $130 million, an increase of 24% compared to the fourth quarter of 2013. The excellent results were driven by strong freight tonnage, high fleet utilization and the many innovative products and services offered by PACCAR parts. For the full-year PACCAR parts achieved record revenues of $3.1 billion and record pretax income of $497 million. PACCAR Financial Services revenues were $302 million in the fourth quarter slightly higher than a year ago. PACCAR Financial Services fourth quarter pretax income was $96 million compared to $90 million earned last year. PACCAR Financial Services revenues were $302 million in the fourth quarter slightly higher than a year ago. PACCAR Financial Services fourth quarter pretax incomes $96 compared to $90 million earned last year. The excellent results benefited from growth and asset balances and continuing strong portfolio performance. For the full-year PACCAR Financial Services earned record pretax income of $370 million. PACCARs capital spending of $300 million to $350 million this year will expand Kenworth, Peterbilt and DAF product offerings enhance the PACCAR engine range and increase the operating efficiency and capacity of our factories and distribution centers. Research and development expenses are estimated to be in a range of $220 million to $260 million. As the company begins its 110thyear we are in an excellent to growth with industry leading products and services. Thank you. Ill be pleased to answer your questions.

**Operator**
: [Operator Instructions] Your first question comes from the line of Patrick Nolan with Deutsche Bank.

**Analyst-1**
: Good morning, Patrick.

**Patrick Nolan**
: Good morning. Thanks for taking my question. I actually had two questions. Could you give us some color on what you would expect -- thanks for the color on Q1 -- but what you would expect for full-year margins to do year over year?

**Analyst-1**
: I think for the full-year or current thought is that margins would be up a bit over the 2014 level target 50 basis points.

**Patrick Nolan**
: That's very helpful. And can you expand on what you're seeing as far as raw material costs? What kind of benefit you think that could be in 2015?

**Analyst-1**
: Well, again we have a long-term agreements with almost all of our suppliers which manage the ups and downs of material cost movement so I suspect you know we will get some benefit but it will be muted because of the long-term arrangement.

**Patrick Nolan**
: That's very helpful. I'll get back in the queue. Thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Steven Fisher with UBS.

**Analyst-2**
: Great thanks. Good morning.

**Analyst-1**
: Good morning.

**Analyst-2**
: Great, thanks, good morning. Clearly there's a big pickup in the industry orders trends in the latter part of 2014. I'm just curious to what extent your order patterns were consistent with that trend as well and do you expect to see a pause in orders before the next reload and how long that pause might be?

**Analyst-1**
: Peterbilt and Kenworths order intake in the fourth quarter was excellent, very consistent with industry order levels and as I said if the order trends continue we will see retail sales at the higher end of our range, but I dont think they will continue at the 123,000 order level which was the fourth quarter level, but they just cant continue that pace.

**Analyst-2**
: Okay and then can you just talk a little bit about how the slowdown in oil activity is affecting your business and kind of when assuming current conditions hold when you might see sort of the worst of the impact on it.

**Analyst-1**
: I guess our assessment of the impact of the lower oil prices is a positive for the U.S. economy and that will create additional consumer spending and consumer demand which I think will benefit freight volumes and be a positive for the industry.

**Analyst-2**
: Okay, thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Tim Thein with Citigroup.

**Analyst-1**
: Good morning Tim.

**Analyst-3**
: Thank you good morning and good luck to your team there on Sunday.

**Analyst-1**
: Thank you.

**Analyst-3**
: So just first one Ron on pricing, truck pricing in North America. It looks like through the first nine months of the year that the realized pricing in U.S. and Canada was just under 2% and Im sure there is all kinds of other things that get include in that or dont that make it maybe a little bit less straightforward, but if we just use that call it 2% pricing for 2014 what would your expectations be for 2015 given that you enter with higher backlog and given your outlook for the markets overall.

**Analyst-1**
: Well I dont know exactly how you get the 2%, but obviously we're participating in a competitive marketplace and we have great products, the performance of the new Kenworth, Peterbilt and DAF products around the world has been excellent and we expect to be able to earn a very fair price and I just think pricing will continue to see levels that have been consistent with what weve seen in 2014.

**Analyst-3**
: Okay got it and just your expectation is marginal increase, but on the back of the higher retail sales forecast for North America, are you still thinking about for parts growth in 2014 still in that kind of 4% to 7% range, is that still your expectation here for 2015?

**Analyst-1**
: Yes I think something in that range in terms of parts deliveries will be something in that range for sure.

**Analyst-3**
: Okay, and just last one for me, Ron, just on Western Europe from a used perspective, used truck perspective, what if any impact are your dealers seeing just given the more difficult environment in Eastern Europe especially Russia? In the past it's been a pretty important outlet for used trucks. Has that led to any kind of backup in Western Europe?

**Analyst-1**
: No, used truck inventory levels are pretty normal I think just the volume of activity is probably dampening a little bit, but not anything of major consequence at all.

**Analyst-3**
: All right. Good, thanks a lot.

**Operator**
: Your next question comes from the line of Nicole DeBlase with Morgan Stanley.

**Analyst-4**
: Yes, good morning guys.

**Analyst-1**
: Good morning.

**Analyst-4**
: So my first question is on R&D. I'm just curious what caused you to take up the midpoint R&D guidance by 7% and the 11% growth that you're projecting year on year. Are there any key projects there that we need to be thinking about?

**Analyst-1**
: Just continue to invest obviously throughout all phases of the business cycle, continue to expand the Kenworth, Peterbilt and DAF model offering as well as continue to invest in, our engine platforms will be launching the MX-11 in North America in the beginning of 2016 and preparing for the transition to greenhouse gas machines requirements in 2017, so thats the bulk of where our spending is.

**Analyst-4**
: Okay, understood, thanks. And then my second question is just around build rates. Given the continued industry order strength we've seen, do you guys have plans to increase your build rates further in 2015?

**Analyst-1**
: The order rates continue I think there will be some potential for us to further increase our build rates as we go through the year.

**Analyst-4**
: Okay. Great, thanks Ill pass it on.

**Operator**
: Your next question comes from the line of Steve Volkmann with Jefferies.

**Analyst-1**
: Good morning, Steve.

**Analyst-5**
: Hi, good morning guys, thanks for taking the questions especially since it's coming today from Massachusetts. So don't hold that against me. But I may not wish you good luck on the weekend but certainly good luck with the business. I'm wondering if I could just follow-up a little bit - you talked about the energy cost declines or price declines being ultimately good for the economy. I'm just trying to figure out the other side of that equation because there's obviously a thesis out there that a fair amount of the truck strength in recent quarters has been driven by capacity increases in the energy segments and transportation of oil and gas and so forth. I'm just curious - I know nobody has to check a box to tell you what they are going to use the truck for when they buy it but you probably have a better sense than we do about how much has been actually going into those end markets and could be at risk going forward?

**Analyst-1**
: Yes, I think about 10% or less of our volume is related to oil and gas. The oil and gas industry and that includes a lot of elements of that industry. So I think it, for sure, if oil prices stay at the levels exploration and production will be at lower activity levels and truck that are participate in that portion of the oil and gas segment. Well have fewer orders, but thats a very small portion of what we do.

**Analyst-5**
: Okay, have you seen any of that in your discussions with clients yet? Are you seeing any orders canceled or anything like that?

**Analyst-1**
: No, it has been and remains pretty constant, year-on-year.

**Analyst-5**
: Okay, great, thats helpful. And then how far out are you booking now, and somebody wants to come you with new orders, or how far out as the backlog. How far out of the delivery times.

**Analyst-1**
: Well, I think we have a very healthy backlog and so probably look at second quarter.

**Analyst-5**
: Okay, great. Thank you.

**Analyst-1**
: Yes.

**Operator**
: Our next question comes from the line of Jamie Cook with Credit Suisse.

**Analyst-1**
: Good morning, Jamie.

**Operator**
: Jamie, if youre on mute. Please unmute your line.

**Analyst-6**
: Hello.

**Analyst-1**
: Hello.

**Analyst-6**
: Can you hear me?

**Analyst-1**
: Yes, we can.

**Analyst-6**
: Were back. Sorry, were back, sorry I dont know what happened there.

**Analyst-1**
: Good morning.

**Analyst-6**
: Sorry about that. I guess just a couple of questions. There's a lot of questions out there in terms of where the US truck cycle is relative to peak. What is your view on what inning of the ballgame we're in there? And then my second question just within Europe, can you talk about your ability or how we should think about your ability to pass through emissions Euro 6 over there this year and if that's a negative to margins? Thanks.

**Analyst-1**
: With respect to Europe pricing is stable and trucks are Euro 6 truck are performing excellently in the market lot of very positive feedback from the customers on the excellent reliability of the DAF product as well as the full efficiency. And theyve been DAF just recently introduced some additional announcements with Predictive Cruise Control and Predictive shifting that further enhanced fuel efficiency. So I think that will be a positive aspect of demand for DAF trucks in 2015. With respect to the peak we dont have the ability to forecast that obviously the market has been improving over the last 15, 18 months and as long as the economy continues to grow. The freight demand is there - there will be demand for the excellent Kenworth and Peterbilt products and you know they continue to expand there model offerings to further enhance transition to the new cabs. So you know that the we can just continue to pure play is the market as the economy progresses.

**Analyst-6**
: And sorry just a follow-up in response to I think Steve Fisher's question, I think he asked about orders, the recent strength in orders and I think you made a comment that PACCAR had pretty good share. But I think there's some concern out there that the orders over the past three months were inflated by in particular one OEM. So can you comment on that or what would -- what do you think the reason why -- I know you don't view it as sustainable but why would orders be that strong for a three-month period if there wasn't anything funky in the order trends?

**Analyst-1**
: I cant comment on what the other OEM orders and take is all I cant says Peterbilt and Kenworth orders were very strong and consistent with overall industry trends and so in great position to continue to take advantage of the strong freight in the demand for our great products.

**Analyst-6**
: All right. Thanks. I'll get back in queue.

**Analyst-1**
: Thanks.

**Operator**
: Your next question comes from the line of Seth Weber with RBC Capital Markets.

**Analyst-7**
: Hey good morning guys.

**Analyst-1**
: Good morning Seth.

**Analyst-7**
: Hey, good morning guys. I'm just wondering given the strength in orders and the volumes, can you talk about whether you're seeing any stress points in the supply chain at this point?

**Analyst-1**
: Suppliers continue to perform excellently and because that the ramp is really occurred over 15 month to 18 month they have been able to adjust and adopt their capabilities to fit our needs and so we see that continuing for the foreseeable future.

**Analyst-7**
: Okay, thanks. And then I guess within your backlog, can you comment are you seeing any evidence of the smaller owner-operators getting back into the market? I know that you've talked about that market not definitionally being different this cycle versus prior but are you seeing any come back from the smaller operators?

**Analyst-1**
: I would say that the order volume that weve experience over the last several quarters has been broadly based and includes demand not just from large fleets but also from the vocational segment as well as some of the smaller size fleets in the market so its more or less a broad based order book that we have.

**Analyst-7**
: Okay, thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Andy Casey with Wells Fargo.

**Analyst-1**
: Good morning Andy.

**Analyst-8**
: Hey good morning everybody. And Ill send a reluctant Boston base good luck to you this weekend also. So first I didnt hear the margin comment very clearly. Was that specific to gross margin?

**Analyst-1**
: Yes.

**Analyst-8**
: Okay thanks.

**Analyst-1**
: Yes.

**Analyst-8**
: And then in North America and just weve seen these cycles before and you know at some point pricing goes up, you are kind of suggesting modest price increase potential, what do you think has to happen in the market to enable more aggressive pricing potential?

**Analyst-1**
: I think the pricing is reasonable given the market conditions, I dont see major movements, I think the length of the backlog is clearly a factor in how price reacts in the market and I would say backlogs were in good share at this point. We dont see any major adjustment in those levels as we go forward.

**Analyst-8**
: Okay, thanks and then if we can go over to the EU from what we can see freight seems to be stable to slowly improving, is that translating into any order improvement and how specifically did orders trend in Q4 versus last year if you could share that.

**Analyst-1**
: The orders are pretty consistent as we look at the quarters over 2014, orders are pretty stable and I think as we talked about with the lower fuel prices historically low interest rates, some of the stimulus measures that could have a benefit for orders as we progress through the year obviously the situation in Russia has impacted demand for that market, but its trending positively and we will see how the year progresses, but I think there are some positive things that could impact it.

**Analyst-8**
: Okay thank you on that and then lastly if I look at the share buyback activity there wasnt a whole lot in 2014, could you help us understand how you are thinking about the potential for the upcoming year?

**Analyst-1**
: As we just have a long-term view of periodically buying back shares and we will continue to take that perspective and buy shares as we feel its appropriate in the marketplaces weve progress into 2015.

**Analyst-8**
: Okay thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Ross Gilardi with Bank of America.

**Analyst-1**
: Good morning, Ross.

**Analyst-9**
: Yes, good morning. Thanks, Ron. Just a couple of questions maybe a little bit more on Europe. If you could just talk a little bit about what you are seeing in different countries and clearly the overall market is still pretty soft. Europe has been weak for many years now. I'm curious where you think we are in fleet age in Europe and if we do get a little bit of a pickup in the European economy do you see any realistic prospects for a decent replacement cycle kicking in the next several years?

**Analyst-1**
: I think thats a good observation Ross there are lots of trucks that were put in the market in the 2006, 2007, 2008 timeframe and while its difficult to find somebody who has an independent measure of that I think the age of the fleet is extending in Europe and so with some good healthy demand, positive demand that could trigger a healthier replacement activity.

**Analyst-9**
: And then could you just talk a little bit more about what you're seeing across the continent?

**Analyst-1**
: Well, I think again as I mentioned Russia the impact there thats - well see how that develops during the course of the year. UK for us which is our largest market impacted by the pre-buy in 2014, but with the good economy we are off to a good start in the UK with our DAF business and Northern Europe as you mentioned or somebody else mentioned the freight activity is up year-over-year as we look at the activity through Germany and its up 2% to 3% for the year last year and continue to show increases in the fourth quarter. So there is a lot of good elements that are present and I think if things can develop to take some of the uncertainty away about how the future might react I think the European potential for upturn is there.

**Analyst-9**
: Okay, thanks Ron. And then I don't know if you can comment on this or not but I'll try anyway. On the competition investigation, I know you can't say anything on the dollar amount or speculate on that but can you give us any sense as your best guess on timing as to when you might be able to provide an estimate? Because obviously several of your competitors have already taken a stab at that?

**Analyst-1**
: Yes, we included an update in the press release on our valuation of the European commission and I dont just dont have anything else to add at this point.

**Analyst-9**
: Got it. Okay, thanks very much.

**Analyst-1**
: Yes, thank you.

**Operator**
: Your next question comes from the line of Andrew Kaplowitz with Barclays.

**Analyst-10**
: Good morning, guys.

**Analyst-1**
: Good morning, Andy.

**Analyst-10**
: Ron, so can you maybe walk us around the world outside of the US in Europe? Your other truck markets have continued to improve after maybe a tough time a year or so ago. So maybe talk to us about Australia, Mexico, these other markets because they do seem like they're getting better.

**Analyst-1**
: Australia is great, market for Kenworth and DAF. We have about a 25% share that market continue to be the market leader. So we are optimistic about our opportunities in that area. The Europe, Australian economies have been impacted obviously by the mining activity and some downturn there. But we think again this in long-term, we are in great shape in Australia. Mexico again we are market leader there, with over 40% share of that heavy-duty market. And well continue to see I think as the year progresses, Mexican economies closely tied with the US economy and so. We expect to see them benefit for some of the activity thats going on in the US, so upside there. And so we talked about Europe, and Brazil is, so early days for us and we continue our study progress and dealers continue to finish their facilities and begin operations out of their permanent facility. So that the progression of our efforts in South America continue as well.

**Analyst-10**
: Okay, that's helpful and Ron, if I could look back at the fourth quarter again, you had guided to I think 5% to 7% up in deliveries. It looks like your truck revenue was up about 5% and the December build was down. It was very strange in the industry. It was probably because of the weird holiday weeks. But it does seem like the industry is being pretty careful with increasing build rates. So maybe you can just comment on PACCAR specifically. Is that sort of the case was build what you thought it would be? Did the holidays mess things up more than you thought? Like any color there?

**Analyst-1**
: It was right. We built exactly what we had planned to build when we talked in the last call, we talked about 5% to 7% increase in production. And we were increased at 7% in terms of trucks produced. There was some offset with the effective foreign currency movement in the quarter. But thats were right inline and as I mentioned we will see strong production increase in the first quarter of this compared to the first quarter of last year, in the tune of 15% to 18%.

**Analyst-10**
: And how should we think about currency for you guys in 2015 in terms of impact on the business?

**Analyst-1**
: Clearly, when we operate in lot of countries around the world in the translation of those foreign currencies into U.S. dollar, impacts revenue and profit numbers but we do have an offset we purchase a fair amount of components from European suppliers that we are using our U.S. products. So there is a bit of natural hedge there.

**Analyst-10**
: Okay. Thanks, Ron.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Ann Duignan with JP Morgan.

**Analyst-11**
: Hi, guys.

**Analyst-1**
: Good morning, Ann.

**Analyst-11**
: I was going to say what's going on this weekend that I don't know about and then I thought oh yes, there is a big football game.

**Analyst-1**
: It will be exciting.

**Analyst-11**
: I guess. I wanted to follow-up on the last question. Your European share was down to 13.8% from 16.2% in 2013. And I wanted to just address that in terms of is that because UK is your largest market and the UK was messed up because of the emissions changes and also how do we think about the competitiveness of the UK business since you produce in the UK but you sell in euros and is that a competitive disadvantage over there?

**Analyst-1**
: So the effect - the market share DAF was at 15% in the second half of the year, the year was really effected by as you mentioned the pre-buy and the transition rules that excited in our two largest markets which is the Netherlands and the UK. So that impacted off share we expect this year that we are going to return back to our 2013 share levels and so in the UK economy as I mentioned is one of the stronger economies in the region. So again we are off to good start there and expect to have a good year in the UK.

**Analyst-11**
: Okay and then competitiveness, the products you build in UK but sell in euros is there any...

**Analyst-1**
: Well, we built trucks on the continent that get sold into the UK we built truck in the UK that go to the continent and again we have a pretty natural offsetting effect of those trucks in the movements back in forth.

**Analyst-11**
: Okay, thank you. That's helpful to understand.

**Analyst-1**
: Sure.

**Analyst-11**
: I just wanted to also ask about -- you talked about less than 10% of your business being exposed to oil and gas and you said broadly oil and gas. Do you include things like the Canadian oil sands when you talk about oil and gas exposure and could you just address the business there? Is there any risk of cancellations -- anything that we might be missing on the oil and gas exposure as we go through 2015?

**Analyst-1**
: When we talk about 10% we're principally talking about trucks that are sold into production activities, those would be water trucks, sand trucks, those types of applications. For sure, you know the level of new permitting is off and so we would expect some impact in the second half of the year, but dont see any significant impact on our backlog at this point. Again, on balance we feel that lower oil prices overall are good for PACCAR, what drives freight in the U.S. economy is a large function of consumer demand and so on balance we think its a very positive things for the company.

**Analyst-11**
: Yes, I guess investors concern is that the two might not happen coincidentally but we might see a slowdown in oil and gas activity and then later in the year consumer activity pick up, so just trying to get a sense of how to put that into model. So I appreciate it and good luck on Sunday. At least I think the game is Sunday, is it?

**Analyst-1**
: Thats right.

**Operator**
: Your next question comes from the line of Jerry Revich with Goldman Sachs.

**Analyst-1**
: Good morning Jerry.

**Analyst-12**
: Hi good morning and good afternoon everyone. Ron Im wondering if you could just talk about the drivers of the 50 basis points in margin improvement 2015 versus 2014, how much of that is just mechanics around the warranty, any mix headwind of higher production rates in Europe versus flat to down or production up in the U.S. and flat to down in Europe. Can you just maybe give us a bit more of the bridge there?

**Analyst-1**
: Jerry obviously the margin really reflects the stronger anticipated market in North America, we are going to be operating for sure for the first part of the year and probably throughout the year at a higher production level than we were at in the first half of 2014. So the benefits of that higher production volume is what's playing through to the margin improvement.

**Analyst-12**
: Okay, and then you alluded to earlier on euro impact on net imports into the U.S. for Europe, what proportion of your U.S. total truck component costs on euros roughly?

**Analyst-1**
: I dont have that number Jerry, its not a great number, but its there is - its a sizable enough number that there is a natural hedge that we have.

**Analyst-12**
: Okay and Ron, you touched on it a moment ago in terms of your guidance I guess implies a year-over-year flat to decline production rate in the North American market. And I'm just wondering are you folks planning for slower demand or is that a function of, look, it's early in the year; let's see what another quarter or two of orders looks like before we get more aggressive about the guidance?

**Analyst-1**
: I dont think I understand your point Jerry where the North American market last year was 250,000, Peterbilt and Kenworth had 28% share that market we are looking next year at 250 to 280 if the demand level continues maybe towards the higher end of that and Peterbilt and Kenworth have great products and I think the opportunity continue to have strong share position in the market. So we are going to have - if that market is there well deliver more trucks in 2015 then we did last year.

**Analyst-12**
: Okay. I guess it just comes back down to on a year-over-year basis your production in the U.S. should be up somewhere in the 30% range. So compared to the full-year guidance at the midpoint or even at the high-end of not that strong growth implies a potential flattish back half of 2015. Does that make sense?

**Analyst-1**
: Im not sure where all of your numbers, but again were going to be able to participate in the market growth and again because of our product positioning we have opportunity to have a very strong share that U.S. Canadian market.

**Analyst-12**
: All right. And to switch gears a bit, we've spent a lot of time over the past couple of years talking about the expanded range of products for the European markets. Can you just talk about the traction that you're getting in the marketplace? As you alluded to earlier, a lot of noise in the 2014 market share numbers. Maybe you could just talk about how the specific launches have gone and what the acceptance rate has been.

**Analyst-1**
: Its been excellent, the XF product we launched that in 2013 and so its been in the market now for over 18 months. The LF and the vocational CF product was launched late 2013, early 2014 and again very well received in the market, DAF introduced some enhancement at the Hanover truck show and has launched those enhancements now into the market in the beginning of 2015 with predictive cruise, and low deck tractors, the CF with the silent package. So lots of good feedback from dealers and customers on the fuel efficiency, the reliability of the products, so DAF is very well positioned with its product as it moves.

**Analyst-12**
: All right, thank you.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Joel Tiss with BMO.

**Analyst-13**
: Hi guys, how's it going?

**Analyst-1**
: Good.

**Analyst-13**
: That's good. Great questions and even better answers. I'm not used to this. The lower spending that you guys - it's just slightly lower in your leasing business. Can you give us any of the dynamics behind that? Are there more used trucks in the market or are you just tempering your growth outlook a little bit?

**Analyst-1**
: Im sure. I am following the question, Joel.

**Analyst-13**
: On your cash flow statement you spent $1.2 billion in 2014 on lease vehicles versus almost $1.4 billion in 2013. So I just wondered if there was any sort of message in that little bit lower spending in a growing market.

**Analyst-1**
: No I think thats a mix shift of the method of financing of vehicles, both a bit in Europe and a bit in North America. So its really just the way that the customers have opted to finance their product.

**Analyst-13**
: Okay, and then since almost everything else has been asked, can you give us any sense if the energy-related vehicles are higher margin or similar margin or lower than the overall segment?

**Analyst-1**
: Lets a similar.

**Analyst-13**
: Okay. Thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of David Leiker with Robert W. Baird.

**Analyst-14**
: Hi, good morning this is Joe Vruwink on the line for David.

**Analyst-1**
: Good morning, Joe.

**Analyst-14**
: I'm in Green Bay Packer country, so you'll excuse me if I don't wish anyone good luck this weekend.

**Analyst-1**
: Well, that was a tough five minutes of football for you.

**Analyst-14**
: Very tough, but moving on. In gaining back market share in Europe, which sounds like it's your plan for 2015, is that just a function of country mix and the UK expected to be stronger or are there customers or applications you've identified that are helping as well?

**Analyst-1**
: I think its a combination of both in country mix and the reception that the Euro 6 product has received in the marketplace we will support DAFs targets for 2015.

**Analyst-14**
: Okay. Are you seeing any sort of shift in let's say the head-to-head matchups at the high-end? I think one of your high-end Swedish competitors gained some market share in 2014?

**Analyst-1**
: Again, I think the 2014 share numbers were really impacted by the level of Euro 5 the sales in the 2014 year and which countries you know your particular was in. So 2014 is probably not representative of sort of the long-term trends.

**Analyst-14**
: Okay. And then shifting to the U.S., when making the comment that maybe for the industry production rates need to stay at or can stay at Q4 levels into 2015, and that's kind of where you get the growth coming from, order rates in 2014 were well above production rates. So it just rough math I think there would still be quite a few units in the backlog just maintaining Q4 production rates that would still really be targeted for 2016 at that point. It kind of goes back to the earlier comment on OEM discipline. But is that kind of a reasonable trajectory where OEMs are planning already for a 2016 delivery cadence?

**Analyst-1**
: I would say the vast majority of our backlog is thats going to be built in 2015 if thats your question Im not certain we are following it.

**Analyst-14**
: Juts in terms of there is already a pretty sizable backlog across the industry, if orders maintain even reasonable rates let's say a low 300 or at 300,000 rates it would seem like there is obviously year the truck market is know for ratching it up to mid high 300 and then crashing back down, it seems like the plans across the industry are for something more gradual than that where a good growth number in 2015, but certainly not a ratcheting back down in 2016.

**Analyst-1**
: Well I think that cycles in our business over the last decade have been both economic, but more importantly regulatory based upon the implementation of emission standards and as we kind of look out over the next five years at least, we dont see significant impact from any regulatory requirements. So the market demand for commercial vehicles is going to be largely based upon the economics in the country.

**Analyst-14**
: Okay great and then one housekeeping item, it looks like your depreciation expense stepped up in Q4, is that the right level that you are thinking about into next year?

**Analyst-1**
: Yes, I think that amount in Q4 annualizes probably a pretty indicative number for next year.

**Joe Vruwink**
: Okay, thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Rob Wertheimer with Vertical Research.

**Analyst-15**
: Hi good morning guys.

**Analyst-1**
: Good morning.

**Analyst-15**
: Two quick questions, definitional really for you, I think the press release said 37% PACCAR penetration, you have obviously been on a very positive trend. I assume you have now just stated that for U.S., Canada and Mexico as appose to what you used to with U.S. Canada and you are still gaining share.

**Analyst-1**
: That really is a U.S. and Canada metric yes. Yes in Mexico we launched the engine last year very well received by our customers there and so its growing percentage penetration in the Mexican market as well.

**Analyst-15**
: But in the fourth quarter press release do you happen to know if you included Mexico in the share of 37?

**Analyst-1**
: No, that was U.S. and Canada.

**Analyst-15**
: Okay Ill come back and circle back afterwards then. Do you have any capacity constraints on that or are you continuing to see customer preference shift or is there any - have you seen yet any capacity preference limit to how far you can go?

**Analyst-1**
: Well, we have two great engine factories, one in Eindhoven and one in Columbus, Mississippi and both can produce the full line of PACCAR engine and so we have the ability to produce engines around the world to that support our needs in whatever market it might be. So capacity is in excellent shape. Our capacity for both the truck business and for engine production is in great shape.

**Analyst-15**
: Excellent, thank you. And then if I may when you take an order in November or December for delivery next year, just mechanically speaking, does that have a potential to have next year's pricing in it or is it always existing year pricing? Thanks.

**Analyst-1**
: Typically if we take a multi-year order there is some factor that's used for the subsequent year in the pricing that is in the order.

**Analyst-15**
: Okay, thank you.

**Operator**
: Your next question comes from the line of David Raso with ISI.

**Analyst-16**
: Hello, thinking about your production mix geographically, the near-term build schedule, can you help us with - it seems like you're implying deliveries are down about 8% fourth quarter to first quarter, just backing into the math that you gave us year-over-year. Can you help us understand the geographic mix in that down 8%?

**Analyst-1**
: The first quarter would be down about 5% from fourth quarter levels with primarily related to Europe.

**Analyst-16**
: Okay and you're implying the gross margins are down a bit sequentially. It looks like the absolute levels of deliveries are down, so there's some maybe just overhead issue. But can you help us understand from a mix perspective I'm generalizing, but I would think North America at this high level would be running better margins than Europe. So why if the mix is more towards North America sequentially should I have down gross margin sequentially?

**Analyst-1**
: Purely reflects the production volumes in the first quarter.

**Analyst-16**
: Okay and then moving further into the year, maybe if you gave it I apologize, I missed it the full-year deliveries. How are you characterizing full-year deliveries 2015 versus 2014?

**Analyst-1**
: Weve given our market range and we expect our shares to be good in all our markets and so thats was the impact of the primary drivers of our volume numbers in our business.

**Analyst-16**
: In Europe the build schedule versus the industry say market share was flat. Early in 2014 dealers were selling out their inventory of Euro 5, would that suggest your builds in 2015 in Europe should be better than the industry rate? Because the industry number you're giving is sales, but again they were selling out of inventory in the first quarter of this year. So are your builds going to be above the industry?

**Analyst-1**
: So, the mid part of our estimate is pretty comparable to last years level. We hope to - expect to see some share improvement, and so we hope that our deliveries and registrations for 2015 or maybe a bit ahead of 2014 level.

**Analyst-16**
: Last question on pricing. A little disappointed what I'm hearing about the 2016 models on pricing. And we all understand what's going on with more vertically integrated drivetrains and who's trying to catch up on lost market share. But let me just ask you point-blank, are you surprised how the pricing is developing? Because usually with this kind of backlog, this kind of extension of build schedules, delivery lead-times I'm hearing 1.5% to 2.5% price increase for the 2016 models is relatively disappointing between you and I. So just trying to understand when those prices are set: first, is that the right magnitude? Second, maybe elaborate on why do you think that is. And then third, can we see pricing improve as the year goes on? I'm just not sure how much - when you set a price can we ratchet back some traditional dealer discounts or so forth during the year? Because again, I'd be hoping to get more pricing in 2015 than say 2% in North America.

**Analyst-1**
: Yes, I don't know what the source of your pricing information is, but obviously Peterbilt and Kenworth have great products, that its all based on the value of proposition with our customers and we think we offer a great value proposition with the industries best truck as well as the industries best fuel efficiency.

**Analyst-16**
: Would you disagree with my sources on that kind of price increase? I'd be happy to hear I'm wrong, but hopefully to the upside. I'm just trying to understand if those are the right numbers, again I'd be thinking we can get more. But can you at least help us order of magnitude, do you think you'll be able to get more pricing than I'm alluding to or less?

**Analyst-1**
: David, again great products and competitive offering and great value for our customer, so.

**Analyst-16**
: Okay, we'll take it off-line. I appreciate it. Thank you.

**Operator**
: Your next question comes from the line of Neil Frohnapple with Longbow Research

**Analyst-17**
: Hey, good morning, guys.

**Analyst-1**
: Good morning, Neil.

**Analyst-17**
: Do you have the new truck delivery breakdown by geography in Q4?

**Analyst-1**
: Yes, we do, just a second. In the US and Canada we delivered 22,200 trucks in the further quarter, and Europe it was 12,100 and in Mexico, South America, Australia and other it was 5,800 trucks.

**Analyst-17**
: Great, thanks. And just a follow-up on an earlier question on the MX penetration here in the U.S. and Canada. The 37% rate in Q4 was in line with Q4 of 2013 and it seems like we've been in that 35% to 40% range for all of 2014. I mean do you still anticipate this installation rate to increase over time? And I guess what do you think is preventing faster adoption of that product closer to your 50% medium-term target?

**Analyst-1**
: Well, I think we will see increased over time, its a great engine and its really a matter of getting more and more of the customers. We are significantly invested maybe in Cummins engines or another brand to get in the vehicle and experience the engine. And so, once they do that we will continue to see conquest business over time and the engine with its horsepower capabilities in the torque capabilities of the engine its very well suited to 75%, 80% of our customer need. So we will see it continue to develop over time.

**Analyst-17**
: And just a follow-up, are you guys planning on doing anything different this year to try to help accelerate the adoption or is the go-to-market strategy kind of the same?

**Analyst-1**
: I think its very consistent.

**Analyst-17**
: Great, thank you very much.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Ted Grace with Susquehanna.

**Analyst-19**
: Good morning, gentlemen.

**Analyst-1**
: Good morning, Ted.

**Analyst-19**
: I was hoping to ask a question on PACCAR Financial. Just as we look forward to 2015, any handholding you can give us on how to think about the pretax contribution, how net interest margins may kind of flow year on year and maybe just start there?

**Unidentified Company Representative**
: The portfolio has grown during the course of the year, portfolio pretty well attract the demand for trucks. So if the truck demand based on the market assumptions that we see that there is probably further portfolio growth as we enter into 2015 and portfolios performance very well past dues have been below 1% now for over two years and we see it continue to perform well and borrowing rates are an historic low levels and we will continue to take advantage of that to support the sale of Peterbilt, Kenworth and DAF products and support our dealers in the floor plan activities.

**Analyst-19**
: Yes, I guess the demand side is a little easier to calibrate on. But I'm just wondering the spread any handholding you can give us on how we should think about spread in the margin?

**Analyst-1**
: I dont think it will be significantly different and what weve seen over the last several years.

**Analyst-19**
: Okay. Thanks helpful. And then maybe just a cleanup question. Can you talk about SG&A and tax rates as we think about 2015?

**Analyst-1**
: SG&A one of our strengths as a company is rigorous over side of our spending activities and our plans and warehouses and offices around the world and well continue to maintain that rigor. I think SG&A would be at levels comparable to 2014 and the tax rate as we look forward probably in the 32% to 33% range is we look to 2015.

**Analyst-19**
: Super. Well best of luck this quarter with the exception of Sunday.

**Analyst-1**
: Thank you very much.

**Operator**
: Your next question comes from the line of Scott Group with Wolfe Research.

**Reena Krishhnan**
: Hi, good morning, it's actually Reena Krishnan sitting in for Scott Group.

**Analyst-1**
: Good morning.

**Reena Krishhnan**
: Hi and I apologize if you may have already answered this, but I just wanted to get a sense in terms of how you're thinking about deliveries for the year. I don't know if you guys ever give color on this, but within your expectations for deliveries, how much of that is -- like how many - how much do have confirmed orders I guess already for the full-year? If that makes sense.

**Analyst-1**
: Our market estimate for the various markets that we participate in. weve identified what those are and we expect to have good share positions in those markets and so that really can give the expectations for units as we look forward for the year. Backlogs are in excellent and we well positioned to take advantage of the market as it progresses during the year.

**Reena Krishhnan**
: Okay thank you.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Alexander Potter with Piper Jaffray.

**Analyst-20**
: Hi guys. I was wondering if you could comment on this recent drop in fuel pricing and whether that impacts peoples' decision to downsize their engine to a 13 liter.

**Analyst-1**
: I dont think that has much impact, I think they are looking because fuel even at the reduction fuel is still the first or second biggest expense in their P&L and so I think they are always looking to get the most advantageous cost level that they can and the MX engine combined with the Peterbilt, Ken T680, DAF trucks provided excellent value proposition for those customers.

**Analyst-20**
: Okay, and then another question I guess along those same lines, saving cost on the fuel bill. Do you think given the decline in diesel pricing that's a natural gas trend is on the back burner? The natural gas has been a niche product and I think it will continue, we dont see any dramatic shit in that but our Peterbilt and Kenworth teams have the leading market share in the natural gas products and so we are well positioned to provide those. For our customers its just not going to be a high percentage of our build.

**Alexander E. Potter**
: And not willing to hazard a guess regarding whether 2015 natural gas truck demand might be up, down or flat versus last year?

**Analyst-1**
: I think it will be similar.

**Alexander E. Potter**
: Okay, fair enough. Thanks guys.

**Analyst-1**
: Thank you.

**Operator**
: Your next question comes from the line of Mike Shlisky with Global Hunter.

**Analyst-21**
: Good morning, guys.

**Analyst-1**
: Good morning Mike.

**Analyst-21**
: I wanted to start off here with a quick question to follow-up on a previous one. Can you maybe just quantify the fourth-quarter impact of FX on your top line and on your pretax income I guess both euro and of course the Canadian dollar as well?

**Analyst-1**
: Yes, for the quarter the impact on revenues was about $160 million and pretax profit was about $13 million.

**Analyst-21**
: Great, and secondly I wanted to ask about your 2014 dividends, historically youve been talking about 45% to 25% payout rate of your annual net income in your overall dividend and just. And just going with what was put out in todays release and well put out back in December. I dont think you kind of hit the very low end of that range, paying out about 45% of your full-year net income. I was kind of wondering are you holding onto the cash for any reason. Is there any reason why didn't want to go towards the higher end there?

**Analyst-1**
: I think weve been very consistent over time and we evaluate that on a ongoing basis and consult with the board, the board decides what levels will you provide dividends and so we have a long track record since 1941. Paying a dividend to our shareholders and well continue I think with that practice for the foreseeable future.

**Analyst-21**
: All right, thanks guys. Good luck on Sunday.

**Analyst-1**
: Thank you.

**Analyst-21**
: And I guess keep those football pumps handy.

**Operator**
: Your next question comes from the line of Kwame Webb with Morningstar

**Analyst-22**
: Good morning, gentlemen. Thanks for taking my question.

**Analyst-1**
: Good morning.

**Analyst-22**
: So the first one for me is what are you guys expecting in terms of Brazilian production rates for 2015?

**Analyst-1**
: I think we will see, be steady and up because as we gain more of our dealers, finishing their permanent facilities, they will be able to enhance their business, which should translate into additional demand for our trucks, our DAF trucks.

**Analyst-22**
: Okay. And when should we expect a more aggressive production ramp there? Should we expect it to be a 2016 or a 2017 type event?

**Analyst-1**
: I think it will be steady.

**Analyst-22**
: Okay.

**Analyst-1**
: I think it will be very steady.

**Analyst-22**
: And then just the other one for me on automatic transmission adoption, I know the penetration rate had been ticking higher over the last couple years. Kind of curious to get your thoughts on 2015.

**Analyst-1**
: Well, I think it will continue to increase in penetration, as this time goes on, both for fuel economy reasons and for driver reasons, very efficient transmissions and they are very easy to drive. So we will continue to see, increasing acceptance of those markets in the markets.

**Analyst-22**
: In terms of your own order mix, what would 2013 versus 2014 would look like.

**Analyst-1**
: Probably about a 10% increase over the course of the year, so fairly significant.

**Analyst-22**
: Okay, great, thanks so much.

**Operator**
: Your next question comes from the line of Marty Pollack with NWQ Investments.

**Analyst-23**
: Wow, a lot of questions have been asked. When you look at Europe, your forecast for European I guess sales is down from 2014. If you look at where the truck cycle in Europe has been and it's totally in a different place where the North America cycle has been and you wonder then - what is the opportunity for some meaningful recovery in Europe? And how is it likely to be affected by what's gone on in the Eastern Bloc with Russia? At the same time, your market share 13.8% seems to be I think considerably lower than the sort of 16% or 17% range you've seen. So if there is upside in PACCAR is it in Europe? And if it's not this year is it next year that we should be seeing some recovery? That's the first question. The second one has to do just with North America. The sustainability of the cycle clearly in 2006-2008, we had the pre-buy impact, I think double ordering. Can you just talk about those dynamics here in terms of the health of the cycle? And even if it's 2015 is a peak, can 2016 be still a fairly strong environment?

**Analyst-1**
: Well I think when you think about Europe as we commented ion our products, the Euro6 products had been very well received by our customers and DAF continues to make enhancements both in terms of application fuel efficiency and so they are very well positioned to take advantage of any uptick in the market and as I mentioned with the lower fuel prices, low interest rates there is a potential for the market to improve, I think its a matter of people getting confident about how the future may look for them and once they gain that confidence just as we saw in the past years here in North America, once they gain that confidence they will be willing to be more aggressive in placing that order. In North America, we said past cycles have been impacted by some of the emissions change , we dont see those kinds of impact and so the truck market will pretty well track the economic development as we see them occur and right now obviously the economic forecast for 2015 are good and we expect to have a positive impact on the size of the market for this year. End of Q&A

**Operator**
: There are no other questions in the queue at this time. Are there any additional remarks from the company?

**Analyst-1**
: I would like to thank everyone for their excellent questions. And thank you, operator.

**Operator**
: Ladies and gentlemen, this concludes PACCARs earnings call. Thank you for participating. You may now disconnect.