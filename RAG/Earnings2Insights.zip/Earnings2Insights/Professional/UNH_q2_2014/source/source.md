## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning. I'll be your conference operator today. Welcome to the UnitedHealth Group Second Quarter 2014 Earnings Conference Call. (Operator Instructions) As a reminder, this call is being recorded. Here's some important introductory information. This call contains forward-looking statements under U.S. Federal Securities laws. These statements are subject to risks and uncertainties that could cause actual results to differ materially from historical experience or present expectations. A description of some of the risks and uncertainties can be found in the reports that we file with the Securities and Exchange Commission, including the cautionary statements included in our current and periodic filings. Information presented on this call iscontained in the earnings release we issued this morning and in our Form 8-K dated July 17, 2014, which may be accessed from the Investors page of the company's website. (Operator Instructions) I would now like to turn the conference over to the President and Chief Executive Officer of UnitedHealth Group, Stephen Hemsley.

### Q&A
**CEO-1**
: Good morning and thank you for joining us today. This morning we will review our first half 2014 performance within the context of the goals we set for this year and the opportunities we see going forward. We see the next 18 months as important given that by January 2016 the ACA will largely be in place and we will be entering an election cycle that will set the stage for shaping the next phases of health reforms. For decades, the trend has been for greater private sector engagement in meeting ever increasing national healthcare needs. These include the foundation of what is today Medicare Advantage, the launch of Medicare Part D drug benefits, the formation of accountable care organizations, steady migration of Medicaid to managed care, the expansion of benefit coverage to the uninsured under ACA exchanges and expanded Medicaid programs and the improvements to the healthcare.gov and many state based exchanges. UnitedHealth Group businesses have participated strongly in each of these developments and we remain focused on making these efforts successful and sustainable as they continue to evolve and settle into the fabric of our national healthcare system. We continue to execute steadily on that change agenda and we believe an improving environment in 2016 and beyond will support acceleration on our earnings growth rate. This morning, we are raising our 2014 revenue outlook to $130 billion from the previous forecasts of $128 billion to $129 billion. We are strengthening our 2014 earnings projection to a tighter range of $5.50 to $5.60 per share. The increasing earnings momentum we expect in the second half of 2014 should position us to grow both revenues and earnings per share in 2015. Advancing our performance in this 18 month timeframe will remain challenging but achievable, anchored by strong Medicaid growth, steadily strengthening Medicare and international performance, deeper entry into new, more established public exchange markets and continuing strong growth and earnings momentum at Optum. These elements are visible as well in second quarter results reported today. In the second half of 2014, UnitedHealth Group grew revenues 7% to $32.6 billion and earned $1.42 per share. Optum contributed nearly 30% of our enterprise operating earnings this quarter. Solid cash flows from operations of $1 billion for the quarter and $2.4 billion for the first half of the year were approximately one times net income, in line with our 2013 patterns. As our strongest cash flows come in the back half of the year, we continue to project a range of $7.8 billion to $8.2 billion in cash flows for full year 2014. Reviewing our results in more detail, starting with UnitedHealthcare. Second quarter revenues grew 6% year-over-year to $30.1 billion. The quarter featured earnings from operations of $1.8 billion, driven by a strong operating margin of 6.1% even with the growing mix of public and senior sector businesses. UnitedHealthcare is seeing significant and accelerating growth in Medicaid. 380,000 more people in the quarter and 635,000 through the first half of the year. Coming from expanded access to Medicaid in about half the states we serve, the launch of Florida's planned Medicaid expansion, and core program growth from already established markets and programs. In Medicare, we grew to serve more than 400,000 more people across all products in the first half of 2014. A very solid and balanced performance considering the market actions we needed to take last year in response to reduced Medicare program funding from CMS. In the core senior medical products of Medicare Advantage and Medicare supplemental benefits, we have grown the number of seniors we serve each year for than a decade and this year should be no exception. There is no question the private sector provides significant value to Medicare beneficiaries. Medicare has been and will continue to be a growth business at UnitedHealthcare. We are privileged to serve one out of every five American seniors. Today we serve 3 million people in Medicare Advantage plans and 12 million across all product types. We expect to deliver overall Medicare growth for years to come, driven by favorable demographic trends and our strong local market cost and value positions, supported by deeply integrated Optum resources in pharmacy services, primary care delivery, health calls, data analytics and compliance. Our Medicare Advantage business works with senior focused care providers under rising levels of well designed shared risk and performance based payment arrangements to deliver more effective clinical management in concert with well-targeted and executed home visits. From the seniors' perspective, we offer market leading access to quality care across a broad spectrum of venues combined with the attractive benefits under strong brands with convenient broad-based distribution. Commercial membership continued to track with recent trends. Pulling back in risk-based products as we remain focused on pricing discipline and endeavoring to strike the right balance in protecting margin and giving back some past growth. In self-funded products, our momentum is steadily strengthening. We are winning national account business and retaining key customers we are privileged to serve. We are pleased to return to serve as a core benefit option in the State of Georgia in 2015. Customers are still announcing final decisions and our pipeline is much stronger than this time last year. We feel positive about our January 2015 position at this early stage. In the individual market, we plan to grow next year as we expand our offerings to as many two dozen state exchanges. This approach is consistent with our long stated plan to take a prudent first year position and then build and expand in 2015 and 2016 as these markets become more established. By participating moderately this year and then watching closely and listening, we have learned about pricing, networks, regulatory structures, distribution and the consumers mindset regarding public exchanges. These data points help and form our positioning for 2015 which should be a better risk vintage for the public exchanges. We believe public exchange markets must be sustainable on their own, so our participation will not overly rely on risk corridors or assumptions under risk sharing provisions. The Congressional budget office estimates that more than 75% of the exchange market is yet to develop. And we believe there will likely be meaningful membership activity in the market after the initial experience of this year and as second year pricing is presented. So we plan to grow steadily from this point forward, advancing our participation in a measured manner in public exchanges in 2015, 2016 and beyond. Bringing together this year's developments across these various product categories, our original forecast for U.S. consumers served is proving fairly accurate in total with greater incremental losses in full risk commercial benefits which we discussed last quarter, offset by exceptional growth in Medicaid which should come in well in excess of 800,000 people this year. Turning to Brazil. Amil has seen clear signs of steady recovery from a surge in utilization beginning in the last half of 2013 in response to aggressive, new government mandated access standards. Our premium rates are improving and are catching up to the increased levels of medical services. We are deploying capital to continue building out Amil's franchises in to Rio, Sao Paulo in northeastern Brazilian market, which nicely benefitted our membership numbers this quarter with 110,000 net growth. In our view, Brazil remains the most fertile market for health benefits and services outside the U.S. and we expect our focus and efforts in this large, high potential market will reward our shareholders for years to come. At UnitedHealthcare, we continue to project a 6% commercial medical cost trend, plus or minus 50 basis points for 2014. Our medical costs remain inline with our plan and remain moderate. The consolidated medical care ratio for the second quarter was 81.6%, 10 basis points higher than last year despite less reserve development and a shift in the mix of our business towards government programs resulting in upward pressure in the ratio year-over-year. These factors were mostly offset by 100 basis point reduction from the implementation of billing of the ACA fees and taxes. Second quarter results were led by the public and senior sector where revenues from federal and state based programs continued to develop positively. Public and senior sector earnings are running slightly favorable to our original 2014 outlook. We are constructively supporting innovative ways to universally improve the quality and affordability of healthcare for consumers. In one example, we and several other healthcare companies are collaborating with the not-for-profit Healthcare Cost Institute to develop and provide free access to online healthcare transparency tools that offer consumers the most comprehensive and accurate information about the price and quality of healthcare services so individuals can make more informed decisions about their health and healthcare. HCCI's transparency tool will be available in January 2015 and HCCI plans to advance more free services for consumers and other key healthcare stakeholders in the quarters and years to come. Last fall we took a more intense focus on improving our Medicare stars performance for Medicare Advantage. We made changes in people, organizational alignment, business processes and funding and resource allocation which we believe are yielding positive results. We project our stars performance for 2015 payment year will be better than expected and will steadily improve in 2016 over 2015 and even more meaningfully in 2017 and '18, creating a steady, multiyear upwards progression. Our commitment is to maintain a baseline of no fewer than 80% of our seniors enrolled in Medicare Advantage plans rated four stars or higher every year. At Optum, we are tracking to deliver record revenues and profits again this year, driven by market demand for our broad portfolio of capabilities and solutions. Second quarter results are on plan with Optum's margins on course to strengthen again in 2014. We expect margins will reach approximately 7% this year even as our pharmacy services business grows at an accelerated pace. These advances are consistent with our original forecast last fall and Optum's 8% by 2016 commitment. We remain focused on building a scalable, end-to-end services platform. Healthcare system participants are beset with more complex challenges then they have ever faced. Their needs have grown well beyond the standalone product offerings that are characteristic of this fragmented market. Optum has integrated services and capabilities to better meet and anticipate the emerging needs of the market, whether around advanced analytics and population health, deeply integrating pharmacy and medical management for more effectively delivering and documenting clinical care. These markets each represent multibillion dollar growth opportunities unified for customers in a flexible, modern comprehensive and fully scaled services platform. The growth in revenue, backlog and pipeline and the increasing number of larger, deeper and more sophisticated Optum relationships demonstrates steady progress in converting these opportunities into revenues and provides visibility and near-term growth and an indication of strong long-term future we see for this business. At the same time, Optum continues to have opportunities to improve its basic operating performance. We continue to better integrate and align internally, focusing on delivering higher value products and services with greater efficiency, better leveraging resources and competencies and information analytics, technology and clinical care, and improving our cost structure and operational efficiency. These efforts are equally important to achieving our long-term earnings goals. Continued investment remains central to Optum's long-term growth. The quarter carried $80 million in investment costs as we deepened capabilities in areas such as consumer engagement tools and distribution services, next generation analytics that uniquely combine administrative and clinical data at scale, next generation medical care review and compliance analytics and services and international versions of product and services that have become established here in the U.S. We will be investing startup costs in major Optum360 relationships and Optum technology outsourcing arrangements and moving forward on services focused to the needs of targeted international markets. These investments continue throughout the year but should have less noticeable effects on results in the fourth quarter of 2014 as Optum's overall growth and performance accelerates and we benefit from the impact of the more seasonal businesses. In the second quarter, Optum's revenues grew 28% to $11.7 billion. Earnings from operations grew 23% year-over-year to $728 million. Operating margins declined slightly to 6.2% due to the planned investments just discussed and the exceptional growth of the OptumRx business. OptumRx again led this quarter's performance. Revenues grew 42%. Earnings from operations doubled while operating margins expanded a full percentage point to 3.6%. We process more than 150 million adjusted scripts this quarter, up 30% year-over-year. Our cost to fill a mail order script decreased 30% over the past year and we expect to drive increased consumer value through higher volumes of mail order business. We had exceeded our goal of 1 million new consumers served from business awards a spectrum of customers in 2014 and have some early awards in hands for 2015 with good a prospect pipeline. This growth is additive to the natural organic growth led by the in-sourcing of UnitedHealthcare's pharmacy business over the past two years. OptumInsight's growth was again led by strong performance in government sponsored services. OptumInsight is providing services to five separate state exchanges in addition to its continuing role with the federal exchange. By the midyear point, computer-assisted coding offerings from our Optum360 Revenue Management Organization were installed in more than 50 customers who operate more than 220 facilities. And the pipeline continues to grow. On the downside, the regulatory pullback in hospital, clinical compliance services continues and has pressures revenues and earnings for that product offering. And at OptumHealth, we are continuing to build out our local care delivery organization. Today our physicians and clinical professionals touch 2 million consumes with high levels of clinical quality to our local clinics, which are prominent leaders in their market. All in, Optum delivered an exceptional second quarter and first half with improved earnings and capital returns compared to a very strong prior year. We expect Optum's earnings to accelerate in the second half of 2014, especially in the fourth quarter as they have in the past years. Driven by strong revenue growth, achieving performance incentives from customers, the accumulating benefits of operational efficiencies and structural cost efforts, and favorable seasonal patterns at OptumInsight and OptumHealth. Optum remains on page to contribute roughly one-third of UnitedHealth Group's 2014 cash flows from operations, all while investing in future growth of this business. To summarize, the first half of the year was strong with revenues growing by $3.5 billion or 6% year-over-year. First half earnings of $2.52 per share position us positively for the full year growth. With a strong second half growth performance from Optum and seasonal strength in UnitedHealthcare's second half operating margins, expected to help accelerate our earnings and bring us to a strong close. We see 2014 revenues at about $130 billion and net earnings in the range of $5.50 to $5.60 per share, with cash flows from operations in the range of $7.8 billion to $8.2 billion. We are intensely focused on continuing to execute evermore sharply on the details and fundamentals in every aspect of our businesses and in everything we do for the people we serve. We will provide a full view of our 2015 expectations at our annual investors conference in New York City on Tuesday, December 2nd. So thank you for your time this morning and we will now take your questions.

**Operator**
: (Operator Instructions) Our first question is coming from Justin Lake of JP Morgan.

**Analyst-1**
: Questions on medical cost trends. I know you indicated trends inline overall, but given the recent data points out there, I was hoping you might have some color to share in terms of real time Rx trends, hospital discharge planners etcetera. And then just a quick follow up on your Medicare Advantage comments in the prepared remarks. Is it reasonable to expect you are in a position to grow membership here for 2015. Thanks.

**CEO-1**
: Yes. So Dan Schumacher, you want to comment. I dont know if we can get into that level of detail but I think we can add some color.

**CFO-1**
: Sure. Good morning, Justin. This is Dan. With respect to the costs, obviously in the quarter we were very pleased with our medical cost performance. And as Steve mentioned, our underlying cost trends remain very well controlled. We continue to make improvements in our medical cost management and a lot of that, honestly, is in strong partnership with Optum. Whether it be payment integrity, local care delivery, our partnership with OptumRx and so forth. And so as Steve mentioned, on the full year we still expect our cost trend to be in the 6% plus or minus 50 basis range. We would like to expect that to be closer to the lower end of that range. With regards to what's happening in the quarter and our early data, nothing would suggest that we are seeing any kind of surge. So as we look at daily hospital census data, as we look at prior authorization for outpatient and inpatient procedures, pharmacy fulfillment, all of those things wouldnt point to any sort of surge in the quarter.

**CEO-1**
: Gail, (indiscernible) now if you want to talk about MA.

**Other-1**
: Sure. Good morning, Justin. This is Gail Boudreaux. In terms of your question on Medicare Advantage. First of all, we really alike our position around Medicare and feel that the work that we have done over the past year has put us in a good position. So overall we are looking to grow. We will provide you a lot more detail obviously at our investor conference but we do feel that the work around network product positioning value has put us in a good place and I feel positive about Medicare.

**CEO-1**
: Do you want to add anything?

**Unidentified Participant**
: I think you said it well.

**Operator**
: Our next question comes from Matthew Borsch of Goldman Sachs.

**Matthew Borsch – Goldman Sachs**
: I was hoping maybe you could talk about the -- what you are seeing in the pricing environment as an update from last quarter in the traditional commercial risk business and maybe not relative to the 280,000 commercial risk lives that lapsed during the quarter.

**CEO-1**
: Sure, Jeff?

**CEO-2**
: Good morning, Matt. It's Jeff Alter. Really nothing has changed in the pricing environment that we discussed in the first quarter. The pressure remains in mainly New York and a couple of other small group markets. You know I would just remind you that a part of that, or a large part of that 280,000 member loss which related to our individual footprint. We had mentioned in our investor conference that we were going to lose individual business throughout the year because of our pullback in a lot of markets. And I think we are beginning to see changes and some good momentum in other parts of our business, other than those few pressured markets. And as Steve mentioned in his prepared remarks, really encouraged by the national account season and then our win back of the State of Georgia and couple of other larger public sector accounts.

**Matthew Borsch – Goldman Sachs**
: Has your view changed at all with respect to -- you are looking at 2015 being a quiet year for contract changes?

**CFO-2**
: Matt, could you clarify what type, I am not following. It's John Rex.

**Matthew Borsch – Goldman Sachs**
: Well, I think that the question earlier in the year had been, with 2015 are you going to see significant carrier switching, particularly for the large accounts that renew on a calendar year basis. And I think you had said, you thought it was going to be a relatively quiet year for that. Now with your backlog increasing, has that view changed at all?

**Other-1**
: This is Gail. In terms of your question, a couple of things. Steve mentioned in the comments and I think Jeff reiterated, in the large case market we feel pretty positive about what we are seeing in that marketplace and the momentum we have. You saw we just won the State of Georgia back, which I think is another positive. In terms of in-year switching, we are very pleased with the pieces that we locked in as part of last year and that provides us a nice long-term run rate. So overall, and we see there are some positive emerging dynamics, but again, we are early into this cycle right now so I dont want to comment for next year but I think it's pretty consistent with what we have said on the last call.

**Operator**
: Our next question comes from Peter Costa of Wells Fargo.

**Peter Costa – Wells Fargo**
: Your guidance for commercial loss ratio back in December was 79.2, plus or minus 50 bps. You noted on the first quarter call that the pressure from SOVALDI and the New York pricing market was pressuring the overall consolidated loss ratio towards the higher end of the 80.5, plus or minus 50 bps, but never, I think, specifically noted what the impact was on the commercial loss ratio. So it's hard to tell right now whether the commercial loss ratio is trending about where you expected it to be or is it more worse than you expected it to be. Especially since it looks like there is some gains from favorable revenue adjustments on the government business. Can you talk to sort of the puts and takes relative to the Medicare business -Medicaid business, and the commercial loss ratio relative to your expectations?

**CEO-1**
: So I will have Dan answer that, but thats quite a question so we will kind of do it in a summarized form

**CFO-1**
: Sure. Thanks, Peter. So obviously in the first quarter we talked about both our consolidated loss ratio and the implications underneath that our commercial loss ratio would be near the higher end of the range that we had provided at investor day. And as we look at the second quarter in light of that revised expectation, we see things tracking well. So our commercial business is tracking in line with those expectations coming out of the first quarter and we are doing a little bit better in the government business on the care ratio.

**Peter Costa – Wells Fargo**
: And can you specifically say what the revenue impacts were from the favorable true-ups in the revenue development in the government business?

**CFO-1**
: I am not going to share specifically the revenue developments but just to provide a little bit more color on the revenue developments. They are not something that -- they are not uncommon for us, particularly in the second quarter. And so what you are seeing is a combination of finalization of our 2013 Medicare revenue that has pulled through to our 2014 estimates and we also have true-ups in our state based programs. So we have got true-ups obviously related to the industry fee as we get that, as well as normal retroactive rate adjustments. So all of those things are representatives out there.

**Operator**
: Our next question comes from Josh Raskin of Barclays

**Josh Raskin – Barclays Capital**
: So just getting back on Medicare Advantage. I appreciate the comments that Gail made around, you guys will look to grow in 2015 and you look your positioning. So is that indicative, I guess it's sort of a two parter so I will admit I am cheating upfront. Are you done with provider renegotiations and network work? And then I guess more importantly, is Medicare Advantage a growth business from an operating earnings perspective next year?

**CEO-1**
: Steve Nelson, why dont you respond to that?

**Other-2**
: Sure. First in terms of just overall positioning. Our Medicare Advantage business as Gail mentioned, we really like the performance so far and we have made quite an investment in stars, in our clinical programs and network. And these things have to work together in order for this to continue to be a growth business for us. And so in terms of network specifically, we have done a lot of the heavy lifting in terms of shaping our network and concentrating our numbers with high quality and highly engaged providers. That work will continue but I would say in kind of a, more of a different format. We are going to be working more with providers inside our network to further concentrate that membership and expand our ACO footprint, engage more heavily in capitation and other kinds of value based contracting within our existing network, as opposed to actually reducing the number of providers. So it's a little bit of shift towards working with providers already on our network but working closely with our network and shaping it and focusing it in this way as it's going to part of an ongoing process and really important as we continue to improve our stars, our clinical performance and our member satisfaction.

**CEO-1**
: I think we are very positive on this. We have taken the steps that were necessary and they were the most disruptive and I think at this point forward we are now positioning this business in a way for good long-term sustainable growth, star compliance. And so while we have continued to be working on this, we are very positive about where this base will go.

**Josh Raskin – Barclays Capital**
: So to recap, you are not making -- so all of the heavy lifting and the big changes around providers and things that really impact the member, thats kind of behind us. The rest of it's going to be kind of behind the scenes, more capitation the better. So I know thats what gives you comfort on the member side but is it also fair to say that, okay, from that perspective it sounds like you are getting a more efficient network and that earnings growth should be and you sort of reset margins over the last couple of years that it's more conceivable to see earnings contributions from that segment as well?

**CEO-1**
: So I think you're fine on all those levels. I do think that we have to be attentive to Medicare Advantage funding levels because that has been a pressure point and so forth. But in terms of the things that would be disruptive to the business, Steve, I think those have run the course....

**Other-2**
: Yes, I think you summarized it well. And we think the earnings range for the government business we have talked about for us, between 3% and 5%. And we are in that range this year and we will continue to be in that range. Thats our view and I am obviously not giving specific guidance for next year but more to come. But thats how we think about it. Really great performance and I am excited about the competitive positioning looking forward.

**Operator**
: Our next question comes from Sarah James of Wedbush Securities.

**Sarah James – Wedbush Securities**
: I was hoping you could provide some color on utilization levels of the newly insured? And it would be really helpful if you could break that out to the newly insured on the Medicaid side, so would work or expansion members versus the commercial side, the exchange members that were previously uninsured?

**CEO-1**
: We will. And now keep in mind we have a very low profile in exchange, but Gail and team, you want to respond?

**Other-1**
: Sure, good morning, Sarah. Steve -- first let me reiterate what Steve said around the public exchange membership. We have got a very modest footprint there so I wouldn't draw any conclusions from our early experience in that sector. On the Medicaid side as you've seen we've gotten tremendous growth. We're really pleased with it. We did expect to see increases in utilization and we also got higher rate sales for that and it's tracking very much in line with the expectations we had. So overall, I think very much in line and we're, again, extremely pleased by the growth that we are seeing not just across the expansion but new states wins as well as expansion of our current existing membership footprint.

**Sarah James – Wedbush Securities**
: And can you just clarify, I think you guys mentioned you're not relying on three R's for 2015. Does that also mean your guidance assumes no receivables for 2014 for the three R's?

**CFO-1**
: Sarah, it's Dan. On the three R's, we have nothing on corridors and risk adjustment and we have very modest reinsurance thats assumed recovery, that's immaterial.

**Operator**
: Our next question comes from Kevin Fischbeck of Bank of America.

**Analyst-6**
: One quick clarification before I get in to main question. Did you say Steve that you have expected 2015 stars to be better than expected? I didnt quite understand that comment.

**CEO-1**
: Yes. We are expecting to track progress in 2015 and build progress from that in '16, '17, '18. So we are committed and see forward progress in stars.

**Analyst-6**
: You dont mean what we know of already. You dont mean the '14 data for '15, you mean '15 for '16 to be better than expected?

**CEO-1**
: Gail, you want to respond to it?

**Other-1**
: Yes. When the stars were published last year, we had a sense of where our membership was. We have made significant improvements in our group business which will help improve our actual '15 results.

**Analyst-6**
: Okay. All right. So it's a membership growth within the high star rating plans?

**CEO-1**
: Thats right.

**Analyst-6**
: Okay. And then just, so the main question is on the exchanges. You mentioned that your year one was about kind of watching and learning and then year two is more about growth. Can you just give us a sense of some of the things that you have learned? Because you are making a really big move. You are going to do a couple dozen states. You have really moved in. What's given you the comfort and the confidence that this business, since you are still relatively new around the claims development, that it is going to be stable into next year and that this is the year to move in rather than waiting another year to get even more information.

**CEO-1**
: Well, I will also have the -- so this will be a team response. But, again, this was consistent with how we positioned this right from the beginning that we would observe the first year for the most part and then endeavor to participate. And we will see how we ultimately participate as we go through the balance of this year and get ready for the next year selling season. But the size of the and response of the exchange, we expected growth in it and so forth plays into that thinking and recognition this is going to be an established sector in the healthcare benefits marketplace and that we have to chose to participate at some point of time. It kind of wanted to make sure that we dont go in too late. So I think, we are thinking this is about the right time.

**Other-1**
: This is Gail Boudreaux again. The only thing I would add is, getting back to Steve's comments, we have felt it was a good long-term market. What we have been able to observe and learn over the course of the market as we know the existing pricing, we know the network constructs, we know the consumer behavior on what they picked in these different markets. We have a better understanding of the regulatory structure and the distribution cadence. So from those factors, we are looking at the market as an opportunity. And again more than 75% of that market is going to emerge, we feel that those markets that we are looking at now are much established. So thats the background around our thinking on exchanges but again we have always thought it was part of our strategy and plan, that this is a good long term market.

**Operator**
: Our next question comes from Andy Schenker of Morgan Stanley.

**Analyst-7**
: Moving over to the operating costs, they were actually meaningfully below our expectations and down year-over-year I think once you accounted for the charitable donation despite the pressures from the industry fee. Could you perhaps discuss the level of investments in the quarter and what other savings may have drove down that ratio?

**Executive**
: Sure. We are quite pleased, Andy, with the operating cost ratio for the quarter. Obviously it's got a lot of pressure because of the implementation of the insurers fee in the second quarter which of course, it wasnt in place last year. We are really seeing the advances in our contributions from our PBM business, which is benefitting not only from scale efficiencies but also significant productivity advances, both around just regular process management as well as the implementation of technology. So Dirk and team have done an excellent job there. Otherwise, as we indicated in the investor conference, we were pursuing somewhere around 70 to 80 basis points of annual productivity improvements and we in fact achieved those in this quarter. So really what you are seeing is just raw productivity and scale advantages coming through our businesses as we project it. In terms of investments, I think we outlined those in the script with respect to the types of things that Optum is investing in. It's really investing in growth and I think that growth is really manifesting in terms of its pipeline expansion year-over-year. Kind of very nice job there and as indicated those investments were about $80 million in the quarter. On top of that as you might suspect, there are significant investments going in across the business so to respond to the implementation of the ACA provisions as well as growth -- more broadly -- are preparing for growth more broadly both in the exchange marketplace as well as in Medicaid.

**Operator**
: Our next question comes from Chris Rigg of Susquehanna.

**Christian Rigg – Susquehanna**
: Just wanted to come back to hepatitis C. Obviously it hasnt been talked about nearly as much on this call but can you give us a sense for how the expenditures sort of tracked from Q1 to Q2 and sort of the pace of expenditures you are expecting in the back half of the year given the potential for some new drugs coming to the market. Thanks.

**CEO-1**
: Sure. Dan?

**CFO-1**
: Sure. Good morning, Chris. Our Q2 spend for hepatitis C was in line with our revised expectations coming out of the first quarter. We will tell you that in the first quarter, our new patient volume peaked in all of our benefits businesses and I think we have got strong controls over the appropriate use. So as we think about the cost related to hepatitis C and its treatment, we have that accounted for and accommodated within our full year trend outlook as well as in our care ratio guidance.

**Christian Rigg – Susquehanna**
: Okay. And then if I could, how are discussions going with the state Medicaid partners with regard to the drug. Thanks.

**CEO-1**
: Austin?

**CEO-3**
: Sure. This is Austin Pittman. First of all, again, this is the cost of the program we expected to be fully reimbursed. We are very pleased and making strong progress in our discussions with our state partners in securing that reimbursement.

**Operator**
: Our next question comes from A. J. Rice of UBS.

**A. J. Rice – UBS**
: Maybe a two part thing on Optum. First of all, I know you have talked around the investment spending and said it was $80 million in the second quarter but that by the fourth quarter it should have less impact. Is that because that $80 million run rate goes down or is that because of the leverage of spending. And then more broadly, just on OptumRx. You mentioned some positive related to the 2015 selling season. I wondered if you can expand more on, is Optum out there actively pursuing business across the board. Do you have your integrated model fully in place now or you can talk to people about total cost, or is that still something that will come in future selling seasons.

**CEO-1**
: We will be anxious to answer that question. Larry, you want to take it?

**CEO-4**
: A.J., it's Larry Renfro. I will start with the question on the planned investments and then I start to take up the PBM question in terms of the sales. So when we began the year and had our plan put together, we expected to spend about $200 million in what I will call planned investments for the future. It's a very very similar model to what we have actually done with the PBM and I think you know over the past few years we spent some dollars in order to get the platforms up to speed and we are kind of using that same playbook. So for the year it's $200 million. We have spent year-to-date about $140. So obviously we are overweight in the first half of the year and we will start to see that go down as we head into the fourth quarter. So financial targets and so forth, this is all planned. There is nothing out of the ordinary. So we are online or inline with everything that we are doing. So again, let me say that again, it's $140 million year-to-date that was planned year-to-date out of a total of $200 million. Dirk?

**CEO-5**
: Yes. So A.J., thanks. A couple of things first. Steve mentioned that we had a nice year in 2014 with respect to our growth. As we look at our pipeline for 2015, our pipeline is up double-digits compared to the same time last year. It's not a ton of business changing hands. If you look at what we have closed this year versus the same time last year, we are certainly ahead. We do feel that our synchronization message is resonating in the market as we go in and we talk to our prospects. It's all about bringing together the medical, the lab, the pharmacy data. Try to optimize outcomes and lower cost. We think we also have a good service offering and I think we do a pretty good job managing specialties. So all of those are contributing to our success.

**Operator**
: Our next question comes from Scott Fidel of Deutsche Bank.

**Scott Fidel – Deutsche Bank**
: Just wondering given the broader entry into the public exchanges in 2015, what your strategy is for surmounting the auto enrollment policy that would seem to give an advantage to incumbents? Is it more that you just expect so much more growth in the exchange market that that's not really an issue? And just wondering whether you think that that policy is a bit anti-competitive for new market entrants or that it just benefits the market in terms of reducing likely the overall amount of churn in the market?

**CEO-1**
: Sure, Jeff?

**CEO-2**
: Good morning, Scott, it's Jeff Alter. On the first part, there is going to be, as Gail and Steve mentioned earlier, still a large amount of the population that we expect to be in those exchanges, we will call at the end of the cycle and we expect to take a large part of that new business. But just on the existing population. You know there is a lot of leverage around the subsidy and price changes, so as competitors change prices, it does tend to move the subsidy dollars around pretty strongly. So we believe there will some, there will also be shopping even though people dont have to shop. I think just the natural consumer play at an exchange is going to cause a shopping experience and we feel we could get some part of that membership shift as it goes along. We are obviously not going to comment on the anti-competitive part of anything.

**Scott Fidel – Deutsche Bank**
: And just as you see some of the initial rate filings now coming out for the exchanges in the individual market when, how would you say that those are coming out so far relative to your expectations in terms of the competitor filings.

**CEO-1**
: I think they are within our range of expectations. You are seeing competitors you might have relied a little bit on the three R protection and as that protection goes away, they have to adjust their pricing. And we are seeing that. So nothing that we have seen to date surprises us or changes the approach that we have taken with our own pricing. We are very comfortable with our pricing and just keep in mind that that pricing is driven not only by our forward view of cost but also, as we have mentioned, we have observed the marketplace. In 2014, we are bringing different products to market in some of these exchanges than we would have traditionally brought. Some more HMO. Much tighter alignment with Optum and some of their programs to help us manage the diseases the health of those members and creating a different -- in some cases a different dynamic with the network.

**Operator**
: Our next question comes from Christine Arnold of Cowen.

**Christine Arnold – Cowen and Company**
: Could you paint us a picture around Optum360? What kind of investments are you making specifically there this year versus next year? What's the potential? What does this look like a couple of years from now? I am having a hard time visualizing the benefit of the financials and precisely what the model looks like?

**CEO-1**
: Yes, Larry, you want to start?

**CEO-4**
: Sure. Christine, I am going to hand this off to Bill Miller who is the executive that runs the OptumInsight and where Optum360 sits. And we will not specifically talk about our customers. Maybe I can frame some of the size of our potential accounts and where we are headed and I will let Bill then to talk specifically about Optum360. I think you know that when we set priorities for 2014, we talked about, really one of the priorities going after, and Steve mentioned it earlier, for the larger, deeper relationships and more complex relationships. And last year we aligned with an organization on the west coast to build revenue cycle management and we are starting to build that. So I am going to give you four, four areas that I would say that will kind of depict what we are trying to do and the size of that. Our external backlog right now is up 20% and thats up to $7.5 billion. Our pipeline is up 122% and continuing to grow. I will say that the government business is in that and if you look to that as a standalone, that's about $1 billion. Probably about $6.6 billion in that total pipeline. If you looked at our top 25 accounts and the revenues that we have had over the past since 2011, our revenues are up 2.5 times. And our accounts that had values of over $100 million are also up 20% year-over-year in the number of accounts that we have. Obviously Optum360, we have a strategy that we are not going to get into detail about because it is an extremely competitive strategy that we are deploying. That's why the amount of investment that we are actually putting in in the first quarter and we will start to see in the fourth quarter, I should say the first half of the year. And we will start to see the benefits of that in the fourth quarter as we talked a few minutes ago with A.J. Also be able to note that we are overweighed in our spend during the first six months of the year. So let me let Bill talk specifically about Optum360 and some of the things going on there.

**CEO-6**
: Yes, Christine, good question and thank you. So as far as painting that picture, I think the picture is, thats a very big market, a fragmented market. And we see ourselves I think very well positioned to drive a lot of efficiencies for health systems that are struggling with that fragmentation. We also bring I think a very strong attitude not only from a technology standpoint which we have served the market with for years, but all the services and processes needed to take out cost and operate a revenue cycle with far more efficiency thats going to be required in an environment where hospitals are continually pressured on their margins. And I think the other thing that we keep top of mind in terms of that vision of the future is we feel uniquely positioned to help drive out the friction between payers and providers, and we also do understand that in the future the role of the consumer and the patient experience associated with their care, their billing is something thats very critical and I think it's part of the mission of Optum360. And the investments associated with that are, I think being able to strengthen our technology portfolio along with on-boarding our largest clients and as Larry said, these relationships are growing in size and we really like the trajectory and the backlog that we have built and the pipeline growth that we have seen. Particularly over the last, I would say seven, eight months. John, you want...?

**CFO-2**
: No, I think -- just to add, Christine, you talked about -- less obviously you talked about the scope of those investments thats clearly encompassed in the $200 million that Larry has been talking about for full year.

**CEO-1**
: And a lot of it is basically implementation on a much more comprehensive revenue cycle, population health, analytics paradigm to change the dynamics in large systems.

**Operator**
: Our next question comes from Ralph Giacobbe of Credit Suisse.

**Ralph Giacobbe – Credit Suisse**
: I want to go back to the MLR point. Can you maybe talk about seasonality in the business, sort of your thoughts there with sort of the continuation of and high penetration of high-deductible plans? Whether there is a potential that that sort of magnifies the cost picture, I guess in the second half of the year. And then along those lines, MLR guidance I guess is still close to that 81% level. You did 82% in the first half. Obviously it implies 80% in the second half. Is that kind of still a fair way to think about it? Thanks.

**CFO-1**
: Hi, Ralph. This is Dan Schumacher. On the seasonality related to high deductible, we continue to make inroads in high deductible offerings. I mean its an offering within our portfolio. I wouldnt say that there is any dramatic shift. I think the normal seasonal progression is what you should expect with regard to commercial and how deductibles play out. With regard to the consolidated loss ratio, our full year guidance was 80.5%, plus or minus 50 basis points and we suggest that that could be near the high-end of the range. And I think thats exactly how you should think about it.

**CEO-1**
: So no change there.

**Operator**
: Our next question comes from Ana Gupte of Leerink.

**Analyst-13**
: I wanted to get some color on the [uplift] (ph) for the small group market in 2015. Now that there is proof of concept for public exchanges, might your competitors and you be more incented to price down because you would still make a margin higher than your potentially public exchange start to trip there offerings of benefits to their workers?

**CEO-1**
: I am not sure that we got clear on the last part of your question. You want to refine that Ana?

**Analyst-13**
: Yes. So I guess what I am trying to understand is, I am hearing generally the buzz is that small group employers are more likely to dump or reduce their offerings for '15. So would that potentially put more pressure on the pricing as well as the size of the market for '15?

**CEO-1**
: Okay. Jeff?

**CEO-2**
: Good morning, Ana. It's Jeff Alter. We continue to believe that the employer dumping will be somewhat moderated, it was moderate this year. We are not sure next year is any year that would be much different than this year as these exchanges establish. And I would say, as you are seeing some of the pricing normalize which might take another year or so for that to happen. Just on the pricing interplay between the two markets. They are different markets and we look at them around the population that we are serving in each one of those. When we think about pricing there is no, right now in our thinking there is an arbitrage between those two marketplaces. They are different. There are different consumers served in those marketplaces. And our pricing for small groups is solely predicated on what we believe that risk looks like, what that membership looks like and then our responses to that risk. And that would be the same for the exchanges as well.

**Analyst-13**
: And does it include your self-insured competition as well. Is that propensity continuing to self-insured? Continuing as there is (indiscernible)?

**CEO-1**
: Ana, I dont know what kind of phone you are on but it's not coming through clearly at all. So you want to try that one more time?

**Analyst-13**
: I was just asking if that is also consistent on the self-insured small and mid-market competition. Is there more movement to self-insured that could create pricing pressure again in fully-insured?

**CEO-1**
: I dont think any difference in what has been going on steadily for maybe the last decade but, Jeff, Gail, any response?

**Other-1**
: This is Gail. No, we haven't seen any acceleration. There is no, as Steve said, a historical trend to self-insured. There was some early discussion around that moving down market but we haven't seen an acceleration in that?

**Operator**
: Our next question comes from Tom Carroll of Stifel.

**Analyst-14**
: So question on your Medicaid performance. You are showing very strong results. So I wonder if you could remind us just kind of what you expect into next year. I mean do you expect outsized enrollment growth to continue into 2015 and additionally, where do you expect pretax margins in this business to settle out given a larger population driven by the Affordable Care Act, as well as new groups like dual eligibles?

**CEO-1**
: Sure. Austin?

**CEO-3**
: Sure. Thanks for the question. We are excited about the growth as well. It's been an outstanding year as Steve highlighted in his opening comments. We now expect that growth to be over 800,000 on the year. And I will tell you that the thing that is great about it, is if you look at this quarter's growth, the 380,000 that we grew this year, it's really evenly split between expansion populations as well as what I call core growth. So thats winning procurement, executing those procurements, implementing new programs within states that we are already in that state and have a relationship, and good strong organic growth. I think as far as the prospects for continued growth, we feel very strong about this business. Particularly if you look at the combined strength of Optum and UnitedHealthcare, our ability to really address state partners needs to deliver value in complex population. So I think the outlook is strong.

**Analyst-14**
: And margins?

**CEO-3**
: As we have talked about before, we expect this business to continue to perform at 3% to 5% range.

**Analyst-14**
: Okay. And that the scale will pull you to the stronger side of that?

**CEO-3**
: Absolutely.

**CEO-1**
: But thats do different than where he have been for the last couple of years.

**Operator**
: Your next question comes from Dave Windley of Jefferies.

**Dave Windley – Jefferies**
: Wanted to get a little more framing around your SG&A expectations as the year progresses. There has been a fair amount of conversation about investments. Your first half is well below, I think your full year guidance. I guess I am trying at, could we expect that the full year will trend towards the lower end of that based on where you are looking so far this year or are there discreet investments that are layering on there in a fairly significant way to drive that up. Thank you.

**CEO-1**
: Yes. I guess a couple of things come to mind, is that we are clearly focused on continuing to be focused an efficient in this. And then there is the selling season in the second half of the year, is a big factor. But, Dave?

**Executive**
: Yeah, David it's Dave Wichmann again. As Steve outlined, it's both the selling season in the back half of the year which effects Q3. Kind of the preparatory work in advance of OEP and then in the Q4 the actual payment of commissions and otherwise associated with that business. But also the significant work we do to prepare for January 1st and the incremental volumes form growth in our business. So we always see the back half of any given year as having a higher operating cost ratio then the first half of the year. With respect to where we are at on overall guidance, we said it would be 16.7% plus or minus 30. We are still squarely within that range for the full year.

**Dave Windley – Jefferies**
: Are there, perhaps around exchange, your significant increase in participation in exchange that you anticipate for '15? Is that in line with what you would have anticipated when you gave guidance originally or is there perhaps more investment to prepare for that for 2015?

**CEO-1**
: David, it's in line with what we had planned all along. So we always anticipated a more modest participation this year and then ramping in the 2015-2016 time period and thats exactly how this is playing out.

**Operator**
: Next question comes from Brian Wright of Sterne, Agee.

**Analyst-16**
: Could you tell us how much of the sequential revenue growth at Optum this quarter was internal versus -- OptumRx was internal versus external?

**CEO-1**
: I dont know if we can but obviously just given the size of UnitedHealthcare that it's a meaningful and the in-sourcing. It's a meaningful element there. Dirk, maybe you could comment generally on your balance for the year. I think you may have that available.

**CEO-5**
: Well, I guess what I would say is, we continue to have a pretty good year as we sit and look at it. Some of the efficiencies that Dave pointed out, we will continue to leverage those as well additional purchasing efficiencies that we have specifically in the generic area should continue to make us expand margins a little bit as we proceed through the year.

**Analyst-16**
: Yes, if I could follow up on EPS progression. Does the commentary about the acceleration in Optum in the fourth quarter and then getting the Medicare Advantage true-ups in second quarter versus third quarter, does that change the back half seasonality versus more recent years like last year?

**CEO-1**
: No, I think in general the pattern is consistent year to year. So the relative, kind of 40:60 in terms of the first half through the second half and then the fourth quarter should be stronger than the third. So that pattern holds up.

**Operator**
: The next question comes from Carl McDonald of Citigroup.

**Analyst-17**
: Six months ago you talked about growing earnings in 2015 but not at the long-term target rate. The earnings growth you talked about this morning, is that still the right context to think about? And related to that if there's any major shift in the moving pieces that you've highlighted previously in terms of another year of reforming from the patient Medicare rate cuts, that would also be interesting.

**CEO-1**
: Yes, I am not sure I got the second half of that but, no, we would expect that our targeted growth rate which is kind of 13%-16%, that 15% would be in that zone, just given the continued adjustments. But then moving 16%-17% beyond, we clearly are focused on getting back to that zone and see a path to that. But the timing in terms of stepping through '15-'16, thats what we are navigating right now.

**Analyst-17**
: I'm sorry, the second half of the question was just if there was any change to some of the bigger moving pieces you talked about previously for 2015 in terms of Medicare rate cuts as well as another year of reform implementation being the biggest headwinds to getting to that long-term growth rate?

**CEO-1**
: Yes, I wouldnt say there are new headwinds, which is a very positive thing to be. And I actually think that we are making real progress on the -- I think this quarter's performance and kind of our outlook. We are making steady progress on the challenges that are in the marketplace for us and everyone else. So I dont think there are any dynamic elements of that. If I go back to the things that I have parsed through in thinking about that, I would say the Medicaid performance and growth is a nice upside. I think our positioning on Medicare, I see us having made a nice adjustment here and are focused on making sure that we are attuned to kind of the next era of Medicare Advantage and Medicare product progression. We see a nice potential in terms of the international market place and good work that has been done in Amil. We are going to keep a positive posture towards the exchange market place and see that in the kind of same margin range as our, let's say our Medicaid business, at a 3% to 5% range. When you look at Optum and its potential and the opportunity for the collaborative care, local care delivery businesses, the potential of the major relationships. Kind of anchoring relationships for OptumInsight and 360 and the ability to kind of diversify and take a new, maybe broader more progressive approach on the PBM. That really does start to tie in medical costs, diagnostic testing and specialty pharma and so forth. I think that to provides a lot of potential to work with, kind of against the challenges that the ACA set in front of all of us and that we are working through right now. So that what gives us a view that we have a lot of work to do but there is lot to work with.

**Operator**
: And there are no further questions at this time.

**CEO-1**
: So with that we appreciate very much your attention today at UnitedHealth Group. Optum, and UnitedHealthcare delivered, I think a very solid second quarter. Growing both revenues and earnings per share. We remain focused on consistent, fundamental execution, innovation, service. We believe we are positively positioned for the full year and a strong close in '14 as well as continuing growth in '15 and beyond. So thank you and we will see you next quarter?

**Operator**
: This does conclude today's UnitedHealth Group's second quarter 2014 earnings conference call. You may now disconnect your lines and everyone have a great day.