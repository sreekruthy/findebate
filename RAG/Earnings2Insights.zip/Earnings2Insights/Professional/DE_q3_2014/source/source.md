## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning and welcome to Deere and Companys Third Quarter Earnings Conference Call. Your lines have been placed on listen-only until the question-and-answer session of todays conference. I would now like to turn the call over to Mr. Tony Huegel, Director of Investor Relations. Thank you. You may begin.

**CTO**
: Hello, also on the call today are Raj Kalathur, our Chief Financial Officer; and Susan Karlix, our Manager of Investor Communications. Today well take a closer look at Deeres third quarter earnings then spend some time talking about our markets and our outlook for the remainder of the year. After that well respond to your questions. Please note that slides are available to complement the call this morning. They can be accessed on our website at www.johndeere.com. First, a reminder. This call is being broadcast live on the Internet and recorded for future transmission and use by Deere and NASDAQ OMX. Any other use, recording or transmission of any portion of this copyrighted broadcast without the express written consent of Deere is strictly prohibited. Participants in the call, including the Q&A session, agree that their likeness and remarks in all media may be stored and used as partof the earnings call. This call includes forward-looking comments concerning the companys plans and projections for the future that are subject to important risks and uncertainties. Additional information concerning factors that could cause actual results to differ materially is contained in the companys mostrecent Form 8-K and periodic reports filed with the Securities and Exchange Commission. This call also may include financial measures that are not in conformance with accounting principles generally accepted in the United States of America or GAAP. Additional information concerning these measures, including reconciliations to comparable GAAP measures is included in the release and posted on our website at www.johndeere.com/financialreports under Other Financial Information. Susan?

**Other**
: Thank you, Tony. Today John Deere announced third quarter earnings and all in all, it was a solid performance. In fact, our income of $851 million was the second highest for any third quarter in company history, exceeded only by last year's total. Our results did reflect moderating conditions in a global farm sector, which hurt demand for farm machinery and contributed to lower sales and profits for our Ag and turf business. However, our other division's construction and forestry and financial services saw improvement in their results. This shows the benefit of having a broad-based business line-up. Overall then it was a quarter of solid performance and one that puts the company on the home stretch of another good year. Now let's take a closer look at the third quarter in detail beginning on Slide 3. Net sales and revenues were down 5% to $9.5 billion. Net income attributable to Deere and Company was $851 million. EPS was $2.33 in the quarter. On Slide 4, total worldwide equipment operations net sales were down 6% to $8.7 billion. In the quarter-over-quarter comparison of net sales, Landscapes accounted for four points of the change. Price realization in the quarter was positive by two points. Turning to a review of our individual businesses, let's start with Agriculture & Turf on Slide 5. Sales were down 11%, primarily due to lower shipment volume, as well as the four point landscapes impact noted on the previous slide. Operating profit was $941 million. In addition to volume, margins in the quarter were negatively impacted by higher production cost related to engine emission regulation, which includes product's material costs and foreign exchange. Before we review the industry sales outlook, let's look at fundamentals affecting the Ag businesses. Slide 6 outlines U.S. Farm Cash Receipts, which are forecast to be down somewhat from 2013. Assuming above trend yields, grain and soybean production levels are expected to be up in 2014, which is resulting in lower prices for those crops. Livestock receipts are forecast to remain at record levels. As a result, our forecasts calls for 2014 cash receipts to be about $387 billion, down about 5% from 2013, which is forecast to be the highest level ever recorded. Concerning cash receipts for next year, based on our expectation that record grain yields in 2014 and resulting lower commodity prices, our very early forecast calls for cash receipts to be down about 3% in 2015. On Slide 7, global grain stocks to use ratios remain at somewhat sensitive levels, even after abundant harvest in 2013. Although supplies appear to be adequate, global grain and oil seed demand remain strong. Unfavorable growing conditions in any key growing region of the world coupled with the unknown impacts for geopolitical issues could lower production; reduce the stock to use ratio and result in prices quickly moving higher. Our economic outlook for the EU 28 is on Slide 8. There are signs of economic stabilization and cyclical recovery, with a modest forecast increase in GDP growth, rising consumer and business confidence and increased exports. With feed costs easing, strong beef prices and near record milk prices, margins remain supportive for livestock and dairy farmers; however, grain prices have declined and farm income is expected to decrease in 2014. As a result, farm machinery demand is expected to be lower for the year. Furthermore, a differentiated picture continues to exist by country. While demand is improving in the U.K. and Spain, we are seeing decline in important markets like France and German. On Slide 9, youll see the economic fundamentals outlined for other targeted growth markets. In the CIS, declining economic growth and further tightening of credit availability continues to weigh on equipment sales, notably Western equipment manufacturers are being impacted by the uncertainty from geo-political issues in the region. Economic growth is expected to slow in China in the second half of the year and the Ag economy there is slowing as well due to lower grain prices. And, ongoing subsidies are supportive of agriculture, their pace of increase has slowed. In addition, the construction sector recession has deepened. Turning to India, although rainfall is expected to return to a more normal level, the weak onset of the monsoon season and minimal precipitation in key agricultural regions could have a negative impact on production. Slide 10 illustrates the value of agricultural production, a good prospect for the health of agro business in Brazil. The 2014 value of Ag production is expected to increase about 5% over the 2013 level. Even with the recent drop in prices Ag fundamentals remain strong for grain helped by 2013s extremely strong market and favorable financing environment. On the other hand, while partially offset by the weak real, lower global commodity prices could reduce farm income. Our 2014 Ag and turf industry outlooks are summarized on Slide 11. Although the Ag economy remains in a relatively healthy state, falling commodity prices are putting pressure on demand for farm equipment, especially larger models. At the same time, strength in the livestock sector is providing support to sales of mid and smaller size tractors. As a result, we now expect industry sales in the U.S. and Canada to be down about 10% this year. The EU28 industry outlook remains down about 5% due to lower crop prices and farm income. In South America, industry sales of tractors and combines are now projected to be down about 15% from 2013s strong levels. Shifting to the CIS, we continue to expect industry sales to be down significantly, with western Ag equipment manufacturers feeling the most impact due to geo-political issues and resulting credit availability. In Asia, sales are now projected to be about flat. Turning to another product category, industry retail sales of turf and utility equipment in the U.S. and Canada continue to be projected at flat up 5% in 2014. Putting this all together on Slide 12, fiscal year 2014 Deere sales of worldwide Ag and turf equipment are now forecast to be down about 10%. In the year-over-year comparison of net sales, landscape accounts for about three points of the change and negative currency translation accounts for about one point. The reduction in our forecast from last quarter mainly reflects lower industry outlooks for sprayer and turf sales in the United States and lower sales in Brazil and Canada. The 2014 forecast for the Ag and turf division operating margin remains at about 14%. The two point decline in operating margin from 2013 is a result of volume, mix, foreign exchange and higher production costs, including product and implementation costs related to the final Tier 4. Before turning to construction and forestry, lets touch on used equipment. Strong, large Ag tailwinds have driven record new equipment sales growth and higher levels of used inventory. The rise in used inventory has been steady across large Ag product lines and the spread between used prices and their original new prices has widened from the tightest ever spreads of 2008 and 2009. Specifically, Deere prices are holding up as well or better than the competition. Our dealer's ability to move used equipment is crucial to our long-term strategy. A new tool to enable this is outlined on Slide 13. Earlier this month, the John Deere certified pre-owned program was introduced, combines less than two years old with less than 1,000 hours and eight hour and four wheel drive tractors, less than three years old and fewer than 1,500 hours are eligible. Products in the program will undergo rigorous inspection. More than 280 points on combines and 150 on tractors will be inspected and tested by John Deere certified technicians. Products also will be backed by an industry leading one-year 500-hour comprehensive power guard warranty and include a one-year subscription to JDLink. This will allow our used equipment customers to experience uptime similar to new equipments, and take advantage of the increased fuel economy, comfort convenience and technology, associated with late model. Now, lets focus on construction and forestry on Slide 14. Net sales were up 19% in the quarter, and operating profit was up 81%. The divisions incremental margin of about 31% was a result of increased volume and price. Our less favorable product mix, negatively affected C&F operating margin in the quarter. This was driven by a tough comparison on service parts and a less favorable region mix primarily driven by increased sales in Brazil. Moving to Slide 15, looking at the economic indicators on the bottom part of the slide, although growth has been disappointing, the United States economy is slowly moving forward and there are positive signs in the market. Unemployment is falling and construction hiring is increasing. Housing starts are slowly ramping up, home inventories are low and existing home sales are rebounding. Landscaping activity is picking up, and financing for land developers is slowly recovering. Additionally, we continue to see a strong domestic energy sector. Based on these factors, Deeres construction and forestry sales are forecast to be up about 10% for the year, this is unchanged from our initial outlook in November, 2013. Our C&F order books are strong. The outlook for the year contemplates increased shipment following the low levels of 2013 as well as industry growth in response to an improving U.S. economy and increased international sales. Global forestry markets are expected to be up about 10% in 2014, unchanged from our previous forecast. Following double-digit growth in 2013, North American forestry markets are expected to be up about 10%, while Europe and Russia are expected to improve from the depressed levels of 2013. C&Fs full year operating margin is projected to be about 9%. Lets move now to our financial services operations. Slide 16 shows the financial services provision for credit losses as a percentage of the total average owned portfolio at the end of July with 10 basis points. This reflects the continued excellent quality of our portfolios. Our 2014 financial forecast contemplates a loss provision of about 11 basis points. Losses remain well below the 10-year average of 28 basis points, and the 15-year average of 48 basis points. Moving to Slide 17, worldwide financial services net income attributable to Deere & Company was $162 million in the third quarter versus $150 million last year. 2014 net income attributable to Deere & Company is forecast to be about $600 million, which is unchanged from a quarter ago. Slide 18 outlines receivables and inventory. For the company as a whole, receivables and inventories ended the quarter down $469 million. That was equal to about 30% of prior 12-month sales, the same as the situation a year ago. Ag and turf ending receivables and inventory were down $552 million. Most of the decrease was accounted for by John Deere Landscapes and John Deere Water. For your reference, we have included on this slide, receivables and inventory for our landscapes and water businesses at the end of the third quarter and fiscal year 2013. Construction and forestry ended the quarter up about $83 million. We expect to end 2014 with total receivables and inventory down about $300 million. Our 2014 guidance for cost of sales as a percentage of net sales shown on Slide 19 remains at about 75%. When modeling 2014, keep in mind the following: price, about two points; lower pension OPEB expense; overhead spending due to tier 4 transition, less favorable mix of product; and tier 4 product cost. Looking at R&D expense on slide 20, R&D was up about 7% in the third quarter, but is forecast to be down about 2% for the year. Moving now to Slide 21, SA&G expense for the equipment operations was down about 15% in the third quarter and is forecast to now be down about 10% for the year. In the year-over-year comparison of SA&G expenses, Landscapes accounts for about seven points of the change and water about one point. On Slide 22, pension and OPEB expense was down about $40 million in the quarter and is forecast to be down about $150 million for the full year. Turning to Slide 23, the equipment operations tax rate was approximately 35% in the third quarter, and is now forecast to be in the range of 33% to 34% for the year. On Slide 24 shows our equipment operations history of strong cash flow. Our forecast for cash flow from equipment operations is approximately $3.7 billion in 2014. The 2014 outlook for the fourth quarter and full year are on slide 25 and 26. Net sales for the quarter are forecast to be down about 8% compared with 2013. This includes about one point of price realization. In the year-over-year comparison of fourth quarter sales, Landscapes accounts for about three points of the change and John Deere water about one point. The full year forecast calls for net sales to be down about 6%. In the year-over-year comparison of net sales, Landscapes accounts for about three points of the change. Price realization is expected to be positive by about two points. FX is expected to be negative by about one point. Finally our full year 2014 net income is now forecast at about $3.1 billion. In closing, John Deere is looking forward to completing another successful year. Whats more, we continue to believe the longer term outlook for our businesses holds considerable promise. For the balance of the year, the company will be scaling back production in line with demand for agricultural products. Actions that illustrate our commitment to responding decisively to change the market conditions. At the same time, plans to expand Deeres market presence throughout the world remain on track and are continuing to move ahead. As a result, we have confidence, the company is well positioned to bring solid returns throughout the business cycle and to realize substantial benefits from the worlds growing need for food, shelter and infrastructure in the years ahead. Ill now turn the call back to Tony.

### Q&A
**CTO**
: Thank you, Susan. Were now ready to begin the Q&A portion of the call. The operator will instruct you on the polling procedure, but as a reminder, in consideration of others please limit yourself to one question and one related follow up. If you have additional questions, we ask that you rejoin the queue. Operator?

**Operator**
: (Operator Instructions) Your first question is from Tim Thein with Citigroup.

**Analyst-1**
: Great, thanks. Good morning. First, Tony I was hoping you could just  good morning, just update us on the early order activity in North America on your spring programs and I think you just remind us, but I think you were planning to do a bit more stocking at the dealer level this year. So, presumably that maybe inflates things, but, can you just kind of update us in terms of what youre seeing there and tail engine or other products?

**CTO**
: Right, we have  there are three early order programs that have just completed Phase I or about to complete Phase I in the U.S. and Canada, the sprayers, planters and tillage equipment  to your point and this would be true for various reasons, there are definitely year-over-year differences in those early order programs, for examples, planters last year had a fast start program that didnt get repeated this year. Sprayers were pretty heavily influenced by our Tier 4 transitions last year. So, to give, in some years weve given a percentage change and its just really apple-to-oranges in most cases, but clearly it leads in the early indications of Phase I on those three products, we would tell that the order programs are down double digits year-over-year.

**Analyst-1**
: Okay. Got it. And then secondly, on the Ag and turf margins, you called out the impacts from Tier 4 costs in the third quarter, can you just help us in terms of how we should think about  in rough terms the impact in 2015 as you transition to similar lower horsepower products which presumably take a little bit longer and are bit more difficult to cover with the price increase at least upfront or initially.

**CTO**
: Sure. Yeah, thats a good point. In the third quarter, we did see a lot of that cost was related that we pointed out was related to product cost which is certainly higher in the third quarter as we transitioned earlier in the most of those products. And to your point, in large Ag, which is what transition this year, the cost portion of that, not necessarily cost plus margin, but the cost portion of that has largely been recovered through pricing. As we move into 2015, thatll be a bigger challenge, not just on small Ag but also as you think about construction, similar to interim tier 4 where we were very clear in year one, we will not be recovering  did not recover the cost on interim Tier 4 in year one, the same will be true with final tier 4 on those products. Of course in all cases we do have the three year commitment that we would cover both cost and margin. But it will take a period of time to grow into that. So, all else being equal, as you look at next year that would be a margin drag as we transition those small Ag and a lot of our construction and forestry product next year.

**Analyst-1**
: Great. Thank you.

**CTO**
: Great. Thank you. Next caller?

**Operator**
: Your next question is from Adam Uhlmanwith Cleveland Research.

**Analyst-2**
: Hi, good morning.

**CTO**
: Good morning.

**Analyst-2**
: Just quickly a follow-up on that, Tony would you care to mention the potential margin drag that youre anticipating or at least to mention it for us?

**CTO**
: Weve not, as you may recall couple of years ago we, as we were going to interim Tier 4, we talked about the actual cost and all the underlying pieces of cost of sales. Last year we started providing and outlook on cost of sales overall and not giving all of the individual details underlying and that would continue to be the case next year. So, when we go, when we release our fourth quarter earnings and provide our first 2015 guidance at that point well have guidance on cost of sales and well be able to talk directionally in the order of magnitude of whats driving that cost up or down as we go into 2015.

**CFO**
: Hey Adam, this is Raj. One the 2015 margin, we will not get into the specifics, but let me give you some outline of how we think about it okay. These are some points you can consider with respect to it. Assuming demand for Ag equipment in the U.S and Canada continues to moderate. One of things weve always said, our goal is to earn above our cost of capital throughout the cycle. So think overhead absorption, we will continue to align factory production to demand as we have mentioned in the third quarter press release. So, lower productions will have a negative impact on overhead absorption for the A&T division and especially true for large Ag products. On SA&G side, we will continue to pull levers in SA&G expenses appropriate. And SA&G number still may go up as a percent of sales. And again all these are assuming AG equipment years and continuous to moderate. On the R&D side, we will be pragmatic but R&D expenses balancing the need for short term lever pulling with the investment needs that can help deliver our long term aspirations. So, number of 12, 20, 28, structure line, that is at the trough of 80% mid cycle upon it, and a peak of 120% thats approximately 28 as OROA, the operating return operating assets. Thats our commitment to provide a solid return toward the cycle. So you should think of that line, but margins will be lower as we move down the line. And as we move up the line, you have said you should expect a margins to be higher. Some of the other considerations, material cost we are significantly impacted by steel prices. So our steel cost generally follow the market prices with the larger feet of six months. And if we can forecast few prices, that should give an indication for our material cost. In terms of Tier 4 transitions as Tony mentioned, many of our small mid AG and C&F products will be transitioning to final Tier 4. In 2015 when higher material cost and higher spending your transition should be expected and we will not fully recover the material cost increases of the pricing in year one especially for these products. But however we are targeting to be marginal neutral in three years. Now on pension and OPEB expense. Well there are several factor that impact pension and OPEB expenses. And they can vary significantly between and now and end of October. If you take for example the more recent discount rate, of around 4.25, if that were to apply at the end of October, and all other factors being equal, our pension and OPEB expenses can go up, hope thats helpful. Thanks.

**Analyst-2**
: That is helpful. Thank you. I'll get back in queue.

**CTO**
: Okay. Thank you. Next caller.

**Operator**
: And the next question is from Ross Gilardi with Bank of America - Merrill Lynch.

**Analyst-3**
: Hey, good morning can you hear me okay.

**CTO**
: We can. Thank you.

**Analyst-3**
: All right. Thanks Tony. So you guys are guiding to 1% pricing in the fourth quarter but still a 2% for the year. So are you seeing deterioration in the new equipment pricing outlook or this is more or less just a rounding error?

**CTO**
: Yeah I think I would point out that it's certainly rounding can have an impact on that. So, I wouldnt read much into that.

**Analyst-3**
: Okay. And then any thoughts on Brazil and whether or not you think the lower soybean in general AG weakness and economic weakness in Brazil incentives the government to extend FINAME into 2015 or any thoughts on FINAME in the next year?

**CTO**
: With FINAME in general, our view would it  lot of way similar to the U.S. farm bill and in the sense that its the process in which Brazil has helped to incentivize and help to deport agriculture as well as other businesses. And so, again it's less of an issue in our minds of whether FINAME continues and is extended into 2015, but more about whats the rate at which it will continue. So the budget has been set really for the year. Like I said in the June timeframe, but the current program is only defined through December. So again it's really more about what will be the rate be rather then whether its in existence or not.

**Analyst-3**
: And any initial thoughts there?

**CTO**
: We do not have any thoughts on that at this point.

**Analyst-3**
: All right. Thanks a lot.

**CTO**
: Okay. Thank you. Next caller.

**Operator**
: And your next question is from the line of Andrew Casey with Wells Fargo Securities.

**Analyst-4**
: Good morning.

**CTO**
: Good morning.

**Analyst-4**
: Just a question Tony on the SA&G, you did really well in the third quarter down about 80 basis points year-over-year. The annual guidance kind of implies relatively flat year-over-year performance in Q4. Can you help us understand what caused the decrease in Q3 and why we really shouldnt expect that to continue into Q4?

**CTO**
: Yeah. I think as you think about SA&G. I mean there is always, in some cases there are some timing differences between the third Q and fourth Q, our fourth quarter and that would be the case this year where you look at year-over-year comparisons, the expense hit in the third quarter last year and they will be in the fourth quarter this year. Id also point out that fourth quarter does tend to be a heavier quarter with SA&G expenses as we finish out the year. The third thing I had mentioned is there was some favorable FX impact in the third quarter thats expected to flip and actually go the other direction. So that would have some impact as well.

**Analyst-4**
: Okay. Thanks. And then on cash flow if I look at the guidance, the decreased roughly 300 million, you had an approximate 200 million decrease to net income that should be partially offset by the 150 million positive inventory and receivables. Given note change to the depreciation CapEx and just a slight change to the pension contribution, can you help us understand the puts and takes that are driving the 300 million decrease?

**CTO**
: Yeah. You hit two of the three, the third really would be payable, the assumption round payable changed. So those are really the three things that drove that lower cash flow forecast.

**Analyst-4**
: Thanks. And then if I can sneak one more in the certified years equipment program. While the equipment is waiting to be sold does that still on the dealer balance sheet or is that now at dealer balance sheet?

**CTO**
: That would still be on the dealer's balance sheet absolutely.

**Analyst-4**
: Okay.

**CTO**
: Think about it as another tool for our deal to help move that used equipment.

**Analyst-4**
: Okay. Thanks a lot.

**CTO**
: Okay. Thank you. Next caller.

**Operator**
: And your next question comes from Jamie Cook with Credit Suisse

**Analyst-5**
: Hi. Good morning. I guess you know a couple of questions. One just given the risk of that I guess first question, you mentioned in your prepared -- in Q&A that when we think about the order book and you talked about sprayers, planters and tillage early indications are they are down year-over-year sorry, double digit, year-over-year historically youve said tillage has been sort of a good indicator of demand for equipment as its more discretionary. Would that imply as you think about 2015, when we think about large tractors and large combines that we should at least see that levels decline just given what we are seeing in tillage in a historic relationship. And then I guess my second question is can you talk about your comfort level with the inventory at the dealer level so in the event that we do have some downtrend in 2015, where they were actively managing this so could inventory in the channel be a potential issue? Thanks.

**CTO**
: Sure, I think as you think about the early order programs and certainly it does give some early indication of the framers and customers appetite for purchase going into the year there are variety of things they can influence that as well. So, certainly we would be using that and that would be part of evaluation as we consider what next year would be, but we would not have an outlook at this point on Ag equipment going into 2015 that were in a position to share publically. I would stress again it is very early in the process that phase one on three of our crop care program, but it can as you pointed out in the past we've certainly viewed that as at least some directionally an idea of where sales may end up going. Some of the things you want to be a little careful not to read too much in or try to ignore some of the fact that the difference -- there are a lot of difference year-over-year too in terms of the in years past, we have been in capacity in many of our product, customers, and dealers knew that; so there was a certainly a greater sense of urgency. I think the expectation next year is for demand to be down and certainly we will have the capacity to meet that demand as we go into 2015. So there is that element as well. That could factor into some of those year over year differences again in a very early stages of those programs. So we will have a much better view as we always do when we get to November with our fourth quarter earnings as we get further into the programs, start to see whats going on with combine early order programs and so on as well. So those will be some things I would mention. From an inventory prospective I think from a concerned prospective and we talked about it all year I think the greater concern would be around used equipment as we come through a period of time with some high level of sales that brings along with it a high level of used equipment and so we are working very diligently with our dealers to bring those used inventory down in line with what we are expecting demand to be. We talked about on the call some of the new programs we have with the certified use. Again I want to be clear this is a long-term strategic program. It isnt intended to be viewed a silver bullet to remedy the situation overnight, but it will certainly be helpful and I think this is something we have put together in conjunction with our dealers and should be very helpful especially with moving that newer equipment through the channel.

**Analyst-5**
: But Tony to be clear last quarter I think you said tractors were bigger issue relative to combine is that still the case or things in total for both tractors and combines deteriorated versus last quarter or the inventory got more than?

**CTO**
: I think that would still be the case as you look at used in and in fact I shouldnt say I think it is still the case for tractors that are a little more elevated than combines. But remember you are also going through a period where we are selling a lot of new combine just ahead of the harvest. So fall is always a critical timeframe. From moving those used combine through the system as we move through harvest.

**Analyst-5**
: Okay. Thanks. Ill get back into you.

**CTO**
: Thank you. Next caller.

**Operator**
: The next question is from Steven Fisher with UBS.

**Analyst-6**
: As we head into this weaker period on Ag in North America just trying to guys how you guys are really thinking about it more broadly. Are you viewing this as may be a shorter 12 months phenomenon, 18 months, or is this do you think about it as a multiyear downturn and how does that affect your planning.

**CTO**
: Well I think the way I would answer that is at this point, as Susan mentioned in her opening comment, you are still while you are seeing stock used ratios at least to the expectation of another good year those stocks will continue to rebuild, but given the very strong demand environment on commodities as well the answer to that question is whats going to happen with the crop that will get planted next year in terms of do you have yet a third year in a row of good growing conditions on a global basis or do you have a year where those yields moderate a bit due to weather -- weather thats in the U.S. or some other region. So thats a tough one to answer and certainly that the advantage we have I think is how we structured the business today in the sense of being able to shift, pull levers where we need to, to be able to ensure that we are able to maintain good returns throughout that cycle. So again I think it's just very premature to try to call whether this a 12-month phenomenon or longer term.

**CFO**
: So I'll just add that longer term tailwinds for Ag demand are still intact. Okay. So from that perspective the demand is continuing to grow and as Tony said depends on how the supply is. If the weather conditions are great everywhere then we might have issue we have today, but if the weather conditions turn out to be more erratic then you know it can be different?

**Analyst-6**
: Okay. And then since you mentioned the levers, I guess cheers for your views on the notion that nearly every one of the global Ag markets is down in tandem at this point and really how that affect your manufacturing strategy, exiting in the past factor utilization has been supported by allocating the U.S. capacity for shipments to some of the non-U.S. markets. So I guess I am wondering to what extent is that reallocation still an option.

**CTO**
: That would be true Steven in some cases so as you look at tractors for example in Waterloo somewhere in the neighborhood of 30% or so typically of the production there is shipped outside of the U.S. and Canada. I would point out some of that will change at the end of 2015 as we localize the aide tractor in Brazil. But then as you look at combines you are down in the neighborhood of 10% of the production in the U.S. is shipped outside of the U.S. and Canada. So we have shifted some of that production those large combines are now being produced in Europe for example as well as Brazil. So that is shifting as business is growing in some of these other regions. Some of that demand has moved closer to the use. So obviously when you look at global production it still has an impact, but on specific factories in the U.S., a lot of those cases it wouldnt be as impactful as it would have been three years ago.

**Analyst-6**
: It's very helpful. Thank you.

**CTO**
: Thank you. Next caller.

**Operator**
: The next question is from Andrew Kaplowitz with Barclays.

**Analyst-7**
: Hi good morning guys. Sorry about that before. So Tony can you talk about dealer inventory in the construction channel actually your largest competitor in construction when it announced earnings talked about how into destock about a billing of dealer inventory in the second half of 2014 now. We recognize that there are much more international outside of North America than you guys are, but how do you look at the dealer channel right now. How concerned you would be that there is quite a bit of inventory in the channel or is it actually in pretty good shape.

**CTO**
: We would say the latter certainly for Deere construction and forestry inventory at the dealer channel would be at very good levels. That -- you may recall we had some questions last quarter on our sales levels and we talked about the fact -- that with our order fulfillment process and construction of forestry, we dont tend to push inventory out into the market. Our dealers dont have a heavy rent program that they can use to bulk up their inventory level either and so we tend to run with some leaner inventories as a result, given our factorys ability to replenish that inventory pretty quickly.

**Analyst-7**
: Okay. Thats helpful and Tony can you talk about your ability to get price excluding the final Tier 4 transitions. Youve maintained your guidance of the company for plus 2% from fiscal 14 but youre getting 1% in fiscal 14. If I might recall, this excludes sort of -- this pricing exclude these transitions so can you talk about the competitive environment you see in Ag. Was there any -- is mix change impacting price at all? What do you see going forward?

**CTO**
: Certainly for this year, we  someone asked earlier and I would say its really more about rounding than a significant change in our pricing for price realization for the fourth quarter. So again I wouldnt read much into that. As you look back over the last decade, weve talked about this but weve averaged a little over three points of positive price realization each year. Were two points this year in a slower equipment demand environment especially for large Ag in the U.S. and Canada and to your point in year one of introducing Tier 4 product, we would not count the price related to that in our price realization calculation, so were getting two points plus the pricing that weve taken on Tier 4 for the products that transitioned this year. So that demonstrates -- we've had pretty good pricing and again thats really about bringing efficiency and being able to provide that higher productivity to the farmer to warrant that higher pricing.

**Analyst-7**
: Thanks Tony.

**CTO**
: Thank you. Next caller.

**Operator**
: The next question is from Larry De Maria with William Blair

**Analyst-9**
: Hi, good morning. Thank you.

**CTO**
: Hello.

**Analyst-9**
: Hey, sorry about that before. Long term fundamentals and demands obviously suggest money for food, and thats kind of always been the case but theres been through the long term weakness in equipment when we come off from below its kind of like we are in the 90s. So I am just curious what is different or the same in this cycle compared to 90s balance sheet just kind of similar in good shape down like they were back then and to call that weather and politics, that potential changes to the trajectory but -- and obviously the supply side is where youre focused on if theres a weather interruption but could you just help us understand -- what is similar or different about this cycle versus the late 90s, which had a relatively extended period of downturn?

**CTO**
: I think one thing I would point out is -- you mentioned balance sheets and certainly compared to the 80s it would be better today but even compared to the late 90s, if you look at the data you are in even better shape. We talk a lot about the underlying demand of commodities and we continue to point to that as well in the sense of our -- historically the cycles have been much more about changes in supply. There a lot of conversations around ethanol for example, which has been very supportive over the last decade of building supply and while the growth is clearly moderating on ethanol demands. There are corn used ethanol. The supporting demand is still in place and our view is youre going to continue to see food demand pickup in other parts of the world and see that growth curve continue to be very strong and that is basically where we think its going to be different year-on-year or this time around.

**CFO**
: And Larry, aside from the market demand, we also want to look at the improvements weve made structurally to our business and that will be a difference between 90s and now. Okay? So we think structurally we're in a better position at this time above our cost to capital at any point in the cycle now.

**Analyst-9**
: Okay, thank guys. And then back then you used to talk about -- you've had your economic model that would talk like normal like tractor demand and combine demand, which however shot to the downside because the fundamentals returned pretty bad back then but care to offer kind of some perspective on where a novelized demand where the model which you just had moved long term averages are for tractor and combine demand given that we are coming off, obviously at a very high level and where we can think about novelized support in an environment like this.

**CTO**
: Yeah, at this point, weve not disclosed and especially for a specific product where we are as a percent of normal. Weve talked about it in our forecast for 2014, we'd tell you with our current forecast we would be slightly below mid cycle and on a global basis for Ag and turf would be again slightly below mid cycle with our current forecast but beyond that theres not much help I can give.

**Analyst-9**
: Well, can you say where would be in North America then as far as you would see.

**CTO**
: The only thing we have provided is on a global basis. So thats really all the help I am going to be able to give in that regard.

**Analyst-9**
: Okay. Thanks Tony.

**CTO**
: Okay? You bet. Thank you. Next caller?

**Operator**
: The next question is from Vishal Shah with Deutsche Bank.

**Analyst-8**
: Thanks for taking my question. I was just curious as to what do you think about the Brazilian market outlook. I know that youve talked in the past about outgrowing that market in light of the down 15% industry forecast. What do you think can you maintain relatively flattish revenues in that market and also how do you think about opportunity in the EU28 region considering some of the share gain initiatives that you have in place over there?

**CTO**
: If you think about Brazil in to your point, weve mentioned this throughout the year and we continue to be true. As you look at the industry guidance that we provide versus Deere expectations of sales, South America would be the greatest differential on the positive side for Deere. Some of that is the fact that we provide industry guidance on tractors and combines only in South America and of course we have a full line of products offered there. With this latest downturn, we were seeing -- we werent necessarily second Deere sales to be down. I dont believe I can say that anymore but certainly strongly outperforming the industry both because of the strength of our broad portfolio there. Also the market share gains that we continue to get on both tractors and combines. So that certainly will drive that. If you think about the market in general, its important to know that youre coming off, its a down year -- you're coming off of a record level in 2013. So most in that market would tell you things arent what they would consider weak just because theres year-on-year, things continue to be very strong. Soya bean farmers even at these levels of pricing are still in profitable territory and so we still have a very positive view on Brazil as we move forward.

**Analyst-8**
: Thats helpful and just on EU28 share again opportunities, are you seeing any of that play out this year and also whats your view of decremental margins in North America given the mix shift towards small Ag. Are we looking at 40% detrimental margins or slightly more than that next year? Thank you.

**CTO**
: If you think about EU28 obviously we continue to be in a difficult market there. Weve seen sales forecast to be lower year-on-year. So were making good progress in terms of our dealer consolidation there, those sorts of things. So we feel like were putting ourselves in a good position though -- to be candid the market share has been a little slower to come though from a strategic perspective were still very encouraged by that. Just real quickly on margins, obviously we dont disclose margin by individual product but certainly weve been very clear that large Ag equipment has better margins than small. So if youre expecting a decrease next year and you assume its all large Ag driven decreases than the incremental will be difficult. But at this point, its again premature really to talk about any kind of specifics in that regard. So anyway with that well move on to next caller.

**Operator**
: And your next question is from Robert Wertheimer with Vertical Research.

**CTO**
: Hi Rob.

**Robert Wertheimer - Vertical Research Partners**
: Sorry for the interruption before. And I apologize if these have been asked before. Ill just ask three and you can skip if they have been. On the certified used, what seems like a nice way to sort of manage without giving price discounts. Is there a fee charge for the buyer or is that sort of gratis in the way for you give away something that you can deliver cost effect away? Will your production plan be influenced, are you going to change the way you sell it all if use inventories rise and then make the dealers place that use before theyre taking order? And last question, do you contemplate in making a cost to capital if you go below the 80% cyclical industry strength? Thanks.

**CTO**
: Yeah, Ill start with the used. And I am not aware of any fee that will charged to the customer related to that certified used. Again its a tool that the dealer can offer. Now certainly while there may not be a specific fee, we would expect that thats going to help drive higher pricing on that used piece of equipment as it comes with again additional inspection on the product, the warranty, the free one year JDLink again should be very supportive of the underlying pricing that the dealer gets on that particular piece of equipment. Again in terms of the way we sell equipment in terms of expecting dealers to have a used piece of equipment sold before we ship new, I think it was your question. There is certainly not a change there. We have talked about on combines as we allocate our early order program. We do the used inventory adding individual dealers location would impact -- does have some impact on the allocation of orders they get in any particular phase of our early order program but that would be the only area that I could really point to that were looking at that from a -- what were selling new equipment.

**Robert Wertheimer - Vertical Research Partners**
: Got it.

**CTO**
: Okay?

**Robert Wertheimer - Vertical Research Partners**
: And I am sorry. On the trough, if you go below 80% do you still hope to cover the cost to capital or is that something you dont contemplate?

**CFO**
: Hey Rob. Its too early to say anything now. What we will tell you is again and I said earlier, its not something that we look at in terms of below trough on a daily basis, okay? What we do is we do model 80120 and what I clearly said is 80120 we know and we perceive. Our goal is to -- we've done a model cost to capital. So we model those, we know those, we talk about those and we can talk more detail at the right time but I dont think we should get beyond that right now.

**CTO**
: One other thing I would point is theres a lot of talk about large Ag and reductions that are expected in large Ag. Remember, on the flip side of that livestock continues to do a very well margins or very strong in small Ag volume not as profitable as large stock. Its still very profitable and were looking at an opportunity to see some strengthening in that part of the business that will certainly help from a returns perspective. So its not all a downward trajectory if you look at again our broad base of business and similarly we have construction in forestry that -- if you look at underlying fundamentals, continue to support some recovery in that particular division. So there are some bright spots in the enterprise that we can point to as well.

**CTO**
: Yeah. Thank you. Next caller?

**Operator**
: The next question is from Mike Shlisky with Global Hunter.

**Analyst-10**
: Good morning. I noticed in your financials that your interest comp to the fin co. was up about 9% from prior year almost up a little bit as a percent of overall sales. Can you tell something financing programs that you havent placed today compared to either maybe last quarter or last year? What kind of change as far as how you have farmers -- finance your equipment from the marketing side?

**CTO**
: Yeah, if youre looking at the comp to credit line on the equipment operation side, is that correct?

**Analyst-10**
: Correct.

**CTO**
: Yeah. Keep in mind, that is really what youve seen reflected there relates the wholesale financing. So to be extensive there is a period of interest free or low interest on the wholesale financing available as we ship the product to the dealer prior to them settling that equipment. That gets charged back to the equipment operations and on that line. So it really isnt reflective of any kind of changes in incentives on retail sales. That actually would impact our net sales as a sales discount.

**Analyst-10**
: Got it and then looking at your prophecies you did mention that you have livestock down in 2015. Just want a little bit more color there. Is there going to be any more pricing or is just smaller herds and kind of what do you see as far as the health of the livestock farmers out there with current feed costs so low?

**CTO**
: Yeah, as I just mentioned when we were talking with Rob, theyre in very very good shape, livestock producers margins are very strong, really across the board. If you look into next year, youre coming off of record high prices and the expectation is that you would see some moderation there as production starts to come up. But to your last point, still a very good level and margins should remain strong from both livestock producers at least for the foreseeable future.

**Analyst-10**
: All right. Thanks so much.

**CTO**
: Okay? Thank you. Next caller?

**Operator**
: The next question is from Ann Duignan with JPMorgan.

**Analyst-11**
: Yeah, hi. Good morning.

**CFO**
: Good morning.

**Analyst-11**
: Can we talk a little bit about your outlook for crop cash receipts and youre looking for the kind of 3% into 2015. When we take the average prices in yields from Wall Street from yesterday we get minus 15. So I am just curious why the difference between you and USDA. Whatre you seeing out there is that you believe prices will be higher and yields lower?

**CTO**
: Well, first of all I wouldnt necessarily say -- the USDA have not updated their cash receipts number and keep in mind the cash received -- that when you look at crop prices and yield, thats on a commodity year basis and again as you know in cash receipts are on a calendar year basis. So 2014 cash receipts are being impacted by somewhat by what will get sold this fall for the current crop. Similarly 2015 cash receipts will be impacted by some assumptions of next years crops if they get sold immediately following harvest. So its not as simple as taking what the changes are, what the current year crop prices are times production. But I would point out as you think about cash receipts to that point its not just about the lower pricing, it is also about production. So as you have higher yields, more commodities to sell even in a lower pricing environment thats supportive of the overall cash receipt. The other fact that its hard to weigh in there is which would be anticipated in the USDA price assumptions for the current year but how much has been sold ahead and is that sold ahead going to occur in calendar year 14 or is that contract are for some time in early 2015 for example, in terms of whether those land that -- and are 14 cash receipts or 15. So thats a long way of seeing -- cash receipts is a pretty complex calculation. You cant simply look at the USDA reports and make good assumptions from that. But it its early and we would be very quick to point that out. Its a very forecast on what we see is 2015.

**Analyst-11**
: Yes but your outlook for farm commodity prices is higher than what the USDA said yesterday, I appreciate all the...

**CTO**
: It would be higher than the midpoint of their range. It is not outside of their range.

**Analyst-11**
: Fair and secondly I am just curious. I am out here in Illinois at conference with couple of 100 of your suppliers on the hydraulic side, I am just curious what kind of conversations you are having with your supply base at this point in the cycle and what kinds of expectations are you setting for your supply base going into 2015.

**CTO**
: Yeah. Thats not something we are going to discuss. We view our supply base as partners and we on a regular basis have conversation with them to make sure they are prepared to meet the demand.

**CFO**
: Ann, this is Raj, on the supplier side, we have a process we follow. So we routinely sit down with them and talk about our orders regardless of where they are right upside or downside, or a safe side. So we will follow the same process that we had in the past.

**CTO**
: We will move on to the next caller. Thanks Ann.

**Operator**
: The next question is from Joel Tiss with BMO Capital Markets

**Analyst-12**
: I learned something today to my next time my wife bust my chops about getting fat Ill just tell her its rounding error. So two things probably more just clarifications I didnt hear you mention why the credit loss provisions were rising?

**CTO**
: Well. We've anticipated that really even last year again that 10 point provision is I would argue it's just reflective of the strength of our credit portfolio. It's still well below our historic ranges. When we were at three points and zero points two years ago, we were very clear those are not sustainable levels and they at some time point we are going to move back towards those historic ranges.

**Analyst-12**
: So I was just looking for any color like is it a little more Russian focused or is there anything else underneath that, but I can follow-up through.

**CFO**
: As you know Joel this is still a very strong any which way you look at it and you are not reading anymore into it.

**CTO**
: In some -- portion of that is lack of recovery. As you look at the provision last couple of years some of that has been recovery of some of the prior year right off and as we had some very good years there just arent the losses to recovery that we've had previously.

**Analyst-12**
: Okay. Great. And you havent talked very much about share repurchased and I know you have your priorities for cash and all that, but you just give us a little flavor of what you guys are thinking around that going forward.

**CFO**
: We will sound like a broken record on this Joel again. Our cash used policy outlined in Slide 29 has not changed and we dont have any intentions of changing it. Again, Single A rating is highest priority for and growth capital expenditures, M&A next priority and consistent moderate dividend increase and you want to have it at 25% -- the pay out at 25% to 35% on mid cycle earnings and then share repurchase, which is as I said, Joel use of cash and we do it when its is enhancing for our long-term shareholders. And what I will add as we have confidence in our ability to generate good operating cash flow throughout the business cycles and so you should expect us to continue with our cash use policy as stated and you can think on what we did last three years that should be an indication of how we will act in the future.

**Analyst-12**
: All right. Thank you.

**CTO**
: Thank you and we will take one more call.

**Operator**
: The last question is from Seth Weber with RBC Capital Markets.

**Analyst-13**
: Thanks guys. Most of them asked and answered, but can you just give us any update or sense what you are thinking about Section 179 or bonus depreciation, how you are thinking about that and kind of just what you are hearing about that from a legislative prospective?

**CTO**
: Sure. As you think about Section 179 I think most would argue that the most like scenario is that both Section 179 and bonus depreciation would be extended at 2013 levels, but not likely to happen before midterm elections and again any extension would likely be retroactive in pickup 2014. Actually if you look at what we have in our model, we've actually taken a bit more conservative approach as we look at both our 2014 and 2015 models and we have our models assuming no extension, but again as you read and what we're hearing the more, most are assuming that it will still be extended at those 2013 levels.

**Analyst-13**
: Okay. That's all I had. Thank you very much.

**CTO**
: Thank you. And again we apologize for the interruption in the middle of the call. Hopefully we did extend the call a bit. So appreciate those of you who were willing to stick around a bit longer and as always will be available throughout the day to take any follow-up questions. Thank you.

**Operator**
: This concludes todays conference call. You may now disconnect.