## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCARs Third Quarter 2015 Earnings Conference Call. All lines will be in a listen-only mode until the question-and-answer session. Todays call is being recorded. And if anyone has an objection, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCARs Director of Investor Relations. Mr. Hastings, please go ahead.

**CTO**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCARs Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer and Michael Barkley, Vice President, Controller. As with prior conference calls, if there are members of the media on the line, we ask that they participate in a listen-only mode. Certain information presented today will be forward-looking and involve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

### Q&A
**CEO**
: Good morning. PACCAR reported strong quarterly netincome of $431 million for the third quarter of 2015. This is the second best quarter in the Companys 110 year history. Net income increased 16% compared to the third quarter last year. PACCARs third quarter sales and financial services revenues were $4.9 billion. Gross margins for truck, parts and other operations were outstanding at 15.3%. These strongmargins were the result of our great product line-up and rigorous cost control generating an 8.9% after tax return on revenues. This was the highest return on revenues achieved since the first quarter of 2007. Im very proud of our 24,500 employees who have delivered industry-leading products and services to our customers worldwide. PACCAR delivered 39,400 trucks during the third quarter, a 6% increase compared to the third quarter of last year. The European economic and truck market outlook continues to improve. GDP growth expectations for this year are 2.6% in the UK, which is PACCARs strongest market in the region, GDP growth is also accelerating on the continent. Freight transport activity on German highways is up 3% year-to-date compared to the same period last year. DAF truck registrations in the European above 16 tonne market are up 30% year-to-date compared to 20% growth for the market as a whole. Weve raised this years 2015 forecast for Europes greater than 16 tonne market to a range of 255,000 to 265,000 units. We expect the strong market conditions to extend into next year. Our 2016 forecast for Europes heavy truck market is a range of 250,000 to 280,000 trucks. DAF has begun construction of $110 million cab paint facility in Westerlo, Belgium to support its future growth. The U.S. economic picture is also positive with GDP forecast to grow 2.5% this year. The housing and automotive industries are bright spots in the economy and create a large amount of freight. Housing starts are projected to grow 13% this year to 1.1 million and the automotive industry is expected to deliver a near record 17.2 million vehicles. U.S. freight tonnage is at strong levels. Our estimate of retail sales for this years U.S. and Canadian Class 8 truck market is a range of 275,000 to 285,000 units. For 2016, U.S. economists are forecasting 2.7% growth in GDP, 13% growth in housing starts and another year of strong sales in the automotive industry, all of which is positive for freight tonnage and truck sale. Next year should be another for the U.S. and Canadian Class 8 truck industry and be in a range of 240,000 to 270,000 units. Gross margins in the fourth quarter for truck, parts and other forecast to be one half to one percentage point higher than last year's fourth quarter. PACCAR's global truck deliveries in the fourth quarter are estimated to be about 9% lower than the third quarter reflecting increased holidays and lower bill rates in North America. This is partially offset by more production days and high of higher bill rates in Europe. PACCAR's parts business generated record revenues of over $2.3 billion and record pretax profits of $430 million for the first nine months of this year. Profit is a 17% increase, compared to the same period last year. The strong results were driven by economic growth and strong freight tonnage in the U.S. and Europe and the many innovative products and services offered by PACCAR parts and our dealers. Excluding the effects of foreign currency translation parts revenues would have been up 8% or $173 million for the first nine months of this year. For the third quarter of 2015, PACCAR parts pretax profit of 145 million generated an excellent return on sales of 18.7%. To support the growing demand for PACCAR in TRP branded parts, PACCAR parts will open a new 160,000 square foot distribution center in Renton Washington in the first half of next year. PACCAR financial services third quarter pretax income was $93 million, compared to $97 million earned a year ago. Excluding the effects of foreign currency translation profit would have increased $2 million for the quarter. The portfolio continues to grow and perform well. PACCARs strong balance sheet and positive cash flow have enabled the Company to continuously invest in new products and facilities. PACCAR recently announced a launch of the PACCAR MX-11 engine in North America early next year. PACCAR successfully launched the MX-11 in Europe two years ago and has installed over 10,000 MX-11 engines in DAF trucks. In addition PACCAR's engine factory in Columbus Mississippi celebrated the production of its 100,000 PACCAR MX-13 engine. Capital expenditures for 2016 are projected to be $325 million to $375 million and research and development expenses are estimated to be 240 million to 270 million. These investments will further enhance our global product ranges, after market support and our manufacturing facilities. In the third quarter PACCAR repurchased 1.4 million share of Company's stock for $79 million. In September the PACCAR Board approved a repurchase of an additional $300 million of common stock. PACCAR continues to enhance its leadership position in the global truck market by developing the highest quality products and services in the industry. Thank you and Ill be pleased to answer your questions.

**Analyst-1**
: Just related to the 2% growth outlook in Europe for 2016, which market or markets within Europe do you think still have the most upside relative to replacement demand potential?

**CEO**
: Probably in terms of the growth percentage probably the southern markets would have the highest growth prospects just because they have been relatively low, so I think percentage wise that will be the case. Another opportunity for DAF is the Russian market which has been down a fair amount over the last couple years and there is obviously potential for that to grow with at a -- from a very low level currently this year.

**Analyst-1**
: And then on the buyback can you talk about how you decided on the $300 million number and whether you think there is any motivation there to make that materially larger and then potentially multiples of that number?

**CEO**
: Yes we have done 300 million over the last couple of times, it's a number of that we feel very comfortable with, provides a reasonable horizon and if we see the opportunity presents itself well authorize an additional amount above and beyond that to appropriate time.

**Analyst-1**
: Make sure where the stock is trading now is not -- thats not part of your thinking at the moment?

**CEO**
: Yes, we obviously have bought back shares during the quarter and with the additional authorization we have the capability to continue to buy shares as we go forward.

**Operator**
: And then your next question will come from the line of Nicole DeBlase with Morgan Stanley.

**Analyst-2**
: So my first question for you is around the 4Q production outlook so within the 9% year-on-year decline, I am just curious how you might frame that within the U.S. and Canada versus Europe?

**CEO**
: So Europe will be up probably in the 30% to 35% range with the fact that we've got more production days and a higher daily build rate and offset by a similar percentage on the North American side reflecting increased holidays and lower build rates in North America.

**Analyst-2**
: And then my second question is with respect to what you guys are hearing from your customers we have had a few big fleets decided to cut their 2015 and 2016 CapEx outlook saying I know the market is super fragmented but I'm curious in particular about what you're hearing from your owner operator customers about their plans for spending next year in North America?

**CEO**
: I would say most of our discussions with our customers and mostly the large fleet customers, their expectations are to buy a similar number of trucks next year as they've purchased in 2015. I think were seeing that in the code activity that's going on currently with Peterbilt and Kenworth and as well as the order intake thats coming in, so people are starting to make decisions about 2016 purchases.

**Analyst-2**
: Okay, thanks. I'll pass it on.

**CFO**
: Nicole I would add that we already have several of our large customer orders in the house. And those volumes are the same as our larger generally than last year.

**Operator**
: And your next question will come from the line of Jerry Revich with Goldman Sachs.

**Analyst-3**
: I'm wondering if you could talk about the R&D budget for next year, obviously you've giving yourself room depending on end-market variability, but at the midpoint of the range is pretty good R&D growth within the context of mixed end-market outlook. Can you just talk about the potential programs that you're increasing spending on 16 versus 15 and then any additional color on U.S. versus Europe that you might be able to share?

**CEO**
: With so much of our product line up now is global in nature. I see next year being somewhat this year in terms of investing really across all elements of our products from continuing to enhance the individual component offerings within our various models at Peterbilt, Kenworth and DAF. We continue to invest in our engine technology obviously were launching the MX-11 in January in North America. And we've greenhouse gas requirements coming into play in 2017. So well continue to invest in our engine technology, our engine efficiency, the engines are performing excellently in the North American market and have for obviously 10 years in Europe. So we continue to invest in those areas as well as new systems and enhancements to our manufacturing capabilities.

**Analyst-3**
: And then I'm wondering if you might be able to share with us your book to bill in the quarter in Europe and separately in the U.S. or if not just maybe update us on how long your lead time spanned in the two regions?

**CEO**
: Europe the order intake for this quarter is up about 30% over where it was last year. So we've a good solid backlog for the fourth quarter and the result were increasing the build rates. We've seen the industry orders in North America and that was reduced that window some and as a result we've adjusted build rates in North America accordingly.

**Analyst-3**
: And then lastly, obviously the concern is what the margin performance will look like if we get to the lower end of your outlook for U.S. and Canada next year. But can you just talk about structural differences we should think about in your business this cycle versus last. I guess your gross margins are certainly higher than what most people would have expected in this cycle. Can you just help us understand how we should think about decrementals et cetera if we get to the low-end of your retail sales outlook?

**CEO**
: I think it starts with the engineering of the product, and our engineers with the development of the 2.1 meter cabs, and those products for Peterbilt, and Kenworth and the Euro 6 products did a fantastic job of developing optimal designs with the balance of cost and performance for our customers. The manufacture building is excellent. So were in great position from an operating standpoint and the products are performing very well in the marketplace. So we feel good about structurally our position in our factories. Our suppliers are performing well, and were able to continue to make the 5% to 7% annual enhancement that is sort of our expectation for ongoing operating efficiency and overall operational improvements.

**Operator**
: And your next question will come from the line of Jamie Cook with Credit Suisse.

**Analyst-4**
: A couple of questions, one, the margin performance in the quarter was impressive and in my opinion relative to where the sales came in. So can you talk about what the drivers were behind that? Was there any material cost benefit? What was the FX, how did FX impact the operating margin? And then I guess just my second question I know you said you are optimistic about 2016 based on what your large fleets customers are telling you. At the same time for the broader industry cancellations have picked up over the past three quarters relative to what you had see on a normalized basis. So have you seen anything like that is that part of the reason why you're taking your fourth quarter production down and is it just a function of people shifting delivery of trucks from the fourth quarter to 2016 or is it just orders going away at this point but you're confident that the customers will come back? Thanks.

**CEO**
: Okay, Im just going to try and tackle all that; so the first part about margins Jamie was really a benefits of a lot of different areas. Obviously as I mentioned it starts with great product and pricing has been solid for us in the third quarter compared to where weve been. So products continue to earn a premium in the marketplace, we are benefitting from somewhat lower material cost and commodity costs, were seeing the benefits of operating efficiencies in our factories and the products are performing excellently in the marketplace and all those really come together to sort of generate the overall margin performance. In terms of cancellations, cancellations for us have just been very normal, I mean nothing to speak of thats different than what we would normally expect. And in terms of timing of deliveries obviously there was a large order intake in the fourth quarter of last year, first quarter of this year and now orders are being placed for 2016 and so I think there is a bit of a low in the build as we see it currently, but the prospects for 2016 are excellent.

**Analyst-4**
: And I am sorry, can you quantify the material cost benefit that you got in the quarter?

**CEO**
: I dont have those particular numbers Jamie, but it was a 10th or 2 of margin percent, I think.

**Analyst-4**
: And what got you the FX as well?

**CEO**
: So the FX we continue to benefit the resource are fair amount of our engine components that for North American build come from Europe and so we benefitted from that during the course of the quarter.

**Analyst-4**
: But you wont quantify the amount?

**CEO**
: I dont have that in front of me.

**Operator**
: Your next question will come from the line of Andy Casey with Wells Fargo Securities.

**Analyst-5**
: Ron I just wanted to go back to your comments about U.S., Canada truck 2016 order placement looking like its good, does that suggest despite the production commentary that you gave earlier that we should kind of expect the positive change in order trends for the last three months of the year?

**CEO**
: I would say that would be the case, I mean orders for the third quarter are at a 17,000-18,000 a month, I think youll see an increase in that. As I know certainly that the Peterbilt and Kenworth number should increase from what they saw in the third quarter.

**Analyst-5**
: And then if we can go back to the question on the margin because clearly you're going to be -- you're anticipating mixed market conditions, next year you had a really good margin performance in third quarter within that though you had the aftermarket parts margin of 240 basis points year-on-year and it's remained above 18% for the really third consecutive quarter. What change is really driving that performance, is it structural or is it just pricing material like you kind of intimated?

**CEO**
: No I think it's more structural, obviously we just as we mentioned celebrated the production of our 100,000 MX engine in our Columbus engine factory. And so the population of MX engines continues to grow and were seeing an increased percentage of MX engine part sales and other engine part sales in the market and that is beneficial. And our team has done a great job of putting together some really innovative programs and offerings and leveraging their cost structure for their parts warehouse. So it's a combination of a lot of different elements, but Id say that the increase in proprietary parts is a key part of it.

**Analyst-5**
: And then last question it looks like you are projecting capital investments to go up in 16 versus 15 is that driven by the projects that you talked about in your monologue or are there...?

**CEO**
: It is, it is so the -- weve got the cab paint shop in Westerlo, weve got some other plant projects at Chillicothe and in Denton weve got the product projects with trucks and engines and then weve got continuing to enhance our systems to be able to continue to move our business forward, so all those elements contribute to that.

**Operator**
: Your next question comes from the line of Ross Gilardi with Bank of America/Merrill Lynch.

**Analyst-6**
: Yes just a couple of questions, just back on the Europe topic, clearly youve seen a lot of strength in Europe year-to-date. But you're forecasting a pretty significant deceleration in 2016 and I am just wondering does that reflect what you are seeing in your order book now or is that just conservatism?

**CEO**
: If you look at that range of market that would be certainly the best market since 2008 and a top five market probably in the history of the European market, so it's quite a good market and we have expectations of 1.5% growth on the continent to continue strong growth in the U.K. We feel like that is our best estimate at this point well know more every time we report as we progress in the next year we will have better insight but we feel good about the European market and what it -- what the prospects are for next year.

**Analyst-6**
: And then I am just wondering if you have seen anything in Europe, any type of change in order momentum or customer discussion in the aftermath of what's happened with VW in the auto space, and has that impacted really any of the just sort of the cadence of what's going on in Europe, and has it opened up any type of market share opportunity for you over the next 12 months?

**CEO**
: I would say thats been a nonevent from our market and our business perspective, it's a certainly related to the automotive but no effect on our business.

**Analyst-6**
: And then I just want to make sure I understood on your comments before on your approach as North America when you talked about 35% production changes, were those year-on-year or sequential comments?

**CEO**
: Sequential, sequential.

**Analyst-6**
: For both Europe and for North America...

**CEO**
: Yes.

**Analyst-6**
: So Europe up 35, North America down 35?

**CEO**
: Yes.

**Operator**
: And your next question will come from the line of Steve Volkmann with Jefferies.

**Analyst-7**
: I am wondering if maybe I can push you a little bit on some other of the drivers for 2016 just to kindly get your thinking direction?

**CEO**
: Sure.

**Analyst-7**
: Directionally I know you have put a lot of effort into bringing your parts distribution and all that is there any reason that parts business would not be up again next year?

**CEO**
: Yes I think it's a lot of it is economic driven it is the amount of freight tonnage, as I mentioned in my comments, freight tonnage in North America is strong, near record levels and the same is the case in Europe, we monitor the mouth statistics and other freight metrics in Europe and those are really almost also at near record levels. So as long as the freight movement is there, there is going to be a need to service and support the truck in keeping the uptime going, so we think with our innovative practices some of the things that our team does with other the fleet services program, some of the online programs that we can continue to grow our share of that aftermarket parts business as we progress through 2016.

**Analyst-7**
: And then I dont know maybe similar comments on finance you are also I think penetrating a little more in that market?

**CEO**
: As is typical during a cycle when things get really good there is a lot more lenders that come into the market and think that they are going to be able to take advantage of that so we are in that particular phase and so we continue to focus on what we do very well, we have a great customer support mechanism, we are focused on serving the commercial vehicle business and our guys do a great job and we will continue to be in that 25% to 30% share of the finance market as we go forward.

**Analyst-7**
: And then just finally on the MX engine I assume you would be expecting to sell more of those next year as a percentage total and maybe any thoughts on what types of volume the MX-11 might be able to drive?

**CEO**
: The MX-11 is not as prevalent in engine in the market as the MX as a 13 litre engine is but now we have our own engine that we can offer in that range and so that will add several percentage points to our PACCAR engine penetration as we get into the next year so I think in the near-term wed expect 40% to 50% of our engines to be PACCAR engines.

**Operator**
: And your next question will come from the line of Patrick Nolan with Deutsche Bank.

**Analyst-8**
: Just a couple of follow-up questions, first on North American pricing in previous cycles as volumes started to come off from the peak, we saw pricing start to get weaker, what are your expectations for that as we go next year as the market starts to move more towards a trend a kind of demand level over the next couple of years?

**CEO**
: I think we are very comfortable with pricing being comparable to current levels, we are competitive in a marketplace, we got a great product and our products realize a fair price in the market and so I dont see any significant price movement in the near-term at all.

**Analyst-8**
: And if I could just go back to the margin question again maybe ask it a different way. So if next year Europe will be up a bit thats more vertically integrated market so in theory the incrementals are better on that volume growth? And North America based on your guidance will be off a bit and then there is some cost savings on the gross margin line. Do you think that measures up to kind of a flattish gross margin next year? Or do you think gross margin would be down slightly if revenue declines a bit?

**CEO**
: I would say it will track volume a little bit, but I would say it would be flattish margin achievement next year compared to this year.

**Analyst-8**
: And if I could just sneak one more in, what's your preliminary view on taxes next year as Europe becomes a bigger portion of the earnings?

**CEO**
: Michael you want to?

**Other**
: Yes we still expect the overall tax rate to be around 31%-32% depending on the extra earnings and other factors.

**Operator**
: And your next question will come from the line of Seth Weber with RBC Capital Markets.

**Analyst-9**
: Most of the questions have asked already, but can you just comment on what you're feeling about dealer inventories. We've been hearing some chatter about inventories across the industry, maybe getting a little bit elevated, are you seeing that? Or have you heard anything to that effect?

**CEO**
: No, not at all, our dealers are typically PACCAR dealers have sort of the low industry average inventory levels and were in that position currently and dealers are in great shape. So feel good about where were at.

**Analyst-9**
: And then just sorry going back to Europe again, I mean how much of the strength do you think is being driven by replacement demand versus I mean you mentioned the German the freight volumes want to -- is it, macro is getting better or is it just the age of the fleet is all then you haven't seen a cycle there. Do you have an opinion to that?

**CEO**
: I think it's a combination of both of those. Just like we saw in North America, there is a combination of some pent up demand as well as some capacity growth.

**Operator**
: And your next question will come from the line of Neil Frohnapple with Longbow Research.

**Analyst-10**
: Could you just talk about used truck price in the North America? What are you seeing in the market we've heard some signs of deterioration in the last 30-60 days? Are you guys seeing anything something similar and just any color you can add there and how that will potentially impact the new truck sale side?

**CEO**
: Yes I don't see used truck pricing having a significant effect on the new truck sales levels. I would say as the third quarter pricing was comparable to what it was a year-ago but you're coming into a period now where there is going to be more trucks in the market and well see how that will develop as we progress in the coming quarters.

**Analyst-10**
: And then do you have an updated industry outlook for heavy duty industry registrations in the South American market. I think previously you have mentioned 70,000 to 80,000 for 2015 and just any initial thoughts on 2016?

**CEO**
: I'll let Bob talk to that.

**CFO**
: We think that 70 to 80 is a good measure for the balance of this year, and well probably experience a similar level of demand in 2016.

**Analyst-10**
: And then just one final housekeeping question. Of the 24,200 units in U.S. and Canada, do you have a specific breakdown by region in the quarter?

**CEO**
: Between U.S. and Canada?

**Analyst-10**
: Correct.

**CEO**
: I don't.

**Operator**
: And your next question will come from the line of Joe Vruwink with Robert W. Baird.

**Analyst-11**
: I wanted to go back to the earlier comment on what large fleets have been saying because I think other than Swift actually all that have made 2016 comment have actually said that they're continue to grow their fleets next year in addition to normal and some have even said accelerated replacement to get the average age down. So with that dynamic and then looking at your forecast for next year to get the retail sales decline in the industry, is the bridge between those two things? Maybe just a deceleration in fleet growth, so 15 was a very healthy year of expansion, next year is going to be good but just not as 15's level?

**CEO**
: I think thats a fair way to think about it. I think that is a -- because again our discussions have been that people are going to invest about what they've invested in 2015. So I think just the pace of maybe how they go about that maybe a little bit more even keeled because of the extraordinary higher order intake in the fourth quarter of 14 and the first quarter of 15.

**Analyst-11**
: And then just based on your prior cycle experiences, it would seem to be unusual to have that sort of commentary from the large fleet, even though they are a small piece of the industry directionally they're helpful to get those comments and then expecting there has been whispers that volumes are down 15%-20% next year that just seems to two great of a disconnect. Would you generally agree with that view?

**CEO**
: Our thoughts are as long as the economy is in that 2% to 3% growth and there is continued strong housing and automotive activity and consumer spending is up 3% or 4% year-on-year, I think the fundamentals of the economy and therefore the effects on the our business I think are all good. So I would agree that 15% to 20% is probably overly pessimistic.

**Operator**
: And your next question will come from the line of Alex Potter withPiper Jaffray.

**Analyst-12**
: I was wondering if you can comment I guess just give an update on Brazil obviously, macro down there it seems like things are pretty much coming apart of the themes but less of the material issue for you guys since you're growing off a non-existent base. But I guess just maybe an update on how volumes are ramping down there I guess dealer development and then maybe South America more broadly speaking as well?

**CEO**
: Yes I feel very good about the progression our team has made, our team is very solid, we just recognized as having one of the top truck models in the marketplace and yes the market is difficult market, but our team is growing and establishing the footprint and doing all the things necessary to position us for long-term growth in that market. Bob do you have other things to add?

**CFO**
: Were continuing to add dealers even in a very difficult market. They are continuing to invest in their footprint. We will be introducing some new truck models at the large South American truck filled FENATRAN next month. Our production volume is small, but it is growing slightly and the fundamentals in Brazil are difficult right now, but the long-term fundamentals for trucking are very good.

**Analyst-12**
: And then I guess one question on the truck cycle in North America then Ill pass it on. Shifting specifically to medium duty there has been some commentary regarding I guess sustained power of the medium duty market maybe not getting whipped around as much as the heavy duty market. Would you say that thats generally consistent with the way you guys are viewing things looking into 2016?

**CEO**
: Yes, I think that traditionally has been the case and I think thats how we think about as we go forward that the ups and downs of that market typically are a little more muted than the heavy duty segment.

**Operator**
: The next question will come from the line of Robert Wertheimer with Barclays.

**Analyst-13**
: A quick question for you I mean you gave some detail on 11 liter which seems to be very successful in Europe. Do you happen to have the current mix has it reached its natural level in Europe or is it still growing and the potential for the U.S. is a follow through?

**CEO**
: Yes so I think it hasnt reached the total potential in Europe I think there as time goes on and greenhouse gas requirements and fuel efficiency expectations increase. Well see more and more downsizing the MX 11 has capability to go up to 430 horsepower and 1,550 foot pounds of torque. So it's a very capable engine, the customers that are using it in Europe are very satisfied with the capabilities and I think we will continue to see a migration to a higher percentage. And it's about 25%-30% of DAFs build at this point. And well ramp that up in North America as we go and I think as more customers experience its capability. Youll see just like weve seen with the MX 13, well see a progression of more and more customers taking that engine on so.

**Analyst-13**
: Perfect, is that solely on sale in 1Q or is it going to be a staged ramp?

**CEO**
: No it will be a ramp-up during the course of next year.

**Analyst-13**
: And then if I can ask one more, in Europe could you speak to your share, your share gains is that geographic more or is it gaining penetration in truck versus tractor you think for a long time or is it maybe if you could give us any color on that? Thanks.

**CEO**
: Yes I think it's really across almost all the markets 2014 was impacted by the Euro 5 pre-buy which was really across most of the geographies and so weve seen a recovery this year across all they almost were up about one percentage point across the breadth of Europe and weve seen similar progression in most countries.

**Operator**
: And the next question will come from the line of Joe O'Dea with Vertical Research.

**Analyst-14**
: First it looks like you did take build down in September in Class 8 for U.S. and Canada. So just whether or not that fully now reflects your expectation for what both build rate should be at into the end of the year or if there is a little bit more work to do on taking build lower?

**CEO**
: No, I think weve adjusted build rates to where we think they need to be and we would anticipate based on where were at today that that will be how well start next year.

**Analyst-14**
: And then also on North America and within location youve previously talked about having very strong share within that market, the order trends within Class 8 straight have been softer recently and so if you could just talk to whether or not that has affected some of the applications that you go into or a few more protected from it and then your kind of outlook for how that should trend moving forward if we get some relief from some of that softness?

**CEO**
: Some of that order trend that you refer to is seasonality. We have two new models one on the Kenworth side and one on the Peterbilt side that are doing very well, the 567 and the T880 and we would anticipate that we would have another strong construction season upcoming.

**Operator**
: And your next question will come from the line of Ted Grace with Susquehanna.

**Analyst-15**
: I was hoping to dig into the parts business a little more and follow-up on some Steve's questions, could you walk through regionally how that business performed and also give us a sense for what the impact of FX was in the quarter?

**CEO**
: So the in the terms of the performance regionally both North America and Europe participated in about 7% to 8% growth year-on-year for the year-to-date period so they both have done very well with their programs to get a greater share of the market and take advantage of the strong freight market, so Ill let Michael talk to the exchange rate effects.

**Other**
: The impact on parts revenues for the quarter was $50 million and for the year-to-date figures $155 million it has been running about that $50 million pace during...

**Analyst-15**
: Any impact on profits?

**CEO**
: The impact on profit for the quarter was pretax income impact was about $10 million.

**Analyst-15**
: Okay can you remind us what is year-to-date?

**CEO**
: And year-to-date would be about $30 million.

**Analyst-15**
: Okay.

**CEO**
: And about a 10 million a quarter pace. That will diminish of course as we enter into different comparatives going into '16 with exchange rates have been relatively stable at these low levels for the past few months.

**Analyst-15**
: And I think as we just think about the growth, I know you said it has been pretty even between North America and Europe, can you talk about it and largely on economic and freight volume driven but can you talk about how we should think about maybe the underlying growth versus some of the company specific initiatives to take share whether thats more store growth or the DC initiatives, et cetera just so we get a sense for what the underlying because obviously freight volumes are growing at high single-digits so just trying to understand that dynamic?

**CEO**
: Lot of facet to that obviously, first of all we continue to invest in new distribution capability or expanded distribution capability we have built the new warehouse in Eindhoven and we recently expanded our racking capability in our Budapest warehouse, we doubled the size of our Lancaster warehouse, were essentially doubling the capacity in the Pacific North West here with the new PDC and renting, so we are continually investing to provide that best-in-class service for our dealers and customers. One of the things that we have done and we talk about it in the press release is we have opened TRP stores -- TRP standalone stores to really support the TRP brand and gain greater access to the second and third owner to the all mix trucks as well as the buses, trailers et cetera. And then our dealers have added lots of locations in North America and Europe to increase the penetration and the presence of their businesses and we are seeing the benefit of that as well, so it's -- and then you add on the additional initiatives the programs that our parts team have put together all those things together are supporting that 8% growth.

**Analyst-15**
: And then the last thing if I could just sneak it in a follow up to question Jamie had about pricing I know you made the comment that pricing overall was solid, could you actually speak to pricing in the U.S. versus Europe and are you seeing any signs or isolated pockets of pricing weakness in Europe?

**CEO**
: No, pricing in both markets I say is very solid. With again the markets as we see them currently are top five markets and our products are performing well they have got a lot to offer a customer in terms of efficiency and low operating cost and so we are seeing good solid pricing with our products.

**Analyst-15**
: Okay, I am thinking more from the standpoint of competitors, from select competitors than from progressive?

**CEO**
: I guess it's typical business I mean we have business that we think is very important to us and another OEMs have business they think it's important to them and so thats just normal I would say it's all normal marketplace behaviour that we see in both North America and Europe.

**Operator**
: [Operator Instructions] Your next question will come from the line of Mike Shlisky with Seaport Global Securities.

**Analyst-16**
: So I wanted to touch back on your Class 5 to 7 share during the quarter, looked pretty solid, I kind of wonder if you can give us kind of color as to perhaps were there any kind of products in the end-market that did better than others in the quarter or any initiatives that you guys took in the quarter to kind of gain some additional share there?

**CEO**
: No nothing I think as time goes on more and more our dealers appreciate what that product can do for their customers. And we continue to see those products perform very well and they just continue to get a growing share of that Class 5 to 7 market.

**Analyst-16**
: And then secondly I also just want to ask about the upcoming new paint facility over in Europe, is paint currently a pinch point for production or for margins, and can we expect the opening of the facility to perhaps unlock some kind of volume upside either in '16 or possibly in '17?

**CEO**
: As we look out for DAFs growth expectations. We've talked before about medium-term targeting a 20% share of the European market and we need more capacity in our paint operations in addition to giving us the capacity obviously it will be state-of-the-art very environmentally friendly and really provide some good efficiencies and qualitative performance that well enjoy for years to come.

**Operator**
: Our next question will come from the line of Ann Duignan with JPMorgan.

**Analyst-17**
: I think most of my questions have been answered by now, but I just want to circle back couple of things. The MX 11 engine that will replace or compete with your current medium-duty engine which if I recall correctly is built by Cummins is that correct?

**CEO**
: Yes, it will compete with Cummins offering. I mean we will basically just replace the offering from Cummins.

**Analyst-17**
: Yes I just wanted to make sure that because I think Cummins builds it for you but you brand it, don't you?

**CEO**
: Well we have a 9 litre that we buy from them that is branded, and well continue to buy that 9 litre. But we also buy some 11-12 litre engines from them that this would essentially replace.

**Analyst-17**
: And then if we look at orders over the last three months, Canada and export orders have been down significantly, Canada down more than 50% export orders down 70% plus. Can you talk about those markets as you head into 2016 and how divergent those might be versus your outlook for the U.S.?

**CEO**
: I think the Canadian order levels have been impacted obviously more by oil and gas, I think than what we've seen elsewhere, so obviously lower oil and gas prices are very positive for almost all of our customers but there are some regions that get impacted by the lower oil and gas prices and so Canada is one of those areas that have seen that but the rest of the Canadian operations and fleet activities that is very good. Export I would say that those markets are down compared to where they have been and Bob talked about some of the South American markets 70,000 to 80,000 probably more normal range would be 100,000 trucks or so per year.

**Analyst-17**
: And you have baked those two markets into your outlook that you have given us today. I mean you're not expecting those to get any better or?

**CEO**
: No, they are just part of the, it is very similar yes.

**Operator**
: At this time there are no further questions. I'll turn the conference call back over to Mr. Hastings for closing remarks.

**CTO**
: Thank you. I would like to thank everyone for their excellent questions. And thank you operator.

**Operator**
: Once again we'd like to thank you for your participation on today's conference call. You may now disconnect.