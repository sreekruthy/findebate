## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCARs Second Quarter 2015 Earnings Conference Call. All lines will be in a listen-only mode until the question-and-answer session. Todays call is being recorded. And if anyone has any objection, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCARs Director of Investor Relations. Mr. Hastings, please go ahead.

**CTO**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCARs Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer; and Michael Barkley, Vice President, Controller. As with prior conference calls, if there are members of the media on the line, we ask that they participate in a listen-only mode. Certain information presented today will be forward-looking and involve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

### Q&A
**CEO**
: Good morning. PACCARreported record quarterly net income of $447 million for the second quarter of 2015. Net income increased 40% compared to the results generated in the second quarter last year. PACCARs second quarter sales and financial services revenues were $5.1 billion. Gross margins for truck, parts and other operations were strongat 15.1%. The excellent margins coupled with the companys rigorous cost control generated 8.8% after tax return on revenues. Im very proud of our 24,500 employees who have delivered industry-leading products and services to our customers worldwide. PACCAR delivered 41,600 trucks during the second quarter, an 8% increase versus the first quarter this year and slightly ahead of our expectations. The improvement reflects increased truck deliveries in North America and Europe due to economic growth and strong freight demand. Looking ahead, we expect PACCARs global truck deliveries in the third quarter to be slightly lower compared to the second quarter, reflecting the normal summer factory shutdown for DAF and Leyland. Third quarter gross margins for truck segment will be impacted by a higher percentage of deliveries to large fleets and the summer shutdown in Europe. The European economic and truck market outlook continues to improve. GDP growth expectations for this year are 2.4% in the UK, which is PACCARs strongest market in the region, with 1.5% GDP growth on the continent. Freight transport activity on German highways is up 2.6% year-to-date through June compared to the same period last year and its at the highest level since the German toll system was launched in 2007. DAF heavy truck order intake for the second quarter was 60% higher than a year ago. Weve raised our forecast for Europes greater than 16 ton market to a range of 240,000 to 260,000 units, reflecting the strength in orders and the improved economic outlook. DAFs heavy truck market share is 15% year-to-date. The US economic picture remains positive with GDP forecast to grow 2.4% this year. The housing and automotive industries are bright spots in the economy and create a large amount of freight. Housing starts are projected to grow 11% this year to 1.1 million and the automotive industry is expected to deliver 16.9 million vehicles, near the record level of 17.3 million set in the year 2000. US freight tonnage is at near record levels. Weve raised our US and Canadian Class 8 truck industry retail sales estimate to a range of 270,000 to 290,000 units this year. The stronger market reflects expansion in industrial fleet capacity due to continued strong freight fundamentals. Peterbilt and Kenworths combined share of the US and Canadian market is 28% year-to-date. PACCARs parts business generated record quarterly pre-tax profits of $146 million, a 15% increase compared to $127 million in the same quarter of last year. The strong results were driven by economic growth in the US and Europe and the many innovative products and services offered by PACCAR parts and our dealers. PACCAR parts revenue was $777 million compared to $778 million achieved in the second quarter of 2014. Excluding the effects of foreign currency translations, parts revenue would have been up 7% for the second quarter and first six months of this year. PACCAR Financial Services second quarter pre-tax income was $91 million compared to $92 million earned a year ago. Foreign currency translation reduced profit by $4 million for the quarter. The portfolio continues to grow and perform well. PACCARs strong balance sheet and positive cash flow have enabled the company to invest $5.9 billion in new products and facilities in the last 10 years. Our outstanding results this year reflect the quality of those investments. Looking forward, PACCAR is well positioned for future growth, with further investments in geographic expansion, aftermarket parts and service capabilities and powertrain and truck technologies that increase fuel efficiency, safety and reliability. This year, PACCARs capital spending of $325 million to $375 million is targeted at enhanced powertrain development and increased operating efficiency of our assembly and distribution facilities. Research and development expenses are estimated to be in the range of $225 million to $250 million. PACCARs technology leadership has been enhanced as Kenworth TruckTech+ and Peterbilt SmartLinq remote diagnostic systems are now in production on new Kenworth and Peterbilt Class 8 trucks specified with the PACCAR MX-13 engine. DAF plans to launch its connected truck technology in the fourth quarter of this year. In addition, PACCAR parts has begun construction of a new 176,000 square foot distribution center in Renton, Washington. We expect this distribution center to open in mid-2016. DAFs cab factory in Westerlo, Belgium plans to begin construction of a new cab paint facility this year. This environmentally friendly paint facility will increase DAFs production capacity and utilize the latest robotic technology to improve operating efficiency. PACCARs Board of Directors approved a 9% increase in the regular quarterly dividend to $0.24 per share at its July meeting. The company has increased the regular quarterly dividend by more than 165% in the last six years. PACCAR continues to enhance its leadership position in the global truck market by developing the highest quality products and services in the industry and providing excellent returns to its shareholders. Thank you. And Id be pleased to answer your questions.

**Operator**
: [Operator Instructions] The first question comes from the line of Ann Duignan with JPMorgan.

**Analyst-1**
: I guess I was interested in  you talked about the investments in powertrain capabilities going forward, can you just give us a little bit more detail on what specifically youre investing in?

**CEO**
: Its all about operating efficiency and being the leader in providing that to our customers to reduce their operating cost. So thats a continual stream of investment in research and development as well as capital to support those initiatives. Weve got greenhouse gas requirements coming into play in 2017 and additional requirements beyond that. And so well just continue to make those investments to support our customers.

**Analyst-1**
: And then on European outlook, can you talk about your revised outlook versus the very strong registrations weve been seeing year to date particularly in June?

**CEO**
: Well, our revised outlook reflects those, strength in those registrations as well as the strength of the DAF order intake. So we see that there could be some further upside potential as the year progresses. But as we see it now, we see it at that 10% improvement is certainly achievable and so there could be some upside.

**Analyst-1**
: And where specifically do you think the upside could come from? Is it Germany, UK or some of the weaker southern countries that are just coming from zero basically?

**CEO**
: I think weve seen general improvement across all the markets, some a little bit more than others, but general improvement across all.

**Operator**
: Our next question comes from the line of Jerry Revich with Goldman Sachs.

**Analyst-2**
: Ron, Im wondering if you could just bridge the margin performance for us in the quarter either year over year or sequentially at the gross margin line. Any specific or significant items that you highlight pricing versus cost, any other factors that you can just maybe help us understand pretty significant expansion on both year over year and sequentially?

**CEO**
: As you know, weve always maintained a healthy discipline of rigorous cost control and we continue to do that. So I think the operating leverage is the single biggest factor that weve seen contribute to our margin performance over the last 12 months and quarter over quarter. So other positive things include some positive effects of materials and pricing, but those are muted compared to the operating leverage.

**Analyst-2**
: And then for the parts business, the 7% organic growth in the quarter, can you flush out for us whether Europe was above or below that? And any color that you can give us from a mix standpoint, I think this is the second or third quarter in a row in which parts mix was favorable to you folks, can you just talk about whats driving that?

**CEO**
: The parts team has done a great job of continuing to build its programs and its expanding its all mixed products capability for both trucks, trailers, buses, et cetera. And so we continue to see nice growth in that business. And we just really saw it spread pretty evenly across all of our geographies, both North America, Europe and around the world.

**Analyst-2**
: And lastly, in Europe, can you tell us what the book to bill was in the quarter or how much lead times lengthened as a result of the orders, just put the 60% order growth into context relative to production in the second quarter, if you dont mind?

**CEO**
: Again, we dont think in those terms generally, but the backlog is very healthy and supports our expected plans to increase our build rate during the second half of this year.

**Operator**
: The next question comes from the line of Joe ODea with Vertical Research.

**Joe O’Dea**
: The first question maybe more specifically on the margin in looking at the truck segment, because that seemed to be the strongest performer between truck and parts, and a very strong sequential incremental margin there. And so understandably some leverage benefit, but also I think you did talk a little bit about maybe some customer mix that was a benefit. Anything else in the quarter? And then how we should think about the back half of the year margin in the truck segment, whether 2Q is a good benchmark or some of the shifts that might happen to bring that down?

**CEO**
: As I mentioned in my comments, we expect that the third quarter will be impacted by little heavier fleet mix in the third quarter as well is normal factory shutdown that we have in Europe. So some leverage effects related to that.

**Joe O’Dea**
: But other than that, nothing else specifically in the quarter to get 10.5% margin?

**CEO**
: Nothing unusual in the second quarter and we dont have any expectations for any unusual items in the third quarter.

**Joe O’Dea**
: And then in North America, on sort of vocational demand, any sort of weakening that youve seen in those markets related to oil and also just with respect to your backlog, did you see any higher activity in terms of cancellations in the quarter?

**CEO**
: No. Cancellations have been at a very low rate and vocational trucks are very active, lots of reasonable growth in housing construction, commercial construction. So its all been pretty steady.

**Operator**
: The next question comes from the line of Patrick Nolan with Deutsche Bank.

**Analyst-4**
: Two questions. The first, can you just discuss where youre seeing some of the pricing dynamics both in North America and Europe?

**CEO**
: I think pricing is reasonably consistent. We have great products, the Peterbilt, Kenworth and DAF teams have pretty much have new product lines that are in the field over the last one to two years and those have been very well received. We continue to invest in fuel efficiency of our engines, the aerodynamics of our vehicles, and all those elements are very well received by our customers. Good value. So continue to achieve our premium pricing for our products. And the outlook is bright as we continue for the rest of this year and into next.

**Analyst-4**
: Second question, very strong margin performance in the quarter, but some of your suppliers have actually said running at this pace of production for the industry inherently some inefficiencies that go along with that, do you see that? I mean, when you think about next years volume outlook, even volumes off a little bit, the margin still go up in North America or is this kind of really good operating environment in your opinion?

**CEO**
: I think its a really good operating environment. I think were in a good position right now and obviously our teams in our factories do a great job of managing to the conditions in the marketplace and we expect that that will continue as we move forward of course this year and next.

**CFO**
: I would just add that the rate of increase in production over the last several quarters has been relatively modest and that has allowed the suppliers to lay in capacity and efficiency improvements in an orderly way and they are performing very well.

**Analyst-4**
: Can I just sneak in one more, what percent of your Class 8 volume was the internal PACCAR engine?

**CEO**
: Its about 40%.

**Operator**
: Our next question comes from the line of Steven Fisher with UBS.

**Analyst-5**
: Im wondering about your visibility into 2016 at this point, how much of the 60% growth in orders in Europe would extend into 2016? And to what extent do you have North American orders for 2016 yet?

**CEO**
: Id say most of the orders for DAF are 2015 build, some 2016 orders, but not a significant amount. And I would say that the build in North America, just a good, a few long term fleet orders that are in the backlog, but not a substantial percentage of 2016 expectations.

**Analyst-5**
: And would that be about typical with where youd expect to be for...

**CEO**
: Yeah, right where we expect to be, a lot of discussions are going on right now with customers about their plans for 2016 and indications are that purchase expectations will be very similar to what weve experienced in 2015.

**Analyst-5**
: And then very solid $600 million of free cash flow in the first half of the year. How do you see that shaping up in the second half? I mean, it looks like your CapEx is scheduled to pick up by maybe a couple of hundred million, but how about on the operating cash flow side?

**CEO**
: I think the operating cash flow will be very consistent from what weve seen in the first half. As you mentioned, the pace of investment in some of the capital projects will likely accelerate and well continue to invest in R&D.

**Operator**
: The next question comes from the line of Nicole DeBlase with Morgan Stanley.

**Analyst-6**
: So Ron, I guess my question is around the 3Q guidance that you gave. Can you give a little bit more on an order of magnitude, I know its normal seasonality to see production dip down in the third quarter as well as gross margins, but can you characterize that at all versus what we saw in 2Q?

**CEO**
: Yeah, I think as I mentioned, just the fact that we typically have a summer shutdown period in Europe and thats two full weeks and two partial weeks, which impacts the level of production. And so, thats just normal business. From a margin perspective, as I mentioned, you do have some operating leverage effects of that and the mix of customers is a little bit more tilted towards the fleet side during the third quarter than what we saw in the second quarter.

**Analyst-6**
: And any change to the full year, I think you guys previously were saying about gross margins about in line with what you reported during 1Q, which would then embed like 100 bps of gross margin expansion?

**CEO**
: I think given the performance in the second quarter, itd probably be up a bit from that.

**Operator**
: The next question is from Seth Weber with RBC Capital Management.

**Analyst-7**
: So going back to the customer mix, I mean, with the fleets, do you expect that to revert back in the fourth quarter to more or like what we saw in the second quarter? Im just trying to understand if this is a seasonal hiccup that you usually see or if there is something structurally thats changing here.

**CEO**
: No, its just normal month to month, quarter to quarter change in who were building trucks for. Nothing more than that.

**Analyst-7**
: So the order book reflects that it would shift back the other way?

**CEO**
: Its just pretty normal.

**Analyst-7**
: If I could clarify something, there was the $4 million currency benefit that you talked to in the prepared remarks. Is that on the finco or was that total company contribution to profit?

**CEO**
: That was on the financial services, it was a reduction of financial services profit for the second quarter versus the second quarter last year.

**Analyst-7**
: And is there a number for how much currency affected the manufacturing business in the quarter for profitability?

**CEO**
: Yes. Lets get our hands on that. Youre looking for the quarter?

**Analyst-7**
: Right.

**CEO**
: For the quarter, for the truck and other, it was $12 million of pretax profit negative impact. That was largely offset by a favorable cost on the engine content side from our engines fleet built in our Columbus, Mississippi. And on the parts side, its about $12 million pretax profit impact.

**Analyst-7**
: So in aggregate about $24 million total?

**CEO**
: Yeah. And then the $4 million from financial services, so in aggregate about $28 million.

**Analyst-7**
: And then if I could just sneak one last one, the SG&A continues to be lower than what weve been expecting, is this a sustainable level do you feel like?

**CEO**
: SG&A has also been benefiting from the impact of currency, a lot of our SG&A is outside the US and so weve had some currency benefit. But the level that youre seeing is sustainable at these currency levels.

**Operator**
: And our next question comes from the line of Andy Casey with Wells Fargo.

**Analyst-8**
: Could you help us a little bit more with the Q3 comment around production, are you basically expecting US, Canada build to be reasonably constant and then everywhere else basically to be down?

**CEO**
: Its all reasonably constant. I think were talking about a 1% to 2% reduction in total truck production for the quarter. So its going to be pretty comparable.

**Analyst-8**
: And then the EBIT margin improvement in parts has been strong year over year for a couple quarters now. Are we beginning to see the improvement related to the increased proprietary engine content that you introduced a few years ago start to run through the parts line or is it just fundamentally the mix that you talked about?

**CEO**
: I think there is definitely some benefit from higher increased engine parts sales. Were up about 90,000 MX engines in the field in North America and hundreds of thousands of engines in the field in Europe. And so that population continues to grow, so we see the benefit of that. And PACCAR parts has done a nice job of developing PACCAR brands and transitioning more and more of the parts sales to PACCAR branded components. So I think the execution by our parts team has been excellent.

**CFO**
: Id add that there continues to be excellent leverage in the parts business from our distribution centers globally and were benefitting from lower freight rates due to fuel prices.

**Operator**
: The next question comes from the line of David Leiker with Robert W. Baird.

**Analyst-9**
: Where are you tracking right now in North America and Europe in your truck plants for capacity utilization?

**CEO**
: We have lots of capacity available in most of our factories to be able to produce trucks to meet customer demand. So its not a concern for us.

**Analyst-9**
: And then theres a lot of discussion about where we are in the cycle and Id say were in an elongated cycle here where economic growth continues to muddle along like we are and demand for trucks stays where it is. In that environment, what kind of ability do you think you have to push margins higher given a relatively constant level of high demand?

**CEO**
: Operating leverage is a very positive thing and so to the extent that we can further take advantage of that, theres some upside. But if you took competitive market and we have great products to provide to our customers and we expect to get good value for what were producing and we expect that to continue overtime. We continue to look for ways to make our plants continuously more efficient and achieve cost reductions to improve our results.

**Operator**
: The next question comes from the line of David Raso with Evercore.

**Analyst-10**
: The stock is not really responding that much to a pretty strong print here so folks are obviously concerned about your ability to grow earnings next year. Can you help us understand a little bit then the moving parts of the incremental margins? Lets strip out currency, if somebody is looking at Europe next year, lets assume they think its up, can you help us understand the incremental margin difference that we can expect to save and what youre seeing right now or just some framework of how to think about if you want to model Europe up, what kind of incrementals can you expect in that region to maybe offset some of the North American decrementals?

**CEO**
: David, we obviously expect to the extent that we can increase production levels, there are some operating leverage benefits that go with that. And if you look at the performance overtime, incremental margins had been 20% plus or minus. And so thats probably more indicative of the longer term trend. And so to the extent that we can get additional volume, I would expect wed see that kind of performance going forward.

**Analyst-10**
: But the question was splitting the geographies, because at least the base case is theyre going opposite directions, right. So if North America is down 10% and Europe is up, you name the number, 15%, 20%, whatever it may be, people are trying to figure out of course North America is larger. But what kind of incremental margins could one expect from Europe given youre more vertically integrated there but obviously pricing is still a bit challenged there. So if you can help us at all differentiating between North America and Europe on incremental margins into next year.

**CEO**
: I think the incremental/decremental is very comparable across the geographies. So theres no significant difference.

**Operator**
: Our next question comes from the line of Ted Grace with Susquehanna.

**Analyst-11**
: First thing, I was just wondering could you just walk through deliveries by region?

**CEO**
: Sure. We actually added a table in our press release at the very end of the schedules.

**Analyst-11**
: I apologize. I missed that.

**CEO**
: Thats okay.

**Analyst-11**
: Second thing I was hoping you might be able to walk through is just in terms of the situation in Europe with the EC, I know you provided an update in the press release saying that youre unable to give an estimate for the impact. And I was just wondering if you could remind us why you cant quantify that? I recognize that there can be different reporting requirements for US versus European companies, but just as a reminder, can you give us the reason why we cant walk through a quantitative framework? And then related basis, would it be fair to assume we could look at the European competitors at least as a framework to think about PACCARs exposure?

**CEO**
: I cant comment on what the competitors have done. Our press release has an update, not any significant developments during the quarter. So thats about all I can say about that.

**Analyst-11**
: And then the last thing if I could just ask, I know you said there were a lot of great things going in the business, I think the numbers speak for themselves, but can you talk about where your biggest concerns are, whats keeping you up at night, anything thats on the horizon that youre very mindful of that you would point to?

**CEO**
: We have a great team that delivers great results as evidenced by the press release. And so I sleep pretty well most nights, I got to tell you. Theres always challenges, always opportunities and so we look forward to seizing those and taking advantage of those as we move forward. So thatll always continue to be our approach.

**Operator**
: The next question is from Ross Gilardi with Bank of America.

**Analyst-12**
: I wanted to understand on the deliveries versus the geographic revenue breakdown, so you had an 8% decline in European sales on a 25% increase in deliveries. I understand whats happened with the euro/dollar, but even if you factor that in, it seems like theres a big gap and Im wondering if you can help bridge that, is that pricing or something with the mix or any help there?

**CEO**
: So the effects of the euro on revenue for the quarter was about $250 million. So you add that back to the equation and part of it is a little bit larger mix of the light duty trucks, the model LF compared to the CF, XF mix during the first half of last year.

**Analyst-12**
: Anything in particular driving that?

**CEO**
: No, just customer demand, all the trucks are great and the LF is particularly popular in the UK and very well received by customers and that market has grown little faster than the rest of Europe, reflecting their economic growth. And so were seeing some benefits from that phenomenon.

**Analyst-12**
: And then back on the parts margin, so youve had two consecutive quarters of 18% to 19%, should we look at this as the newer and higher baseline going forward? And is there any reason why that number actually cant go up if you continue to post 6% to 8% organic growth in the parts business over the next several years like you have in the past?

**CEO**
: I think as Bob said, weve gotten the benefits of operating leverage and that should continue. Obviously, freight rates are dependent lot on diesel prices. And so that will go up or down as diesel prices move. But again, our team has done a good job of transitioning to PACCAR branded components and with our newest designs, we have a higher element of proprietary content. So I think were in good shape and positioned well and shouldnt see significant movements from where were at currently.

**Operator**
: Our next question comes from Mike Shlisky with Global Hunter.

**Analyst-13**
: Wanted to ask you guys about Brazil, it wasnt really mentioned in the press release or in any of your comments. I know its been a really rough market this year, wondering if you can give us your thoughts as to how thats going and whether the DAF volumes there are ramping in line with your expectations.

**CEO**
: So we continue to be a pretty small player in that market. Our team is doing great. The factory is running very well. The quality of the product is excellent and very well received by the customers. Our dealers continue to invest in their facilities to fully represent the DAF brand in the market. The market this year will be down substantially, probably in the 45,000 to 55,000 truck range, South America total probably 70,000 to 80,000 trucks for the year. But we have a great team and a great long term perspective on building our business. And it will be a bigger and bigger contributor to PACCARs results overtime.

**Analyst-13**
: My other question is about the new parts DC thats opening in 2016 in Washington. Is there any chance for any kind of a gross margin impact while theres some kind of a transition or in the opening process there at some point during 2016?

**CEO**
: No, we opened and expand distribution centers on an ongoing basis and its just part of continuing to support that growing parts business and our dealers needs to have same day delivery to meet their needs. So there wont be any margin impact as a result of that transition.

**Operator**
: The next question is from Scott Group with Wolfe Research.

**Analyst-14**
: Just one quick question, the 40% youre doing with your own engines in the US, whats the  any update on the near and long-term target there?

**CEO**
: I think well continue to see that grow, more and more customers a lot of times theyll start with some level if theyre a larger fleet and as they get experience, most will often increase their percentage penetration in our fleet with the MX engine. So we expect that to continue to grow 50%, 60% overtime. The engine has the capability to meet about 80% of our customers needs. So were very excited about the potential for that as we progress over the next three to five years.

**CFO**
: Today, in the North American market, we offer the PACCAR MX 13, beginning next year well also be offering the PACCAR MX 11 engine which was introduced in Europe a couple of years ago with a great success. So well be enhancing the North American engine lineup.

**Analyst-14**
: And is 50% to 60% you think thats a realistic target for next year?

**CEO**
: I think overtime.

**Analyst-14**
: How about on the medium duty side?

**CEO**
: We install PACCAR engines, branded engines purchased from Cummins for our medium duty product.

**Analyst-14**
: I guess the question was, do you think about doing  expanding into the medium duty on the engine side here in North America?

**CEO**
: Its always a possibility, but nothing on the short term horizon for us in that area.

**Operator**
: [Operator Instructions] The next question is from Ted Grace with Susquehanna.

**Analyst-11**
: I just wanted to follow up on the outlook for the MX platform, the 13 specifically. Have you entered into conversations with other OEMs unnamed who might be interested in buying that engine from you over time? Is there an opportunity that you could sell that to competitors?

**CEO**
: Typically it hasnt been our approach. We have a great engine to support our product and we got the capacity to support future growth, but selling to other OEMs is not an avenue that we thought about pursuing.

**Analyst-11**
: Could it be conceivable if it  obviously get you volume and not just pull through but obviously profit margin with that?

**CEO**
: Its possible, but really not part of our thought process at this time.

**CFO**
: We do sell a handful of engines to bus, luxury bus and coach manufacturers, but its really not significant in terms of overall production mix.

**Operator**
: There are no other questions in the queue at this time. Are there any additional remarks from the company?

**CEO**
: I would like to thank everyone for their excellent questions and thank you operator.

**Operator**
: Ladies and gentlemen, this concludes PACCARs earnings call. Thank you for participating. You may now disconnect.