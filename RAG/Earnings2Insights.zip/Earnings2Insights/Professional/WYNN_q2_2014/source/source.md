## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning. My name is Stephanie, and I will be your conference operator today. At this time, I would like to welcome everyone to the Wynn Resorts Second Quarter 2014 Earnings Conference Call. All lines have been placed on mute to prevent any background noise. After the speakers' remarks, there will be a question-and-answer session. (Operator Instructions). Mr. Lewis Fanger, Vice President at Wynn Resorts, you may begin your conference.

**Other**
: Good morning and thank you. Joining the call today are Matt Maddox, Kim Sinatra; Steve Cootey; Maurice Wooden; Scott Peterson here in Las Vegas, and we have Steve Wynn and the Macau operating team dialing in from Macau. With that said, I will turn it over to Matt Maddox.

**Executive-1**
: Good morning or evening for everyone in Asia. Before we get started, I just want to remind everybody that we will be making forward-looking statements under the Safe Harbor of Federal Securities laws, and those statements may or may not come true. SoI am going to go ahead and turn it over to Steve in Macau to get this started.

**CEO**
: As usual, the numbers should speak for themselves. We are very happy with our business this past quarter. I am going to engage in a little different approach in a moment, but with regardto the most important thing in this company, the progress of our construction and our $4 billion Wynn Palace hotel in Cotai, I am happy to say we are on budget, we are proceeding apace on schedule, and we are about 18 months out, and still feeling that we will make Chinese New Year of 2016. The most frequently asked question of all of us, whether in United States or in China, is what about Cotai? What about that Chinese market? Are the vacillations of the economy in China changing anything? How do you feel about your prospects of opening the palace? What about cannibalization? What will happen to the peninsula when you open? The very-very common sense rational questions have come at us, and as we get closer, they become more frequent, and I think that one of the things we can do on a conference call like this today, is to give some really serious guidance on how people who have an interest in this company, who are on this call, analysts, investors, and even our competitors, can address that question and come up with a very predictable and rational answer. In order to do that exercise with you today, I am going to look at the past and at the present, as we try and understand the future, and I have decided to use a mechanism to explain our company and our business plan, by comparing ourselves to what I consider to be the most profitable company in gaming, the sands. There are neighbors in Las Vegas, and then our neighbors here in China. And they are a very-very well run company, we admire them, and enjoy being a neighbor. But as is the case so often in gaming, historically and currently, we have a completely different business plan. What are the words that you hear so often in the press and in this industry is the integrated resorts, and that word has been bounced around enough, that we wanted to find that on our own terms. When we say integrated resorts, a very important word to us, we mean that the entire place is held together, the enterprise, by a notion of who our customers are, and how we are going to appeal to them; and then we make sure that every part of the facility is integrated in that concept, in that idea from the facility itself, and especially to the staffing of that facility, the kind of people we look to hire, and retain as executives and employees, and if we are right, and we have integrated properly, then retail, slot machines, food and beverage, room rates, and most of all profitability, will reflect the truth or the validity of that concept that is at the heart of our enterprise. And as I say, the best way to do that, is to compare ourselves to The Sands, the most profitable company in gaming and with operations all over the world, including Macau and Las Vegas. But The Sands has a different approach than we do, and we are going to define ourselves by giving some comparisons, and these comparisons that we are going to give, of our business plan versus The Sands. I think probably shed more light on what investors and analysts can expect about our company, as we go forward in the next 18 months, and launch Wynn Palace. First of all, in Macau, The Sands has ten times as many rooms as we do. They have -- we have 1,000, they have 10,000. They have multiples of machines, multiples of tables, multiples of square footage of retail being operated, and multiples of restaurants. They are twice the EBITDA of our company, a little better than twice, we are approximately half as profitable in Macau as The Sands, with only 10% of the rooms. I am going to ask my colleagues here to give you some of the data that compares the performance of Wynn to its neighbor, and let's start with retail sales. Robert or Frank, you want to take that?

**CFO-2**
: Tenant sales per square foot at Wynn Macau was 17,000 versus Sands Group at 2,400.

**CEO**
: And we get to take 145% of that as rent. Let's talk about slot machine.

**CFO-1**
: Wynn per unit slot was 105,000 versus their 36,000, close to three times theirs.

**CEO**
: About three times, about the tables?

**CFO-1**
: Tables, Wynn per unit, 2.4 million versus their 1.5 million -- 1.5 times theirs.

**CEO**
: That ratio, they have 150% of the rooms in Las Vegas. That ratio of 3.5, the yield, compare us to them, we are 3.5 times per unit, that is about the same in Las Vegas, where they have 7,100 rooms and we have 4,700. Our run rate for the past six months through June 30 of Las Vegas is a little over $1.5 billion in EBITDA, $501 million, and July has picked up that rate, both here and there. Let's talk about average room in Macau for a moment.

**CFO-2**
: Our average room rate was 334. Theirs was an average of 210.

**CEO**
: 210 versus 334, right. So the reason I mentioned that, is that they make a ton of money. But the approach that we take, each of these companies, is quite different one from the other. We have integrated all of our departments, under the notion that we are after a certain customer, that has an awful lot of discretionary income. We understand that customer both in America and in China and everything we do here with our staffing and the preparation of our facilities, is directed at integrating everything for that customer and anticipating their needs. The good news is, is that we have these yields and we are profitable, probably much more so than our size. But the bad news is, is that we are a little slower getting online. In order to integrate these resorts and produce the kind of results that we are describing here today, we have to really grind on every aspect of our buildings, as we build them. So it takes us longer in design development. Our detail is time consuming. I guess the best summary of what we do, and so our EBITDA per room in Las Vegas is what, compared to our neighbors?

**CFO-3**
: 34,000 versus 9,300. 3.6 times.

**CEO**
: Okay. And Scott in Las Vegas, how does it look? Is it the same?

**CFO-4**
: Yeah, that was Las Vegas.

**CFO-3**
: That was Las Vegas Steve.

**CFO-2**
: Oh, Macau EBITDA per room is 304,000 versus 80,000.

### Q&A
**CEO**
: 304,000 versus 80,000. Now, as I say, The Sands is the most profitable company in gaming, and a company that has my complete admiration. The point I am trying to make here today, is that when you ask what will happen to us, when we double our tables and increase our rooms by 170%, we tend to have a very positive expectation about a project like that, and that allows us safely to spend $4 billion on a facility in Cotai. To summarize, I think everything about our company is rooted in the principle of a story very old, but still relevant, the three little pigs. We build houses of brick, and our houses of brick take a little longer to erect than some of the others. But they're built for the long term, and we are seeing that now. We are seeing it through this day, these last few days of July, both in Nevada and in Macau. So having made that point, I hope it will be helpful in distinguishing our business plan from our competitors, and maybe be a little bit instructive for those people who are trying to understand what will happen, when we open up in 18 months. Primarily, we are making sure, that we do not cannibalize the peninsula. Our occupancy is 98.4%. We have more demand in the premium mass market than we can handle, and we can do this on purpose, because we want to make sure that as 2016 Chinese New Year rolls around in January, 18 months from now, that we will be able to spread our wings and keep flying at the same altitude. I think its time therefore to take questions.

**Operator**
: (Operator Instructions). Your first question comes from the line of Joe Greff with JP Morgan. Your line is open.

**Analyst-1**
: Hello all. I have a question on the margins in the calendar second quarter. They were a little bit below what we expected, particularly given the relative growth rates of mass versus VIP. Can you help us explain, were there any other one time issues, any kind of hold in the direct VIP business that had a negative impact on margins, or were there any kind of one time labor expenses that had compression on margins?

**CEO**
: Matt or --?

**Executive-1**
: Sure, so Joe, you're right on the labor side, we had $21 million in additional labor expense. As you know, we announced the additional bonus that had not been accrued for in the first quarter in April, and so about $6 million of that $21 million was one time, but that was one thing that affected earnings. Secondly, we did hold lower in the direct program in our life-to-date norm.

**Analyst-1**
: Are you able to quantify that direct low hold impact?

**Executive-1**
: No, I don't want to get into that, we usually don't do that. But I can tell you that that -- we did hold about 100 basis points lower than our norm in the direct program.

**Analyst-1**
: Got it. And just broadly, can you talk about the premium mass growth that you obviously talked about just a few moments ago. How much of that is really a trade-down from the VIP into that premium mass, versus some organic metric on newer mass premium players or existing premium mass players wagering more?

**CEO**
: That question is so complicated, I don't know how to answer. Joe, you're up. You seem to be ahead of us on this. We saw a slowdown during June, in some of the junket operators. Interestingly enough, it was the smaller, more thinly capitalized junket operators, but the bigger junket operators did just fine, and then the business, I can tell you, because its a public conversation today, that the business in July ticks back up again at the junkets. We are having a good month with our junket operators. So whatever, however choppy it was in June, we are seeing that sort of flatten out again, and do better in July. We are having the best July ever in the history of Las Vegas, and probably the best July in the history of Macau.

**Analyst-1**
: And do you think Vegas is benefiting? Do you think Las Vegas is benefiting from some of the Macau VIP players, maybe foregoing a trip to Macau and heading to Vegas, or are we just sharing something that's very anecdotal at this point?

**CEO**
: It's anecdotal at this point Joe. I will ask Matt or Steve Cootey or Frank or Robert or Gamal is sitting here. Gamal is very-very preoccupied with Cotai at the moment, but the guys were playing with numbers, you guys have anything to add to that?

**Executive-1**
: And Maurice is here too, we have been discussing that a lot internally Steve.

**CEO**
: I mean, we have the biggest share of Asian and Latin business in Nevada, and we have had, since I built the Mirage and Bellagio, and Wynns, and encore. Nothing has changed in the last 30 years, as far as our position with Asian and Latin players. We have always been able to keep an edge in that are of casino marketing. As long as I can remember, its going on 30 odd years now. Yeah?

**Executive-2**
: In Las Vegas, we have been fortunate that every segment in the gaming areas, so all international, domestic and slots have been up. And so it really isn't just where we feel its just the contribution of additional Far East customers coming here during that period, its really all segments.

**CEO**
: Well there you are. That was Maurice Wooden, Joe. Let's take our next question.

**Analyst-1**
: Great. Thank you guys. That's all for me.

**Operator**
: Your next question comes from the line of Shaun Kelley with Bank of America. Your line is open.

**Analyst-2**
: Hi. Good morning and good evening everybody. I was just wondering Steve, I think last quarter, you gave a much better prognosis for kind of your overall outlook for Las Vegas. It seems like that operating environment is continuing to -- could you just give us a little bit more color on what you guys are seeing right now in that business, and then anybody who is online, any color on kind of -- particularly in the summer, Vegas suffers from some seasonal softness, usually due to kind of less convention in group business. So what you guys are seeing on bookings from some of that corporate activity in Vegas would be helpful?

**CEO**
: We are knocking -- I mean, we got a couple of nights left. We are pushing $50 million this month in Las Vegas. I never had a $50 million in July in my business career, 40 odd years in gaming. Maurice, I think this is your area.

**Executive-2**
: So we actually have focused early in the year, looking at the summer, and then obviously we are looking now, toward the end of the year, as far as making sure we have all of our calendars loaded for opportunities. And so summer is one where we dialed in, and we recognized that if we get contribution from all of the different environments, including hospitality, which is the retail, food and beverage, and then on the slot side, as well as the -- again gaming side, we felt like this was an opportunity for us to be able to really take and hopefully accelerate what we were doing earlier in the year. And what we have seen is, is we have continued momentum, and we have been very busy, it has been a very active summer, and we feel like we have a very calendar going forward toward the end of the year, and so we are very optimistic.

**CEO**
: We want to be the first company to break through calendar year of over $0.5 billion of profit in Las Vegas, beginning to sound a little bit like Macau; and in order to do that, we have to do $37 million a month for the last six months of the year. Well if we hit $50 million in July, that $30 million -- we'd do that a couple of months, we won't even need December. I am dying to do this. All of us at the company, we are watching this kind of stuff by the day. I mean, we run the company long term, but we have such fun short term. Playing these kind of games and setting these weekly, monthly goals for ourselves. So it helps. But I don't know what other color to give you on this.

**Analyst-2**
: I think that's helpful. And I guess, just my other question would be a specific one in Macau. So it looked like some of the retail and other maybe entertainment revenues were a little light, versus what we have seen in the last couple of years. Anything to call out on that, specifically in Macau? Is there anything, the retail shops or anything that was -- that we're seeing; and you guys saw a difference in customer behavior there, with any of the corruption stuff or anything that might have impacted that?

**CEO**
: The corruption stuff, the idea that the central government is making a concerted effort to clarify to the citizens of the People's Republic of China that the government is not corrupt, is probably a wonderful thing. I know President Z has made that a centerpiece of this administration. As far as whether we are feeling implications of that in our retail business, that's a very tricky question. I don't know how to answer that. Robert Gansmo, Gamal, any of you guys have a take on that kind of question?

**CFO-1**
: It was mostly in the watch boutique, it wasn't really across the board. Its specific to a kind of a buyer.

**CEO**
: Yeah, we noticed weakness in the watch boutique area. Sometimes if there is a lot of publicity -- I am going to speculate. There is a lot of publicity, that China is going to have a slowdown, or China is having this or China is doing this. People who live in China, businessmen read that, and just like they do it in America, businessmen, they just take their eye off their own business, and they say I better pull back if that's going on. I don't want to be the last one to react, and they behave preemptively [ph], without actually having a reason to do it, other than the publicity. We are getting that feeling here, that everybody sort of overreacted. The fact that the government is behaving in a very responsible and serious steadfast way, is good news for everybody. But it has a different effect on people emotionally. We see that in the United States as well.

**Analyst-2**
: No, no, no, I think that's really helpful. Thank you very much.

**Operator**
: Our next question comes from the line of Carlo Santarelli with Deutsche Bank. Your line is open.

**Analyst-3**
: Hey guys. I just wanted to follow-up on one comment that you made Steve, regarding July. I thought you said you were having a record month as well in Macau. Just given maybe some of the trends that we are seeing in the market through July, I think, most people are speculating, the market is probably down low to mid single digits for the month. But you guys obviously sound like you are having a pretty good go of it. Could you maybe attempt to quantify is that a share gain, and if so on the VIP side or the mass side?

**CEO**
: I don't know if its a share gain. But we haven't had a July as robust as this one since 2011?

**Executive-1**
: Since 2011. This is going to be our best July, Carlo, and its really across the board. We are stabilizing on the VIP side. We are growing on the mass and slots and its going to be a great July.

**CEO**
: And that in spite of the fact, that those guys at Cotai, namely The Sands and Galaxy and the City of Dreams, they have got really fabulous places, and they know how to run. I mean, the competition, I said it last quarter, I am saying again, this is a very-very serious place, the staff at these hotels are all super pro, and we are enjoying this sunny season, here on the peninsula, which everybody was predicting was going to be yesterday's newspaper. Hardly the case, hardly the case. Again, I want to point out, that we have never as a company, in my business career, have never been anywhere, except an intensely competitive market. We thrive on the intensity of the competition that's almost, we do better when the temperature is hotter, as far as competition goes; because all these wonderful hotels, bring all these people to town, and we get a crack at everybody with our program. And so, we are enjoying the competition here.

**Analyst-3**
: Understood. Thank you. And just if I could ask one quick follow-up on your table and slot count in Macau? Obviously both were down in the period. Does that have anything to do with, maybe some retrofitting for the smoking, or how should we be looking at the change in counts?

**CEO**
: I am glad you mentioned that. We are in construction on the whole south end of the original Wynn casino, and we are adding two really spectacular spaces, that we decided we wanted to introduce into the market for Chinese New Year, one year ahead of Cotai. And so we took and closed half of that casino months ago, and started a very expensive $60 million, am I right Mike? $60 million presentation. In order to make sure that Wynn Macau could hold its head up against even Wynn Palace, we decided to do this really gorgeous thing, which we are going to show everybody for Chinese New Year in January, one year before the Wynn Palace opens up, Wynn Macau is going to get a shot in the arm, that will -- is going to be very important. So we closed -- we are doing these numbers, with a big chunk of our casino shutdown.

**Analyst-3**
: Thank you everybody.

**Operator**
: Your next question comes from the line of Felicia Hendrix with Barclays. Your line is open.

**Analyst-4**
: Hi thank you. Good morning, good evening. Matt, just starting off with just a point of clarification. So it seems like there will be an incremental bonus expense of about $15 million per quarter on a going forward basis?

**Executive-1**
: No, no, no, no. The second quarter we had to catch-up for the first quarter. On a going forward, its between $5 million to $7 million per quarter.

**Analyst-4**
: Okay, thank you.

**Executive-1**
: And that would be rolling in, in 2015.

**Analyst-4**
: Right. Okay. And then, just also, on the [indiscernible] at your properties there now, it looks like the promotional expense run rate is increase on the premium outside of your business. I was just wondering if you could help us quantify for that, or how to think about that?

**Executive-1**
: What I can say on that Felicia, is that, our margins have remained very steady in our mass and slots. So I wouldn't want to get into how much money we are spending to generate these type of returns, but our margins have held in both mass and slot business in Macau.

**Analyst-4**
: That's very helpful, thank you. And Gamal, my final question is on labor, particularly with the dealers, and as you plan for the opening of Wynn Palace; just wondering, can you talk a bit about how you are thinking about staffing the gaming tables, and how you're going to manage and potentially mitigate the labor inflation that we might see there?

**Executive-3**
: I think what Mr. Wynn has done in February by having an increased bonus and offering shares has made this property and this company far more popular than any of our competition; and we have seen a drop in the turnover in number of employees that leave the company. I think we will have a much better opportunity finding that labor as we open. So I think we will be in pretty good shape when it comes to that.

**CEO**
: But you know all the competition or on the call, everybody knows what everybody is doing, there is no secrets here. We are all friends. We are all watching each other, and everybody is going to try and take their best shot, to make sure they are properly staffed. Okay. Let's say that's true. It's also true today. Everybody is perfectly staffed. No one short of employees. Everybody has got dealers and waitresses and cooks and housekeeping, and we all got them from the same place. So what happened? We got five stars in all of our hotels. Our service levels are integrated with our business plan. What do you think is going to happen 18 months from now? Exactly the same thing. That's the reason I went through that whole dissertation, when we started the call. Sure, there is always challenges. There is challenges for Galaxy, there is challenges for City of Dreams at SJM, and there's certainly challenges for Venetian and The Sands. But the fact of the matter is, the way we meet those challenges, and the results that our business plans produce are clearly visible to you, and have been for the past 10 years or more. So the past and the present at the clearest indication of where its going. The economy, the competitive market always moves here and there, up and down, sideways, left and right, but its the program, and the management philosophies, the business plans at their core that define these companies, and tell you where they are going to go.

**Analyst-4**
: Okay. Thanks.

**CEO**
: Yeah, thanks Felicia.

**Operator**
: Your next question comes from the line of Steven Kent with Goldman Sachs. Your line is open.

**Analyst-5**
: Hi, good afternoon. Two questions; first, maybe we miscalculated something, but it looks like the number of slot machines declined in the Macau, and I just was wondering what the strategy --

**CEO**
: Its a remodel, Steve.

**Analyst-5**
: Okay, perfect. So that will move back up, once that remodel is done?

**CEO**
: I don't know. I am not quite sure. We find that we can win the money with less equipment in Las Vegas. We are winning more money, and I think we dropped off 10% or 15% of our machines, because we changed the presentation of our floor. We didn't want to look like everybody else. Its not about how many machines, its who's playing them.

**Executive-3**
: Steve, this is Gamal. We basically, with the drop in the number of units, our slot per unit per day has increased substantially as you see in the numbers. So its really about those 20% of the customers, giving us 80% of our profit in slots. That's our focus, and that's why we have been incredibly successful in the last six or nine months, focusing on those customers.

**CEO**
: Does that answer your question Steve?

**Analyst-5**
: Yeah that actually goes to sort of the second part of the question, which is just the way you have managed your customer base; because Steve as you said in the beginning, you're going to have more capacity yet by every metric that you described, you get more profit, more revenue per unit. As you open up the Palace, is there -- I know you feel confident that you will be able to maintain some of those numbers, but why won't there be some dilution? Do you have some sense to some of those metrics, that there is even more depth behind that, meaning that there are even more affluent high end customers who want the Wynn experience, who will pay similar numbers to what you're achieving in the existing -- in the existing property?

**CEO**
: Perfect question, and we can answer that question; not because I say so, let's just look at it from an entirely different perspective. We had revenues per unit and EBITDA per room and all that other metric stuff, three years ago, and we looked cool compared to the competitors, and you know, we are grateful for that. Then what happened? The Sands, the Galaxy, the Melco guys, SJM built brand new hotels, we didn't. They built gorgeous new hotels. They have put in beautiful VIP rooms. They dealt with the same junket operators we did. They put out the promotional allowances to the slots. They built magnificent suites. They did everything -- it appears we do. And what happened to us? Absolutely nothing. Now if we can hold our head up against that kind of competition, I am not saying that demand is perfectly elastic for any company, but I am saying, that there is an awful lot of evidence on the table to indicate that demand for our product may be a hell of a lot more elastic than you might think. And I say that, not out of bravado, or because I am trying to make myself believe, I am just asking anybody who is on this call, including my dinner pal, Sheldon Adelson. What are we looking at? What determines the future? The situation today, nobody can say that the demand is perfectly elastic. But what I am saying is, if you're wondering what's going to happen to us in 2016, take a look at what's happening right now, when we are up against the toughest guys in the world, who really know what to do. The facilities at the Venetian are par excellence. The facilities at the Galaxy and at Melco, everybody has really come out of the box, A number one, first class. Its something else that's going on here. Its about a program, a sense of [indiscernible] that starts with the employees and goes from top to bottom. We have been doing it a long time. probably -- that's another advantage we have. At this point in my life, I guess I am the oldest operator in terms of time on the job of the gang of bosses, that include Francis Loi and Lawrence Ho and Sheldon and myself. I think I have been at it, not as long as Stanley Ho, but probably longer than the guys who work for Stanley. So we've had a chance to make virtually every mistake you can make and we are making new ones now. But we have got our own game now, and we don't play the same game that the other guys do, and that's one of the reasons why Macau is such a healthy place today, because there is a choice between the Venetian, the Galaxy, a City of Dreams, and a Wynn kind of place, and that menu, that choice is at the heart of the longevity of Las Vegas against Indian Casinos in California. Remember when they said, if they have real gambling in California, you can roll up the streets in Las Vegas? Not quite. Not quite. We adjust, but our program, and our sense of ourselves has not changed. So again, I am not guaranteeing what the results are going to be in Cotai, but I am telling you why we feel sort of comfortable in this environment, and we are feeling very positive about where its going to go. We love Macau, we love the environment of China. Its steadfast; its steady; its predictable, unlike some other places that I could mention.

**Analyst-5**
: Okay. Thank you.

**Operator**
: Your next question comes from the line of Harry Curtis with Nomura. Your line is open.

**Analyst-6**
: Hey good morning. Just a follow-up on Macau. Steve, you mentioned that your business has stabilized. Your volume in the first quarter was quite a bit higher than the second quarter, the question is, at what level has it stabilized? What I am wondering is, has there been a behavior of VIP customers that may take a longer period of time to come back, particularly if they are defensive about the Chinese Government's Anti-Corruption Campaign?

**CEO**
: Matt, you've got a feeling about that? You'd like to think about --

**Executive-1**
: You know, Harry, July is up from June, but as you can see in the numbers that the government puts out every week. It is still down, in VIP year-over-year in single digits. So we have seen it stabilize and come up, from what we think is the bottom in June, and every time we try to predict, how quickly it will recover in the past, it has always recovered much faster than we predict. So what we can tell you is, its better than it was in June, and it feels stable.

**CEO**
: Harry, Gamal Aziz, in anticipation of this call, walked into the office about 30 minutes ago, and I am going to ask him to repeat what he read to me.

**Executive-3**
: Harry, this was the exact question posed to Steve a couple of years ago.

**CEO**
: June of 2012.

**Executive-3**
: June of 2012, about the demise of the VIP business, and his answer was that, you know, there has been an increase in the capacity of VIPs and I am not sure if the picture is clear of a marked slowdown. The market is still growing, and I think they will continue to grow. I think you've seen the VIP business growing since 2012. It may take a pause of some sort, but we don't think that its the end of things, as we have heard it so many times by now. We have seen a July stabilization after a June drop, and whether it comes back in the next 60 or 90 days, or it gets like the first quarter in the next 90 days, we don't know. But we are sensing a stabilization and a tremendous growth in the other segments in the market, mainly the premium mass and the slots.

**Analyst-6**
: And as you talk to your direct customers, what is their level of confidence in the future? Have you had those conversations?

**CEO**
: It does. Linda's here. She just came back from Beijing. Linda Chen.

**Executive-4**
: So when you say stabilize, I think its only up reasonably for all the high end customers to take a pause, and their recreational spending, that -- its like, basically you feel the economy, where the world is going to go for a slower growth, then you're not going to spend so much -- as much money on recreation or entertainment. And then -- but I don't think that's actually probably good stable growth, because they are here for the long term, they are not here to just play and make a quick return. So they are actually looking at gaming as part of their -- if you may, normal long term recreational entertainment budget. I think we are actually seeing more of new customers that have never been to Macau, which is a positive, that there is actually a difference of profile, demographics of newer mass customers that are coming in, that we have never seen before. So I think for the long term, that doesn't mean the markets will have a lot more potential to grow.

**CEO**
: There is a wonderful SAT word for the college board tests, I remember, inexorable. I love that word. Inexorable is a word that I think of in terms of the growth of the Chinese economy, inexorable, which is a kind of thing you might see on Bill O'Reilly's word of the night. It means unstoppable. Growth is going to go from 10 to 6, but the base is so much bigger.

**Analyst-6**
: Steve, I am going to give you the week's award for the Gary Loveman prize for vocabulary. Shifting gears to --

**CEO**
: I am not sure I like Gary Loveman. Its all the same to you. But I'd like to have the Sheldon Adelson. If I have a choice, I will take the Sheldon Adelson prize.

**Analyst-6**
: So, getting back to Vegas real quick, your ADR in Vegas has now come back to around $25 or so, its still $25 below the peak in 2007, which isn't all that much. Yet, in an EBITDA per room, from that perspective, you are still quite a bit below the pace of where you were back in 2007, and I am just trying to understand what the primary drives of that is; is it a mix of customers, is it gaming, which is it?

**CEO**
: First of all, if I knew then what we found out after we opened it, Sheldon wouldn't have built Palazzo. I wouldn't have built Encore. And I am sure that MGM wouldn't have done City Center. None of us, we all start these projects three, four years in advance of the recession. Remember, we opened Encore on December 22nd of 2008, can you think of a more perfect negative moment to open 2,000 rooms that cost $2.25 billion. And if we hadn't built those rooms, we might be making pretty close the same amount of money, and we would owe $2 billion less. But the hindsight's perfect, but at this point, its all history. What we are seeing now is, where are we going, what's the health of the market? Are we building on our own base? Are we headed in the right direction? Are we comfortable about our investment in China? Do we feel good about Nevada? The answer to those questions, speaking for myself and my colleagues on this call, is yes, we are comfortable about our investment in Las Vegas, we are happy with Las Vegas. We are feeling very up about it. We are enjoying the privilege of being part of the Macau scene, and looking forward to the future. When you start splitting hairs about 2007, look, we made $427 with 2,700 rooms, in a place where everybody said you can't make money at the Desert Inn. Well, that didn't turn out to be accurate. We made more money than everybody on the strip, including Bellagio, with 2,700 rooms, where the Desert Inn was, supposedly at the wrong end of the strip. Another interesting point. Development makes the location, the location doesn't make the development, unless you happen to be in Las Vegas, or you happen to be in the city of Macau. So I mean, when looking back at 2007, it was delicious, and may be that's -- it was what we saw coming in 2007, that allowed us to start that to have building in 2005, that turns out, was a capacity we didn't need. But we didn't need the Bellagio capacity, we didn't need City Center capacity, if I can speak for my friends in the other companies. But what the heck, I mean, it takes a long time to get these places up and running.

**Executive-1**
: And Harry, if you look at the history of domestic gaming revenues, its clearly the domestic gaming that people overestimated. So domestic gaming has not grown from 2007 to today, like everyone thought. But the other segments have done quite well.

**Analyst-6**
: All right. Very good. Thanks a lot.

**Operator**
: Your next question comes from the line of Robin Farley with UBS. Your line is open.

**Analyst-7**
: Thanks. As you yield manage the Macau floor, can you give us a little color on the breakdown of the VIP versus the mass tables?

**CEO**
: Who wants to take that? Frank? Frank Cassella, the Chief Financial Officer of Wynn Macau?

**CFO-2**
: Our VIP Wynn per unit per day is 32,000; mass Wynn per unit is 17,000.

**CEO**
: Robin, Frank Cassella's father, Danny Cassella, was my Chief Financial Officer and opened the Mirage with me, in 1989, on November 22nd. I am sorry, go ahead, Frank.

**Analyst-7**
: Nice little bit of history. I was also looking for just kind of the mix on your floor, as you are kind of yield managing your shift tables between VIP and mass, where that was in Q2?

**CEO**
: Why do you care about that? We yield manage that Robin. If we said okay, some of the junket operators were a little wobbly from time-to-time, we add them, we subtract them, then we put the tables back into the mass. If we think we can make more money. Its the kind of thing that we are yield rate managing these tables on a monthly basis. We acknowledge that we do it, so does Sheldon, so does Lawrence, so does Francis, and so does Ambrose So and Louis Ng across the street. We all do it. What color would you like on that? I want to respond, we want to be accurate.

**Analyst-7**
: Its just usually a breakdown that you provide in the release in some form, you usually talk about the number of tables. So maybe you are not going to provide that going forward?

**Executive-1**
: Yeah Robin, that's right. It was 263 VIP tables, 191 mass tables, for 455, and that count is down, because of all the construction that we have going on, and some changeovers in [indiscernible] from VIP to mass.

**Analyst-7**
: Okay, great. Thank you. And then --

**CEO**
: Robin, is that important? Just for my own benefit, you keep very careful track of that?

**Analyst-7**
: Its something we look at in the market looking for trends with VIP versus mass. We look at market share among the operators in the different segments. I think that's what investors generally look at.

**CEO**
: I see. Okay.

**Analyst-7**
: My other question is, on Cotai, you talked about how you're going to keep competing, as Cotai opens. I understand the overall picture. I am just wondering, when you look at the opening, and there are a number of properties with different opening dates, within a quarter or two of your project opening? It sounds as if everything is on track with your project opening. Do you care whether other projects open in the same quarter? Do you think that will kind of impact?

**CEO**
: Would it make any difference if I did? I have no control over them. I was at Cotai when I landed the other day, and activity at MGM and the Parisien was either non-existent or light, for whatever reason. So I don't know what the latest scoop is on my colleagues, my friend's projects. When has Parisien said it was going to open, when will it open. I am sure if you ask Venetian, they will tell you, but those dates are what they are and when resorts, personnel, have no control over it, we just have to deal with it. Whenever those dates come due, and the market and the tours and these projects come of age, then they will come online, and hopefully, they will all just have wonderful beginnings. But we don't have much -- because we have no control over it, we don't give any thought about it.

**Analyst-7**
: I guess you used the phrase, you deal with it when it happens. I guess, is there anything different about your opening, or what you do if there are two projects opening in that quarter, or [indiscernible] open?

**CEO**
: No, no, what we do is we finish the building. Hopefully we have the proper time, in which to turn it into a campus for two weeks or more, where we run it just for ourselves, and the employees stay in the rooms and the employees eat in the restaurants, and we breakdown the computers and we try all of our backup systems, and we just drive around the place for 14 or 20 days if we get the chance. So they only open the doors to the public, we are ready for them; and we can deliver a service level that isn't scratchy and erratic, and we are not apologizing, because this doesn't work or that didn't work. We try and build into our budget, enough money to run the place at full payroll, for at least two weeks or more, so that we take the punishment, not our guests. And we are going to do that, no matter who's opening, when or what. The most important thing, first impressions matter, is to get the place off on the right foot. So that the service levels match the elegance of the carpet and the marble and the onyx and all the other stuff that we put into it. So that program is fixed in our mind, and it doesn't relate at all to what the other guys do.

**Analyst-7**
: Okay, great. Thank you.

**CEO**
: Sure.

**Operator**
: Your next question comes from the line of Tom Marsico with Marsico Capital Management. Your line is open.

**Analyst-8**
: Good evening Steve, how are you doing?

**CEO**
: Just great Tom. Dealing with the jetlag on this side.

**Analyst-8**
: I am dealing with patience on this side. We started this investment, years ago at $13, so I am going to reminisce a little bit. I think the stock is right now at $211 or so. I don't know how many dividends we have received. We have experienced the greatest recession since 1945, and there is questions about the capacity that's being added at Cotai, in relationship to the fastest growing economy in the world, and the largest [indiscernible] market being Asia in the world. You have companies that are becoming public here in the next several months in China, that will have market valuations in excess of over $100 billion. So the wealth is being created, I don't think that most investors have seen the wealth creation that's going on in Asia, that's being experienced right now. So given the environment of the greatest recession, there is this continuous concern that the amount of capacity that was built in Las Vegas with the lag times that you would have suggested, is happening with the new hotels going on Cotai? And if you'd look at the growth of the economy in China, compared to what we have been experiencing here in the United States for the last several years, I think that's where the biggest concern becomes. But if you go deeper into the numbers and look at the vibrancy of that Asian economy. I think that's where investors are missing the opportunity or understanding how large Cotai can be? And I think that they are also missing the fact, something that you have touched on, but maybe not directly is that, as more of these hotels are built, people will be attracted to come to the hotels. But what the main attraction is in town, is when they see, as you would refer to it, your joint. Your joint has always filled up, because of the people you hire, the way you execute, and the type of products and services that you offer your customers. So with that comment, I think that the opportunity is execution on the Palace. You say you are on time opening up in 18 months. I think you also have a great opportunity as customers become more discreet and move from the VIP segment into the mass segment, the segment that you think make a lot more money in on a margin basis. And so, maybe you could just talk a little bit about how you're trying to improve that premium mass experience versus what the VIP's see in the services, and the type of experience that they have, compared to your premium mass customer?

**CEO**
: Thank you for the kind comments, Tom, it has been a pleasure having you as an investor all this time. I remember, when we started the road show, and I came at your office, and it was October of 2002, and everybody pulled their deals off the street, and we were up against it. And you looked at me and said, never mind the speech, we will take 5% of the deal. It was a wonderful moment, and thanks for the kind words, and I will address your request.

**Analyst-8**
: It has not been a shabby investment Steve, and I think that we were in for 10% of the deal.

**CEO**
: Okay. So about the premium mass market; every time someone asks an important and complex question, that could be taken any number of ways, my philosophy, I think process is the answer to most problems. I wish they understood that in Washington, but process. Back up to something you're certain of, and then, come forward, once you've got yourself grounded in a simple, come forward again and deal with the complex question. Okay, what's the most important thing in our business, guest experience? Who takes care of guest experience, the staff of employees. Those are the two central truths, on which every decision we make are based. We ground ourselves with those two truths, that if we have good guest experience, people will come back again, tell their friends, and maybe pay us more money in the future. And we'd say that that guest experience is not about the carpet or the onyx and all that stuff, its 90% about the people, because only people make people happy. So, when we are designing the hotel, and we want to get the premium mass, we are saying, what's the premium mass, besides the term that Wall Street people, when they talk about the gaming industry? Its that person with more money, who likes to come on vacation, gamble, eat and shop. But this person has enough money to stay at the best hotel, or whatever they think is the best hotel. The branding, the cache matters, and how do they find out about it? From personal experience, but before that, word of mouth. The truth prevails in creating a brand. Not the advertising, not the baloney that CEOs like me lay out, but the truth prevails. So what we do, in order to get the premiums mass market, is we build a better product, and the way you build a better product, is to make every single minute detail that goes into the whole, better from scratch, we are talking about the width of the hallways, the balancing of the lighting, the level of sound, the color coordination of the place, if we are talking about the building. Every single thing is better, and we are banking on -- and here is the key to it. Guys like myself and the people that I am in business with, we have been attracted to each other, because we all believe that the public gets it, that people do know the difference between pretty and ugly, clean and dirty, that the public has an innate sense of discretion. Now there is exceptions. There are people without any damn taste in the world, there are people who are very-very discriminating and see every little detail. But basically this company, is built on a foundation that says the public knows the difference, and if we give them that difference, they will reward us with their patronage. That's the whole secret of Wynn Resorts. Nothing else. It isn't more complicated than that, and that's why we grind on the details. That's why we take longer to build our voices, that's why we end up outperforming the competition. We've never made a secret of it. Hell, the guys that have worked for MGM, won't work for me. What happened to the culture? The end if I know. But our culture is bad [ph] and simple, and that's how we will get more of the mass market. And damn it, we will get more of the mass market Tom, as sure as my name is Steve. Not because I say so, but because we are dedicated to a business plan and a common sense program that has never disappointed us. We think plain and simple, and then we act on it, based upon those simple truths, that if we give a better guest experience through our employees, that we will be rewarded with the patronage of the most affluent, the most discriminated, the people who really know the difference, and those incidentally are the ones that want better food, that shop in better stores, that want a fancier bedroom to sleep in, that want a bigger TV to watch, and that want to be treated by employees, who make a personal connection with them. And that's our story, and that's all we ever knew, and that's the basis of every decision we have ever made, as a family, as a group. Gamal, am I talking for you? I mean, I have done a lot of talking here today.

**Executive-3**
: Absolutely.

**Analyst-8**
: Steve. I think that's one of the reasons, as we got through the recession, and I was comparing the recession, the great recession back in the 30s, I used 1945, as the World War 2, and that was back in the 30s, you had the greatest recession/depression. But the point I was trying to make is, the type of customer that you attract, is the type of customer that is able to ride out difficult economic times, and that they do come back, and they come back just as the Four Season clients' comes back, because they have a greater amount of propensity to spend, because you don't have to spend the money that they make from their jobs, just on the essentials. They have that extra dollar to spend on entertainment and travel, and the amount of travel that we are seeing in Asia and the growth of the market is unprecedented for most investors that have been in the market, let's say, over the last 20 years or so. We have never seen anything like China.

**CEO**
: Issy Sharp, you hit the nail on the head.

**Analyst-8**
: Issy Sharp, exactly.

**CEO**
: Issy had it, and we look at Issy, and I did, as a younger guy and said, oh boy, you know who else had it, Bill O'Hara, when he was alive. He didn't have the fanciest places, but he had a sense of [indiscernible] and esprit de corps. When I went to Reno and stayed in his hotel, the employees lit me up. Its not the building so much as it is the people, and O'Hara had it and Issy Sharp's got it. Those things have changed over years unfortunately.

**Analyst-8**
: Thanks for all your hard work. Its a great quarter.

**CEO**
: Nice conversation, Tom. Thanks for giving me the chance. We will take another question. We are not in any hurry, we got plenty of time.

**Other**
: Actually Steve, that's the end of the time. We are at right over an hour. So Tom closed our call, it was the last question.

**CEO**
: It was pure fun. Anyway, we will see what happens 90 days from now. 90 days from now we will also have a decision in Boston, they say on September 12. They are going to decide, and we are waiting to see how that turns out. Thanks everybody. See you next time. Thanks Matt. See you all.

**Operator**
: This concludes today's conference call. You may now disconnect.