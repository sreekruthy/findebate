## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCAR's Second Quarter 2014 Earnings Conference Call. [Operator Instructions] Today's call is being recorded and if anyone has an objection, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCAR's Director of Investor Relations. Mr. Hastings, please go ahead.

**Other**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCAR's Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President andChief Financial Officer; and Michael Barkley, Vice President, Controller. [Operator Instructions] Certain information presented today will be forward-looking and involve risks and uncertainties, including general economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

### Q&A
**RonaldE. Armstrong**
: Good morning. PACCAR reported improved revenues and net income for the second quarter of 2014. PACCAR's second quarter sales in financial services revenue were $4.6 billion and quarterly net income was $319 million and after-tax return on revenues of 7%. Revenues were up 6% and net income increased 9% compared to the results generated in the second quarter last year. PACCAR Parts achieved record sales this quarter, and PACCAR Financial generated record pretax profits. I'm very proud of our 22,600 employees, who have delivered industry-leading products and services to our customers worldwide. PACCAR delivered 33,700 trucks during the second quarter, a 6% increase versus the first quarter this year. This growth reflects increased truck deliveries in the U.S. and Canada due to the ongoing replacement of the aging truck population and higher fleet utilization driven by record freight tonnage. Looking ahead, we expect to increase truck deliveries in the third quarter by about 5% compared to the second quarter, reflecting the continued strength of the North American Class 8 market. Third quarter gross margins should be slightly higher than the second quarter, reflecting the benefits of higher production and improved operating efficiencies. It is encouraging that U.S. employments gains this year have been the strongest since 2006. Other good economic news is that U.S. auto sales are projected to be over 16 million vehicles and housing starts over 1 million units this year. These positive trends are benefiting truck demand in North America. U.S. and Canadian Class 8 industry retail sales are estimated to be in the range of 230,000 to 250,000 trucks this year. Industry orders for Class 8 trucks in the U.S. and Canada for the first half were over 145,000 trucks, a 34% increase over the comparable period last year. Economic news in Europe is trending positively, with GDP growth expectations for this year of 1.1%. Year-to-date through June, freight in Germany, as measured by the amount index, was 3% higher than the same period last year. Europe's greater than 16-tonne market is projected to be in the range of 210,000 to 230,000 units. Customers in Europe accelerated purchases of Euro 5 vehicles last year and are gradually adjusting to the increased prices of Euro 6 trucks. Production of DAF Trucks in Brazil is progressing, with build rates expected to increase gradually through 2014. PACCAR Parts business generated record quarterly revenues of $778 million, a 10% increase compared to $710 million in the same quarter of the prior year. PACCAR Parts quarterly pretax income was $127 million, an increase of 16% compared to the $109 million earned in the second quarter of 2013. The strong results were driven by improved fleet utilization and the many innovative products and services offered by PACCAR Parts. PACCAR Financial Services revenues were $303 million in the second quarter compared to $289 million a year ago. PACCAR Financials' second quarter pretax income was a record $92 million compared to $82 million earned last year. The improved results benefited from growth in asset balances and excellent portfolio performance. PACCAR's strong balance sheet and positive cash flow have enabled the company to invest over $2.1 billion in new products and facilities in the last 3 years. In the second quarter, DAF introduced a new range of Euro 6 CF and XF 4-axle trucks and tractors for heavy-duty applications. These new vehicles expand DAF's product range in the construction, container and refuse markets. In addition, Kenworth and Peterbilt launched new medium-duty cabover trucks, with extensive exterior and interior enhancement. The Kenworth K270 and K370 and the Peterbilt Model 220 have been designed with an enhanced turning radius and shorter overall length to excel in urban delivery applications. PACCAR's capital spending of $250 million to $300 million this year is targeted at enhanced powertrain development and increased operating efficiency of our assembly facilities. Research and development expenses are estimated to be in the range of $200 million to $225 million. During the second quarter, PACCAR's Board of Directors approved a 10% increase in the regular quarterly dividend to a record $0.22 per share. PACCAR's increased the regular quarterly dividend by more than 140% in the last 5 years. PACCAR continues to enhance its leadership position in the global truck market by developing the highest-quality products and services in the industry, investing in new geographic regions and providing excellent returns to our shareholders. On behalf of the PACCAR management team, I'd like to thank the many analysts and investors who attended our investor conference on May 28 and 29 at Peterbilt's Denton, Texas plant. We enjoyed sharing our plans and our world-class facilities and products with you, and we appreciate your feedback on the event. I'd be pleased to answer your questions. Thank you.

**Operator**
: [Operator Instructions] Your first question comes from the line of Nicole DeBlase from Morgan Stanley.

**Analyst-1**
: So just a couple of questions for you. First, Ron, if you could comment a little bit more on your acceptance of Euro 6 pricing. Obviously, it's been a hot issue for you guys. How does it trend during the quarter? Is commentary getting any better? And what's your expectation for Europe as we move into the back half of the year?

**CEO**
: Yes. Euro 6 pricing is, as we've identified before, is up quite a bit over the Euro 5 pricing. It has been challenging to gain acceptance of that pricing in the market, and we've recovered the price increase but not realized any additional margin on that. So that continues to be the case, the European market is very competitive. And -- but I think we see with the fundamentals, the economic fundamentals of Europe trending positively that once the market normalizes that we'll see an increase in demand as we progress to the second half.

**Analyst-1**
: Okay. That's helpful. And then secondly, so you said gross margin's up slightly Q-on-Q. I think last quarter, you were a little bit more explicit. You set up 20 to 40 basis points. Is there any way you could kind of frame what up slightly means?

**CEO**
: It's slightly. It's not a significant amount.

**Operator**
: Your next question comes from the line of Stephen Volkmann from Barclays -- I'm sorry, Jefferies.

**Analyst-2**
: So I'm going to actually follow-up a little bit on Europe, if that's all right. You're talking about the second half being up a little bit sequentially. I guess the first one, is you talked about 5% sort of quarter-over-quarter production increase. Is Europe up quarter-over-quarter in the third quarter?

**CEO**
: No. We have our traditional summer shutdown period in the third quarter, so it's not up. So the increases is North America.

**Analyst-2**
: Okay. And so then, I guess, you would assume the fourth quarter in Europe is a little bit better. I think you're planning for second half to be a little higher. Do you have orders sort of on the books for that or is it sort of that you're hoping the economy kind of continues to sort of come back a little bit?

**CEO**
: So I think it's more focused on the economic fundamentals that are there and supporting the increased freight activity that we're seeing.

**Analyst-2**
: Okay. I got it. And then my final question is can you just say something about pricing in the North American market? Given the amount of volume we have here, I guess, I would think maybe things would be starting to get a little bit better but any color would be great.

**CEO**
: I think pretty steady. The buyers of trucks are large fleet customers that we have long-term relationships with, and so I'd say it's pretty steady.

**Operator**
: Your next question comes from the line of Jamie Cook from Credit Suisse.

**Analyst-3**
: I guess just my -- another follow-up question on the margin front. I mean, to Nicole's point, you guided to a 20 to 40 basis point margin improvement sequentially last quarter and on the gross margin line you came in 80 bps better. So in your opinion, sort of what drove the upside surprise? And then at what point do you feel like -- or what do you need to see where you feel like we finally get some year-over-year improvement on the gross margin line, because in the first half of the year it's still trending down year-over-year? And then my last question relates to the Parts business. We've seen, I think, this is like the -- I don't know, fourth or fifth -- actually, no, I mean, probably 6 quarters of pretty good top line growth and we're trending in sort of the high-single-digit range. Do you think that's sustainable going forward?

**CEO**
: That's a multifaceted question, Jamie. So the European -- or just the margin side...

**Analyst-3**
: Yes. Your margins were better than what you forecast.

**CEO**
: Sure. And so...

**Analyst-3**
: And so I'm trying to figure out if that's the same for Q3? And then what do you need to see to get to year-over-year gross margin improvement?

**CEO**
: Sure. So as we think about margins in the second quarter, I mean, there's a combination of some price realization in North America, rigorous cost control and then the operating efficiency of running our factories at a higher rate. So those 3 things, I think, combined. We'll see some benefit from operating efficiency in the third quarter again, but we also have the shutdown period, which has a bit of fixed cost that goes with that. So that's a little bit of an offset, some of the upside on operating leverage.

**Analyst-3**
: And then what do you need to see -- to start to see year-over-year improvement in gross margins? And then last is the growth that you've seen in parts, which has been pretty healthy, do you think that's sustainable in the back half of the year?

**CEO**
: Sure. I think, obviously, the market strength of the market is the key thing that drives margins over time. And so if demand continues to accelerate and backlogs get extended, that probably provides some pricing leverage opportunity. We're anticipating good market, steady market as we progress through the second half. So we'll see how that develops. And Parts has had an excellent performance and wonderful products. There are TRP brands, the PACCAR Genuine and DAF parts product lines have done excellently. And so we'll continue to see some level of growth. Right now, we're thinking, for the year, somewhere in the 5% to 8% range, I think.

**Analyst-3**
: Okay. Can I push in the margin one more time?

**CFO**
: Sure.

**Analyst-3**
: I mean, I guess, I sit here and I look, and your gross margins have been pretty consistent over the past couple of years, 2012, 2013. It looks like we'll end 2014 at some point and we're 5 years into what historically has been a 6-year cycle. So is there the risk of this cycle just given where we are unless your view of this cycle is different that we just don't get the improvement in gross margin?

**CEO**
: Well, the peak in the last cycle, if you'll recall, Europe and North America was a 300,000-plus truck market with backlogs extended almost up to a year at points and we're nowhere near those kinds of numbers. So that provides a unique pricing opportunity that's not present currently.

**Operator**
: Your next question comes from the line of Andy Casey from Wells Fargo Securities.

**Analyst-4**
: Just a question back on Parts. Was there any specific region that grew faster than the other regions, specifically, I guess, was U.S. and Canada kind of the shining star in the quarter or was it pretty well spread at that 10% rate against -- across most regions?

**CEO**
: No. I think U.S. and Canada was up a little bit more than average in Europe, just a little bit below that. But both had excellent quarters and good performance by the team and the markets, like I said, with freight activity at pretty good levels in all of our markets that's supporting good Parts business.

**Analyst-4**
: Okay. And then if it's possible, could you kind of address the demand trends that you're seeing outside of -- the ones that you've already talked about, Europe, U.S., Canada, Brazil, specifically, I guess Mexico, Australia and then the Andean region?

**CEO**
: Okay. So let's start with Mexico. Mexico, good start to 2013, softened in the back half of last year. We're starting to see some improvement in demand in the Mexican market, as well as in the Andean region. There's some emissions changes that are occurring in Colombia that are going to be positive to demand in the second half of this year. Brazil, the market is soft -- softening. Economic growth there is slowing. But again, we're on a slow, steady ramp-up period, so it doesn't really impact us but we continue our slow and steady ramp-up in Brazil. Australia is, I'd say, steady. Not -- GDP growth is relatively low. Mining activities lower than it has been, but just good and steady.

**Operator**
: Your next question comes from the line of Ross Gilardi from Bank of America Merrill Lynch.

**Analyst-5**
: Just a couple of questions. But first of all, it feels like some of your customers are really getting pinched by the driver shortage now. And I guess, on one hand, it's putting pressure on them to buy new trucks to retain drivers. On the other hand, it's probably pressuring their business on wage inflation and things like that. So going forward, do you think an ongoing driver shortage contributes positively or negatively to your business?

**CEO**
: Well, I think, obviously, Peterbilt, Kenworth and DAF products are at the top of the market in terms of driver, in terms of their need for -- or their desire for new trucks to drive. They're the great fit and finish, great performance and become a real asset for a company as they're recruiting drivers. So I think it could have a positive potential on demand for the Kenworth, Peterbilt and DAF products.

**Analyst-5**
: On the flip side, are you seeing any signs that some of the pressure, some of the driver shortage are adversely impacting order patterns for trucks into the second half of the year?

**CEO**
: I don't know if I would see it impacting the patterns per se. I think they're -- all other things being equal, customers would buy some additional trucks if they had a clear path to having additional drivers, but I don't see it affecting the patterns that we've seen over the last several quarters.

**Analyst-5**
: Okay. And then on Brazil, I mean, obviously, your business is just starting out and you've got a very good long runway ahead of you. But I'm kind of surprised you didn't reduce your outlook for the Brazilian truck market that may not really impact how many trucks you can sell in particular this year. But just wondering is it more difficult to get customers to take a chance on a new brand in a weaker market like this right now? And do the current market conditions in Brazil dampen your penetration expectations in the next several years at all?

**CEO**
: Yes. So the market size that we referenced in the press release is the South American Class 8 market, which includes Brazil, Argentina as well as the Andean region. We see -- within that, Brazil being down 10% or so, the Andean region being maybe a little more flat compared to where it was prior year. I think, last year, the total number for the South America was 160,000 trucks or so. We're thinking 140,000, 150,000. So down 5% to 10% over last year's levels for the South American Class 8 market. And in terms of our business, again, we're just ramping up, getting going. And our guys are -- our team has just performed excellently there in terms of getting the factory up and running. Our dealers are still building out their facilities to represent DAF in the marketplace. And so that whole process continues. But we still see the long-term prospects for our business to be excellent.

**Operator**
: Your next question comes from the line of Andrew Kaplowitz from Barclays.

**Analyst-6**
: So can you talk about what you're seeing in Eastern Europe right now? How much of a risk is that market, specifically Russia to your outlook? You've already -- we've seen issues there with some of your competitors. Are you seeing anything there yet that we need to be concerned with?

**CEO**
: Well, I think as it stands now, we'll see fewer truck deliveries in Russia this year than we saw last year because of the -- some of the challenges that are there in the area. But it continues to be -- we've continued to increase our representation with dealers in the area. We have a strong park. We're expecting good growth in parts sales in the area. So it's a bit challenging for the short term, but long term we feel very good about the development of our business in Russia and continuing to grow that over the coming years.

**Analyst-6**
: And Ron, as you sort of build out your MX engines, what we see also in the industry is some of the guys who were your suppliers, too, have talked about higher warranty expense on some of their new engines. How comfortable are you guys in sort of warranty expense control as you go forward that we won't see a little bit of volatility there as we go forward with PACCAR?

**CEO**
: I think with the introduction of on-board diagnostics, the industry, as you mentioned, have seen some challenges, all the complexity that goes with that. But there's been a nice progression of -- with our sales and others, and we'll continue to see that progression as we get more and more experienced with those regulations and guidelines. And so we're comfortable that we'll perform very well and our engines are very well received by the customers, great reliability, durability and the fuel efficiency is just -- has been very well received. So we're -- we still view it as a great upside potential for our engine business long term.

**Analyst-6**
: Ron, can I ask just you quickly about the vocational market? You guys talked about it being strong earlier this year. Construction have gotten more mixed here over the summer. Do you still see any strength in that market for you guys?

**CFO**
: Yes. I think -- this is Bob. The vocational market is, certainly, year-on-year much stronger than it was last year at this time, and PACCAR with new products for both Kenworth and Peterbilt in the North American market is very well positioned to take advantage of the opportunity.

**Operator**
: Your next question comes from the line of Ann Duignan from JPMorgan.

**Analyst-7**
: I wanted to take a step back and just ask you in North America, what you're seeing out there in the fundamentals from demand for the oil tanks to transport domestic oil. And also, are you seeing any customers purchasing trucks to take advantage of the rail capacity issues that we're seeing out there, particularly in the Midwest?

**CEO**
: Yes. I don't think either of those are significant factors up or down. I'd say it's fairly consistent in terms of the number of trucks that we're selling to customers in those areas. I think things are good, solid, but nothing, I guess, I would say is a significant trend upward or downward in that.

**Analyst-7**
: Okay. That's helpful. And then same question, I guess, on sleepers versus take cabs. Any change in the trends there or anything incremental?

**CFO**
: No. I think our sleeper mix has remained fairly steady, perhaps it's grown slightly as we've seen some of the fleets play some expansion orders. But in general, a pretty standard mix for us.

**Analyst-7**
: Okay. And on the pricing side, are you seeing any aggressive pricing by your competitors? We're hearing about discounts to list price on one of your competitors for -- if you buy their entire drivetrain. Are you seeing any aggressive pricing from your competitors to encourage full integration -- fully integrated drivetrains?

**CEO**
: Nothing I would say that's pervasive in the market. Everybody has their particular conquest point that they protect and go after. But I'd say it's pretty steady market in that regards. In Europe, with sort of the softness of Euro 6, pretty competitive pricing environment but nothing peculiar to any particular manufacturer.

**Analyst-7**
: Okay. And then Europe, any particular region or is it just in general because customers are bolting at the increased price?

**CEO**
: Yes, just in general.

**Operator**
: Your next question comes from the line of Jerry Revich from Goldman Sachs.

**Analyst-8**
: Ron, I'm wondering if you could talk about how the product warranty performance is tracking in Europe? I know you have a lot of test miles, can you just update on how that's playing out in the marketplace? And also can you just flush out your prior comment on U.S. on-board diagnostics? Is that an issue that you're monitoring or have you taken up your accrual rates there?

**CEO**
: Yes. So Euro 6, the products have been very well received by customers, both from a reliability and fuel efficiency standpoint. So very well received, continue to get good accolades. DAF, in fact, just -- was recognized in Poland as truck of the year with their products. So good recognition. And from our perspective, obviously, there's a lot of elements of the truck that are new and were very well designed and again, receiving good accolades. So we'll continue to experience good warranty performance on those trucks as we progress through this year. The on-board diagnostics, again, it's something that's affected the entire industry. Everybody has transitioned with that. And we're seeing steady progression of managing that, and it'll be well managed as we go forward.

**Analyst-8**
: And I know it will come out in the Q, but can you share your warranty expense with us in the quarter, just so we get a sense of how much of the margin improvement that you saw this quarter was on the warranty side?

**CEO**
: Yes. I don't have those numbers, Jerry. It's not a major element of our total cost structure. I think on the 10-Q, it combines expense with extended warranty and a few other things. So I don't have those numbers readily available.

**Analyst-8**
: Okay. But maybe as part of the discussion on the warranty -- or on the margin trends in the back half of the year, this is one area that if you continue to execute consistent with your prior product rollouts, that can be an area that drives margins above prior year levels in the back half of the year. Is that reasonable?

**CEO**
: Warranty is just a standard part in doing business. And I would say there's not any significant trends one way or another reflected in our results.

**Analyst-8**
: Okay. And from a CapEx standpoint, you've made a slight tweak to the CapEx plan this quarter. But compared to the prior guidance or the initial 2014 guidance, you're reducing CapEx by about $100 million. Can you just talk about what areas of your capital deployment plans you're tightening the belt on? But is it all around or are there any specific projects where you're delaying or holding back on?

**CEO**
: So it's really timing. There are some product and facility activities that we've got on our plans. So just the timing of executing those has been pushed out a bit as we look at when we're ready to execute on certain things. So no particular things that have been just -- it's really mostly timing.

**Operator**
: Your next question comes from the line of Joel Tiss from Bank of Montreal.

**Analyst-9**
: Just -- can you talk a little longer term about expansion plans? Maybe over the next couple of years, Brazil is going to be where you want it to be and running on track. And what would be some of the next areas that you think you can grow the company? Is it finance or geographic?

**CEO**
: Sure. Brazil is clearly an opportunity to continue just to achieve the targets that we've set out for Brazil. So that's an excellent opportunity. And as we look to the Eastern Europe, Russia, Ukraine, think about Turkey, those provide some good opportunities upside long term. As we talked about Russia, short-term challenges but long term, we feel good about that. And then Asia is an opportunity where, as you know, we don't have great participation in the truck market at this point. And we've got offices in India and China that represent us well. And we have a technical center in India. We do a lot of procurement in those areas. And so we stay very close to those markets to understand what the trends are and continue to look for an opportunity at the right time to participate. But at this point, nothing short term in our drawing board.

**Analyst-9**
: I know you guys won't help us probably with anything behind the scenes on merger talks with Volkswagen. But can you just remind us what the company's sort of overall thinking is on selling the company or anything like that? Do you feel like you guys are always for sale at the right price? Or do you feel like there's nobody who can do a better job than the current management team, so there's no need. You know what I mean? Just sort of the philosophical angle on how you think about that.

**CEO**
: Joel, I mean, there have been no discussions with Volkswagen and the company continues to focus on running the business day in, day out, and we've got a great team and that's our focus.

**Operator**
: Your next question comes from the line of Patrick Nolan from Deutsche Bank.

**Analyst-10**
: Most of my questions have been asked, but I just had 2 follow-ups. First on PACCAR Financial, continues to improve there on a year-over-year basis. Can you just give us some color on what you expect for the remainder of 2014 and into next year?

**CEO**
: Yes. The asset base has continued to grow. Our teams there have done an excellent job of representing our capabilities in the marketplace. There's -- as time goes on, particularly North America, as the truck markets improve, more and more competitors like to wade back into the market. But our teams -- we have great service capability and continue to win. About 30% of the new PACCAR trucks that get sold are funded by our PACCAR Financial and PACCAR Leasing businesses. So we'll continue, I think, to see that as the retail sales grow so, too, will our asset base, somewhat. And so that would be a positive development for us as we progress through the year. And customers with the good freight conditions are performing very well and paying their truck payments. We continue to see past dues below 1% in our portfolio. So no indications that, that's going to change in the near term. But -- so good performance by our finance team and used truck markets are in good shape. We've seen probably 4% to 5% appreciation in used truck prices year-on-year. So things are in good shape and the teams are executing very well.

**Analyst-10**
: And can you expand on your ability to raise rates to customers as your borrowing costs could start to move higher as you move into 2015?

**CEO**
: We're typically -- the yield to the customer typically moves -- maybe it's not basis point by basis point, but generally moves in the same direction as our borrowing cost.

**Analyst-10**
: And if I could just sneak one quick one. On the SG&A, it actually came down sequentially on an absolute dollar basis despite the increase in revenue in the quarter, sequentially. Was there any timing issues we should be thinking about there or is that a pretty clean number?

**CEO**
: It's a pretty clean number. Yes, the first quarter had, typically, has a little bit more, I think, stock compensation-related expenses included in it, so that's pretty steady as she goes.

**Operator**
: Your next question comes from the line of Steven Fisher from UBS.

**Analyst-11**
: You guys have a pretty diversified customer base in North American heavy-duty truck. How should we think about what types of customers are only replacing versus those that are actually expanding capacity at this point?

**CEO**
: I guess, I would say that in any sector there's probably a combination of some, and then there are probably some that are actually downsizing depending on their trends in the business. So I don't know if I see any...

**Analyst-11**
: Or maybe I'll ask it this way. In terms of sort of larger fleets versus independent operators or midsized, any differentiating trends among those classifications?

**CFO**
: I think that our customers are seeing a good rate environment. They have generally high-utilization rates and generally across-the-board, irrespective of the fleet size or the vocation, are continuing to replace equipment and expanding their fleet to accommodate the new opportunities with a little bit better economy out there. And I wouldn't say that there's one segment that is unique in that regard. It's really across-the-board with all of our customer segments.

**Analyst-11**
: Okay. And then I know you mentioned the freight growth rate in Germany. But within Western Europe, more broadly, can you maybe differentiate what demand trends you're seeing in some of these specific markets?

**CEO**
: I would say that based on what -- the statistical availability is a little more limited in Europe, but I would say that Germany is a pretty good proxy for, generally, what we're seeing in Europe in terms of freight activity. That it's probably up in most countries in Europe year-on-year.

**Operator**
: Your next question comes from the line of Rob Wertheimer from Vertical Research.

**Analyst-12**
: So one quick question on U.S. or North American production. I think you had signaled a bigger production increase than you did in the quarter. Was there anything to that? Was it the driver shortage or any other factors or is it just normal variability?

**CEO**
: No. It really was the fact that Europe was a little softer than what we had thought when we talked in April.

**Analyst-12**
: Okay. Perfect. And then just a second -- maybe I'll just wrap it all together. I don't know if you gave your MX engine penetration in North America or U.S. and Canada, however you want to do it, this quarter. And I'm curious as to whether that was margin accretive in the quarter. Yes, I'm not sure you've ever talked about that very explicitly. And then whether you've seen any stopping points, whether you've hit any saturation or whether it can continue to build in the order book.

**CEO**
: So we were at about 35% penetration for the quarter. And we'll continue, I think, as we progress, we -- you look at the MX engine and the applications that it can meet the needs of our customers. We'll continue to see that, that percentage will grow over time as you see in the marketplace, about 50%. 13-liter, 50%; 15-liter engine sales in the Class 8 market. And we think that it will continue to trend more towards 13-liter over time as people look for reduced weight per fuel economy. So we see that the prospects for the MX are good. In terms of margins, it's just part of the cost of our truck and -- so no real margin impact.

**Analyst-12**
: Okay. Now that's great. And do you have any comment on -- I think you launched in Mexico, how's the initial feedback on that? And I'll stop there.

**CEO**
: It's good. We're selling the MX in the Mexican market at a Euro 4 level. And obviously, that's a level that we sold in Europe for many years. And so it's been well received, it performs well, great fuel efficiency as well as torque and horsepower ratings. So very well received.

**Operator**
: Your next question comes from the line of Seth Weber from RBC Capital Markets.

**Analyst-13**
: So back at the Analyst Day, I think you had talked about, for Brazil, needing a kind of a build 10 units per day to kind of get a good -- to get a positive return. Can you just update us on that when you think you might get there? Is that still the right number to think about?

**CEO**
: Well, I think that's still a fair number to think about, and we're probably 2015 or so before we get to that point.

**Analyst-13**
: Can you update us on how the distribution build out's going there?

**CEO**
: Going good. Our dealers are investing in 20 locations. So several are open, several are near open and several well along in the construction phase. By the end of this year, most of the initial 20 facilities will be completed, and several of the next phase or next 20 facilities that are committed will be started. So that is progressing well.

**Analyst-13**
: Okay. And just a follow-up, the new DAF vocational trucks you introduced, I guess, this quarter, can you give us any color there and indicate was that accretive to margin in the quarter?

**CEO**
: No. It really is -- it's just the -- what it was is the -- as we transition from Euro 5 to Euro 6, these are the more complex, high-content trucks and were sort of the last batches of the DAF Euro 6 vehicles to be introduced. And so now that really completes their Euro 6 offerings but not that many sales in the quarter, but it really just replaces a comparable Euro 5 offering.

**Operator**
: Your next question comes from the line of Scott Group from Wolfe Research.

**Analyst-14**
: So Ron, I think in one of the earlier questions about margins, you talked about hey, the last cycle, we got to a really high build numbers and backlogs. I get the backlogs not there, but we're ordering trucks on a run rate north of 300,000 right now. So why isn't this the time to get more price? And do you think -- can PACCAR take a leadership role to start trying to push more pricing?

**CEO**
: Well, we feel like we always have a leadership role and we are the premium product in the market, so that's how we approach our business. And we work very closely with our customers to provide them competitive -- competitively priced vehicles that recognize the value that the PACCAR products provide. And so it's all driven by the competitive marketplace and we'll continue to maintain our leadership position.

**Analyst-14**
: Do you think this is the environment where you can start pushing pricing harder or still not there yet?

**CEO**
: Again, it's a 240,000 plus or minus truck market and some of the truck markets that we talked about previously were 300,000 truck markets. And so if you look back, over time, there's a pretty good correlation with the size of the truck market and the ability to price and leverage your cost structure.

**Analyst-14**
: Okay. And then just last question. So I see you guys increased the dividend this quarter. Can you share with us were there any discussions at the board about starting to emphasize the share buyback anymore?

**CEO**
: Yes. We have an authorization that has about $100 million or so of unused buyback capacity. So as we have, historically, we buy back shares from time to time and we'll continue to evaluate that.

**Operator**
: Your next question comes from the line of Alex Potter from Piper Jaffray.

**Analyst-15**
: I guess, first, just a housekeeping question. Can you give deliveries for Europe and North America in the quarter?

**CEO**
: So for U.S. and Canada, 20,500 trucks; 8,900 in Europe; and 4,300 for Rest of World.

**Analyst-15**
: Okay. Great. And then wanted to touch one last time here on gross profitability just to make sure I understood correctly. It sounds like -- clearly, you had nice volume in North America that helps things. Price realization in North America helps things, presumably a mixed shift towards parts helps things. But Europe, on a sequential basis, wasn't any better, wasn't any worse than it was last quarter. Is that fair?

**CEO**
: I'd say that's a pretty fair assessment.

**Analyst-15**
: Okay. Very good. And then, lastly, you mentioned in the release that you're focusing some CapEx and I guess R&D on "enhanced powertrain development." Just wondering if you can elaborate, I guess, strategically on exactly what that means? That would be very helpful.

**CEO**
: So obviously, the customers that operate our trucks are focused on the lowest total cost of ownership, and fuel being one of the more expensive parts of their cost of operation. And so we're very focused on gleaning every percent improvement in fuel economy that we can from a variety of sources, including the aerodynamics of the truck itself, the engine, operating efficiency, the integration of the engine with the transmission and axles and Aftertreatment Systems. So it's a continuous focus by our teams, both here and in Europe, to achieve industry-leading fuel efficiency.

**Operator**
: Your next question comes from the line of Adam Uhlman from Cleveland Research.

**Analyst-16**
: I was wondering if you could speak to what you're seeing in material cost trends and with the build rate in North America going up. Have you seen any supply chain issues pop up yet?

**CEO**
: So I think material costs are pretty steady. Cost movements have not been a significant factor from quarter-to-quarter even year-on-year. And in terms of supply-based performance, it's just -- it's normal business, business as usual. And our supply base is moving in lockstep with us. Any day, there might be a little bit disturbance. But all in all, suppliers are performing very well.

**Analyst-16**
: Okay. Got you. And then when you think about your build plan in North America for the second half of the year, how full are you right now? And are the orders reaching out into 2015? And along with that, have you established 2015 pricing yet?

**CEO**
: Well, I mean, we do. We have long-term orders that we assume, we take in and so there are some trucks that are on the board for 2015 delivery, it's not a significant amount. And we're -- work closely with our customers to provide them competitive pricing, whether it's short term, mid term or long term. Well, it's sort of business as you as usual in that regard so...

**CFO**
: Plants are in great shape. We have lots of capacity to handle the demand that we're seeing.

**CEO**
: Yes.

**Operator**
: Your next question comes from the line of David Leiker from Robert W. Baird.

**Analyst-17**
: This is Joe Vruwink on the line for David. When you look of the success you've had in driving growth in the Parts business, is there maybe a way to isolate the contribution from internal engines versus maybe some expanded coverage initiatives maybe just from the carry through you've had from strong new truck volumes this cycle?

**CEO**
: Well, I think all of those elements have made a contribution to the Parts growth, as well as the truck utilization. So we have very well-developed All Makes brand with TRP that services not only other makes of trucks, but the bus and trailer segment. We have the PACCAR Genuine and DAF brand of parts in Europe that are represented very well. And our Parts team put together very innovative programs to continue to build and capture a greater share of the parts marketplace. So all of those things are contributing to the incremental growth that PACCAR Parts is achieving.

**CFO**
: We should also give some credit to our dealer body. They are actively investing in their business, expanding their locations, expanding their hours of service and -- it's really a combination of the programs of PACCAR Parts and how our dealers are performing in the markets.

**Analyst-17**
: Okay. So the new Parts center that's being constructed later this year, is that just to support the existing run rate on the business or is it anticipation of any maybe additional growth initiatives you could outline?

**CEO**
: That's really supporting the continued growth and supporting our dealers that are in the Northwestern part of the U.S. And so -- but it's pretty normal. Last year, we doubled the size of our Lancaster facility and this will be essentially a doubling of our capacity in the Northwest U.S. But over time, all of our PDCs, we either expand them or build new ones to support the increased distribution opportunity that we have.

**Analyst-17**
: Okay. And then, lastly, just wanted to touch on financing sort of in the industry. So when you look at the captive credit arms of the truck companies, there's been pretty good success this cycle and kind of filling a void left by the other financing arms or the other finance hole[ph], like, commercial, let's say. Wondering if you're seeing a greater push by some of these other lending sources and sort of a chase for yield to help facilitate maybe a higher level of industry volume going forward?

**CEO**
: I think, again, as I think I've commented earlier, what we see at this point in the cycle, there are increased entrants into the financing world, which can create a more competitive pricing environment. But customers appreciate PACCAR Financial and PACCAR Leasing. The fact that we're here throughout the cycle, we only finance trucks and trailers for the industry. Our people are well versed in providing the best service, so that's a real competitive advantage for our team.

**Analyst-17**
: Would you expect your penetration levels to stay pretty much the same and does that need to come at the expense of maybe in that margin?

**CEO**
: No. I think 30% penetration is about where we'll stay.

**Operator**
: Your next question comes from the line of Neil Frohnapple from Longbow Research.

**Analyst-18**
: Clearly, you had a strong parts revenue quarter. But as customers are increasing the replacement of their aged fleets, are you anticipating any sort of parts revenue slow down or growth to at least decelerate at some point like in 2015 due to the strength of the new truck sales that would essentially bring down the average age of the fleet?

**CEO**
: I don't think that will be a significant factor. Again, with the new truck volumes, there's still lots of parts opportunities that go with outfitting trucks and accessories, et cetera. So I don't see that as being a major factor in terms of parts movement.

**Analyst-18**
: All right. And then just a quick follow-up to Scott's question on production in Brazil. You mentioned at the Analyst Day you guys were building 2 trucks per day. What's your daily production rate today and have you seen progress since then towards the 10 per day?

**CEO**
: Yes. We've increased that to 3.

**Operator**
: Your next question comes from the line of Ted Grace from Susquehanna.

**Analyst-19**
: Two quick kind of cleanup questions. One, could you just comment on the impact of FX in the quarter both on OE side of the business in the Parts from a revenue and a profitability standpoint just so we appreciate what that dynamic was?

**CEO**
: Ted, we're gathering the -- yes, the overall impact on revenues for the quarter compared to prior quarter was about $60 million and about $3 million of pretax profit impact from currency movements. And mostly due to the euro being stronger this year compared to last. You're interested in breaking it down between...

**Analyst-19**
: Just differentiating between truck and the Parts business to see if there was a -- just so I'd appreciate -- at the segment level, I had to think about it.

**CEO**
: Yes. I mean, for the quarter, for the truck side, the impact to currency was about $1 million and about $10 million on the revenue side.

**Analyst-19**
: Okay. And then the balance would have gone to Parts?

**CEO**
: Yes. Pretty close to that. I mean, there are some other pieces there as well. But the Part side, there's some mixed things in there as well. The Parts' size is about $9 million on the revenue side and about $3 million on the market.

**Analyst-19**
: Okay. That's helpful. And then the last thing, obviously, a strong quarter and you raised kind of your outlook for the market. Execution, very strong as we've come to expect with PACCAR a bit. Ron and Bob, when you sit back and think about kind of the concerns you have out there, whether they're within your control or outside your control, can you just maybe walk through the 1 or 2 items that consume that part of your day the most?

**CEO**
: Yes. The -- it's sort of business as usual. It's -- there's always challenges day to day, week to week. But the opportunities we continue to focus on investing in our business throughout the business cycle, continue to focus on rigorous cost control, continue to focus on managing our plant metrics, our warehouse capabilities so that we're prepared in the good markets, the challenging markets. And so we're just -- we'll just stay focused that they. It's how we operate our business and that's how we'll continue to approach it.

**Analyst-19**
: Absolutely. And it's a very rigid dividend. But said otherwise, there's no one kind of outstanding issue that's consuming more of your time than any other?

**CEO**
: No. I'd say, at this point, nothing that stands out. That's a real challenge or that's a real opportunity. It's pretty steady, it's pretty focused in all facets of our business.

**Operator**
: Your next question comes from the line of Jeff Kauffman from Buckingham Research.

**Analyst-20**
: I got to tell you, most of my questions have been answered by this point, so let me just throw one on the balance sheet. What level of cash do you like to keep optimally? You mentioned the dividend increase, you mentioned the share repurchase authorization, but you have reduced your capital spending, the R&D is coming down and you're sitting with roughly $2.6 billion of cash and marketable securities. What's the right level of cash to be sitting on?

**CEO**
: I feel very comfortable with where we're at. Currently, you look back at history and the relationship of cash to our total balance sheet, where we're really sort of where we've historically been. And so we're quite comfortable with that. And as we said, we just upped our regular dividend payout and we'll continue to evaluate the opportunity for additional returns to shareholders in the forms of special dividends and/or share buybacks.

**Operator**
: Your next question comes from the line of Steve Wilhelm from Puget Sound.

**Steve Wilhelm**
: This is actually Puget Sound, it's Steve Wilhelm. This is pretty much Renton focused. The 2 things I wanted to ask about in terms of the distribution center, could you say a little bit more about why you're doing it and how much it will cost? I mean, how many people it will employ and when it will be done?

**CEO**
: Well, we have a distribution center in Renton currently. It's about half the size of the proposed facility. And it's just -- the level of parts distribution activity in Northwest United States and Western Canada has increased, and so it's time to support that increased business activity. Our dealers continue to invest and reinvest in their businesses and add new locations. And so that increases the parts opportunity. So we won't see a significant change in employment levels because we -- just the distribution center employees will move from their current location to the new location. And as we continue to grow, there'll be some incremental employment as time goes on but it's not a significant amount of additional.

**Steve Wilhelm**
: How many are there now and how much are you investing on this?

**CEO**
: Yes. I don't know those numbers right off the top of my head, Steve.

**Steve Wilhelm**
: Okay. If I could find out later, that would be great. And then secondly, in terms of the -- well, all right, in terms of the Renton plant of the factory, what's the -- how many people are there and what's the status of production with the increases, in general? If I remember right, I thought you were building specialty trucks there mostly. And are you going to be building any long-haul trucks again or not, kind of what's -- where is that going?

**CEO**
: Continue -- the folks in that plant continues to be specialty trucks. And just as we have done in our other facilities in North America, Renton is also being able to increase its build rates somewhat here during this period of strong order demand. So good for the Renton campus, our Renton campus group.

**Steve Wilhelm**
: Could you -- well, you put a number on a couple in terms of Brazil. Could you say how many trucks you're producing a month or something? How much that's gone up and maybe how many people?

**CEO**
: So again, I don't have all those details, but we can come back to you on that.

**Operator**
: Your next question comes from the line of David Raso from ISI Group.

**Analyst-21**
: Just a quick question on the truck deliveries in Europe. Obviously, seasonally, we go down the third quarter, but just to have a better feel about how we're looking at the current order book and how you're thinking about deliveries for fourth quarter in Europe. Are we back above the 10,000 level for the fourth quarter? Just trying to think about extrapolation sequentially off what I'd suspect will be the bottom of the build schedule during this year's third quarter.

**CEO**
: Yes. Dave, we're -- we continue to be a build-to-order company. And if we get the orders, we will build them. We feel positive about the potential for additional trucks in the fourth quarter, but it's too soon to have a clear indication of whether that's the case or not.

**Analyst-21**
: Well, I guess asked another way. I mean, earlier, the comment was -- was it, is it macro versus what's in the order book. I mean, can you give us some feel for orders on hand for the fourth quarter, just so we have an idea how much is macro, new orders, independent versus what's already there.

**CEO**
: Yes. It's just -- it's mostly macro. It's based on sort of economic trends and the opportunities that we see there. It's not the order book as it exists today.

**Operator**
: There are no other questions in the queue at this time. Are there any additional remarks from the company?

**Other**
: I'd like to thank everyone for their excellent questions. And thank you, operator.

**Operator**
: Ladies and gentlemen, this concludes PACCAR's earnings call. Thank you for participating. You may now disconnect.