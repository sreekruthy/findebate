## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning and welcome to Deere and Companys second quarter earnings conference call. Your lines have been placed on listen-only until the question-and-answer session of todays conference. I would now like to turn the call over to Mr. Tony Huegel, Director of Investor Relations. Thank you. You may begin.

**CTO**
: Thank you. Also on the call today are Raj Kalathur, our Chief Financial Officer; and Susan Karlix, our Manager of Investor Communications. Today well take a closer look at Deeres second quarter earnings, then spend some time talking about our markets and our outlook for the second half of fiscal 2014. After that well respond to your questions. Please note that slides are available to complement the call this morning. They can be accessed on our website atwww.johndeere.com. First, a reminder. This call is being broadcast live on the Internet and recorded for future transmission and use by Deere and NASDAQ OMX. Any other use, recording or transmission of any portion of this copyrighted broadcast without the express written consent of Deere is strictly prohibited. Participants in the call, including the Q&A session, agree that their likeness and remarks in all media may be stored and used as part of the earnings call. This call includes forward-looking comments concerning the companys plans and projections for the future and are subject to important risks and uncertainties. Additional information concerning factors that could cause actual results to differ materially is contained in the companys most recent Form 8-K and periodic reports filedwith the Securities and Exchange Commission. This call also may include financial measures that are not in conformance with accounting principles generally accepted in the United States of America or GAAP. Additional information concerning these measures, including reconciliations to comparable GAAP measures is included in the release and posted on our website at www.johndeere.com/financialreports under Other Financial Information. Susan.

**Other**
: Thank you Tony. Today John Deere announced earnings for the second quarter of 2014 and it was another solid performance. In reporting income of almost $1 billion, the company again demonstrated a depth execution of its operating plans, keeping costs and assets under control, while successfully managing major new product transactions. In addition, Ag and turf profits were somewhat lower. However, construction and forestry and financial services operations had significantly improved results. In our view this reflects the power of our broad based business lineup and it is one of the reasons we are continuing to call for full year income of $3.3 billion. Now lets take a closer look at the second quarter in detail, beginning on slide three. Net sales and revenues were down 9% to $9.9 billion. Net income attributable to Deere and Company was $981 million. EPS was $2.65 in the quarter, thats the second highest earnings per share in the company history. On slide four, total worldwide equipment operations net sales were down 10% to $9.2 billion. In the quarter-over-quarter comparison of net sales, Landscapes accounts for three points of the change. Also included is an unfavorable impact from currency translations of one point. Price realization in the quarter was positive by two points. Turning to a review of our individual businesses, lets start with Agriculture & Turf on slide five. Sales were down 12%, primarily due to lower shipment volumes, as well as a three point landscapes impact noted on the previous slide. Operating profit was $1.2 billion. Before we review the industry sales outlook, lets look at fundamentals affecting the Ag businesses. Slide six outlines U.S. Farm Cash Receipts, which are forecast to be down somewhat from 2013. Assuming trend yields, grain production levels are expected to be up in 2014, which would result in lower feed grain prices. Livestock receipts are forecasted to remain at record levels. As a result, our forecasts calls for 2014 cash receipts to be about $393 billion, down only 3% from 2013, which was the second highest level ever recorded. On slide seven, global grain stocks to use ratios remain at sensitive levels, even after abundant harvest in 2013. The southern hemisphere, notability Brazil and Argentina is just now concluding the large harvest of both corn and soybeans. Planting is well underway in North American where farmers appear to be shifting some acreage from corn to soybeans in response to relative prices. But even though supplies appear to be adequate, global grain and oil seed demands remain strong. Unfavorable growing conditions in any part of the world would hurt production, reduce the stock to use ratio and result in prices quickly moving higher. Our economic outlook for the EU 28 is on slide eight. There are signs of economic stabilizations and cyclical recovery, with a modest forecast increase in GDP growth and rising business and consumer confidence. With feed costs easing strong beef prices and near record milk prices, margins remain supportive for livestock and dairy farmers. While remaining near long term averages, grain prices and farm income are expected to decrease in 2014. As a result, farm machinery demand is expected to be lower for the year. However, a differentiated picture continues to exist by country. While we see demand improving in the U.K. and Spain, some decline in important markets like France, German and Poland bears watching. On slide nine youll see the economic fundamentals outlined for other targeted growth markets. In the CIS, slowing economic growth and product availability continues to weigh on equipment sales, while import polices are negatively impacting combine sales in Russia, Kazakhstan and Belarus. As geo political tensions between Russia and Ukraine continue, fewer acres are being planted and less inputs such as fertilizers and insecticides are being used, putting the 2014 crop at risk. Slide 10 illustrates the value of agriculture production, a good prospect of the health of agro business in Brazil. The 2014 value of agriculture production is expected to increase about 5% over the 2013 levels. Brazil Soybeans product is expected to increase again this year, with yields of historically high prices and margins. On the other hand, while partially offset by the weak real, lower global commodity prices could reduce farm income. Our 2014 Ag and turf industry outlooks are summarized on slide 11. In the U.S. and Canada we continue to expect an Ag industry decline of 5% to 10%. The EU 28 industry outlook remain down about 5% due to lower crop prices and farm income. In South America, industry sales of tractors and combines are now projected to be down about 10% from 2013s strong levels. South America continues to grow in importance for Deere. In April we introduced over 60 new products in the region, including 5E Series tractors with cab, self-propelled sprayers for sugarcane, planters and a new complete lineup on combine. Shifting to the CIS, we now expect industry sales to be down significantly, while in Asia, sales are projected to be up slightly. Turning to another product category, industry retail sales of turf and utility equipment in the U.S. and Canada are now projected to be flat to up 5% in 2014. This slight change in our outlook is mainly due to the impact the harsh winter had on sales in the first half of the year. Putting this all together on slide 12, fiscal year 2014 Deere sales of worldwide Ag and turf equipment are now forecast to be down about 7%. In the year-over-year comparison of net sales, landscape accounts for about three points of the change and negative currency translation accounts for about one point. The one point reduction in our forecast from last quarter mainly reflects lower industry outlooks for Ag sales outside the U.S. and Canada and for the turf business. 2014 operating margin for the Ag and turf division is forecast at about 14%. The two point decline in operating margin from 2013 is a result of volume, mix, foreign exchange and higher production costs, including implementation costs related to final tier 4. We have talked for some time about how a favorable mix associated with strength in the large Ag sector has been benefiting margins by one to two points. This year the mix benefit is forecast to be about one point. The mix benefit in 2013 was two points. Lets focus now on construction and forestry, on slide 13. Net sales were up 2% in the quarter and operating profit was up 63%. The divisions and incremental margin of 196% is a result of C&Fs diligent focus on cost and the law of small numbers. Moving to slide 14, looking at the economic indicators on the bottom part of the slide, youll note that although the fundamentals are all lower than three months ago, the economy is slowly moving forward and there are positive signs in the market. Unemployment is falling and construction hiring is increasing. Housing starts are slowing ramping up, home inventories are low and prices are improving. Landscaping activity is picking up and financing for land developers is slowly recovering. Additionally, we continue to see a strong domestic energy sector. Deeres construction and forestry sales are forecast to be up about 10% for the year, which is unchanged from a quarter ago. The increase reflects higher shipments following the low levels of 2013, as well as industry growth in response to an improving U.S. economy and increased international sales. Global forestry markets are now expected to be up about 10% in 2014. Following double-digit growth in 2013, North American forestry markets are expected up about 10%, while Europe and Russia are expected to improve from the depressed levels of 2013. C&Fs full year operating margin is projected to be about 9%. Lets move now to our financial services operations. Slide 15 shows the financial services provision for credit losses as a percent of the total average owned portfolio at 30 April with five basis points, reflecting the continued excellent quality of our portfolios. Our 2014 financial forecast contemplates a loss provision of about 12 basis points. Losses remain well below the 10-year average of about 28 basis points, and the 15-year average of 48 basis points. Moving to slide 16, worldwide financial services net income attributable to Deere & Company was $148 million in the second quarter versus $125 million last year. 2014 net income attributable to Deere & Company is forecast to be about $600 million, which is unchanged from a quarter ago. Slide 17 outlines receivables and inventory. For the company as a whole, receivables and inventories ended the quarter down $603 million. That was equal to 32.1% of prior 12-month sales, down from 33% a year ago. Ag and turf ending receivables and inventory were down $554 million. Most of the decrease was accounted for by John Deere Landscapes and John Deere Water. Construction and forestry ended the quarter down $49 million, driven by lower Canadian consigned inventories. We expect to end 2014 with receivables and inventory down about $175 million. Our 2014 guidance for cost of sales as a percentage of net sales shown on slide 18 is about 75%. When modeling 2014, keep in mind the following: price, about two points; lower pension OPEB expense; less favorable mix of product, overhead spend due to tier 4 transaction, tier 4 product cost and foreign exchange. Looking at R&D expense on slide 19, R&D was down about 6% in the second quarter, mainly due to timing of projects. Our 2014 forecast calls for R&D expense to be down about 1% compared to last year. Moving now to slide 20, SA&G expense for the equipment operations was down about 14% in the second quarter and is forecast to be down about 7% for the year. In the year-over-year comparison of SA&G expenses, Landscapes accounts for about seven points of the change and water about one point. On slide 21, pension and OPEB expense was down about $40 million in the quarter and is forecast to be down about $150 million for the full year. Turning to slide 22, the equipment operations tax rate was approximately 32% in the second quarter. One of the discreet items benefiting the tax rate in the quarter related to John Deere Water as noted in our financial statements. For full year 2014, the effective tax rate is now forecast to be in the range of 33% to 35%. On slide 23 you see our equipment operations history of strong cash flow. Our forecast for cash flow from equipment operations is approximately $4 billion in 2014. Slide 24 highlights share repurchase activity since 2004. Of note is our strong share repurchase activity year-to-date, which has exhausted our 2008 repurchase authorization. Repurchases are now taking place under the $8 billion authorization announced in December. On slide 25 and 26 we outlined our 2014 outlook for the third quarter and full year. Our net sales forecast for the third quarter is down about 4% compared with 2013. This includes about two points of price realization. In the year-over-year comparison of third quarter sales, Landscapes accounts for about four points of the change. The full year forecast calls for net sales to be down about 4%. In the year-over-year comparison of net sales, Landscapes accounts for about three points of the change. Price realization is expected to be positive by about two points; FX is expected to be negative by about one point. Finally our full year 2014 net income forecast remains at about $3.3 billion. In closing, John Deere expects to achieve near record earnings for the full year and the company is well positioned to deliver solid financial results throughout the business cycle. We are confident our investments in new products and markets, coupled with a tight reign on costs and assets will keep our growth plans moving ahead. As for our plan, we believe they are essential to helping meet the worlds growing need for food, shelter and infrastructure and we continue to believe John Deere is exceptionally well positioned to benefit from these developments in the quarters and years to come. Tony.

### Q&A
**CTO**
: Now were ready to being the Q&A portion of the call. The operator will instruct you on the polling procedure. But as a reminder, in consideration of others, please limit yourself to one question and one related follow up. If you have additional questions, we ask that you rejoin the queue. Operator.

**Operator**
: (Operator Instructions) The first question comes from Jamie Cook with Credit Suisse.

**Analyst-1**
: Hi, good morning. I guess two questions; first, Tony or Susan if you could just provide some color on how the order book has trended relative to last quarter with some of the new tier 4 final products introduced. Whether youve seen any drop off in how youre thinking about visibility for the second half of the year. And then I guess my second question just relates to the implied decremental margins in the back half of the year in Ag. It seems like they should be worse in the back half given your top-line assumptions. I thought the second quarter probably would have been the worse with production down more. If you can just walk me here if theres anything Im missing there? Thanks.

**CTO**
: Sure, yes and first of all of the order book, I think maybe as an overarching comment on large Ag in particular, what we would tell you is if you think about the retail order coverage that we have on our forecast, we would tell you compared to last year we would be roughly inline. Its slightly below where we were a year ago, but again, roughly in line with the order coverage we have on the forecast. So again, I think trending pretty well there. Specifically related to final tier 4, we talked about this last quarter as well with specifically the 8R tractor, where we were seeing very strong orders for that final tier four tractor. Didnt really see any kind of drop-off at that time. Our order book, we often talk about where were at from an availability perspective and we would tell you on 8Rs our order availability is into October. There is some availability remaining on that product for the year, but well into October in terms of that availability. So again, pretty good story from that perspective.

**Analyst-1**
: Any color on combines Tony.

**CTO**
: Well again, it wouldnt have changed much from our second quarter. You know our early order program tends to pretty much fill out that program and we saw that order fill pretty much the way we had anticipated and again have, we feel pretty good in terms of the order coverage obviously to the forecast cast we have in place today.

**Analyst-1**
: Sorry, then the second question on the implied detrimentals in the back half.

**CTO**
: On the detrimentals when you keep in mind that as you look historically at our cost of sales, second quarter tends to be the best; the lowest cost of sales as a percent of net sales of any, and that will true this year. But if you look at the differential in whats implied in the outlook, you will note that second quarter relative to the comments that you mentioned with the transitions we had, second quarter isnt as strong as what you would normally see, but it still is forecast to be our best quarter from a lower cost of sales as a percent of net sales kind of ratio. So I guess that I would argue that you are seeing in the forecast in terms of the differential not being as broad as what you would normally see.

**Analyst-1**
: Okay, thanks. Ill get back in queue.

**CTO**
: Thank you. Next caller.

**Operator**
: Your next question is from Seth Weber, RBC Capital Markets.

**Analyst-2**
: Hey, good morning everybody.

**CTO**
: Hey Seth. How are you?

**Analyst-2**
: How are you? Good thanks. Two questions, so just your level of confidence in the construction and forestry up 10% for the year. I mean that suggests a pretty powerful ramp here in the second half, something like the high teens growth rate for each of the third and fourth quarters. Can you just maybe give us a little bit more color there on how of that is dealer restocking and how much of is some of the new production you are adding and then I have a follow-up question.

**CTO**
: Sure, yes. And we would tell you again, that outlook as you mentioned hasnt changed. Its always, and we talked about this throughout the year, it always has recognized more strength in the back half. Remember, to be fair, the comps do get a bit easier in the back half of the year, year-over-year, but if you look, our order book is up strong. We tell you that the order book is up double digits. We feel pretty good about that. As it breaks down though, when you think about where are those higher sales coming from, we would tell you about three-fourth of the sales are coming from our U.S. and Canada market and about a quarter of the sales increase will come from outside the U.S. and Canada. We didnt break out how much is inventory versus retail, but again as you talked about before, certainly the inventory build is a fair amount of that increase for U.S. and Canada as we ended last year with very low inventory levels versus being what the market was last year. So our dealers are building inventory in anticipation or expected to build inventory, both in anticipation of the higher retail, as well as we would argue kind of right sizing from a pretty strong pull down last year.

**Analyst-2**
: Okay, thank you and then just to follow up on Brazil, the change in outlook for the South American market, that tempered a little bit. I mean is that still around the tsunami dislocation or is there something that you feel like has actually softened in the overall market.

**CTO**
: Yes, first I want to make sure were clear. Thats tractors and combines only, so it wasnt applied to the remaining part of our business, which is a significant part of our sales in South America. Its primarily driven by a little bit of softening in a couple of markets, really around tractor. So if you think about Argentina, some challenges with import tariff and thats primarily impacting tractors, at least for Deere and then also the sugarcane industry had little bit weaker markets in Brazil, a little weaker margins and we would anticipate sales to be a bit lower than what was previously expected on tractors and to that industry as well.

**Analyst-2**
: Okay, thats very helpful. Thank you very much.

**CTO**
: Thank you. Next caller.

**Operator**
: And your next question comes from Steven Fisher, UBS.

**Analyst-3**
: Hi, good morning. I wonder if you could just talk a little bit about the cost actions that you took in the quarter, where were they focused, how quickly can they kind of give you some pay back and how much more runway do you have on cost actions from here, should things deteriorate a little bit further?

**CTO**
: I mean, I think as we talked about and as we anticipate and see the markets changing with our FDA structure, we do have what we refer to as lever studies and expectations of what we can pull. I think part of what your seeing and in the quarter actually as it relates to C&S for example, we pulled a number of levers last year at the division and its been slow to release those levers until we see those very strong sales that were anticipating coming through. Theyve kept some of those pulled to the extent they can and I think really as you move forward in the upcoming years, it depends on what the market provides, there are a number of things we can do. You saw quite a bit of discipline around R&D and SA&G in the quarter for example. Some of that to be fair is timing of projects. SA&G for example tends to be a little higher in the back half of the year for a number of reasons, but those would be the things we would think about certainly in terms of levers that we could pull if necessary to keep our margins as strong as possible.

**CFO**
: Steve, this is Raj. As you know, the process we have is byproduct. Almost every unit is looking at where they are on the line. You talk about in the 8120 or depending on the product it might vary that line and they need to provide us expected return at different points in the line, okay different returns. So each one of them is working automatically on whether its cost of sales items or SA&G items okay, how they can get to walk down the line if they are coming down or walk up the line. So you have hundreds of things going on in the company depending on where that particular product line is, they may take a different action at another product line. So you are seeing us walking down the line and thats the benefit you see. If some portions of large Ag are coming down and you can expect them to walk down the lines there. If our small Ag is going up to North America, theyll walk up the line.

**Analyst-3**
: Okay, thats helpful and then just a question on the small equivalent side in Ag. It seems to be holding up better than the larger side. Can you just talk about sort of the visibility you have there and if theres pent up demand thats coming through now and what sort of a feed outlook looking maybe a little flatter, what kind of visibility you have there on the small equivalent side.

**CTO**
: Yes, on small Ag versus large, I mean this is a broad statement and our order book would not be as far out and rarely would be versus the large. So you dont have quite as much visibility, but certainly as expected were seeing strength in that market. Livestock margins continue to remain very strong and are expected to really through the year and most are expecting it to continue to be strong, even in the next year and thats a market thats had some struggle in the recent years. So pent-up demand is hard to measure, but you can argue that a market or a part of our business that has had lower sales in recent years and has the opportunity to just from a cycle perspective to improve that as we move forward and thats really what were seeing today.

**Analyst-3**
: Thank you.

**CTO**
: Thank you. Our next caller.

**Operator**
: Your next question is from Andrew Casey, Wells Fargo.

**Andrew Casey – Wells Fargo**
: Thanks. Good morning everyone.

**CTO**
: Good morning.

**Andrew Casey – Wells Fargo**
: Thanks Tony. Was there any specific region that is driving the $50 million decrease in the trade receivable and inventory outlook for 2014?

**CTO**
: I dont believe theres any specific region that we would point to, that would be driving that reduction. We tend to look at it from an enterprise perspective, so I dont have a great answer for you on that Andy.

**Andrew Casey – Wells Fargo**
: Okay, thanks. And then I guess a follow-up on that is...

**CTO**
: Youre talking on C&F on the quarter?

**Andrew Casey – Wells Fargo**
: Yes.

**CTO**
: Actually I would argue, some of that is going to be Canada. If you look at it at a region, we talked a lot last year, a bit last year about consigned inventory in Canada. Well, its was a bit high and that came down nicely and year-over-year is actually down very nicely. I was thinking for the year, but certainly at this point in time its I would argue, Canada.

**Andrew Casey – Wells Fargo**
: Im sorry Tony, I didnt ask the question right. The $50 million reduction in the Ag and turf segment for the year, down 275 versus prior...

**CTO**
: Oh, between Ag and turf, no. I think again that your really looking at kind of minor adjustments here and there. I would argue that its a relatively  given that versus the total receivables in inventory, thats a minor adjustment.

**Andrew Casey – Wells Fargo**
: Okay, and is that all behind you with Q2 or does some of that remain ahead.

**CTO**
: Well, keep in mind, much of where were at Q2, so I would say its still ahead, because if you look at Q2, much of that is really driven by lower receivables and inventory as it relates to landscapes and water. If you took those out your relatively flat year-over-year and so when you get to the end of the year well have further pull out.

**Andrew Casey – Wells Fargo**
: Okay, Ill follow-up. Thanks.

**CTO**
: And I add that and I do want to point out for others as well. Keep in mind that as you look at the end of Q2 versus the year end, there is a difference in terms of year-over-year compare. So last year at the end of Q2 under landscape inventory and receivable would have been in our reported numbers. They were not in our year end numbers, so thats why when you look at the Q2 reduction, its much greater than what were anticipating for the end of the year, but if you pull out the impact of landscapes youll see a greater reduction actually at the end of the year versus where were at currently. Next caller.

**Operator**
: Your next question is from Adam Uhlman, Cleveland Research.

**Analyst-5**
: Yes, hi guys. Good morning.

**CTO**
: Hello.

**Analyst-5**
: I guess first of all on construction and forestry, if you could start by addressing the price realization you got in that business and also talk about how the tier 4 final price increases are coming through?

**CTO**
: Yes, specific to construction and forestry, we dont talk about price realization by division. So we did talk about two points of price realization for the year on an enterprise basis and what we would tell you is in our current forecast we would anticipate both divisions participating in a positive way on price realization and so again, thats about all we really talk to from a price perspective. If you think about our final tier 4, we do have some constrains. I dont know if that was a broad comment or if that was specific to construction and forestry.

**Analyst-5**
: Maybe if you could just address both.

**CTO**
: Yes, so if you think about that broadly, final tier 4, while we do have some construction products transitioning in 2014 and its more or less a large Ag transition year more than construction and in that regard from a cost perspective, we would tell you that we would anticipate recovering all of the cost on large Ag in the year. We are still recovering some of the interim tier 4 costs actually on construction and forestry, so we can tell you by the end of the year our forecast would estimate roughly 90% recovered on interim tier 4 and remember, construction, because of the size of the product, the horsepower range of the product tended to be about a year behind in the transition from what Ag was, so were making good progress, kind of on plan.

**CFO**
: So Adam, this is Raj. On the topic of price utilization, with regards to C&S, we did say in our press release about higher sales discounts and heres a competitive environment we are facing and we have built our share over a long period of time based on providing better products, better services and better business processes. So you should expect us to defend our share while delivering healthy margins.

**Analyst-5**
: Okay, got you. So with the kind of positive price this quarter, but thats the goal for the year.

**CTO**
: Well, I mean I think if you ask specifically about the quarter, that would be true, but keep in mind, as you think about price realization and the mention of sales incentives in the press release with accrual accounting as the assumptions change in terms of your anticipation on what are these sales incentives or any other types of accruals like that, keep in mind, the accrual change is not just for current sales, but also for the population thats in the field already that you recorded sales in the past. So you do get a larger than expected increase in that particular quarter. And again, I think its more important really to look at it from an annual perspective as it relates to that and again, that would be a positive price realization for the year.

**Analyst-5**
: Okay, thank you.

**CTO**
: Okay, thank you.

**Operator**
: The next question is from Jerry Revich, Goldman Sachs.

**Analyst-6**
: Good morning. This is Matthew Rybak on behalf of Jerry. First, I was wondering if you could talk about the impact of tier 4 conditions on factory costs in the quarter and then possibly update us on the timing of major product line transitioning costs in the coming quarters.

**CTO**
: Yes, I mean we dont talk about specific cost levels. The cost pieces as you may recall beginning in 2013, we changed our guidance and we talk about the total cost of sales as percent of net sales and at that time we discontinued the individual pieces of the dollar amount. But certainly it was a factor and as you look at the cost of sales for the quarter. But I would tell you if you look at things like mix and FX, those were also very significant impacts in the costs. As you go forward through the year there would be some, but the majority of those transitions would be behind us, at least as it relates to large Ag and again we have some significant transitions coming up for next year, 2015 as we transition small Ag, as well as a pretty large number of construction and forestry products.

**Analyst-6**
: Perfect. And then can you talk a little bit about the drivers of your CapEx reduction guidance this year and maybe where your cutting investment and talk about your longer term CapEx plans compared to significant new facility investments youve made over the past couple of years.

**CTO**
: Yes, I would tell you that that CapEx reduction is really just minor adjustments and as we get closer to the end of the year, really examining what we would expect to complete this year. As you might imagine, many of those projects are multi year projects, so whats going to get done this year versus next, those sort of thing. So I would not read much into that adjustment that we made there. And then you know we talked about from the longer-term perspective. At least in the short to mid term that $1.1 million to $1.3 million range is what you should anticipate as you report and thats not just new facilities. Remember we had with final tier 4, thats driving a significant portion of the CapEx requirement as well and lead through 2015. We certainly have a fair number of products that continue to transition.

**Analyst-6**
: Okay, thank you very much.

**CTO**
: Okay, thank you.

**Operator**
: Your next question is from Vishal Shah, Deutsche Bank.

**Analyst-7**
: Yes hi, thanks for taking my question. Im just wondering if you can provide some more details around your C&S guidance of 10% growth this year. How much of it is coming from market growth versus inventory rebuild and whether the growth is coming from domestic and international markets and also, just any update on your thoughts on expectations for bonus appreciation as well as timing of 179 incentives. Thank you.

**CTO**
: Sure. Yes and I mentioned earlier on the call, really if you think about that 10% net sales increase for Deeres construction and forestry business, about three quarters of that is coming from U.S. and Canada, both as you mentioned inventory, some inventory restocking as well as the stronger retail environment. About a quarter of those sales come from outside the U.S. and Canada. So those are things like our businesses in Brazil, those new facilities and factories come on line and we talked about strengthening forestry demand in the European market as an example. So thats really whats driving that business. If you think about the U.S. past incentives, theres been a number of activities in converse around that, kind of moving those potential extensions forward. What we will tell you, at least what we have in our modeling. So what were anticipating in our Ag modeling is that they would both be extended, but the extension wouldnt be past until late calendar 2014 and so for Deere in terms of our 2014 benefit to our sales, it would be limited to nothing. Obviously we would have some benefit early in the year, so that would be our expectation. Again, what were modeling is the section 179 gets extended at about half the level. Not that we have any particular intelligence that would tell you that thats where it is, but effectively were splitting the difference, whether it would be at the 500,000 or not get extended at all and thats the rational for why we use that number in our modeling. But again, thats where were seeing the model line.

**Other**
: And I think the thing to keep in mind is were saying late calendar 2014 gross profit is now impacted until 2015.

**CTO**
: Right.

**Analyst-7**
: Thank you.

**CTO**
: Okay. Next caller.

**Operator**
: Your next question is from Ann Duignan with JP Morgan.

**Analyst-8**
: Hi, good morning guys.

**CTO**
: Hi.

**Analyst-8**
: I want to go back to Jamies question, just get the question answered more clearly. If you look at during combine order books for North America this year, where did it come in relative to last year, just the year-over-year change, not versus your forecast.

**CTO**
: Well, we havent talked to it. I mean we talked about large Ag being down double digits and certainly that would include our combine order book, so pretty much as expected, but certainly down double-digits.

**Analyst-8**
: And combines been a little bit more than the average?

**CTO**
: Let me look at it here, just a second Ann. If you look at combines relative to, its kind of with other large Ag products. As we look at what our industry retail sales estimates are, which obviously would be a fair chunk of that, I would tell you that they are not down more than the rest of the industry, more than the other large Ag products. I would say its pretty much right on average.

**Analyst-8**
: Okay, another large product here including things like sprayers and...

**CTO**
: Your talking sprayers, planters, well obviously our row crop tractors, four wheel drive tractors those sorts of products. Think about the product that a typical row crop framer would use.

**Analyst-8**
: Yes. Okay, and then going forward, how should we think about your financial services business in terms of the revenue come in, but larger forecasting. We shouldnt have been surprised I suspect, but we tend to finance more again as the large crop farmer in the U.S. Can you just give us a context of how we should think about that business going forward if the large row crop framer remains under pressure?

**CTO**
: Yes, I mean I think as you think about market share if you will for John Deere financial, as it relates to our Ag business in the U.S. and Canada, that would be our strongest market share business and its running right around 60% of the Ag sales, would be financed with John Deere financial and as youre aware our biggest competitor there is Cash, which takes up the bulk of the remainder. But as you move forward, to your point, while were anticipating the portfolio to increase during 2014, its because that you have  were still even though year-over-year, say over down, they are still anticipating more acceptances this year versus those that would be maturing or being paid off. If you continue to see pressure and our sales would flatten or maybe decrease, then obviously over a period of time you would see some lower portfolio and revenues. At least as it relates to U.S., Ag could potentially decrease, but youd have to make assumptions on what rest of the world and our penetration is and how that changes in the rest of the world as well. So theres obviously a lot of moving pieces there.

**Analyst-8**
: Okay, and just quickly as a follow-up to the section 179 question earlier, what are your thoughts on the mid term elections and the outcome of the mid term elections, upside potential to your 179 or downside. Do you have any thoughts on that?

**CTO**
: We really dont, we dont. Again, the assumption is that after those mid term election, again late calendar years, its likely to be extended, so...

**Analyst-8**
: Okay, thank you.

**CTO**
: Again, at least thats what we have in our base case, so...okay, thank you.

**Analyst-8**
: Yes, thanks.

**CTO**
: Next caller.

**Operator**
: The next question is from Mircea Dobre, Robert Baird.

**Analyst-9**
: Good morning guys.

**CTO**
: Hey Mirc.

**Analyst-9**
: I guess, Id like to go back to construction and forestry for a second. Im a little bit confused about a top line guidance, because if I look at the last couple of quarters, you had very good orders. You talked about very good orders here and seasonally at least it would make sense to me that the second quarter would be when we see a lot of dealer inventory restocking. Yet, weve seen readily tepid growth from a top line perspective over the last couple of quarters and your pointing out to much higher growth in the back half. Yet the economic indicators youre using in your forecast, all seem to have been adjusted lower. So can we sort of bridge the gap here? What sort of confidence do you have in your forecast at this point and what gives you that confidence I guess.

**CTO**
: Yes, I think again Ill mention a couple of things. First of all Ill point out that while those economic indicators have lowered again, and those are people from outside sources of course, but given that they are still pointing upward and then pointing towards some improved overall market conditions. The other thing I would point out. As it relates specifically to that dealer restocking, keep in mind that one of the difference for Deere versus at least many of our competitors is our order fulfillment process. We have very much a pull type system where our dealers, we dont push a lot of inventory out into the market. We allow our dealers to pull it as needed and with our pretty short order windows that we at lease attempt to have, were much more of a just-in-time type of process versus build up that inventory ahead of time sort of situation. So weve been building much closer to retail and that part of the timing difference that youll see for Deere versus maybe some of our competitors who push some significant inventory in the field ahead of those sales materializing.

**Analyst-9**
: I see and then, A&T, if we can talk a little bit about Russia too. I mean the sanctions there seem to be escalating. I know you have two plants in the country. Have you seen any impact on your operations and would you sort of characterize the risk if you would to your operations in Russia at this point.

**CTO**
: Yes, I think that obviously those conflicts, both as it relates to the Ukraine and Russia, certainly is in our forecast. We talked about that in terms of our industry outlook being down significantly. Again, especially as it relates to western manufacturers like ourselves and so there is a number of factors obviously that go into that, that ultimately a lot as a result of some of that conflict. So weve anticipated and the greatest impact we think at this point would be on the sales and so weve pulled that into our outlook. At this point, in terms of concerns around assets, those sorts of things, not a major impact and certainly at least as it relate to sales. Now that we have challenges and potential challenges around import restrictions; credit availability because of that conflict is becoming even more of a difficult situation for our customers and dealers in some cases, those sorts of things. So we are looking at how do we take some of the pressure off of our dealers, keeping inventors as low as possible and those sorts of things for a variety of reasons. It reduces our exposure, but it also helps reduce the exposure of our dealers from a longer-term perspective.

**Analyst-9**
: All right, thanks.

**CTO**
: Okay, thank you. Next caller.

**Operator**
: Your next question is from Nicole DeBlase, Morgan Stanley.

**Analyst-10**
: Yes, good morning Tony and Susan and Raj. So may be we could just talk a little bit about used equipment. I dont think thats been brought up yet. What are you guys seeing from a dealer perspective, both with respect to inventories and pricing?

**CTO**
: Yes, not a significant change from what weve talked about last quarter. Again on used combines, we can tell you, all things considered were pretty comfortable with the used combine inventory levels at our dealers. Certainly pricing we talked about last quarter, again is lower year-over-year and we tell you as it relates to at least the best intelligence we have on competitors, certainly in line with industry, in terms of those lower combine use prices. As it relates to tractors, again as we said last quarter, they are relatively high. Again, its reflective of the very strong demand that weve had on new tractors, but thats an area that we certainly continue to focus. Pricing would be down a little bit year-over-year. We tell you again to the extent we have intelligence around whats going on with our competitors, we would tell you we believe our tractor prices, these tractor prices are holding in quite a bit better than competition, but it is down slightly year-over-year.

**Analyst-10**
: Okay great, thats pretty helpful Tony and maybe just with respect to the third quarter guidance. I dont know if youre willing to give any color on this, but Im going to try any way. You said down 4% for equipment ops, any color between the C&F and the A&T segment there.

**CTO**
: Yes, thats not something we would  obviously if you look at the rest of the year kind of implied guidance. Certainly we are expecting some pretty strong quarter from our C&F division as we go in actually the rest of the year for that particular division versus what you would have implied in the Ag and turf. But other than that, there is not much more we would speak to.

**Analyst-10**
: Okay, fair enough. Ill pass it on, thanks.

**CTO**
: Okay, thank you. Next caller.

**Operator**
: The next question is from Andrew Kaplowitz, Barclays.

**Analyst-11**
: Hey, good morning. Its Alan Fleming standing in for Andy this morning.

**CTO**
: Hi Alan.

**Analyst-11**
: Tony if I could, Id like to press you a little more on your assumptions for Ag in the second half of the year. I think in Brazil you had previously talked about growth coming from some of your other product lines such as sugarcane harvesters and cotton pickers and maybe every sprayers. Is that sill something that youre expecting to see in the second half of the year? And then if you could talk about what youre seeing in Europe, it seems like its a very mixed market there and were getting I think some mixed messages from some of your competitors. So whats your visibility like and are you seeing the recovery that you expected.

**CTO**
: Sure and as it relates to Brazil youre correct and we talked about it. If you think about the business outside of tractors and combines for Deere, in Brazil would be more than a third of our sales. There are those other products. And certainly if you look at industry guidance versus Deere expectations for our net sales, we would tell you we continue to see South America as the biggest differential, partly because of the fact that you are only looking at tractors and combines in the industry outlook and as I mentioned, we have a fair amount of our sales coming from other types of products, as well as our expectation that well continue to see those market share gains that weve had in recent years, we would expect to continue. So again that would be our greatest differential. As we think about Europe, certainly as Susan mentioned in her opening comments, it is really a mixed bag and we didnt, we didnt change our industry outlook in Europe, so that would imply that we are at least on an overall basis not seeing further deterioration in that regard. We dont have the order book coverage that you would have on large Ag in the U.S. and Canada thats a typical situation there and so you can speak as well to where we are at from an order book perspective that you see in markets like the UK, which is a good market for Deere recovering off of low levels and theyve had a couple of fairly depressed years, but we are all seeing some strength there. Spain is beginning to recover. But then you have other key markets that Susan mentioned that are seeing some decline; France and Germany being the most notable, Poland notable as well. Keeping like some of that isnt so much around whats going and from a profitability perspective its partly related to that, but also in some of those Eastern European countries in particular, its a transition year. This being a transition year for common Ag policy in Europe is also having some impact in certain situations.

**Analyst-11**
: Okay, I appreciate that. And if I could you ask you a question on cash. I mean you continue to ratch it up, your repurchase activity. I know youre going to tell us that your cash priorities havent changed, but is it fair to say that you seem at least a little more confident that the intrinsic value of your stock versus where its trading is undervalued and it means that it maybe a little more worthwhile for you to be more aggressive than usual with buyback.

**CFO**
: Hey Alan, this is Raj. Yes, our cash priorities have not changed and as you know the single A rating and then the funding of operations and M&A consistently modestly raising our dividends to 25%, 35% of fair ratio in its cycle. And then when we still have the cash that we can use, we put it to us, only if we feel long term, especially long term shareholders are going to be a value added form, okay. Now when we had the $8 billion share repurchase authorization, which was about 25% of our market cap, our announcement in December. We suggested that we see that the statement of confidence in our ability to do well throughout the cycle. So as long as we are generating good levels of cash and have enough of our priority stated and our analysis indicates repurchase of value enhancing, especially for our longer-term shareholders, we should expect us to continue repurchases.

**CTO**
: Okay, thank you. Well have time for one more, hopefully quick call or questions.

**Operator**
: Your last question is from David Raso Group, ISI.

**Analyst-12**
: Hi, Ill try to be quick Tony. Just more direct question on the construction and revenue guidance. You mentioned the order book is healthy. The revenue guidance implies to the rest of the year 17% for C&F. Is the order book up that much?

**CFO**
: Yes, we dont give you exact numbers but also remember the order book is only for a certain period of time, right. These are orders for a certain period of time. It is a lot healthier that is all I can tell you right now.

**CTO**
: Its certainly superiority of that outlook and that forecast.

**Analyst-12**
: Okay, thats helpful. And the second quarter revenues for construction and forestry, I know you expected first half slower, second half stronger, I get that, but literally the second quarter. Was that revenue as you expected or above or below?

**CTO**
: For C&F, I dont think it was significantly out of line from the expectations.

**CFO**
: So overall David, its Raj again. For the total company, if you the first second quarter and the revenues coming down in the second quarter compared to our earlier guidance, now there are two things that happened. One is related to weather and we talked about turf and we talked about a little bit with Ag, especially in Canada. The second part of it has to do with places like where the geo political issues exist, Argentina and CIS. So if you look at it going forward, CIS, Argentina is where we see some more softness and we will not make up all those whether related messes in the Q2, otherwise its minor adjustments, not a significant change.

**CTO**
: And those again will be for the full company and mostly impacting Ag and I think we mentioned in the opening comments. As you think about the sales coming in lower than what we had forecasted for the enterprise, most of that lower sales was driven by Ag and not C&F.

**Analyst-12**
: Okay, I appreciate the clarification. Thank you.

**CTO**
: Okay, thank you. All right, that will conclude our call. We appreciate your participation and as always, well be available throughout the day for return calls. Thank you.

**Operator**
: Thank you. This does concluded todays conference. We thank you for your participation and you may now disconnect your line.