## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to PACCAR's fourth quarter 2015 earnings conference call. All lines will be in a listen-only mode, until the question-and-answer session. Today's call is being recorded, and if anyone has any objections, they should disconnect at this time. I would now like to introduce Mr. Ken Hastings, PACCAR's Director of Investor Relations. Mr. Hastings, please go ahead.

**CTO**
: Good morning. We would like to welcome those listening by phone and those on the webcast. My name is Ken Hastings, PACCAR's Director of Investor Relations. And joining me this morning are Ron Armstrong, Chief Executive Officer; Bob Christensen, President and Chief Financial Officer; and Michael Barkley, Vice President, Controller. As with prior conference calls, if there are members of the media on the line, we ask that they participate in a listen-only mode. Certain information presented today will be forward-looking and involve risks and uncertainties, including general, economic and competitive conditions that may affect expected results. I would now like to introduce Ron Armstrong.

**CEO**
: Thanks, Ken, and good morning. Thanks to PACCAR's 23,000 employees around the world, 2015 was an outstanding year for the company with many records established. PACCAR achieved record revenues of $19.1 billion and record net income of $1.6 billion and after-tax return on revenues of 8.4%. Net income increased 18% versus the prior year. 2015 was PACCAR's 77th consecutive year of earning a net income. These excellent results reflect the strongest North American heavy-truck market since 2006, and the highest European heavy-truck market since 2008. In addition, PACCAR Parts earned record pre-tax income and PACCAR Financial Services achieved another strong profit year. PACCAR celebrated several important milestones in our 110th anniversary year. This included the delivery of DAF's 1 millionth truck, the production of the 100,000 engine in our Mississippi engine factory, and 35th anniversary celebrations at Peterbilt's Denton, Texas factory, and at PACCAR leasing. During the year, PACCAR continued investing in premium quality products and services in our core markets, and expanding our presence in emerging markets to provide the foundation for future growth. PACCAR's fourth quarter sales in Financial Services revenues were $4.4 billion and quarterly net income was $347 million, a strong 8.8% after-tax return on revenues. During the quarter, European truck deliveries increased, partially offsetting reduced North American truck deliveries. The strong contribution of all company segments enables PACCAR to attain the highest operating margins in our industry. PACCAR declared cash dividends of $2.30 per share last year, a 25% increase compared to 2014 and the highest total dividend in company history. The regular quarterly dividend was raised by 9% during the year. PACCAR's total dividends in 2015 provided a yield of over 4%, which is in the top 100 companies in the S&P 500. During 2015, PACCAR repurchased 3.8 million shares of its stock for $202 million. PACCAR delivered 35,400 trucks during the fourth quarter, in line with expectations. Vehicle deliveries and truck and other margins in the first quarter this year are projected to be comparable to the fourth quarter. Peterbilt and Kenworth achieved a good market share of 27.4% in the U.S. and Canada heavy-duty truck market in 2015. Class 8 truck industry retail sales totaled 278,000 units for the year. Peterbilt and Kenworth also achieved a record 17.4% share of the U.S. and Canadian medium-duty truck market last year, resulting in a record 27,300 medium-duty truck deliveries for PACCAR. 2016 will be another good year for the U.S. and Canadian Class 8 industry truck market with retail sales estimated to be in a range of 230,000 units to 260,000 units. Additional good news is that Peterbilt and Kenworth dealer inventories are in great shape entering this year. DAF increased its market share to 14.6% in the European above 16-tonne truck market last year, compared to 13.8% in 2014. The market was a strong 269,000 units in 2015. Looking at this year, we anticipate that the European above 16-tonne truck market has the potential to expand further and be in a range of 260,000 vehicles to 290,000 vehicles. Economic growth in Europe is expected to increase this year to 1.7% with more than 2% growth anticipated in the UK, DAF's largest market. PACCAR Parts generated record pre-tax profit of $556 million and strong revenues of $3.1 billion in 2015. The excellent results were driven by strong freight tonnage, high fleet utilization, and the many innovative products and services offered by PACCAR Parts. During the year, PACCAR Parts set records for parts deliveries to fleets, online part sales, and TRP part sales for all makes of trucks and trailers. For the fourth quarter, PACCAR Parts achieved revenues of $750 million and pre-tax income of $126 million. Our expectation for 2016 is that parts and revenues  is that parts revenues, excluding the effects of currency movements, could increase 3% to 5%. PACCAR Financial Services revenues were $293 million in the fourth quarter, and pre-tax income was $90 million. The good results benefited from continuing strong portfolio performance. PACCAR leasing end of the year was a record 39,000 units in its full-service leased portfolio. For the full year, PACCAR Financial Services earned pre-tax income of $363 million. At this point, I'm going to have Michael Barkley address the effects of currency movements on our segment operations.

**Executive**
: For the truck segment, the quarter-over-quarter comparison has us  the impact of currency was $200 million on revenue, and for the full-year, the impact was $940 million on revenue. The profit impact was minimal given that we have a large amount of material coming for engines into our Columbus engine factory from the eurozone. For parts, the quarterly impact on revenue was $38 million, and for the full year was $193 million. The impact on profit was $4 million for the quarter and $34 million for the full year. For Financial Services, the impact on revenue was $17 million and the impact for the full year was $79 million. And the impact on profit for Financial Services was $5 million for the quarter and for the full year was $22 million.

### Q&A
**CEO**
: Thank you, Michael. As we look at next year, PACCAR's projected research and development spending of $240 million to $270 million and capital expenditures of $325 million to $375 million will expand Kenworth, Peterbilt, and DAF product offerings, enhance the PACCAR engine range, and increase the capacity and operating efficiency of our factories and distribution centers. As the company begins its 111th year, we are in an excellent position to lead the industry with the highest quality products and services. Thank you, and I'd be pleased to answer your questions.

**Operator**
: Your first question comes from the line of Tim Thein with Citi.

**Analyst-1**
: Great, thanks. Good morning, Ron.

**CEO**
: Good morning, Tim.

**Analyst-1**
: Thanks. Just on the first one, maybe you could extend, I think you had mentioned the margins, 1Q being comparable to 4Q based on the way things look today. Can you extend that to your expectations for the year?

**CEO**
: I think that as we think about margins for the year, I think that we see the full year being barely comparable to 2015.

**Analyst-1**
: Okay, got it. And then just on the market share trend in Europe, obviously, how the individual countries play out can influence that quite a bit. Just in terms of some of your key markets, what are you thinking in terms of how you're planning for that expectation of just overall share? I know that's not easy to forecast at this time of year, but I guess just based of your gains, can you continue to gain further share for DAF across Western Europe?

**CEO**
: DAF has a really long history of continuing to grow their share progressively over the long term, and that would continue to be our target with the investments that we made and the great new Euro VI products that they have in the marketplace, the continuing enhancements that we make to the PACCAR engines. We've got a great product lineup. We have great service capability with PACCAR Parts and PACCAR Financial. So our anticipation is that we'll continue to increment that market share on our way to our medium-term target of 20%.

**Analyst-1**
: All right, thanks a lot.

**CTO**
: Thank you.

**Operator**
: Your next question comes from the line of Alex Potter with Piper Jaffray.

**Analyst-2**
: Hi. I was wondering if you could comment a bit on inventory, I guess, broadly in the channel. You mentioned during your prepared remarks that you think Peterbilt and Kenworth are in good shape when it comes to retail inventory. I was just wondering if you guys think that PACCAR was maybe more nimble than some of your competitors when it comes to responding to the recent downturn in orders because obviously a lot of folks have been talking about the buildup of inventory out there in the channel? So if you guys have I guess low inventory, that would imply that most of the inventory concerns are being felt by other truck companies. Is that accurate?

**CEO**
: I can't really comment on the nimbleness of our competitors, but I know that we monitor our business very closely and manage it to balance the delivery of trucks with the demand that's in the market. I would say that based on what we know we have 45  50 days worth of inventory in the channel. I think the industry is closer to a 90-day measure. So as I said, we are really in great shape in terms of where we're at starting the 2016 year.

**Analyst-2**
: Okay, very good. That's good to hear. I was wondering, I guess, also if you could maybe make a couple comments here on pricing. Obviously, if you look at just pure truck revenue and divide it by the number of units sold, it looks like there was a pretty material degradation in sequential terms. But obviously, you've got some ForEx in there. You've got presumably some mix maybe toward medium-duty. I was just wondering if you could maybe help us interpret that sequential decline and how much is, I guess, "real pricing".

**CEO**
: Obviously, the margin performance for the quarter and the year were excellent. We expect that, as we've mentioned, margins in the first quarter to be comparable to what we saw in the fourth quarter. Almost all of the per unit degradation is exchange-related. So that's just the effects of translating currencies around the world into the U.S. dollar.

**Analyst-2**
: Okay, very good. Thanks a lot, guys.

**CTO**
: Sure.

**Operator**
: Your next question comes from the line of Steven Fisher with UBS.

**Analyst-3**
: Thanks, good morning.

**CEO**
: Good morning, Steven.

**Analyst-3**
: I'm wondering what you're seeing in terms of used truck pricing and how that's influencing your forecast of demand for 2016 on new sales at this point. I think last quarter, it sounded like it wasn't much of an issue, but wondering if anything has really changed there.

**CEO**
: I think what we're seeing is there are more used trucks coming into the market, and that's dampening used truck prices a bit. But the great news is that the Kenworth and Peterbilt products continue to earn a premium relative to the competition. And so we're very involved with selling used trucks last year. As a company, we sold about 9,000 trucks globally, and we'll do that again this year. So we'll use that as a tool to be able to support new truck business and our finance operations.

**Analyst-3**
: Okay. And I think the margins have favored North America over Europe based on volumes and Euro VI program over the last year or so. Do you anticipate that in 2016 the margins kind of in balance again between the two regions at this point?

**CEO**
: We think the margin  as we said, we expect it to be comparable to last year, and I think that would  on a market basis, I think that would be true as well.

**Analyst-3**
: So still, in other words, favoring North America over Europe sounds like then?

**CEO**
: Yeah.

**Analyst-3**
: Okay, thanks a lot.

**CTO**
: Thank you.

**Operator**
: Your next question comes from the line of Nicole Deblase with Morgan Stanley.

**Analyst-4**
: Thanks, guys. Good morning.

**CEO**
: Good morning.

**Analyst-4**
: So, Ron, my first question is around your 1Q production outlook. I know you guys had flattish Q-on-Q, but what are the thoughts on U.S. and Canada versus Europe? Do you also expect like a flattish outcome for both of the regions?

**CEO**
: I think that North America is going to be up in the 10% to 15% range, and Europe would be down in that range just because of workdays and production, beta (15:57) production levels in each of the markets.

**Analyst-4**
: Okay, that's really helpful. Thanks, Ron.

**CEO**
: Sure.

**Analyst-4**
: And then my second question is just what have you guys seen or heard from U.S. customers with respect to the MX-11 launch so far?

**CEO**
: Well, it's just  we're just getting those into the field. The customers who have had the test trucks that have been running in the market  we have hundreds of thousands of test miles on those trucks, and the feedback from those customers has been excellent. So, the MX-11 has been in the European market now for two years, with great responses now, 25% of the production in our European operations. So, we're excited to offer that and think that'll be a nice enhancement to meet customer needs both in the vocational and regional haul applications.

**Analyst-4**
: Okay, thanks, Ron. I'll pass it on.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Jerry Revich with Goldman Sachs.

**Analyst-5**
: Hi. Good morning and good afternoon, everyone.

**CEO**
: Thanks, Jerry.

**Analyst-5**
: Ron, I wonder if you could talk about your bookings in Europe in the quarter. Did your lead times widen out? It sounds like you're taking the build rate higher, if I'm not mistaken, in the first quarter, given the number of working days. Is that right? Can you just flush out for us what you're seeing in that market, please?

**CEO**
: Can you rephrase your question, Jerry?

**Analyst-5**
: Sure. So, can you talk about whether your lead times extended in the fourth quarter? It looks like in Europe, it looks like your build rates are moving higher. So I would guess your book-to-bill in the fourth quarter was greater than 1. But I'd appreciate any color there.

**CEO**
: Order intake during the course of last year really outpaced the build rate in the first parts of the year. And so we were ramping up build rate, and build rates as we start 2016 are comparable to where we ended up last year with fewer work days and just a slight reduction in the average daily count for the first quarter. So it's  lead times are in excellent shape, really, in all of our markets as we begin 2016.

**Analyst-5**
: Okay. And then obviously, we'll get the details when the 10-K comes out. But I'm wondering if you could just help us bridge the year-over-year gross margin performance for fourth quarter 2015 versus fourth quarter 2014 in terms of the contribution of pricing, net of material cost. Any piece that you could help us with would be helpful.

**CEO**
: There's a lot of moving pieces in there, Jerry, with pricing cost movement, customer mix, model mix, et cetera. So that's  we really don't have that level of granularity here.

**Analyst-5**
: Okay. And then in terms of the 2016 outlook, for the full-year, you mentioned you're looking for comparable gross margins even though shipments, I think, are expected to be down based on your outlook for North America and European truck markets. Can you talk about what's favorable at the gross margin line that's providing that tailwind despite lower volumes?

**CEO**
: Our teams are just doing a great job of rigorously managing the cost structure. We, obviously, work very closely with our suppliers to make sure that we're getting our fair share of commodity cost movements. We have great products. The Kenworth, Peterbilt and DAF products are the highest quality and demand premium price in the market. So, as we look at this year, we feel that 2016 will be comparable to our 2015 levels.

**Analyst-5**
: All right, thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Ann Duignan with JPMorgan.

**Analyst-6**
: Hi, guys. Good afternoon here.

**CEO**
: Good morning, Ann.

**Analyst-6**
: Can we talk about your Parts business a little bit? It came in weaker on revenues and significantly weaker on EBIT margins than I was forecasting. Now I don't know if I was just setting too high an expectation. Can you just talk about Parts in Q4 and what went on there, did I miss something from a seasonality perspective?

**CEO**
: No. I think as we look at Parts  Michael talked about the exchange rate effects and so when you compare the fourth quarter results with the fourth quarter the prior year, they're essentially the same as last year, very strong fourth quarter last year. There were fewer new trucks being delivered as well as I think a little bit of rebalancing of inventories in the market, but as we commented, we think Parts will continue to grow as we enter into 2016. Our Parts team has done a great job with some of the many programs that they've put in place. And we continue to see, obviously, growth in the engine parts business as we go forward. So, we think there's continued to see positive momentum as we go to 2016.

**Analyst-6**
: Okay, that's helpful color. On your outlook for North America down 12%; U.S. and Canada down 12%, most of the industry is forecasting significantly greater decline, going back to replacement levels of somewhere around down 20%. What are you seeing out there, what are your customers telling you, what are you teams telling you? Where do you think the strength is coming from versus where others are forecasting?

**CTO**
: Obviously the on-highway business is supported by strong freight tonnage metrics. They've been pretty flat but at a very high level. I think the last numbers that came out were like the second highest level on record. So, freight activities look good, the estimation for growth for next year for North America is 2% to 3% growth. So, consumer demand is strong. And so, we see a lot of positives that are going to support a good market. If you look at the 230,000 trucks to 260,000 trucks, it could be the second third best in the last decade. So, it's a good market for next year. So, we're optimistic about how things will develop as we talk to customers, as I think we commented last quarter. Customers are ordering  that have ordered are ordering levels comparable to what they ordered in 2015. I'd say a little bit of the difference is just that their expectations last year, the expectations for delivery were, they needed them as soon as they could get them. And now, they're thinking a little bit spreading those deliveries out a little further across the year. So, we're seeing positive things overall.

**CEO**
: And I would add that Kenworth and Peterbilt are very strong in the vocational segment and construction activity continues to be strong, forecasted to grow once again for residential housing in 2016 and so the vocational segment for us is performing very well, especially with the new products that we're introducing into both Kenworth and Peterbilt.

**Analyst-6**
: And does that give you confidence in guiding to flattish or comparable margins, year-over-year despite a decline in revenue?

**CTO**
: As we look at the expectations for the year, cost and...

**CEO**
: Our parts mix will grow a little bit and the parts margins are obviously good. We'll continue to operate it at a very high level in the Parts business and that should be a net positive for margins as well.

**Analyst-6**
: Okay, very good. I appreciate the color. Great. Thank you.

**Operator**
: Your next question comes from the line of Jamie Cook with Credit Suisse.

**Analyst-7**
: Hi. Good afternoon.

**CEO**
: Good morning, Jamie.

**Analyst-7**
: A couple questions. One, it sounds like you guys are obviously more constructive relative to your peers, but if you look at the industry numbers, cancellation rates have picked up over the past several months. Have you seen any of that, or have you been immune to that? And then I guess a broader, just cycle question, do you view this as a  obviously, the level decline you're expecting this year is less than the industry, but do you view this as a one year, mid-cycle pause, or would you look at this more as a normal downturn? Thank you.

**CEO**
: Cancellation activity in our operations are very normal. There's nothing unusual that is happening in that arena. And in terms of where we're at in the cycle, I think that's to be determined. The economic fundamentals are positive, and we see that we're going to track what the demand is, and we think the demand is going to be a good market for 2016.

**Analyst-7**
: All right, thanks. I'll get back in queue.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Andy Casey with Wells Fargo.

**Analyst-8**
: Hello, everybody.

**CEO**
: Good morning, Andy.

**Analyst-8**
: First question on the Parts business revenue in the quarter, Ron, you mentioned inventory rebalancing in the channel. Was that broad-based, or was it concentrated in some of the regions?

**CEO**
: No, I think that was general across the dealer body.

**Analyst-8**
: Okay, thanks. And then on the margin question somebody asked earlier, if you compare the margin in the quarter with the run rate of the first three quarters, which was very strong, the margin in the quarter went down roughly a couple hundred basis points. Is that all seasonality, or was there an impact from this rebalancing?

**CEO**
: I think there are obviously some operating leverage effects in there, and it probably reflects more the mix of parts that were being distributed during the quarter.

**Analyst-8**
: Okay, thanks. And then in truck, I just was hoping a little bit more clarity to one of Jerry's question. Could you talk about what you saw in European truck in terms of the order activity in Q4? Was it as strong a growth as you saw in the first few quarters, or is it moderating in line with your outlook there?

**CEO**
: I think it's steady and I'd say in line with our outlook. Yes, I think that's a good way to say it.

**Analyst-8**
: Okay. And then in the U.S. and Canada, you had some order volatility toward the end of the year, November weak, December better. Did you see that December better continuing into January, or are we into a little bit of the seasonal doldrums there?

**CEO**
: I think most of the ups and downs are just timing of when some of the larger fleet orders appear in the order board. So I think as I said, large fleets are planning buys, and their buys are generally pretty consistent with what we saw for deliveries in 2015.

**Analyst-8**
: Okay, thank you very much.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Joel Tiss with Bank of Montreal.

**Analyst-9**
: Hey, guys. How is it going?

**CEO**
: Good. Good morning.

**Analyst-9**
: That's good. Good morning, good afternoon, whatever. Anyway, we keep dancing around this question. I just wondered if you could spend a couple of minutes giving us a little more of a comprehensive list underneath the volume numbers which you obviously give us for the industry. Can you just give us a couple of the bigger factors? You talked about mix and parts being better, but some of the bigger factors that are going to drive profitability, pricing, under-absorption, any manufacturing efficiency improvements, people reductions, mix between the U.S. and Europe, just a couple of the bigger ones to help us get a feel for what some of the levers are you have inside to control the margins.

**CEO**
: I think if you just go down the list, I think pricing reflects good markets. And so we have great products to offer the market, so we feel good that our products demand a fair price in the marketplace. Cost, I think there's probably a little bit of downward momentum on prices with commodity cost reductions. so that's a bit of a benefit. But everybody is getting that same benefit in the industry. Our factories and businesses around the world do a great job of managing their cost structure. And our purchasing groups around the world do a great job of procuring and working closely with our suppliers. We have a great supply base that provides us timely deliveries, quality parts. And so we work closely with them to make sure that we can support our business and our factories can operate efficiently. So all the factors as we talked about R&D for next year, we're projecting a little bit of an uptick. That R&D spending will occur pretty ratably during the course of the year. We manage our SG&A closely. We're thinking SG&A for next year will be comparable to our 2015 levels, and that those amounts will be pretty comparable quarter to quarter. So as we look at next year, we feel good about the prospects of being able to continue to manage in a very prudent, cost effective way.

**Analyst-9**
: That's great. And then have you shared at all a medium or longer-term view on medium-duty market share? I know you've had a big new product push for the last couple of years, and it seems to be working.

**CEO**
: We have great medium-duty products and more and more of our dealers are becoming engaged in the medium-duty business. And I think we're seeing the benefits of that over time in North America. We have great products in Europe. As I mentioned, with the increase in share, we did get to a record level of medium-duty deliveries last year. And we'll continue to invest in our product, to continue to make enhancements, and look forward to continuing to have opportunity to grow that business going forward.

**Analyst-9**
: All right. So there's no number on where you could be five or 10 years from now.

**CEO**
: No, I don't. We obviously continue to push the number. We're 27% share of the heavy-duty market, 17% of the medium-duty market in North America, so there's lots of upside for us.

**Analyst-9**
: All right. Thank you so much.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Tim Robinson with Susquehanna Financial.

**Analyst-10**
: Good morning, guys. Thanks for taking my call.

**CEO**
: Good morning.

**Analyst-10**
: I know you guys have managed your inventories well in U.S. and Canada. But just looking at retail sales and builds at your peers, one of them has grown substantially. The industry is up substantially. I was just wondering whether you think you can hold pricing, given the dynamics in the U.S. and Canada.

**CEO**
: We're seeing prices pretty stable in the U.S. and Canadian market as we progress through the first parts of the year. So, we expect that that will continue.

**Analyst-10**
: That's great. And then just a clarification on the parts outlook. Could you just go through that by region?

**CEO**
: I think that's our expectation, really in both regions, some level of growth in the 3% to 5% range for both North America, Europe. And obviously, we're starting to grow our business in Brazil. So...

**Analyst-10**
: Got you.

**CEO**
: ...that's our overall perspective.

**Analyst-10**
: Okay. And then when we think about your parts margin outlook going into 2016, should we expect the mix that impacted 4Q to continue to be a headwind, or is that something that largely corrects itself with inventory rebalancing and would sort of go back to the levels of the first nine months of 2015?

**CEO**
: I think our margin expectations for next year will be comparable to 2015.

**Analyst-10**
: Okay. And are you getting any benefits from the MX-13 in your parts business yet in the U.S.?

**CEO**
: Sure. Absolutely.

**Analyst-10**
: Okay.

**CEO**
: Yeah. And we got 105,000 engines that we've produced out of our Columbus factory. And that we're seeing that engine business  it's still early days from a parts perspective, but that will continue to be a positive factor in our Parts business for years to come.

**Analyst-10**
: Got it. Okay, that's it for me. Thanks for taking my call.

**CEO**
: Sure, absolutely. Thank you.

**Analyst-10**
: Bye.

**Operator**
: Your next question comes from the line of David Raso with ISI.

**Analyst-11**
: Thank you. Maybe I missed it. The production for the full-year of 2016, North America and Europe, I know you gave us the first quarter sequentially, but what's the full-year assumption?

**CEO**
: We don't have  provide that level of detail. But you can look at the market size estimates, and I think get to a pretty good number.

**Analyst-11**
: So your production versus those industry forecasts, you'd say, are very much in line?

**CEO**
: Yes.

**Analyst-11**
: Again, I know we're asking the same question again, but over the last 30 years, you have eight years of revenue declines; and seven of them, gross margins go down. So is there something about the currency benefit, North America buying from Europe? But obviously North America is down more than Europe is in 2016. So that one has fully explained it. Can you help us more on price cost? It's just obviously history would tell you, for you to be forecasting flat gross margins is abnormal. So, with a little more specificity, can you help us understand where is the difference between your history that down volume equals flat gross margins? I know the Parts is helpful, but at 17% of the business, it's not that large. So, again, it's an important issue for all of us, so we appreciate the detail.

**CEO**
: Sure. It's all the factors that we talked about. I mean, it's the cost management aspects, the favorable potential movement from commodity cost movements. So, all the elements of our total margin picture play into that and there's no one individual item that I can point to and say, that's the difference.

**Analyst-11**
: The kind of arguments that Parts being bigger is today you're more vertically integrated in North America, so thus bottom decline would be more painful than prior down cycles. I mean, I know it's not a big number, but there's something about heavy expenditures, building up Brazil now the market that weak. There's some easy retrenchment of recouping of levels of losses in Brazil. We're just trying to flash out why are you that comfortable guiding flat gross margins.

**CEO**
: Do you have anything else to add, David? Thank you.

**Analyst-11**
: Okay. No, I appreciate it. Just a key issue for everybody. So, thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Neil Frohnapple with Longbow Research.

**Analyst-12**
: Hi, guys. Good morning.

**CEO**
: Good morning.

**Analyst-12**
: As a follow-up to Joel's question, you talked about medium-duty market share. Can you just provide any granularity on what you're seeing in the underlying medium-duty market in North America and your outlook for that market this year?

**CTO**
: I would think that the medium-duty market, I think, last year was 80,000 units or so. And I think we're thinking in the 65,000, 75,000 range for 2016.

**Analyst-12**
: Okay. And then just, what would be driving that decline that you guys are looking for?

**CTO**
: Neil, the medium-duty business at PACCAR is being influenced significantly by the level of construction activity. We put a lot of medium-duty trucks into the construction market and so that's been strong. And as a result, our deliveries into that market have been strong. And we would expect that to continue at good strong levels in 2016.

**Analyst-12**
: Okay.

**CTO**
: We've also introduced some new product, the Cab-Over products at Kenworth and Peterbilt are both beginning to develop good traction. More and more of our dealers are stocking and selling those trucks. And that's a net contribution to our medium-duty production as well.

**Analyst-12**
: Okay. And then as a follow-up to used truck pricing in North America, what are you seeing with regards to used truck inventory levels in the channel currently? Are they a bit high and then would you expect them to normalize at some point this year?

**CEO**
: Well, I think used truck inventory levels for PACCAR are very normal, yeah. We have a pretty normal level of used trucks and we expect that sort of stay as we look at lease returns, et cetera. As we progress through the year, we should be able to keep that at very normal levels throughout the year.

**Analyst-12**
: All right, thanks. I'll pass it on.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Joe O'Dea with Vertical Research.

**Analyst-13**
: Hi. Good morning.

**CEO**
: Good morning.

**Analyst-13**
: Just on the Europe delivery volumes last quarter and what you're looking for in the first quarter, it seems like it would be at a higher rate for the market than where your 15% shares or so. So could you talk about whether there's an inventory build effort right now into the year, or are there opportunities where you think there's an increase in market share in 2016?

**CEO**
: Again, as we talked about earlier on market share, we have a long tradition of building that share and our teams had done a great job of getting the products in place, great products in place with really industry-leading fuel efficiency, and so we continue to target growing our share into various markets. And there's inventory levels throughout the channel, dealer inventories in Europe are in great shape. And so there's no real inventory buildup or reduction. It's pretty steady.

**Analyst-13**
: Okay, thank you. And then just a last one, I guess. On the share repurchase, it looks like a little bit faster pace into the end of the year than where you have been previously. Any reason that that was maybe abnormal, or is that kind of a level that you anticipated and you would only need another authorization to keep going at that level?

**CEO**
: Obviously, as we said in our press release, we think the shares are an attractive option at the current pricing level. And so, we expect we'll continue to do some share repurchases during the course of 2016, as we do in many years.

**Analyst-13**
: Okay, thanks a lot.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Adam Uhlman with Cleveland Research.

**Analyst-14**
: Hi, guys. Good morning. Good afternoon.

**CEO**
: Good morning.

**Analyst-14**
: I was wondering if we could dig into the Finance business, your aspirations for 2016, how you expect that business to unfold. And then within there, the Leasing business, maybe you could talk about some of the key operating trends that you follow. What have you been seeing in the business, and how are you thinking about it for 2016?

**CEO**
: Yeah. I think as we look at our portfolio and our asset base, I think the earning asset  average earning assets that we'll have for 2016 would be fairly comparable to our 2015 levels, which were really at record levels. And the Leasing business has done very well over a long period of time, celebrating their 35th anniversary in 2015. They continue to work very closely with our dealers and our customers to continue to grow that business. They ended the year with a record level of units in the fleet, and we continue to look for opportunities to expand our business in Europe. And during 2015, we launched our PacLease business in Australia. So continue to look for ways to have leasing make a valuable contribution to the overall company results.

**Analyst-14**
: Okay, thanks. And then could you talk to  it's not a big expense for you. But could you talk to your pension expense expectations for 2016?

**CEO**
: I think they'll be very comparable to  it's a pretty steady level. It obviously gets impacted by the level of employment, discount rates, et cetera. So I think we'll see maybe some benefit from a slightly higher discount rate that will benefit pension expense a little bit in 2016 for North America.

**Analyst-14**
: Okay, thank you.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Sameer Rathod with Macquarie.

**Analyst-15**
: Hi, good morning.

**CEO**
: Good morning.

**Analyst-15**
: There seems to be a lot of press recently on autonomous vehicles from large tech companies. It seems like they're moving regulation forward in various s states. And if you look at it objectively, the technology is getting better. The miles driven autonomously is going exponentially. How does PACCAR think about this? What steps are you guys taking today for a potential market in the future on the truck side? And generally, how do you feel it's evolving?

**CEO**
: So all of our truck divisions and our engineering teams around the world are involved in evaluating all the technologies that can benefit our customers, including the technologies that will support autonomous driving. We've demonstrated autonomous vehicles at various exhibitions in North America. Our team in Europe has also demonstrated their autonomous capabilities with tuning activities, working with government and educational institutions. So a lot of work in that area, working closely with suppliers who have the technologies that can support that activity. So it's an ongoing activity. I think we're several years away from seeing that in the truck business. But we're right at the forefront of all the developments that are going on in that arena.

**Analyst-15**
: Okay, thanks.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Jeff Kauffman with Buckingham Research. Jeff, your line is open. Please proceed with your question.

**Analyst-16**
: Sorry about that. I had the mute on. Good morning, everyone.

**CEO**
: Good morning, Jeff.

**Analyst-16**
: Thank you. A lot of questions have been asked on the margins and the gross margins in your core markets. I'd like to go in a different direction and talk about some of the emerging and expanding markets. That was a big highlight of an analyst meeting you had just a little bit ago when you were talking about your plans in Russia and your plans in Brazil. These markets are obviously very weak right now. Wouldn't you think that this is a very good time strategically to be moving in and making investments in these markets? So I guess two questions. Number one, how are you doing in the various emerging markets, and what are your forecasts for those areas? And then of the CapEx that you're spending, how much of that is dedicated to emerging market investment right now?

**CEO**
: Sure. Obviously, Brazil, we've made a significant investment in our new plant operations, the products that we've launched and are launching in the market. We're excited about the prospects for Brazil and the rest of South America as we go forward. Our teams are doing a great job. We have a great dealer representation that is representing the DAF product in the Brazilian market. We have the opportunity to increase our production and increase our penetration. We had an excellent showing at the Fenatran truck show in November in Sao Paulo. So our team enters 2016 with a lot of positive momentum in a challenging market. In Russia, the DAF organization there has done a good job over the last years of increasing the number of locations representing the DAF product. And when the economy improves in Russia, we'll be able to grow our deliveries in that particular region. If you look at Asia, still an area of opportunity for our company. We continue to evaluate ways that we can participate greater. We have great presence in India and China with our purchasing activities, our technical office in Pune, India that supports our information technology and engineering activities. So we're very cognizant of what's going on in those markets and continue to look for opportunities to play a bigger part. As we look forward, we just invested in Brazil with the launch of the DAF CF product, so expanding the product offerings. We're now assembling the MX engine in our DAF Brazil factory. So we'll continue to make investments in expanding the product offerings and improving the productivity and efficiency and the capacity of our operations in these markets.

**Analyst-16**
: Okay. And just following up on that, you did about 16,000 units of what I would call non-core markets last year. This number is small, but you gave a forecast for North America, you gave a forecast for Europe. How should we think about this non-core market's number?

**CTO**
: Relatively flat 2016 compared to 2015. Certainly, that would be the case in South America, somewhere in the range of 70,000 units to 80,000 units, heavy-duty in the whole region.

**CEO**
: I agree. I think that's a good estimate for next year.

**Analyst-16**
: Okay, thank you and congratulations.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Mike Shlisky with Seaport Global.

**Analyst-17**
: Hi, guys.

**CEO**
: Good morning, Mike.

**Analyst-17**
: Good morning. Hey. Do you have anything on the MX-11? Can you give us your thoughts at the  what kind of penetration you expect now there's launch for 2016? And perhaps more broadly, what should we expect to see PACCAR Engines penetration rate in the overall Class 8 market in 2016?

**CEO**
: Well, the MX-11, we think that will be very well-received. It's been very well-received in Europe. We think that as customers get more exposed to it and accustomed to its capability, that it will become a greater portion of our engine build in North America. We continue to ratchet up our MX engine penetration in Kenworth and Peterbilt products, averaging around 40% for the year, 42% in the fourth quarter. The MX-11 will help move that further forward. And we see in the near term, next year or two, getting that up closer to the 50% range. And as we look at the capability of our engines currently and in the coming years, it will meet roughly 80%, 85% of what customers need to do their work. And we continue to get more and more of our customers starting to take some MXs to really test them in their fleet. And typically after customers have had that chance to have that test and they see the great performance of those engines, the great fuel efficiency, more and more of those are converting their business to the MX engine. So, it will continue to progress over the next years.

**Analyst-17**
: Great. I think I also wanted to ask about on the large side, some of the larger moving parts here in the first quarter. Does not having a big presence at this year's Mid-America Truck Show do anything that's material to support the first quarter margins here versus the prior year?

**CEO**
: No.

**Analyst-17**
: It's not enough to be a factor.

**CEO**
: That's not a factor.

**Analyst-17**
: All right, great. Thanks, guys.

**CEO**
: Thank you.

**Operator**
: Your next question comes from the line of Mike Baudendistel with Stifel.

**Analyst-18**
: Thank you. Just want to ask you about the next upcoming greenhouse gas standard. Is that something you're already meeting or expect to meet by the deadline?

**CEO**
: When you say the next standard, you're talking about 2017 or the...

**Analyst-18**
: Yes, 2017.

**CEO**
: So we're in the midst of beginning the certification process with the EPA and CARB.

**Analyst-18**
: Okay, great. And also wanted to ask you under the new parts distribution facility in Renton. Is it possible to quantify how much you expect to have to add to the parts revenue and do you view that as being something that is more able to maintain the historical growth rate you've had of about 8% in parts revenue growth, or is it something that can enable you to grow faster than that?

**CEO**
: No. I think it supports and we've got a long history of incrementing our parts distribution capacity, almost every year, in some form or fashion and so this is just the next step to continue to support that ongoing growth level for our parts operations.

**Analyst-18**
: Okay, great. That's all I had. Thank you.

**CEO**
: Thank you.

**Operator**
: And there are no other questions in the queue at this time. Are there any additional remarks from the company?

**CTO**
: I'd like to thank, everyone, for their excellent questions, and thank you, operator.

**Operator**
: Ladies and gentlemen, this concludes PACCAR's earnings call. Thank you for participating. You may now disconnect.