## Financial Earnings Call


### Prepared remarks
**Operator**
: Good morning, and welcome to Deeres Fourth Quarter Earnings Conference Call. Your lines have been placed on listen-only until the question-and-answer session of todays conference. I would now like to turn the call over to Mr. Tony Huegel, Director of Investor Relations. Thank you. You may begin.

**CTO**
: Hello. Also on the call today are Raj Kalathur, our Chief Financial Officer; Marie Ziegler, Vice President and Treasurer; and Susan Karlix, Manager, Investor Communications. Today, well take a closer look at Deeres fourth quarter earnings and full-year results then spend some time talking about our markets and the outlook for 2013. After that, well respond to your questions. Please note that slides are available to complement the call this morning. They can be accessed on our website at www.johndeere.com. First, a reminder. This call is being broadcast live on the Internet and recorded for future transmission and use by Deere and Thomson Reuters. Any other use, recording or transmission of any portion of this copyrighted broadcast without the express written consent of Deere, is strictly prohibited. Participants in the call, including the Q&A session, agree that their likeness and remarks in all media may be stored and used as part of the earnings call. This call includes forward-looking comments concerning the companys plans and projections for the future. Theyre subject to important risks and uncertainties. Additional information concerning factors that could cause actual results to differ materially is contained in the companys most recent Form 8-K and periodic reports filed with the Securities and Exchange Commission. This call also may include financial measures that are not in conformance with accounting principles generally accepted in the United States of America, or GAAP. Additional information concerning these measures, including reconciliations to comparable GAAP measures is included in the release and posted on our website at www.johndeere.com/financialreports under Other Financial Information. I will now turn the call over to Raj.

**CFO**
: Good morning and afternoon, everyone. First, let me say how pleased I am to be part of todays call. To give you some background about who I am, I joined John Deere in 1997 and have spent my career in different functional areas, starting in finance, including business development, sales and marketing and operations in North American and Asian locations. Before becoming the Deputy Financial Officer in April 2012, I was based in Singapore as Vice President of Sales and Marketing for our ag and turf businesses in Asia and Africa. Before that, I was Managing Director of the companys India operations. Im looking forward to bringing the benefit of my business experience to my role as CFO and to working with our Investor Relations team and many of you. Before turning things over to Susan for a fuller discussion of our results, a few words about what we experienced in the fourth quarter and our future business prospects. In our last conference call in August, we noted that our third quarter performance was impacted by manufacturing inefficiencies, which particularly affected the production of combines. At the time, our then CFO, Jim Field, said we expected these issues to be largely behind us by the end of the fiscal year. Im pleased to say thats exactly what happened. Our factories have done a good job of catching up with demand and are running quite well. In addition, John Deere has completed its best ever fourth quarter and best ever full-year in terms of both sales and earnings. We are pleased with our record results in 2012. As we all know, the world faces some big economic challenges today ranging from the U.S. fiscal cliff possibilities to euro debt crisis and the slowdown in emerging market economies. Todays economic uncertainties are real and troubling and John Deere is taking serious precautions in response. However, we dont see these issues having a lasting impact on the powerful tailwinds that we believe will drive demand for agriculture and construction equipment well into the future. In fact, we couldnt agree more with our CEO, Sam Allens comments in todays earnings announcement that we have great confidence in Deeres prospects and in our ability to deliver value to investors in the future. Susan?

**Other-1**
: Thank you, Raj. Now lets take a look at the fourth quarter in detail beginning on slide 3. Net sales and revenues were up 14% to $9.8 billion in the quarter. Net income attributable to Deere & Company was $688 million. On slide 4, total worldwide equipment operations net sales were $9 billion, up 14% quarter-over-quarter, included is an unfavorable impact from currency translation of about three points, price realization in the quarter was positive by four points. Turning to a review of our individual businesses, lets start with ag and turf on slide 5. Sales were up 16% in the quarter. Operating profit was $931 million. There is one item that affected operating profit Id like to touch on. As mentioned in the press release issued this morning and noted on this slide, the division recorded a small write-down, approximately $33 million pre-tax, relating to our water business. This write-down reflects the near-term actions we have taken to integrate water into the A&T divisions business and distribution channel. John Deere Water continues to be a long-term strategic opportunity for the company. Before we review the industry sales outlook, lets look at some of the fundamentals affecting the ag business. Slide 6 outlines U.S. commodity price estimates that underlie our financial forecast. Corn, soybean and wheat prices are reflective of the weather-driven events that affected the growing season and are supportive of equipment sales. Prices for cotton continue to fall, as stock levels globally are about 65% higher than two years ago. Slide 7 highlights cash receipts. Driven by strong crop prices, 2012 forecasted cash receipts of $388 billion is a record level. In 2013, strong crop prices are expected to continue and livestock receipts are forecasted to increase, spurring 2013 cash receipts even higher. As a reminder, in our modeling, current and prior-year cash receipts are the primary driver of equipment purchases in the U.S. market. With cash receipts at record levels, this bodes well for future farm prospects. Our economic outlook for the EU27 is on slide 8. The investment mood remains positive due to high commodity prices and corresponding strong income levels. However, the overall economic situation continues to weigh on farmer sentiment as wet weather accounted for a poor U.K. harvest and inadequate rainfall hampered the fall/winter crop planting in the Southeast EU. On slide 9, youll see the economic fundamentals outlined for a few of our other targeted growth markets. Slide 10 illustrates the value of agricultural production in Brazil. This is a good proxy for the health of agribusiness. It encompasses over 20 different crops and has a high correlation to tractor sales over time. With forecasts for an increase in acres planted, higher yields and sustained high crop prices, the 2013 value of ag production in Brazil is expected to increase about 9% over the 2012 level. Our 2013 ag and turf industry outlooks are summarized on slide 11. Industry sales in the U.S. and Canada are expected to be about flat in relation to the strong levels of 2012. We continue to see strength in demand especially for high horsepower tractors but our outlook is tempered by the drought-related effects on the livestock and dairy sectors. The EU27 industry outlook is flat to down 5% from the attractive levels of 2012. Our 2013 industry outlook in the CIS countries is modestly higher on the heels of strong commodity prices. Industry sales of tractors and combines in South America are expected to be up about 10% in 2013. With strong commodity prices forecast call for an increase in planted acres resulting in higher yields. In addition, current government programs in Brazil support higher amounts of financing and lower interest rates, which will benefit the industry in our fiscal 2013. In Asia, we expect little change in 2013 compared with 2012. Soft economic conditions continue in both India and China. As well, high interest rates and the impact on crop yields from the delayed monsoon bear caution in India. The uncertainty over subsidy policy framework under the new Chinese government is also a factor in our outlook. Turning to another product category, we expect industry retail sales of turf and utility equipment in the U.S. and Canada to be up about 5% in 2013, reflecting some improvement in the U.S. economy. We expect to outperform the industry with the launch of new turf and utility products especially new utility vehicles and commercial and residential mowers. Putting this all together on slide 12, fiscal year 2013 Deere sales of worldwide ag and turf equipment are forecast to be up about 4%. 2013 operating margin for the ag and turf division is forecast at about 15%. Before moving to C&F, lets touch on our early order programs. The combine early order program began in August with sales being allocated by quarter this year. Orders for combines are progressing nicely with all production sold out for quarters one and two. Dealers began placing orders for third quarter production earlier this month. In aggregate, the other seasonal programs for planters, sprayers, drills, air seeding and tillage are all up double-digits. Of note, sprayer production is almost full, even with additional capacity available this year. Our 2013 outlook is supported by this promising early order activity. Lets focus now on construction and forestry on slide 13. Net sales were up 7% in the quarter. Operating profit was $120 million, an increase of 38%. For the quarter, C&F incremental margin was about 31%, a noticeable improvement over the 8% incremental margin realized in the fourth quarter of 2011. Price realization and higher shipment volumes contributed to the results. On slide 14, looking at the economic indicators on the bottom part of the slide, keep in mind, these Global Insight projections assume a rational resolution to the so-called fiscal cliff and expiration of the payroll tax cuts. Even as the housing sector slowly recovers and consumer confidence is up, overall economic growth continues at a slow pace. Deeres C&F business continues to benefit from sales to independent rental companies and the energy and material handling sectors. As well, Deere dealers continue to see strength in the rental and used-equipment markets. Fiscal 2013 net sales in construction and forestry are forecast to be up about 8%. Global forestry markets are expected to be flat in 2013 as weakness in Europe is being offset by improvement in the United States. C&F full-year operating margin is projected to be about 8%, a slight improvement over 2012. Investments in growth are the largest factor underlying C&F operating margin. The two new factories going up in Brazil, and another in China, add additional research and development costs and selling, administrative and general expenses. We expect such growth-related expenses and costs, with little to no revenue from the new factories, to run through 2013 and well into 2014. These factories position us well for the future as Brazil is one of the worlds fastest-growing construction equipment markets and China is an important market long-term. While construction and forestrys full-year 2013 outlook is stronger than 2012, its first quarter will be against a very tough compare. Recall, in the first quarter of 2012, the division had extremely high production volumes of high-horsepower machines prior to the transition to Interim Tier 4 engines. In the first quarter of 2013, shipments will shift to more purchased products, like excavators and commercial worksite machines, so not only will mix shift away from the higher-horsepower machines, keep in mind that purchased products have no impact on absorption. Higher product costs associated with Interim Tier 4 will have an impact in the quarter, as well as the global growth expenses discussed earlier. Nonetheless, the full-year outlook is good. Lets move now to our financial services operations. Slide 15 shows the financial services provision for credit losses as a percent of the total average-owned portfolio at 31 October, 2012 was essentially zero. This reflects the excellent quality of our portfolios, as well as some allowance reductions in the U.S. construction and forestry and Brazil ag portfolios, reflecting improved market conditions. Our 2013 financial forecast contemplates the loss provision returning to a more typical level of about 26 basis points as a percentage of the average-owned portfolio. Keep in mind, the 10-year average is about 34 basis points. Moving to slide 16, worldwide financial services net income attributable to Deere & Company was $122 million in the fourth quarter, which is about flat with the previous year. Before moving to receivables and inventory, lets touch on two items in financial services quarterly results that may warrant further explanation. One is the higher reserves for crop insurance claims. In the fourth quarter of 2011, we accrued an underwriting gain on our crop insurance premium. The opposite happened in the fourth quarter of 2012, we accrued an underwriting loss. $25 million was the amount recognized in fiscal year 2012 for the drought, the majority of which was recorded in the third quarter. The second item is the higher provision for credit losses. In the fourth quarter of 2011, reductions were taken on the allowance for doubtful receivables, whereas there were no similar reductions made in the fourth quarter of 2012. It is important to note as we discussed on slide 15, the provision as a percent of the total average-owned portfolio was essentially zero in the fourth quarter of 2012, reflecting the excellent quality of our portfolios. Looking ahead, we are projecting worldwide financial services net income attributable to Deere & Company of about $500 million in 2013. Slide 17 outlines receivables and inventory. For the company as a whole, receivables and inventory ended the year up about $1.3 billion. This was in line with our forecast and provides further evidence that our third quarter execution issues have been resolved. We expect to end 2013 with ag and turf receivables and inventory nearly flat with 2012 levels. C&F will be up about $175 million due to expected further recovery in the sector. Before moving on, it is important to note that in fiscal 2012, over 5,000 new employees joined the John Deere team. These additions are necessary to support our growth, both domestically and internationally, and will impact cost of sales, R&D and SA&G in 2013. Since almost two-thirds of the new employees came aboard in the last three quarters of 2012, there will be a noticeable increase in expense in the first half of the year, especially in the first quarter. As we head into the new fiscal year, we will begin providing guidance on the cost of sales as a percent of net sales as shown on slide 18. Cost of sales may be impacted by price realization, production or manufacturing costs, raw material costs, engine emission product costs, absorption and the effects of foreign currency exchange, cost of sales is expected to be approximately 74% of net sales in 2013. For modeling purposes, keep in mind, price realization: we are forecasting about three points in 2013; Interim Tier 4 product costs that weve talked about the last two years; on slide 17, we talked about 2013 receivables and inventory expected to be up about $200 million, a far lower increase than we had in 2012, which affects absorption; and the impact on cost of sales from the new employees discussed earlier. Looking at R&D expense on slide 19, R&D was up about 16% in the fourth quarter and up about 17% for the full year compared to the same periods last year. In August, we provided full year 2012 R&D guidance of up about 15%. Due to the extremely short timeframe between full implementation of Interim Tier 4 and the regulatory dates for Final Tier 4, spending has been accelerated in many product areas. Our 2013 forecast calls for R&D expense to be up about 3%. Moving now to slide 20, SA&G expense for the equipment operations was up about 9% in the fourth quarter and up about 7% for the full year. SA&G expense is forecast to be up about 7% in 2013. The equipment operations tax rate was about 38% in the fourth quarter and 35% for the full year, as you can see on slide 21. The quarterly rate was impacted by updated Accounting Standards Codification 740 reserves, a lower Section 199 deduction and the goodwill impairment charge for water. For full year 2013, the effective tax rate is forecast to be in the range of 34% to 36%. On slide 22, you see our equipment operations history of strong cash flow. We are forecasting cash flow from equipment operations to be about $3.4 billion in 2013. Slide 23 outlines our use of cash priorities, which is unchanged and no doubt familiar to many of you. Our number one priority is to manage the balance sheet, including liquidity, to support a rating that provides access to low-cost and readily available short- and long-term funding, plus Deere is strongly committed to its A rating. You may have noticed we had about $6 billion in enterprise cash and marketable securities on the balance sheet at 31 October. With all the uncertainty in the global economy, coupled with our normal heavy first quarter seasonal needs, we felt it prudent to pre-fund our first quarter requirements. Long-term, we do not plan to continue this level of pre-funding. Our second use of cash priority is funding value-creating investments in our operations, such as the two new construction facilities in Brazil referenced earlier. A third priority is to provide for the common stock dividend which we have raised 64% since 2010. Over time, we want to consistently deliver a series of moderately increased dividends while targeting a 25% to 35% payout ratio on average. In this regard, we are mindful of the importance of maintaining the dividend and thus not growing it beyond the point that can be comfortably sustained by our cash flow. Share repurchase is our method of deploying excess cash once the previous requirements are met and as long as such repurchase is value-enhancing. From 2004 through 2012, we have returned 60% of cash from operations to shareholders through dividends and share repurchases. On slide 24, we outline our 2013 outlook for the full year and the first quarter. Our net sales forecast for the full year is up about 5% compared to 2012. This includes about three points of price realization. Our full-year 2013 net income forecast is about $3.2 billion. The first quarter forecast calls for net sales to be up about 10% compared with the first quarter of 2012. Price realization in the quarter is expected to be positive by about four points with unfavorable currency translation of approximately one point. In closing, John Deere enters 2013 on a strong pace. Were looking for a continuation of this performance in the year ahead, thanks in large part to strength in the global farm sector. At the same time, the company is capitalizing on the positive long-term macroeconomic trends by pursuing new markets, adding productive new models of equipment and extending its competitive position throughout the world. John Deeres plans for helping meet the worlds growing need for food, shelter and infrastructure are well on track and achieving a good deal of success; all of which supports our confidence about the future and our ability to serve customers and investors over the long-term. Tony?

### Q&A
**CTO**
: Thank you, Susan. Were now ready to begin the Q&A portion of the call. The operator will instruct you on the polling procedure. But as a reminder, in consideration of others, please limit yourself to one question and one related follow up. If you have additional questions, we ask that you rejoin the queue. Operator?

**Operator**
: Thank you. We will now begin the question-and-answer session. (Operator Instructions) Our first question or comment comes from Andy Kaplowitz. Your line is open. And please state your company name.

**Andy Kaplowitz – Barclays**
: Good morning, guys. Barclays.

**Other-1**
: Good morning.

**CTO**
: Hi, Andy.

**Andy Kaplowitz – Barclays**
: Could you guys talk a little bit more about the U.S. ag market  the outlook for 2013? How are tractors doing so far? I know you dont have an early order program but how are they doing, maybe some lead-times? And then I think we understand the livestock market is relatively weak, but if youve gotten things like sprayers basically sold out and youve got combines pretty strong, is there potential upside to a flat market, again assuming its a strong market to begin with?

**CTO**
: Yeah, Andy. This is Tony. And I would say that on the tractor question, our order book, as you point out, we dont have an early order program but the order book for U.S. and Canada is roughly the same type of availability as last year; but keep in mind that is with higher capacity so as you look at 8R Tractors for example, availability is out to April 2013 timeframe; again similar to last year. And then the 9RT Track Tractors would be May of 2013.

**Andy Kaplowitz – Barclays**
: So it looks pretty good. Tony, maybe I could shift gears and ask you about  so youve decided to do new guidance in cost of sales, and Im sure you guys anticipate that we would ask you about  to break that down a little bit if you could or at least help us think about material costs and emission cost in 2013, how should we think about it, and how did it end up in 4Q?

**CTO**
: Sure. And as we move forward in the past, as you know, weve given specific numeric guidance. We can certainly help kind of directionally, but as we look at those costs, Susan cited really the three highest increases, emissions costs would be the greatest increase. Absorption also is impacting the year as you see a lower build in inventories and receivable. And then the various overhead spend including the portion of that employee cost, our employee adds that impact cost of sales. So those are the three main drivers in the year.

**Andy Kaplowitz – Barclays**
: But at least material costs should be pretty benign at least in the forecast for 2013?

**CTO**
: It was not significant enough to bear mentioning, so.

**Andy Kaplowitz – Barclays**
: Got you. Okay, Ill get back in queue. Thank you.

**CTO**
: Thank you.

**Operator**
: Thank you. Our next question or comment comes from Jamie Cook. And please state your company name.

**Andrew Buscaglia – Credit Suisse**
: Hi. This is actually Andrew Buscaglia on behalf of Jamie Cook. Thanks for taking my question.

**CTO**
: Good Morning.

**Andrew Buscaglia – Credit Suisse**
: So if you were to add back the $33 million goodwill charge to ag, incrementals still seem a little light at 9% or so. Can you just talk through some of the factors driving incrementals in the quarter and then how they stood relative to your expectations?

**CTO**
: Sure.

**CFO**
: Andrew, now there are two items  this is Raj  there are two items that in particular you need to make note of. One is the goodwill charge, that was about $33 million for water pre-tax and $31 million after-tax, and if you include that plus the effective tax rate increases, it was almost a $70 million impact on net income that was one-time. Okay? So you got to look at both sides. And these two alone, on a one-time basis, impacted the net income by $70 million. So if you add that back to the net income, now it wouldve been higher than the guidance we provided and higher than the First Call consensus estimates.

**CTO**
: And then if you look at ag specifically, certainly the goodwill charge wouldve impacted those margins but, the press release talked about increased production costs, things like Interim Tier 4 costs, manufacturing overheads as well as some profit shares that hit cost of sales different year-over-year. Interim Tier 4 cost alone in the quarter was about $105 million so a little over $100 million, and then SG&A and R&D both were up pretty considerably in the quarter.

**Andrew Buscaglia – Credit Suisse**
: Okay. And, then on those Interim Tier 4 costs, can you just talk about your expectations on spend for Tier 4 in 2013?

**CTO**
: Yeah, again, as we talked about before and coming in line really with what our expectations are, certainly not going to see a year-over-year increase like we saw in 2012 but its not an insignificant number. As you look out into 2013, you have products that converted throughout the year. So, you had a partial year of cost increase for 2012 and youll see a full-year increase in 2013. So, they will be up and it is the number one driver of cost increase in our cost of sales. Okay, thank you.

**Andrew Buscaglia – Credit Suisse**
: Okay. Thanks, guys.

**CTO**
: Lets go to the next caller.

**Operator**
: Thank you. Our next question is from Rob Wertheimer. And, please state your company name.

**Rob Wertheimer – Vertical Research**
: Its Vertical Research. And, good morning, everybody.

**CTO**
: Good morning.

**Rob Wertheimer – Vertical Research**
: Two quick ones if I can; the early order season looks like its going great. Deere customers seem to have concerns about soil moisture  weather is hard to predict for next year  but where were going into this year or is that a concern thats fading and its just a regular weather uncertainty?

**CTO**
: Sure.

**Other-2**
: It is something that Deere is watching in the U.S. certainly, but its way too early to make any predictions at this stage of the game. But, it is something that were watching. Has it affected initial sales? Certainly not from the commentary on the early order programs on  ranging from combines to sprayers and even frankly what youre seeing with the tractor activity.

**Rob Wertheimer – Vertical Research**
: Yes, seems like youre not overly concerned. I dont know if youre willing to answer this one but can you tell us where underlying construction margins, maybe you could do it just for the U.S., or extra growth investments are trending? Obviously, youre investing a lot; youve gained share, I think, in construction. I think the business is doing well but its not showing up the margins and I just dont know how big a drag that is on the growth side.

**Other-2**
: Im unable to quantify it for you or just maybe unwilling, but suffice it to say that you have seen the construction equipment division performing very well prior certainly to the recession and we have  we are delivering that kind of performance. But, there is no question that we are impacted in this division by pretty  for them, pretty significant investments, not only in growth, in Brazil and were talking about China, but also frankly in some IT4 expenses. Now, I should be starting to say Final Tier 4 expenses. Again, the time  the lag time between the implementation of IT4 and Final Tier 4 is very compressed.

**Rob Wertheimer – Vertical Research**
: Okay, Ill stop. Thank you very much.

**CTO**
: Thank you.

**Other-1**
: Thank you, Rob.

**Operator**
: Our next question is from Jerry Revich. And, please state your company name.

**Jerry Revich – Goldman Sachs**
: Hi. Its Goldman Sachs. Good morning and happy Thanksgiving.

**CTO**
: Thanks, Jerry. Happy Thanksgiving.

**Jerry Revich – Goldman Sachs**
: Youve had strong retail sales for tractors in Europe over the past couple of months. Can you talk about if thats driven by your regional mix or new product lineup and whether you expect the tailwinds for Deere versus the industry to continue as you look into the early part of 2013?

**Other-2**
: There are a number of factors at play in Europe, including the very significant product line expansions that you saw when you were in Lisbon a year and a half ago. Weve also made strides in strengthening our distribution capabilities in the market and we think thats starting to pay some nice dividends.

**Jerry Revich – Goldman Sachs**
: Okay, thanks. And, just to circle up on the Interim Tier 4 discussion, Tony, whats the magnitude of increase in 2013 versus 2012, if you could quantify that for us? Its nice to hear that the combine production issues have been addressed, but certainly your guidance is looking for 4% net income growth on 5% sales growth, and Im just wondering if you could just flesh out for us the Interim Tier 4 headwinds and the overhead head count headwinds that Susan alluded to in her remarks.

**Other-2**
: This is Marie. Ill just say its over $200-million impact on the IT4 for the cost.

**CFO**
: I think this is a question thatll come up often so let me address the cost of sales items.

**Other-2**
: Yes.

**CFO**
: So, if you look at the  item-by-item, let me provide some qualitative view for each one of these. Price realization, of course, impacts the cost of sales as a percent of net sales; thats up 3%. Its already set. Volume is going to be up for 2013 about 2 points. Manufacturing inefficiencies in 2012 that we had, you should not see in 2013. Now, material we said is not significant either way. In terms of IT4 material, its like Marie just said; its not as high as last year. I would say its about 60% of what we had last year. Depreciation is going to be higher and overhead expenses, as you can imagine, the 5,000 additional people and thats going to impact cost of sales, SG&A, and also R&D. So, to that extent thats going to be higher as well.

**Jerry Revich – Goldman Sachs**
: Thank you very much.

**CTO**
: Thank you.

**Operator**
: Thank you. Our next question is from Ann Duignan. Please state your company name.

**Ann Duignan – JP Morgan**
: Hi. Good morning, guys. JP Morgan.

**Other-2**
: Good morning.

**Ann Duignan – JP Morgan**
: Hi. Can you talk a little bit about  what Im worrying about here is price increases of 3%, is that enough to more than offset the higher cost of Tier 4? Or, are we looking at structurally lower margins going forward? The margin this quarter in ag and turf should have been higher in our view given the number of combines you were intending to ship out. So, Im just trying to get a sense of whats cyclical and if theres anything secular.

**CTO**
: Sure. If you look at where we ended the year, pretty much in line with what we were saying from a price perspective. For the ag and turf division, we had  we were about 90% of the Interim Tier 4 costs were covered  or recovered through 2012. C&F, as expected again, a little lower than that, about 75%. So, certainly with the price realization, were looking at next year would expect to get much further along the line on that.

**Ann Duignan – JP Morgan**
: What does that mean, Tony, much further...?

**CTO**
: Well, if you look....

**Ann Duignan – JP Morgan**
: It doesnt sound like youre going to get to 100%.

**CTO**
: If you look at the 3%  I dont know exactly at 100%. Certainly, ag and turf is already at 90%. So, I think its fair to assume youre going to get to the 100% there. And, were looking at these on a product-by-product basis. So, as weve talked about with the smaller ag equipment, its harder to recover that cost; its a higher percent of the cost of the equipment on a product that is more price sensitive. So  versus large Ag which is where construction has similar challenges as well. So, certainly, if you look at the 3% price realization versus the cost increase in just the year, it more than covered.

**CFO**
: Hey, Ann, this is Raj. Now, you do  you did, Im assuming, notice that the operating margins go up in 2013 compared to 2012. Now, the other thing, if you look at the incremental margins, of course they are better in 2013 compared to 2012; its improving. And, if you were to calculate the net income incrementals that would be about 6.6% for 2012, goes up about 2 points  roughly 2 points for 2013. So, the margins are actually getting better from 2012 to 2013.

**Ann Duignan – JP Morgan**
: Okay. Thats helpful color. And, then just circling back, if we look at SG&A up 7% this year, up another 7% next year thats, what, three times the rate of inflation. Are you using any kind of marketing or financing programs out there to support sales?

**Other-2**
: So, Ann, let me just maybe set the table here and go back to net sales as a  and the change in net sales versus the change in our SG&A because I think that might help calibrate things. In 2010  Im going to go back three years  our net sales were up 14%, SG&A was up 10%. In 2011, we were up 25% for net sales, SG&A only up 12%. Net sales in 2012, as you know we just reported, up 14%, SG&A up 7%. So, there is a little bit of catch-up, if you will, from some spend required to support the infrastructure, if you will, of these higher sales in the form primarily of people. So, we think that while we are very mindful of our expenses, and I can assure you as a member of the CFO staff were very mindful of our expenses, we are actually exhibiting good control relative to the types of growth that we have not only delivered, but what we have envisioned for the future.

**CFO**
: And, if I can add to what Marie said, Ann; now the 2012 versus 2011, 14% to 7% that Marie mentioned, if you look at the quarter four, okay, quarter four of 2011 our SG&A was about $769 million, okay? Thats a 9.5% increase above the quarter four 2012 so thats fine. Now, if you look at the guidance we had going into July  August guidance going into the fourth quarter, we actually did better than the guidance we provided to you at that point. So, I think the guidance we provided was about $880 million, and our quarter four actual SG&A was $842 million.

**CTO**
: And, Ann, this is Tony. The other thing I would add there is I think your question focused in on potential incentive programs in the market. And, if you look at our price realization both in 2012 and again in 2013 with 4 points and then another 3 points that would be pretty hard to do with incentive programs in the market.

**Ann Duignan – JP Morgan**
: So, your incentive programs, if they were financing, would show up in pricing or would they show up in SG&A?

**CTO**
: They would show up in the pricing, yes, so  okay? Thank you.

**Ann Duignan – JP Morgan**
: Okay. Thank you.

**CTO**
: Thank you.

**Operator**
: Thank you. Our next question or comment is from Ashish Gupta. And, please state your company name.

**Ashish Gupta – CLSA**
: Hi. Good morning. CLSA.

**CTO**
: Good morning.

**Other-2**
: Good morning.

**Ashish Gupta – CLSA**
: Good morning. Can you quantify the impact on operating profit from the combine issues? And, I think you had had an issue in the first quarter, third quarter, and then fourth quarter as well.

**CTO**
: We talked about in the third quarter some costs from the execution issues and that was part of the spend increase that we spoke to last quarter but I think maybe what youre getting at is, certainly from a shipping pattern perspective, we had some impact from the combines, much lower shipments than normal in the first part of the year, especially in the first quarter, and then picking up in the back half of the year. And, again, of course thats impacted because of the IT4 transition.

**Other-2**
: That was on plan. It was the third quarter that wasnt.

**Ashish Gupta – CLSA**
: Okay.

**CFO**
: And, there was really no impact from any manufacturing inefficiency issues for combines in Q4, okay?

**Ashish Gupta – CLSA**
: Okay.

**CFO**
: So, all of that was in Q3 and we said that will be behind us and it is behind us.

**Ashish Gupta – CLSA**
: Great. And, then I know you mentioned that your lead times for tractors are looking similar to last year but with the added capacity. I was just wondering could you remind us the year-over-year increases in capacity for the products like sprayers and tractors where youve added on.

**CTO**
: Well, keep in mind, its hard to  we certainly have talked about within Waterloo the expand of capacity but as you know thats a facility thats really for global production on the 7000, 8000, and 9000 series tractors. So, its hard to distinguish how much of that capacity is specifically related to the U.S. and Canada production. So  we talked about in the past for Waterloo specifically, by the end of 2012, we would add 15% capacity there. And, then again we made another announcement in March of last year for an additional 10% capacity that is coming here  coming through 2013 so  or will be in place in  I think mid-2013 is what we had indicated that capacity would be in place. So, again, I wouldnt take that to mean that youve got a full 10% capacity increase in Waterloo tractors for the U.S. and Canada market but we do, in fact, in 2012 have higher capacity for that market. Okay?

**Ashish Gupta – CLSA**
: Fair enough. Thanks a lot.

**CTO**
: Okay, thank you.

**Operator**
: Thank you. Our next question or comment comes from Steve Volkmann. Your line is open. And, please state your company name.

**Steve Volkmann – Jefferies**
: Hi. Good morning, everybody. Its Jefferies.

**Other-2**
: Good morning.

**CFO**
: Good morning.

**Steve Volkmann – Jefferies**
: My question is about the comment that Susan made on wanting to pre-fund the first quarter and having extra cash on the balance sheet and maybe not needing to do that going forward. So, Im trying to figure out what would be a more normal level of cash. And, Ill ask my related follow-up which is, have you changed your view of what dividends should be given potential changes in taxation? And, also you talk about mid-cycle earnings which raises the question  I think in the past youve said things about where you think we are versus mid-cycle in your various businesses. So, maybe you can help us with that too.

**Other-2**
: Wow! Okay, first of all, we would view with our global growth the operating cash requirements that you would see at  typically at a yearend would be somewhere in the $4 billion to $5 billion range and that really reflects the changing nature of the business and thats basically where we are today. So, weve got about $1 billion to $1.5 billion extra in pre-funding. Depending on how market conditions play out, as we move through the end of the year and we see hopefully a very successful resolution to this fiscal cliff, we wont feel it necessary to have that level of pre-funding. So that, I think, takes care of your first question.

**Steve Volkmann – Jefferies**
: Thank you.

**Other-2**
: Regarding the dividend, the dividend really is the purview of the Board, and so I will not be able to make a comment on the dividend. And, your third question would  we are not providing a prescriptive or point-blank number on where we are. Its fair to say that the ag markets in the U.S. are very strong, not as strong in markets outside, and construction is still in, Ill say, a recovery mode, although theyre getting closer to a more typical cycle. So, three questions for you, Steve.

**Steve Volkmann – Jefferies**
: But, I asked them quickly. Thank you very much.

**Other-2**
: Thank you very much.

**Operator**
: Thank you. Our next question is from David Raso. And, please state your company name.

**David Raso – ISI**
: ISI. Im just making sure I understand the moving parts on the margin guidance for next year. Can you clarify the IT4 cost? Somebody mentioned up $200 million, then another mention was but thats only 60% of the cost we had in 2012. Is that the right way to look at it? Its basically the rough numbers would be it was $300 million or so in 2012 but its only $200 million in 2013 so its a $100-million benefit year-over-year?

**CTO**
: No. Keep in mind, when we talk about incremental cost, in 2012 the total costs were about $485 million higher year-over-year, okay? When we talk about the impact on cost of sales being up again in 2014 thats in addition to the $485 million so its additive. So if you look back further, 2011 was $155 million, we had another $485 million last year, and then were adding on top of that yet again this year.

**David Raso – ISI**
: Okay. So, to frame the positives and negatives for year-over-year margin in ag, this will be the question, right? The idea is youre implying incremental margins next year of 28% for ag and turf. And, if you adjust for some of the goodwill in this quarter, call it 25%, 26%, so its still a pretty healthy number. But, your costs are up for Interim Tier 4, but the price for ag alone, you said 3% for the whole company. Is ag and turf a little bit beyond that? Youre saying its a little higher, 3.5%....

**CTO**
: We dont guide on specific divisions. Certainly, both divisions are contributing.

**David Raso – ISI**
: Okay. So, if we just put the positives and negatives, right, the negatives are higher costs, the positive is you get more price. The overhead absorption, receivables and inventories went up over $1 billion for ag and turf in 2012. This next year, its obviously a lot more modest, barely up at all. So, a negative would be the overhead absorption?

**CTO**
: Correct.

**David Raso – ISI**
: You have some costs as well with the employees. But, for the mix  and we can debate if the sales guidance is conservative now off the order book, but Im just trying to take it at face value. The mix, the U.S. comments have been relatively positive. South America, I would argue, is a decent margin geography for you in ag when it comes to margins. Would you describe the mix from the order book, the geography, however you want to look at it, is the mix going into 2013 for ag and turf, would you view that as positive for margins?

**Other-2**
: When we talk  when we think about that ourselves, we tend to look at products not geographies, and you have products in some geographies that have very attractive yields and some that dont. And so, its really more product centric. With that, Tony didnt mention it as one of the driving factors so, David, we dont have a comment on that.

**David Raso – ISI**
: Okay. All right, I appreciate it. Thank you.

**Other-2**
: Thank you.

**CTO**
: Thank you.

**Operator**
: Our next question comes from Seth Weber. And, please state your company name.

**Adam Nielsen – RBC Capital**
: Hi. Its Adam Nielsen, on for Seth. How are you? Thanks.

**CTO**
: Good. How are you?

**Adam Nielsen – RBC Capital**
: Good, thanks. Im just wondering if you could speak a bit about the competitive environment in Brazil. It looks like you pick up some share in tractors since  into the fall. So, are you able to hold pricing pretty stable there in defense of margins? Or, is it getting a little more competitive?

**CTO**
: Yeah. Certainly, again as you look at our price realization for the year, I think thats indicative of our ability to hold that price so.

**Adam Nielsen – RBC Capital**
: Okay. And, then on the  along similar lines....

**CTO**
: Keep in mind on those tractors  on large tractors, most of those  those are ordered well in advance of when were actually shipping and retailing those. So thats also impacting it.

**Other-2**
: And for the sake of those who may not be as familiar with our Brazilian operations, we have made significant investments down there in factory, capacity. We have had a very significant broadening of our tractor line but frankly of many product lines. Two years ago, approximately we launched 50 new products, many of which were in categories that we were not yet competing. We also have a very good dealer organization. Weve been growing their presence and their footprint in Brazil as well and were benefiting from that.

**CFO**
: This is Raj. So, overall, our tractor portfolio in Brazil has been strengthening, our dealer channel has been strengthening, and our price realization has been good, okay? So, its a positive story for us so far, okay?

**Adam Nielsen – RBC Capital**
: Great. And, along those same lines, the cost drag next year  in 2013 relative to this year, can you frame that for us? I know China will be a little later but can you frame those for the new capacity adds?

**Other-2**
: In terms of  no. Actually, the  it would be implied or included in the kinds of guidance that weve already provided. But, were not going to be able to comment specifically on the factory. Thank you.

**Adam Nielsen – RBC Capital**
: Okay. Thanks.

**CTO**
: Next caller.

**Operator**
: Thank you. Our next question is from Robert McCarthy. And, please state your company name.

**Rob McCarthy – Robert W. Baird**
: Its Robert W. Baird. Good morning, everybody.

**Other-2**
: Good morning.

**CTO**
: Good morning.

**CFO**
: Good morning.

**Rob McCarthy – Robert W. Baird**
: Can I first just get a definitional clarification? Youre talking about fiscal 2013 COGS being 74% of what exactly? Is it net sales for the equipment operations or net sales and revenue for the equipment operations?

**CTO**
: Net sales of the equipment operations.

**Rob McCarthy – Robert W. Baird**
: Net sales of the equipment operations, okay.

**CTO**
: Yeah, so.

**Rob McCarthy – Robert W. Baird**
: So, excluding finance and interest income and other income that are reported....

**CTO**
: Right. Yeah, as typical when we are providing our guidance, it would be on the equipment operations with financial services on the equity basis.

**Rob McCarthy – Robert W. Baird**
: I just wanted to make absolutely sure.

**CTO**
: Absolutely.

**Rob McCarthy – Robert W. Baird**
: And, in the release of course there are comments about strength in  or expected continued strength in large equipment in the U.S. and Canadian market offsetting pressure on U.S. and livestock and dairy sectors. That does imply improved mix in the U.S. and Canada, doesnt it?

**Other-2**
: Again, I think weve got a number of factors at play. If mix was a significant factor up or down, we would have cited it when we were going through the factors to think about for next year.

**Rob McCarthy – Robert W. Baird**
: Okay. So, its an immaterial consideration, okay. So, the other question I had was Mr. Allen was on television a couple of days ago, talking about the uncertain current macro environment and made comments about Deere having specifically slowed or deferred certain investments. How do I think about your  the guidance that youre issuing today for expense levels and CapEx, unchanged full-year CapEx, in light of those comments? Does it suggest that the CapEx budget has some upside if we see a quick resolution to fiscal cliff issues, for example? Can you help us here?

**CFO**
: Yeah. Robert, this is Raj.

**Rob McCarthy – Robert W. Baird**
: Hi.

**CFO**
: Now, our forecast essentially for CapEx and other expenses indicate caution based on the economic uncertainties, okay? Now, we have asked the divisions  we have approved the capital expenditures and expenses but asked our units to delay as much of it as practical into January, okay? Now, the current plans of course reflect our assessment of the probabilities of different economic outcome. And, as the economic scenarios become clearer, we may modify our plans, right? So, we will pull levers and cut down in investments if the scenario worsens, and we may accelerate our plans as prudent if the economic scenario turns positive. So, you should see that as just a pragmatic, sensible approach to both CapEx and expenses.

**Rob McCarthy – Robert W. Baird**
: Yeah, I got it. Okay, thank you very much.

**CTO**
: Thanks, Rob. Okay, next caller.

**Operator**
: And, are you ready for the next question?

**CTO**
: Yes, please.

**Operator**
: Thank you. Our next question comes from Vance Edelson. And, please state your company name.

**Vance Edelson – Morgan Stanley**
: Good morning. Its Morgan Stanley. You mentioned a few months ago that you might need to extend the balance sheet a bit in Europe to facilitate sales given the credit conditions. Any update on that? Would you say thats an upward or downward trend at this point?

**Other-2**
: I think what we were referring to there is that were actually looking at some partnerships with some banks to help us facilitate financing in various markets, and we have or are close to having in some markets some new agreements thatll help us in countries in Europe and in the former Soviet Union where we  or the East Bloc would be better to say where we havent had a presence. But, I dont have anything to publicly announce on this call.

**Vance Edelson – Morgan Stanley**
: Okay. Thats helpful. And, just a quick follow-up on something you recently mentioned. I think you said youre getting closer to recovery mode on the construction side, and overall, youre calling for modest improvement in the U.S. Is that a bit conservative even with the sluggish economic growth that you cite, just given the possibility of bouncing off the bottom now that there actually are some green shoots? Could you elaborate a little on what leads to the forecast for modest improvement?

**CTO**
: On construction and forestry? Again, were really  its a similar story to what we saw last year. Were continuing to see strength in the rental channel, energy related, those sorts of things is whats drive  continuing to drive that modest improvement for that particular division.

**Vance Edelson – Morgan Stanley**
: Yeah, okay. Thank you.

**CTO**
: All right? Okay, thank you. Operator, I think we have time for one more question.

**Operator**
: Thank you. Our next question comes from Eli Lustgarten. And, please state your company name.

**Eli Lustgarten – Longbow Securities**
: Longbow Securities. Good morning, everyone.

**CTO**
: Good morning.

**Other-2**
: Good morning.

**Eli Lustgarten – Longbow Securities**
: Okay. Can I get one clarification? In the back of your release, you have pension and OPEB expenses going up $70 million. You didnt cite it as an expense as it is done. Is that correct? Is it about a $0.02 impact for the higher pension expenses because you didnt get as much in 2012?

**Other-2**
: Well thats funding.

**Eli Lustgarten – Longbow Securities**
: No, it says expense.

**Other-2**
: No, it is expense; sorry.

**CTO**
: Yeah, it is up  it will be up about $70 million; thats on an enterprise basis. Of course, most of that is equipment operations.

**Other-2**
: Right.

**Eli Lustgarten – Longbow Securities**
: And so, there is an impact that should have been  that we would notice in the numbers? Can we...?

**Other-2**
: Thats correct.

**Eli Lustgarten – Longbow Securities**
: And....

**CTO**
: And that would be  Eli, thats about two  roughly, its about two-thirds cost of sales and the rest SA&G.

**Eli Lustgarten – Longbow Securities**
: And, youve showed there  that as a cost. You gave us also the first quarter is going to be up 10%. Can you give us  and the rest of the year very modest based on your forecast. Can you (inaudible)  that 10% gain, is that just normal seasonality, an easy comparison in combines because there is some questions about the depreciation expense benefit expiring at the end of the year? So, whether or not people are trying to actually to get equipment, are you seeing any of that? Alternatively, the insurance checks seem to be coming later and probably not until January and February. So, do you have any of that factored in? Give us some help on how the insurance checks are playing out and the depreciating expense and how it affects the first quarter and the later quarters?

**CTO**
: Yeah. Certainly, I think  as you said in part of that, I think its more of a reflection of last year and the lower sales of combines. Keep in mind, in terms of the....

**Other-2**
: Production.

**CTO**
: The production, right, of combines. But, last year  or in terms of the tax incentive, keep in mind, they have to take possession by that  by the end of the year and with the order books in the position that we have them in, they would have needed to have those ordered well in advance in order to take advantage of any of that tax incentive. The other thing to keep in mind, its 50% this year; in 2011, it was 100%. So, it would really go down to the more traditional. As you look out into 2013, it goes down to the five-year depreciation so 20%. So, its not as large of a step function from 2012 to 2013 as it was from 2011 to 2012.

**Eli Lustgarten – Longbow Securities**
: And, the insurance check impact? Thats probably the most significant one that people worry about because theyre not going to get the checks until January and February, at least according to most....

**CTO**
: Yeah, I think our expectation for credit would be that by the end of the year about 70% of our expected claims will be paid by then.

**CFO**
: By the end of calendar year.

**CTO**
: By the end of calendar year, yeah; sorry.

**Eli Lustgarten – Longbow Securities**
: Yeah, I was more  not so much worried about claims on you, but I was worried  I was asking more on the impact of farmer purchases and timing of it and whether that....

**CTO**
: Well thats  but thats our  checks from our John Deere insurance. Its hard to know what other insurance companies are doing, but if you look at just our business, for our customers 70% of the expected payments will be made by the end of the calendar year.

**Eli Lustgarten – Longbow Securities**
: And, is there  is there any place that you have excess inventory or issues? Particularly in construction equipment, we now see a big widespread inventory liquidation going on because a lot of rental channels are filled (inaudible). Are we seeing any shutdowns or any place where inventories are out of whack in any part of the product line?

**CTO**
: Out in the field inventory, no.

**Other-2**
: For construction, heck, by virtue of the fact that were actually projecting inventories will end next year up a bit, were in very good shape. And, again on our  on the ag side, while theres always little pockets here and there, its pretty de minimis relative to the size of the business.

**Eli Lustgarten – Longbow Securities**
: And, no excess combine used inventories or any issues?

**Other-2**
: Were very comfortable with levels across the board.

**CFO**
: Thanks, Eli.

**CTO**
: Okay. Thanks, Eli. And, with that, we thank you for your participation in the call. As always, well be available the rest of the day to answer any additional questions you may have. Operator?

**Operator**
: That concludes todays conference call. Thank you for your participation. You may disconnect at this time.